import { n as normalizeComponent } from "./index-3c10d39a.js";
import "./element-ui-f852ba61.js";
const loginsso_vue_vue_type_style_index_0_scoped_8cfa164c_lang = "";
const _sfc_main = {
  __name: "loginsso",
  setup(__props) {
    return { __sfc: true };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c;
  _vm._self._setupProxy;
  return _c("div");
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "8cfa164c",
  null,
  null
);
const loginsso = __component__.exports;
export {
  loginsso as default
};
