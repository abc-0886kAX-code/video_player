import { c as commonjsGlobal, k as getDefaultExportFromCjs, j as computed, r as ref$1, w as watch, y as onBeforeUnmount, u as unref } from "./element-ui-f852ba61.js";
import { u as useElementRefs } from "./useElement-8dd44703.js";
import { n as normalizeComponent, u as useRoute, m as mergeObject, i as isNil } from "./index-3c10d39a.js";
var video_min = { exports: {} };
/**
 * @license
 * Video.js 7.21.4 <http://videojs.com/>
 * Copyright Brightcove, Inc. <https://www.brightcove.com/>
 * Available under Apache License Version 2.0
 * <https://github.com/videojs/video.js/blob/main/LICENSE>
 *
 * Includes vtt.js <https://github.com/mozilla/vtt.js>
 * Available under Apache License Version 2.0
 * <https://github.com/mozilla/vtt.js/blob/main/LICENSE>
 */
(function(module, exports) {
  !function(e, t) {
    module.exports = t();
  }(commonjsGlobal, function() {
    for (var e, u = "7.21.4", i = {}, a = function(e2, t2) {
      return i[e2] = i[e2] || [], t2 && (i[e2] = i[e2].concat(t2)), i[e2];
    }, n = function(e2, t2) {
      t2 = a(e2).indexOf(t2);
      return !(t2 <= -1) && (i[e2] = i[e2].slice(), i[e2].splice(t2, 1), true);
    }, l = { prefixed: true }, t = [["requestFullscreen", "exitFullscreen", "fullscreenElement", "fullscreenEnabled", "fullscreenchange", "fullscreenerror", "fullscreen"], ["webkitRequestFullscreen", "webkitExitFullscreen", "webkitFullscreenElement", "webkitFullscreenEnabled", "webkitfullscreenchange", "webkitfullscreenerror", "-webkit-full-screen"], ["mozRequestFullScreen", "mozCancelFullScreen", "mozFullScreenElement", "mozFullScreenEnabled", "mozfullscreenchange", "mozfullscreenerror", "-moz-full-screen"], ["msRequestFullscreen", "msExitFullscreen", "msFullscreenElement", "msFullscreenEnabled", "MSFullscreenChange", "MSFullscreenError", "-ms-fullscreen"]], r = t[0], s = 0; s < t.length; s++)
      if (t[s][1] in document) {
        e = t[s];
        break;
      }
    if (e) {
      for (var o = 0; o < e.length; o++)
        l[r[o]] = e[o];
      l.prefixed = e[0] !== r[0];
    }
    var d = [], c = function(a2, s2) {
      return function(e2, t2, i2) {
        var n2, r2 = s2.levels[t2], t2 = new RegExp("^(" + r2 + ")$");
        "log" !== e2 && i2.unshift(e2.toUpperCase() + ":"), i2.unshift(a2 + ":"), d && (d.push([].concat(i2)), n2 = d.length - 1e3, d.splice(0, 0 < n2 ? n2 : 0)), !window.console || (n2 = !(n2 = window.console[e2]) && "debug" === e2 ? window.console.info || window.console.log : n2) && r2 && t2.test(e2) && n2[Array.isArray(i2) ? "apply" : "call"](window.console, i2);
      };
    };
    var h = function t2(i2) {
      function n2() {
        for (var e2 = arguments.length, t3 = new Array(e2), i3 = 0; i3 < e2; i3++)
          t3[i3] = arguments[i3];
        a2("log", r2, t3);
      }
      var r2 = "info", a2 = c(i2, n2);
      return n2.createLogger = function(e2) {
        return t2(i2 + ": " + e2);
      }, n2.levels = { all: "debug|log|warn|error", off: "", debug: "debug|log|warn|error", info: "log|warn|error", warn: "warn|error", error: "error", DEFAULT: r2 }, n2.level = function(e2) {
        if ("string" == typeof e2) {
          if (!n2.levels.hasOwnProperty(e2))
            throw new Error('"' + e2 + '" in not a valid log level');
          r2 = e2;
        }
        return r2;
      }, (n2.history = function() {
        return d ? [].concat(d) : [];
      }).filter = function(t3) {
        return (d || []).filter(function(e2) {
          return new RegExp(".*" + t3 + ".*").test(e2[0]);
        });
      }, n2.history.clear = function() {
        d && (d.length = 0);
      }, n2.history.disable = function() {
        null !== d && (d.length = 0, d = null);
      }, n2.history.enable = function() {
        null === d && (d = []);
      }, n2.error = function() {
        for (var e2 = arguments.length, t3 = new Array(e2), i3 = 0; i3 < e2; i3++)
          t3[i3] = arguments[i3];
        return a2("error", r2, t3);
      }, n2.warn = function() {
        for (var e2 = arguments.length, t3 = new Array(e2), i3 = 0; i3 < e2; i3++)
          t3[i3] = arguments[i3];
        return a2("warn", r2, t3);
      }, n2.debug = function() {
        for (var e2 = arguments.length, t3 = new Array(e2), i3 = 0; i3 < e2; i3++)
          t3[i3] = arguments[i3];
        return a2("debug", r2, t3);
      }, n2;
    }("VIDEOJS"), p = h.createLogger, f = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof commonjsGlobal ? commonjsGlobal : "undefined" != typeof self ? self : {};
    function m(e2, t2) {
      return e2(t2 = { exports: {} }, t2.exports), t2.exports;
    }
    var g = m(function(e2) {
      function t2() {
        return e2.exports = t2 = Object.assign || function(e3) {
          for (var t3 = 1; t3 < arguments.length; t3++) {
            var i2, n2 = arguments[t3];
            for (i2 in n2)
              Object.prototype.hasOwnProperty.call(n2, i2) && (e3[i2] = n2[i2]);
          }
          return e3;
        }, t2.apply(this, arguments);
      }
      e2.exports = t2;
    }), y = Object.prototype.toString, v = function(e2) {
      return T(e2) ? Object.keys(e2) : [];
    };
    function _(t2, i2) {
      v(t2).forEach(function(e2) {
        return i2(t2[e2], e2);
      });
    }
    function b(i2) {
      for (var e2 = arguments.length, t2 = new Array(1 < e2 ? e2 - 1 : 0), n2 = 1; n2 < e2; n2++)
        t2[n2 - 1] = arguments[n2];
      return Object.assign ? g.apply(void 0, [i2].concat(t2)) : (t2.forEach(function(e3) {
        e3 && _(e3, function(e4, t3) {
          i2[t3] = e4;
        });
      }), i2);
    }
    function T(e2) {
      return !!e2 && "object" == typeof e2;
    }
    function w(e2) {
      return T(e2) && "[object Object]" === y.call(e2) && e2.constructor === Object;
    }
    function S(e2, t2) {
      if (!e2 || !t2)
        return "";
      if ("function" != typeof window.getComputedStyle)
        return "";
      var i2;
      try {
        i2 = window.getComputedStyle(e2);
      } catch (e3) {
        return "";
      }
      return i2 ? i2.getPropertyValue(t2) || i2[t2] : "";
    }
    var E = window.navigator && window.navigator.userAgent || "", k = /AppleWebKit\/([\d.]+)/i.exec(E), C = k ? parseFloat(k.pop()) : null, I = /iPod/i.test(E), x = (jt = E.match(/OS (\d+)_/i)) && jt[1] ? jt[1] : null, A = /Android/i.test(E), P = function() {
      var e2 = E.match(/Android (\d+)(?:\.(\d+))?(?:\.(\d+))*/i);
      if (!e2)
        return null;
      var t2 = e2[1] && parseFloat(e2[1]), i2 = e2[2] && parseFloat(e2[2]);
      return t2 && i2 ? parseFloat(e2[1] + "." + e2[2]) : t2 || null;
    }(), L = A && P < 5 && C < 537, O = /Firefox/i.test(E), D = /Edg/i.test(E), R = !D && (/Chrome/i.test(E) || /CriOS/i.test(E)), M = (zt = E.match(/(Chrome|CriOS)\/(\d+)/)) && zt[2] ? parseFloat(zt[2]) : null, N = Xt = !(Xt = (Xt = /MSIE\s(\d+)\.\d/.exec(E)) && parseFloat(Xt[1])) && /Trident\/7.0/i.test(E) && /rv:11.0/.test(E) ? 11 : Xt, U = /Safari/i.test(E) && !R && !A && !D, B = /Windows/i.test(E), F = Boolean(X() && ("ontouchstart" in window || window.navigator.maxTouchPoints || window.DocumentTouch && window.document instanceof window.DocumentTouch)), j = /iPad/i.test(E) || U && F && !/iPhone/i.test(E), H = /iPhone/i.test(E) && !j, V = H || j || I, q = (U || V) && !R, W = Object.freeze({ __proto__: null, IS_IPOD: I, IOS_VERSION: x, IS_ANDROID: A, ANDROID_VERSION: P, IS_NATIVE_ANDROID: L, IS_FIREFOX: O, IS_EDGE: D, IS_CHROME: R, CHROME_VERSION: M, IE_VERSION: N, IS_SAFARI: U, IS_WINDOWS: B, TOUCH_ENABLED: F, IS_IPAD: j, IS_IPHONE: H, IS_IOS: V, IS_ANY_SAFARI: q });
    function G(e2) {
      return "string" == typeof e2 && Boolean(e2.trim());
    }
    function z(e2) {
      if (0 <= e2.indexOf(" "))
        throw new Error("class has illegal whitespace characters");
    }
    function X() {
      return document === window.document;
    }
    function K(e2) {
      return T(e2) && 1 === e2.nodeType;
    }
    function Y() {
      try {
        return window.parent !== window.self;
      } catch (e2) {
        return true;
      }
    }
    function Q(i2) {
      return function(e2, t2) {
        if (!G(e2))
          return document[i2](null);
        t2 = K(t2 = G(t2) ? document.querySelector(t2) : t2) ? t2 : document;
        return t2[i2] && t2[i2](e2);
      };
    }
    function $(e2, i2, t2, n2) {
      void 0 === e2 && (e2 = "div"), void 0 === i2 && (i2 = {}), void 0 === t2 && (t2 = {});
      var r2 = document.createElement(e2);
      return Object.getOwnPropertyNames(i2).forEach(function(e3) {
        var t3 = i2[e3];
        -1 !== e3.indexOf("aria-") || "role" === e3 || "type" === e3 ? (h.warn("Setting attributes in the second argument of createEl()\nhas been deprecated. Use the third argument instead.\ncreateEl(type, properties, attributes). Attempting to set " + e3 + " to " + t3 + "."), r2.setAttribute(e3, t3)) : "textContent" === e3 ? J(r2, t3) : r2[e3] === t3 && "tabIndex" !== e3 || (r2[e3] = t3);
      }), Object.getOwnPropertyNames(t2).forEach(function(e3) {
        r2.setAttribute(e3, t2[e3]);
      }), n2 && ye(r2, n2), r2;
    }
    function J(e2, t2) {
      return "undefined" == typeof e2.textContent ? e2.innerText = t2 : e2.textContent = t2, e2;
    }
    function Z(e2, t2) {
      t2.firstChild ? t2.insertBefore(e2, t2.firstChild) : t2.appendChild(e2);
    }
    function ee(e2, t2) {
      return z(t2), e2.classList ? e2.classList.contains(t2) : new RegExp("(^|\\s)" + t2 + "($|\\s)").test(e2.className);
    }
    function te(e2, t2) {
      return e2.classList ? e2.classList.add(t2) : ee(e2, t2) || (e2.className = (e2.className + " " + t2).trim()), e2;
    }
    function ie(e2, t2) {
      return e2 ? (e2.classList ? e2.classList.remove(t2) : (z(t2), e2.className = e2.className.split(/\s+/).filter(function(e3) {
        return e3 !== t2;
      }).join(" ")), e2) : (h.warn("removeClass was called with an element that doesn't exist"), null);
    }
    function ne(e2, t2, i2) {
      var n2 = ee(e2, t2);
      if ((i2 = "boolean" != typeof (i2 = "function" == typeof i2 ? i2(e2, t2) : i2) ? !n2 : i2) !== n2)
        return (i2 ? te : ie)(e2, t2), e2;
    }
    function re(i2, n2) {
      Object.getOwnPropertyNames(n2).forEach(function(e2) {
        var t2 = n2[e2];
        null === t2 || "undefined" == typeof t2 || false === t2 ? i2.removeAttribute(e2) : i2.setAttribute(e2, true === t2 ? "" : t2);
      });
    }
    function ae(e2) {
      var t2 = {}, i2 = ",autoplay,controls,playsinline,loop,muted,default,defaultMuted,";
      if (e2 && e2.attributes && 0 < e2.attributes.length)
        for (var n2 = e2.attributes, r2 = n2.length - 1; 0 <= r2; r2--) {
          var a2 = n2[r2].name, s2 = n2[r2].value;
          "boolean" != typeof e2[a2] && -1 === i2.indexOf("," + a2 + ",") || (s2 = null !== s2), t2[a2] = s2;
        }
      return t2;
    }
    function se(e2, t2) {
      return e2.getAttribute(t2);
    }
    function oe(e2, t2, i2) {
      e2.setAttribute(t2, i2);
    }
    function ue(e2, t2) {
      e2.removeAttribute(t2);
    }
    function le() {
      document.body.focus(), document.onselectstart = function() {
        return false;
      };
    }
    function de() {
      document.onselectstart = function() {
        return true;
      };
    }
    function ce(e2) {
      if (e2 && e2.getBoundingClientRect && e2.parentNode) {
        var t2 = e2.getBoundingClientRect(), i2 = {};
        return ["bottom", "height", "left", "right", "top", "width"].forEach(function(e3) {
          void 0 !== t2[e3] && (i2[e3] = t2[e3]);
        }), i2.height || (i2.height = parseFloat(S(e2, "height"))), i2.width || (i2.width = parseFloat(S(e2, "width"))), i2;
      }
    }
    function he(e2) {
      if (!e2 || e2 && !e2.offsetParent)
        return { left: 0, top: 0, width: 0, height: 0 };
      for (var t2 = e2.offsetWidth, i2 = e2.offsetHeight, n2 = 0, r2 = 0; e2.offsetParent && e2 !== document[l.fullscreenElement]; )
        n2 += e2.offsetLeft, r2 += e2.offsetTop, e2 = e2.offsetParent;
      return { left: n2, top: r2, width: t2, height: i2 };
    }
    function pe(e2, t2) {
      var i2 = { x: 0, y: 0 };
      if (V)
        for (var n2 = e2; n2 && "html" !== n2.nodeName.toLowerCase(); ) {
          var r2, a2 = S(n2, "transform");
          /^matrix/.test(a2) ? (r2 = a2.slice(7, -1).split(/,\s/).map(Number), i2.x += r2[4], i2.y += r2[5]) : /^matrix3d/.test(a2) && (a2 = a2.slice(9, -1).split(/,\s/).map(Number), i2.x += a2[12], i2.y += a2[13]), n2 = n2.parentNode;
        }
      var s2 = {}, o2 = he(t2.target), u2 = he(e2), l2 = u2.width, d2 = u2.height, e2 = t2.offsetY - (u2.top - o2.top), o2 = t2.offsetX - (u2.left - o2.left);
      return t2.changedTouches && (o2 = t2.changedTouches[0].pageX - u2.left, e2 = t2.changedTouches[0].pageY + u2.top, V && (o2 -= i2.x, e2 -= i2.y)), s2.y = 1 - Math.max(0, Math.min(1, e2 / d2)), s2.x = Math.max(0, Math.min(1, o2 / l2)), s2;
    }
    function fe(e2) {
      return T(e2) && 3 === e2.nodeType;
    }
    function me(e2) {
      for (; e2.firstChild; )
        e2.removeChild(e2.firstChild);
      return e2;
    }
    function ge(e2) {
      return "function" == typeof e2 && (e2 = e2()), (Array.isArray(e2) ? e2 : [e2]).map(function(e3) {
        return K(e3 = "function" == typeof e3 ? e3() : e3) || fe(e3) ? e3 : "string" == typeof e3 && /\S/.test(e3) ? document.createTextNode(e3) : void 0;
      }).filter(function(e3) {
        return e3;
      });
    }
    function ye(t2, e2) {
      return ge(e2).forEach(function(e3) {
        return t2.appendChild(e3);
      }), t2;
    }
    function ve(e2, t2) {
      return ye(me(e2), t2);
    }
    function _e(e2) {
      return void 0 === e2.button && void 0 === e2.buttons || (0 === e2.button && void 0 === e2.buttons || ("mouseup" === e2.type && 0 === e2.button && 0 === e2.buttons || 0 === e2.button && 1 === e2.buttons));
    }
    var be, Te = Q("querySelector"), we = Q("querySelectorAll"), Se = Object.freeze({ __proto__: null, isReal: X, isEl: K, isInFrame: Y, createEl: $, textContent: J, prependTo: Z, hasClass: ee, addClass: te, removeClass: ie, toggleClass: ne, setAttributes: re, getAttributes: ae, getAttribute: se, setAttribute: oe, removeAttribute: ue, blockTextSelection: le, unblockTextSelection: de, getBoundingClientRect: ce, findPosition: he, getPointerPosition: pe, isTextNode: fe, emptyEl: me, normalizeContent: ge, appendContent: ye, insertContent: ve, isSingleLeftClick: _e, $: Te, $$: we }), Ee = false, ke = function() {
      if (false !== be.options.autoSetup) {
        var e2 = Array.prototype.slice.call(document.getElementsByTagName("video")), t2 = Array.prototype.slice.call(document.getElementsByTagName("audio")), i2 = Array.prototype.slice.call(document.getElementsByTagName("video-js")), n2 = e2.concat(t2, i2);
        if (n2 && 0 < n2.length)
          for (var r2 = 0, a2 = n2.length; r2 < a2; r2++) {
            var s2 = n2[r2];
            if (!s2 || !s2.getAttribute) {
              Ce(1);
              break;
            }
            void 0 === s2.player && null !== s2.getAttribute("data-setup") && be(s2);
          }
        else
          Ee || Ce(1);
      }
    };
    function Ce(e2, t2) {
      X() && (t2 && (be = t2), window.setTimeout(ke, e2));
    }
    function Ie() {
      Ee = true, window.removeEventListener("load", Ie);
    }
    X() && ("complete" === document.readyState ? Ie() : window.addEventListener("load", Ie));
    function xe(e2) {
      var t2 = document.createElement("style");
      return t2.className = e2, t2;
    }
    function Ae(e2, t2) {
      e2.styleSheet ? e2.styleSheet.cssText = t2 : e2.textContent = t2;
    }
    var Pe = 3;
    window.WeakMap || (ui = function() {
      function e2() {
        this.vdata = "vdata" + Math.floor(window.performance && window.performance.now() || Date.now()), this.data = {};
      }
      var t2 = e2.prototype;
      return t2.set = function(e3, t3) {
        var i2 = e3[this.vdata] || Pe++;
        return e3[this.vdata] || (e3[this.vdata] = i2), this.data[i2] = t3, this;
      }, t2.get = function(e3) {
        var t3 = e3[this.vdata];
        if (t3)
          return this.data[t3];
        h("We have no data for this element", e3);
      }, t2.has = function(e3) {
        return e3[this.vdata] in this.data;
      }, t2.delete = function(e3) {
        var t3 = e3[this.vdata];
        t3 && (delete this.data[t3], delete e3[this.vdata]);
      }, e2;
    }());
    var Le, Oe = new (window.WeakMap ? WeakMap : ui)();
    function De(e2, t2) {
      var i2;
      Oe.has(e2) && (0 === (i2 = Oe.get(e2)).handlers[t2].length && (delete i2.handlers[t2], e2.removeEventListener ? e2.removeEventListener(t2, i2.dispatcher, false) : e2.detachEvent && e2.detachEvent("on" + t2, i2.dispatcher)), Object.getOwnPropertyNames(i2.handlers).length <= 0 && (delete i2.handlers, delete i2.dispatcher, delete i2.disabled), 0 === Object.getOwnPropertyNames(i2).length && Oe.delete(e2));
    }
    function Re(t2, i2, e2, n2) {
      e2.forEach(function(e3) {
        t2(i2, e3, n2);
      });
    }
    function Me(e2) {
      if (e2.fixed_)
        return e2;
      function t2() {
        return true;
      }
      function i2() {
        return false;
      }
      if (!e2 || !e2.isPropagationStopped || !e2.isImmediatePropagationStopped) {
        var n2, r2, a2, s2 = e2 || window.event;
        for (n2 in e2 = {}, s2)
          "layerX" !== n2 && "layerY" !== n2 && "keyLocation" !== n2 && "webkitMovementX" !== n2 && "webkitMovementY" !== n2 && "path" !== n2 && ("returnValue" === n2 && s2.preventDefault || (e2[n2] = s2[n2]));
        e2.target || (e2.target = e2.srcElement || document), e2.relatedTarget || (e2.relatedTarget = e2.fromElement === e2.target ? e2.toElement : e2.fromElement), e2.preventDefault = function() {
          s2.preventDefault && s2.preventDefault(), e2.returnValue = false, s2.returnValue = false, e2.defaultPrevented = true;
        }, e2.defaultPrevented = false, e2.stopPropagation = function() {
          s2.stopPropagation && s2.stopPropagation(), e2.cancelBubble = true, s2.cancelBubble = true, e2.isPropagationStopped = t2;
        }, e2.isPropagationStopped = i2, e2.stopImmediatePropagation = function() {
          s2.stopImmediatePropagation && s2.stopImmediatePropagation(), e2.isImmediatePropagationStopped = t2, e2.stopPropagation();
        }, e2.isImmediatePropagationStopped = i2, null !== e2.clientX && void 0 !== e2.clientX && (r2 = document.documentElement, a2 = document.body, e2.pageX = e2.clientX + (r2 && r2.scrollLeft || a2 && a2.scrollLeft || 0) - (r2 && r2.clientLeft || a2 && a2.clientLeft || 0), e2.pageY = e2.clientY + (r2 && r2.scrollTop || a2 && a2.scrollTop || 0) - (r2 && r2.clientTop || a2 && a2.clientTop || 0)), e2.which = e2.charCode || e2.keyCode, null !== e2.button && void 0 !== e2.button && (e2.button = 1 & e2.button ? 0 : 4 & e2.button ? 1 : 2 & e2.button ? 2 : 0);
      }
      return e2.fixed_ = true, e2;
    }
    var Ne = function() {
      if ("boolean" != typeof Le) {
        Le = false;
        try {
          var e2 = Object.defineProperty({}, "passive", { get: function() {
            Le = true;
          } });
          window.addEventListener("test", null, e2), window.removeEventListener("test", null, e2);
        } catch (e3) {
        }
      }
      return Le;
    }, Ue = ["touchstart", "touchmove"];
    function Be(s2, e2, t2) {
      if (Array.isArray(e2))
        return Re(Be, s2, e2, t2);
      Oe.has(s2) || Oe.set(s2, {});
      var o2 = Oe.get(s2);
      o2.handlers || (o2.handlers = {}), o2.handlers[e2] || (o2.handlers[e2] = []), t2.guid || (t2.guid = Pe++), o2.handlers[e2].push(t2), o2.dispatcher || (o2.disabled = false, o2.dispatcher = function(e3, t3) {
        if (!o2.disabled) {
          e3 = Me(e3);
          var i2 = o2.handlers[e3.type];
          if (i2)
            for (var n2 = i2.slice(0), r2 = 0, a2 = n2.length; r2 < a2 && !e3.isImmediatePropagationStopped(); r2++)
              try {
                n2[r2].call(s2, e3, t3);
              } catch (e4) {
                h.error(e4);
              }
        }
      }), 1 === o2.handlers[e2].length && (s2.addEventListener ? (t2 = false, Ne() && -1 < Ue.indexOf(e2) && (t2 = { passive: true }), s2.addEventListener(e2, o2.dispatcher, t2)) : s2.attachEvent && s2.attachEvent("on" + e2, o2.dispatcher));
    }
    function Fe(e2, t2, i2) {
      if (Oe.has(e2)) {
        var n2 = Oe.get(e2);
        if (n2.handlers) {
          if (Array.isArray(t2))
            return Re(Fe, e2, t2, i2);
          var r2 = function(e3, t3) {
            n2.handlers[t3] = [], De(e3, t3);
          };
          if (void 0 !== t2) {
            var a2 = n2.handlers[t2];
            if (a2)
              if (i2) {
                if (i2.guid)
                  for (var s2 = 0; s2 < a2.length; s2++)
                    a2[s2].guid === i2.guid && a2.splice(s2--, 1);
                De(e2, t2);
              } else
                r2(e2, t2);
          } else
            for (var o2 in n2.handlers)
              Object.prototype.hasOwnProperty.call(n2.handlers || {}, o2) && r2(e2, o2);
        }
      }
    }
    function je(e2, t2, i2) {
      var n2 = Oe.has(e2) ? Oe.get(e2) : {}, r2 = e2.parentNode || e2.ownerDocument;
      return "string" == typeof t2 ? t2 = { type: t2, target: e2 } : t2.target || (t2.target = e2), t2 = Me(t2), n2.dispatcher && n2.dispatcher.call(e2, t2, i2), r2 && !t2.isPropagationStopped() && true === t2.bubbles ? je.call(null, r2, t2, i2) : !r2 && !t2.defaultPrevented && t2.target && t2.target[t2.type] && (Oe.has(t2.target) || Oe.set(t2.target, {}), r2 = Oe.get(t2.target), t2.target[t2.type] && (r2.disabled = true, "function" == typeof t2.target[t2.type] && t2.target[t2.type](), r2.disabled = false)), !t2.defaultPrevented;
    }
    function He(e2, t2, i2) {
      if (Array.isArray(t2))
        return Re(He, e2, t2, i2);
      function n2() {
        Fe(e2, t2, n2), i2.apply(this, arguments);
      }
      n2.guid = i2.guid = i2.guid || Pe++, Be(e2, t2, n2);
    }
    function Ve(e2, t2, i2) {
      function n2() {
        Fe(e2, t2, n2), i2.apply(this, arguments);
      }
      n2.guid = i2.guid = i2.guid || Pe++, Be(e2, t2, n2);
    }
    function qe(e2, t2, i2) {
      return t2.guid || (t2.guid = Pe++), (e2 = t2.bind(e2)).guid = i2 ? i2 + "_" + t2.guid : t2.guid, e2;
    }
    function We(t2, i2) {
      var n2 = window.performance.now();
      return function() {
        var e2 = window.performance.now();
        i2 <= e2 - n2 && (t2.apply(void 0, arguments), n2 = e2);
      };
    }
    function Ge(n2, r2, a2, s2) {
      var o2;
      function e2() {
        var e3 = this, t2 = arguments, i2 = function() {
          i2 = o2 = null, a2 || n2.apply(e3, t2);
        };
        !o2 && a2 && n2.apply(e3, t2), s2.clearTimeout(o2), o2 = s2.setTimeout(i2, r2);
      }
      return void 0 === s2 && (s2 = window), e2.cancel = function() {
        s2.clearTimeout(o2), o2 = null;
      }, e2;
    }
    function ze() {
    }
    var Xe, Ke = Object.freeze({ __proto__: null, fixEvent: Me, on: Be, off: Fe, trigger: je, one: He, any: Ve });
    ze.prototype.allowedEvents_ = {}, ze.prototype.addEventListener = ze.prototype.on = function(e2, t2) {
      var i2 = this.addEventListener;
      this.addEventListener = function() {
      }, Be(this, e2, t2), this.addEventListener = i2;
    }, ze.prototype.removeEventListener = ze.prototype.off = function(e2, t2) {
      Fe(this, e2, t2);
    }, ze.prototype.one = function(e2, t2) {
      var i2 = this.addEventListener;
      this.addEventListener = function() {
      }, He(this, e2, t2), this.addEventListener = i2;
    }, ze.prototype.any = function(e2, t2) {
      var i2 = this.addEventListener;
      this.addEventListener = function() {
      }, Ve(this, e2, t2), this.addEventListener = i2;
    }, ze.prototype.dispatchEvent = ze.prototype.trigger = function(e2) {
      var t2 = e2.type || e2;
      e2 = Me(e2 = "string" == typeof e2 ? { type: t2 } : e2), this.allowedEvents_[t2] && this["on" + t2] && this["on" + t2](e2), je(this, e2);
    }, ze.prototype.queueTrigger = function(e2) {
      var t2 = this;
      Xe = Xe || /* @__PURE__ */ new Map();
      var i2 = e2.type || e2, n2 = Xe.get(this);
      n2 || (n2 = /* @__PURE__ */ new Map(), Xe.set(this, n2));
      var r2 = n2.get(i2);
      n2.delete(i2), window.clearTimeout(r2);
      r2 = window.setTimeout(function() {
        n2.delete(i2), 0 === n2.size && (n2 = null, Xe.delete(t2)), t2.trigger(e2);
      }, 0);
      n2.set(i2, r2);
    };
    function Ye(e2) {
      return "function" == typeof e2.name ? e2.name() : "string" == typeof e2.name ? e2.name : e2.name_ || (e2.constructor && e2.constructor.name ? e2.constructor.name : typeof e2);
    }
    function Qe(e2) {
      return "string" == typeof e2 && /\S/.test(e2) || Array.isArray(e2) && !!e2.length;
    }
    function $e(e2, t2, i2) {
      if (!e2 || !e2.nodeName && !it(e2))
        throw new Error("Invalid target for " + Ye(t2) + "#" + i2 + "; must be a DOM node or evented object.");
    }
    function Je(e2, t2, i2) {
      if (!Qe(e2))
        throw new Error("Invalid event type for " + Ye(t2) + "#" + i2 + "; must be a non-empty string or array.");
    }
    function Ze(e2, t2, i2) {
      if ("function" != typeof e2)
        throw new Error("Invalid listener for " + Ye(t2) + "#" + i2 + "; must be a function.");
    }
    function et(e2, t2, i2) {
      var n2, r2, a2 = t2.length < 3 || t2[0] === e2 || t2[0] === e2.eventBusEl_, t2 = a2 ? (n2 = e2.eventBusEl_, 3 <= t2.length && t2.shift(), r2 = t2[0], t2[1]) : (n2 = t2[0], r2 = t2[1], t2[2]);
      return $e(n2, e2, i2), Je(r2, e2, i2), Ze(t2, e2, i2), { isTargetingSelf: a2, target: n2, type: r2, listener: t2 = qe(e2, t2) };
    }
    function tt(e2, t2, i2, n2) {
      $e(e2, e2, t2), e2.nodeName ? Ke[t2](e2, i2, n2) : e2[t2](i2, n2);
    }
    var it = function(t2) {
      return t2 instanceof ze || !!t2.eventBusEl_ && ["on", "one", "off", "trigger"].every(function(e2) {
        return "function" == typeof t2[e2];
      });
    }, nt = { on: function() {
      for (var e2 = this, t2 = arguments.length, i2 = new Array(t2), n2 = 0; n2 < t2; n2++)
        i2[n2] = arguments[n2];
      var r2, a2 = et(this, i2, "on"), s2 = a2.isTargetingSelf, o2 = a2.target, u2 = a2.type, l2 = a2.listener;
      tt(o2, "on", u2, l2), s2 || ((r2 = function() {
        return e2.off(o2, u2, l2);
      }).guid = l2.guid, (s2 = function() {
        return e2.off("dispose", r2);
      }).guid = l2.guid, tt(this, "on", "dispose", r2), tt(o2, "on", "dispose", s2));
    }, one: function() {
      for (var r2 = this, e2 = arguments.length, t2 = new Array(e2), i2 = 0; i2 < e2; i2++)
        t2[i2] = arguments[i2];
      var n2 = et(this, t2, "one"), a2 = n2.isTargetingSelf, s2 = n2.target, o2 = n2.type, u2 = n2.listener;
      a2 ? tt(s2, "one", o2, u2) : ((a2 = function e3() {
        r2.off(s2, o2, e3);
        for (var t3 = arguments.length, i3 = new Array(t3), n3 = 0; n3 < t3; n3++)
          i3[n3] = arguments[n3];
        u2.apply(null, i3);
      }).guid = u2.guid, tt(s2, "one", o2, a2));
    }, any: function() {
      for (var r2 = this, e2 = arguments.length, t2 = new Array(e2), i2 = 0; i2 < e2; i2++)
        t2[i2] = arguments[i2];
      var n2 = et(this, t2, "any"), a2 = n2.isTargetingSelf, s2 = n2.target, o2 = n2.type, u2 = n2.listener;
      a2 ? tt(s2, "any", o2, u2) : ((a2 = function e3() {
        r2.off(s2, o2, e3);
        for (var t3 = arguments.length, i3 = new Array(t3), n3 = 0; n3 < t3; n3++)
          i3[n3] = arguments[n3];
        u2.apply(null, i3);
      }).guid = u2.guid, tt(s2, "any", o2, a2));
    }, off: function(e2, t2, i2) {
      !e2 || Qe(e2) ? Fe(this.eventBusEl_, e2, t2) : (t2 = t2, $e(e2 = e2, this, "off"), Je(t2, this, "off"), Ze(i2, this, "off"), i2 = qe(this, i2), this.off("dispose", i2), e2.nodeName ? (Fe(e2, t2, i2), Fe(e2, "dispose", i2)) : it(e2) && (e2.off(t2, i2), e2.off("dispose", i2)));
    }, trigger: function(e2, t2) {
      $e(this.eventBusEl_, this, "trigger");
      var i2 = e2 && "string" != typeof e2 ? e2.type : e2;
      if (!Qe(i2)) {
        i2 = "Invalid event type for " + Ye(this) + "#trigger; must be a non-empty string or object with a type key that has a non-empty value.";
        if (!e2)
          throw new Error(i2);
        (this.log || h).error(i2);
      }
      return je(this.eventBusEl_, e2, t2);
    } };
    function rt(e2, t2) {
      t2 = (t2 = void 0 === t2 ? {} : t2).eventBusKey;
      if (t2) {
        if (!e2[t2].nodeName)
          throw new Error('The eventBusKey "' + t2 + '" does not refer to an element.');
        e2.eventBusEl_ = e2[t2];
      } else
        e2.eventBusEl_ = $("span", { className: "vjs-event-bus" });
      return b(e2, nt), e2.eventedCallbacks && e2.eventedCallbacks.forEach(function(e3) {
        e3();
      }), e2.on("dispose", function() {
        e2.off(), [e2, e2.el_, e2.eventBusEl_].forEach(function(e3) {
          e3 && Oe.has(e3) && Oe.delete(e3);
        }), window.setTimeout(function() {
          e2.eventBusEl_ = null;
        }, 0);
      }), e2;
    }
    var at = { state: {}, setState: function(e2) {
      var i2, n2 = this;
      return _(e2 = "function" == typeof e2 ? e2() : e2, function(e3, t2) {
        n2.state[t2] !== e3 && ((i2 = i2 || {})[t2] = { from: n2.state[t2], to: e3 }), n2.state[t2] = e3;
      }), i2 && it(this) && this.trigger({ changes: i2, type: "statechanged" }), i2;
    } };
    function st(e2, t2) {
      return b(e2, at), e2.state = b({}, e2.state, t2), "function" == typeof e2.handleStateChanged && it(e2) && e2.on("statechanged", e2.handleStateChanged), e2;
    }
    function ot(e2) {
      return "string" != typeof e2 ? e2 : e2.replace(/./, function(e3) {
        return e3.toLowerCase();
      });
    }
    function ut(e2) {
      return "string" != typeof e2 ? e2 : e2.replace(/./, function(e3) {
        return e3.toUpperCase();
      });
    }
    function lt() {
      for (var i2 = {}, e2 = arguments.length, t2 = new Array(e2), n2 = 0; n2 < e2; n2++)
        t2[n2] = arguments[n2];
      return t2.forEach(function(e3) {
        e3 && _(e3, function(e4, t3) {
          w(e4) ? (w(i2[t3]) || (i2[t3] = {}), i2[t3] = lt(i2[t3], e4)) : i2[t3] = e4;
        });
      }), i2;
    }
    var dt = window.Map || function() {
      function e2() {
        this.map_ = {};
      }
      var t2 = e2.prototype;
      return t2.has = function(e3) {
        return e3 in this.map_;
      }, t2.delete = function(e3) {
        var t3 = this.has(e3);
        return delete this.map_[e3], t3;
      }, t2.set = function(e3, t3) {
        return this.map_[e3] = t3, this;
      }, t2.forEach = function(e3, t3) {
        for (var i2 in this.map_)
          e3.call(t3, this.map_[i2], i2, this);
      }, e2;
    }(), ct = window.Set || function() {
      function e2() {
        this.set_ = {};
      }
      var t2 = e2.prototype;
      return t2.has = function(e3) {
        return e3 in this.set_;
      }, t2.delete = function(e3) {
        var t3 = this.has(e3);
        return delete this.set_[e3], t3;
      }, t2.add = function(e3) {
        return this.set_[e3] = 1, this;
      }, t2.forEach = function(e3, t3) {
        for (var i2 in this.set_)
          e3.call(t3, i2, i2, this);
      }, e2;
    }(), ht = m(function(e2, t2) {
      function i2(e3) {
        if (!e3 || "object" != typeof e3 || (t3 = e3.which || e3.keyCode || e3.charCode) && (e3 = t3), "number" == typeof e3)
          return o2[e3];
        var t3 = String(e3), e3 = n2[t3.toLowerCase()];
        return e3 || ((e3 = r2[t3.toLowerCase()]) ? e3 : 1 === t3.length ? t3.charCodeAt(0) : void 0);
      }
      i2.isEventKey = function(e3, t3) {
        if (e3 && "object" == typeof e3) {
          var i3 = e3.which || e3.keyCode || e3.charCode;
          if (null == i3)
            return false;
          if ("string" == typeof t3) {
            e3 = n2[t3.toLowerCase()];
            if (e3)
              return e3 === i3;
            if (e3 = r2[t3.toLowerCase()])
              return e3 === i3;
          } else if ("number" == typeof t3)
            return t3 === i3;
          return false;
        }
      };
      for (var n2 = (t2 = e2.exports = i2).code = t2.codes = { backspace: 8, tab: 9, enter: 13, shift: 16, ctrl: 17, alt: 18, "pause/break": 19, "caps lock": 20, esc: 27, space: 32, "page up": 33, "page down": 34, end: 35, home: 36, left: 37, up: 38, right: 39, down: 40, insert: 45, delete: 46, command: 91, "left command": 91, "right command": 93, "numpad *": 106, "numpad +": 107, "numpad -": 109, "numpad .": 110, "numpad /": 111, "num lock": 144, "scroll lock": 145, "my computer": 182, "my calculator": 183, ";": 186, "=": 187, ",": 188, "-": 189, ".": 190, "/": 191, "`": 192, "[": 219, "\\": 220, "]": 221, "'": 222 }, r2 = t2.aliases = { windows: 91, "\u21E7": 16, "\u2325": 18, "\u2303": 17, "\u2318": 91, ctl: 17, control: 17, option: 18, pause: 19, break: 19, caps: 20, return: 13, escape: 27, spc: 32, spacebar: 32, pgup: 33, pgdn: 34, ins: 45, del: 46, cmd: 91 }, a2 = 97; a2 < 123; a2++)
        n2[String.fromCharCode(a2)] = a2 - 32;
      for (var a2 = 48; a2 < 58; a2++)
        n2[a2 - 48] = a2;
      for (a2 = 1; a2 < 13; a2++)
        n2["f" + a2] = a2 + 111;
      for (a2 = 0; a2 < 10; a2++)
        n2["numpad " + a2] = a2 + 96;
      var s2, o2 = t2.names = t2.title = {};
      for (a2 in n2)
        o2[n2[a2]] = a2;
      for (s2 in r2)
        n2[s2] = r2[s2];
    });
    ht.code, ht.codes, ht.aliases, ht.names, ht.title;
    var pt = function() {
      function s2(e3, t2, i2) {
        var n2 = this;
        !e3 && this.play ? this.player_ = e3 = this : this.player_ = e3, this.isDisposed_ = false, this.parentComponent_ = null, this.options_ = lt({}, this.options_), t2 = this.options_ = lt(this.options_, t2), this.id_ = t2.id || t2.el && t2.el.id, this.id_ || (e3 = e3 && e3.id && e3.id() || "no_player", this.id_ = e3 + "_component_" + Pe++), this.name_ = t2.name || null, t2.el ? this.el_ = t2.el : false !== t2.createEl && (this.el_ = this.createEl()), t2.className && this.el_ && t2.className.split(" ").forEach(function(e4) {
          return n2.addClass(e4);
        }), false !== t2.evented && (rt(this, { eventBusKey: this.el_ ? "el_" : null }), this.handleLanguagechange = this.handleLanguagechange.bind(this), this.on(this.player_, "languagechange", this.handleLanguagechange)), st(this, this.constructor.defaultState), this.children_ = [], this.childIndex_ = {}, this.childNameIndex_ = {}, this.setTimeoutIds_ = new ct(), this.setIntervalIds_ = new ct(), this.rafIds_ = new ct(), this.namedRafs_ = new dt(), (this.clearingTimersOnDispose_ = false) !== t2.initChildren && this.initChildren(), this.ready(i2), false !== t2.reportTouchActivity && this.enableTouchActivity();
      }
      var e2 = s2.prototype;
      return e2.dispose = function(e3) {
        if (void 0 === e3 && (e3 = {}), !this.isDisposed_) {
          if (this.readyQueue_ && (this.readyQueue_.length = 0), this.trigger({ type: "dispose", bubbles: false }), this.isDisposed_ = true, this.children_)
            for (var t2 = this.children_.length - 1; 0 <= t2; t2--)
              this.children_[t2].dispose && this.children_[t2].dispose();
          this.children_ = null, this.childIndex_ = null, this.childNameIndex_ = null, this.parentComponent_ = null, this.el_ && (this.el_.parentNode && (e3.restoreEl ? this.el_.parentNode.replaceChild(e3.restoreEl, this.el_) : this.el_.parentNode.removeChild(this.el_)), this.el_ = null), this.player_ = null;
        }
      }, e2.isDisposed = function() {
        return Boolean(this.isDisposed_);
      }, e2.player = function() {
        return this.player_;
      }, e2.options = function(e3) {
        return e3 && (this.options_ = lt(this.options_, e3)), this.options_;
      }, e2.el = function() {
        return this.el_;
      }, e2.createEl = function(e3, t2, i2) {
        return $(e3, t2, i2);
      }, e2.localize = function(e3, i2, t2) {
        void 0 === t2 && (t2 = e3);
        var n2 = this.player_.language && this.player_.language(), r2 = this.player_.languages && this.player_.languages(), a2 = r2 && r2[n2], n2 = n2 && n2.split("-")[0], n2 = r2 && r2[n2], t2 = t2;
        return a2 && a2[e3] ? t2 = a2[e3] : n2 && n2[e3] && (t2 = n2[e3]), t2 = i2 ? t2.replace(/\{(\d+)\}/g, function(e4, t3) {
          t3 = i2[t3 - 1];
          return "undefined" == typeof t3 ? e4 : t3;
        }) : t2;
      }, e2.handleLanguagechange = function() {
      }, e2.contentEl = function() {
        return this.contentEl_ || this.el_;
      }, e2.id = function() {
        return this.id_;
      }, e2.name = function() {
        return this.name_;
      }, e2.children = function() {
        return this.children_;
      }, e2.getChildById = function(e3) {
        return this.childIndex_[e3];
      }, e2.getChild = function(e3) {
        if (e3)
          return this.childNameIndex_[e3];
      }, e2.getDescendant = function() {
        for (var e3 = arguments.length, t2 = new Array(e3), i2 = 0; i2 < e3; i2++)
          t2[i2] = arguments[i2];
        for (var t2 = t2.reduce(function(e4, t3) {
          return e4.concat(t3);
        }, []), n2 = this, r2 = 0; r2 < t2.length; r2++)
          if (!(n2 = n2.getChild(t2[r2])) || !n2.getChild)
            return;
        return n2;
      }, e2.addChild = function(e3, t2, i2) {
        if (void 0 === t2 && (t2 = {}), void 0 === i2 && (i2 = this.children_.length), "string" == typeof e3) {
          var n2 = ut(e3), r2 = t2.componentClass || n2;
          t2.name = n2;
          var a2 = s2.getComponent(r2);
          if (!a2)
            throw new Error("Component " + r2 + " does not exist");
          if ("function" != typeof a2)
            return null;
          a2 = new a2(this.player_ || this, t2);
        } else
          a2 = e3;
        return a2.parentComponent_ && a2.parentComponent_.removeChild(a2), this.children_.splice(i2, 0, a2), a2.parentComponent_ = this, "function" == typeof a2.id && (this.childIndex_[a2.id()] = a2), (n2 = n2 || a2.name && ut(a2.name())) && (this.childNameIndex_[n2] = a2, this.childNameIndex_[ot(n2)] = a2), "function" == typeof a2.el && a2.el() && (n2 = null, this.children_[i2 + 1] && (this.children_[i2 + 1].el_ ? n2 = this.children_[i2 + 1].el_ : K(this.children_[i2 + 1]) && (n2 = this.children_[i2 + 1])), this.contentEl().insertBefore(a2.el(), n2)), a2;
      }, e2.removeChild = function(e3) {
        if ((e3 = "string" == typeof e3 ? this.getChild(e3) : e3) && this.children_) {
          for (var t2, i2 = false, n2 = this.children_.length - 1; 0 <= n2; n2--)
            if (this.children_[n2] === e3) {
              i2 = true, this.children_.splice(n2, 1);
              break;
            }
          i2 && (e3.parentComponent_ = null, this.childIndex_[e3.id()] = null, this.childNameIndex_[ut(e3.name())] = null, this.childNameIndex_[ot(e3.name())] = null, (t2 = e3.el()) && t2.parentNode === this.contentEl() && this.contentEl().removeChild(e3.el()));
        }
      }, e2.initChildren = function() {
        var i2, t2, e3, n2 = this, r2 = this.options_.children;
        r2 && (i2 = this.options_, t2 = s2.getComponent("Tech"), (e3 = Array.isArray(r2) ? r2 : Object.keys(r2)).concat(Object.keys(this.options_).filter(function(t3) {
          return !e3.some(function(e4) {
            return "string" == typeof e4 ? t3 === e4 : t3 === e4.name;
          });
        })).map(function(e4) {
          var t3, e4 = "string" == typeof e4 ? r2[t3 = e4] || n2.options_[t3] || {} : (t3 = e4.name, e4);
          return { name: t3, opts: e4 };
        }).filter(function(e4) {
          e4 = s2.getComponent(e4.opts.componentClass || ut(e4.name));
          return e4 && !t2.isTech(e4);
        }).forEach(function(e4) {
          var t3 = e4.name, e4 = e4.opts;
          false !== (e4 = void 0 !== i2[t3] ? i2[t3] : e4) && ((e4 = true === e4 ? {} : e4).playerOptions = n2.options_.playerOptions, (e4 = n2.addChild(t3, e4)) && (n2[t3] = e4));
        }));
      }, e2.buildCSSClass = function() {
        return "";
      }, e2.ready = function(e3, t2) {
        if (void 0 === t2 && (t2 = false), e3)
          return this.isReady_ ? void (t2 ? e3.call(this) : this.setTimeout(e3, 1)) : (this.readyQueue_ = this.readyQueue_ || [], void this.readyQueue_.push(e3));
      }, e2.triggerReady = function() {
        this.isReady_ = true, this.setTimeout(function() {
          var e3 = this.readyQueue_;
          this.readyQueue_ = [], e3 && 0 < e3.length && e3.forEach(function(e4) {
            e4.call(this);
          }, this), this.trigger("ready");
        }, 1);
      }, e2.$ = function(e3, t2) {
        return Te(e3, t2 || this.contentEl());
      }, e2.$$ = function(e3, t2) {
        return we(e3, t2 || this.contentEl());
      }, e2.hasClass = function(e3) {
        return ee(this.el_, e3);
      }, e2.addClass = function(e3) {
        te(this.el_, e3);
      }, e2.removeClass = function(e3) {
        ie(this.el_, e3);
      }, e2.toggleClass = function(e3, t2) {
        ne(this.el_, e3, t2);
      }, e2.show = function() {
        this.removeClass("vjs-hidden");
      }, e2.hide = function() {
        this.addClass("vjs-hidden");
      }, e2.lockShowing = function() {
        this.addClass("vjs-lock-showing");
      }, e2.unlockShowing = function() {
        this.removeClass("vjs-lock-showing");
      }, e2.getAttribute = function(e3) {
        return se(this.el_, e3);
      }, e2.setAttribute = function(e3, t2) {
        oe(this.el_, e3, t2);
      }, e2.removeAttribute = function(e3) {
        ue(this.el_, e3);
      }, e2.width = function(e3, t2) {
        return this.dimension("width", e3, t2);
      }, e2.height = function(e3, t2) {
        return this.dimension("height", e3, t2);
      }, e2.dimensions = function(e3, t2) {
        this.width(e3, true), this.height(t2);
      }, e2.dimension = function(e3, t2, i2) {
        if (void 0 !== t2)
          return -1 !== ("" + (t2 = null === t2 || t2 != t2 ? 0 : t2)).indexOf("%") || -1 !== ("" + t2).indexOf("px") ? this.el_.style[e3] = t2 : this.el_.style[e3] = "auto" === t2 ? "" : t2 + "px", void (i2 || this.trigger("componentresize"));
        if (!this.el_)
          return 0;
        t2 = this.el_.style[e3], i2 = t2.indexOf("px");
        return -1 !== i2 ? parseInt(t2.slice(0, i2), 10) : parseInt(this.el_["offset" + ut(e3)], 10);
      }, e2.currentDimension = function(e3) {
        var t2 = 0;
        if ("width" !== e3 && "height" !== e3)
          throw new Error("currentDimension only accepts width or height value");
        return t2 = S(this.el_, e3), 0 !== (t2 = parseFloat(t2)) && !isNaN(t2) || (e3 = "offset" + ut(e3), t2 = this.el_[e3]), t2;
      }, e2.currentDimensions = function() {
        return { width: this.currentDimension("width"), height: this.currentDimension("height") };
      }, e2.currentWidth = function() {
        return this.currentDimension("width");
      }, e2.currentHeight = function() {
        return this.currentDimension("height");
      }, e2.focus = function() {
        this.el_.focus();
      }, e2.blur = function() {
        this.el_.blur();
      }, e2.handleKeyDown = function(e3) {
        this.player_ && (ht.isEventKey(e3, "Tab") || e3.stopPropagation(), this.player_.handleKeyDown(e3));
      }, e2.handleKeyPress = function(e3) {
        this.handleKeyDown(e3);
      }, e2.emitTapEvents = function() {
        var i2, t2 = 0, n2 = null;
        this.on("touchstart", function(e4) {
          1 === e4.touches.length && (n2 = { pageX: e4.touches[0].pageX, pageY: e4.touches[0].pageY }, t2 = window.performance.now(), i2 = true);
        }), this.on("touchmove", function(e4) {
          var t3;
          1 < e4.touches.length ? i2 = false : n2 && (t3 = e4.touches[0].pageX - n2.pageX, e4 = e4.touches[0].pageY - n2.pageY, 10 < Math.sqrt(t3 * t3 + e4 * e4) && (i2 = false));
        });
        function e3() {
          i2 = false;
        }
        this.on("touchleave", e3), this.on("touchcancel", e3), this.on("touchend", function(e4) {
          !(n2 = null) === i2 && window.performance.now() - t2 < 200 && (e4.preventDefault(), this.trigger("tap"));
        });
      }, e2.enableTouchActivity = function() {
        var t2, i2, e3;
        this.player() && this.player().reportUserActivity && (t2 = qe(this.player(), this.player().reportUserActivity), this.on("touchstart", function() {
          t2(), this.clearInterval(i2), i2 = this.setInterval(t2, 250);
        }), e3 = function(e4) {
          t2(), this.clearInterval(i2);
        }, this.on("touchmove", t2), this.on("touchend", e3), this.on("touchcancel", e3));
      }, e2.setTimeout = function(e3, t2) {
        var i2, n2 = this;
        return e3 = qe(this, e3), this.clearTimersOnDispose_(), i2 = window.setTimeout(function() {
          n2.setTimeoutIds_.has(i2) && n2.setTimeoutIds_.delete(i2), e3();
        }, t2), this.setTimeoutIds_.add(i2), i2;
      }, e2.clearTimeout = function(e3) {
        return this.setTimeoutIds_.has(e3) && (this.setTimeoutIds_.delete(e3), window.clearTimeout(e3)), e3;
      }, e2.setInterval = function(e3, t2) {
        e3 = qe(this, e3), this.clearTimersOnDispose_();
        t2 = window.setInterval(e3, t2);
        return this.setIntervalIds_.add(t2), t2;
      }, e2.clearInterval = function(e3) {
        return this.setIntervalIds_.has(e3) && (this.setIntervalIds_.delete(e3), window.clearInterval(e3)), e3;
      }, e2.requestAnimationFrame = function(e3) {
        var t2, i2 = this;
        return this.supportsRaf_ ? (this.clearTimersOnDispose_(), e3 = qe(this, e3), t2 = window.requestAnimationFrame(function() {
          i2.rafIds_.has(t2) && i2.rafIds_.delete(t2), e3();
        }), this.rafIds_.add(t2), t2) : this.setTimeout(e3, 1e3 / 60);
      }, e2.requestNamedAnimationFrame = function(e3, t2) {
        var i2 = this;
        if (!this.namedRafs_.has(e3)) {
          this.clearTimersOnDispose_(), t2 = qe(this, t2);
          var n2 = this.requestAnimationFrame(function() {
            t2(), i2.namedRafs_.has(e3) && i2.namedRafs_.delete(e3);
          });
          return this.namedRafs_.set(e3, n2), e3;
        }
      }, e2.cancelNamedAnimationFrame = function(e3) {
        this.namedRafs_.has(e3) && (this.cancelAnimationFrame(this.namedRafs_.get(e3)), this.namedRafs_.delete(e3));
      }, e2.cancelAnimationFrame = function(e3) {
        return this.supportsRaf_ ? (this.rafIds_.has(e3) && (this.rafIds_.delete(e3), window.cancelAnimationFrame(e3)), e3) : this.clearTimeout(e3);
      }, e2.clearTimersOnDispose_ = function() {
        var n2 = this;
        this.clearingTimersOnDispose_ || (this.clearingTimersOnDispose_ = true, this.one("dispose", function() {
          [["namedRafs_", "cancelNamedAnimationFrame"], ["rafIds_", "cancelAnimationFrame"], ["setTimeoutIds_", "clearTimeout"], ["setIntervalIds_", "clearInterval"]].forEach(function(e3) {
            var t2 = e3[0], i2 = e3[1];
            n2[t2].forEach(function(e4, t3) {
              return n2[i2](t3);
            });
          }), n2.clearingTimersOnDispose_ = false;
        }));
      }, s2.registerComponent = function(e3, t2) {
        if ("string" != typeof e3 || !e3)
          throw new Error('Illegal component name, "' + e3 + '"; must be a non-empty string.');
        var i2 = s2.getComponent("Tech"), n2 = i2 && i2.isTech(t2), i2 = s2 === t2 || s2.prototype.isPrototypeOf(t2.prototype);
        if (n2 || !i2) {
          var r2 = n2 ? "techs must be registered using Tech.registerTech()" : "must be a Component subclass";
          throw new Error('Illegal component, "' + e3 + '"; ' + r2 + ".");
        }
        e3 = ut(e3), s2.components_ || (s2.components_ = {});
        r2 = s2.getComponent("Player");
        if ("Player" === e3 && r2 && r2.players) {
          var a2 = r2.players, r2 = Object.keys(a2);
          if (a2 && 0 < r2.length && r2.map(function(e4) {
            return a2[e4];
          }).every(Boolean))
            throw new Error("Can not register Player component after player has been created.");
        }
        return s2.components_[e3] = t2, s2.components_[ot(e3)] = t2;
      }, s2.getComponent = function(e3) {
        if (e3 && s2.components_)
          return s2.components_[e3];
      }, s2;
    }();
    pt.prototype.supportsRaf_ = "function" == typeof window.requestAnimationFrame && "function" == typeof window.cancelAnimationFrame, pt.registerComponent("Component", pt);
    var ft = function(e2) {
      if (void 0 === e2)
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      return e2;
    };
    var mt = function(e2, t2) {
      e2.prototype = Object.create(t2.prototype), (e2.prototype.constructor = e2).__proto__ = t2;
    };
    function gt(e2, t2, i2, n2) {
      return function(e3, t3, i3) {
        if ("number" != typeof t3 || t3 < 0 || i3 < t3)
          throw new Error("Failed to execute '" + e3 + "' on 'TimeRanges': The index provided (" + t3 + ") is non-numeric or out of bounds (0-" + i3 + ").");
      }(e2, n2, i2.length - 1), i2[n2][t2];
    }
    function yt(e2) {
      var t2 = void 0 === e2 || 0 === e2.length ? { length: 0, start: function() {
        throw new Error("This TimeRanges object is empty");
      }, end: function() {
        throw new Error("This TimeRanges object is empty");
      } } : { length: e2.length, start: gt.bind(null, "start", 0, e2), end: gt.bind(null, "end", 1, e2) };
      return window.Symbol && window.Symbol.iterator && (t2[window.Symbol.iterator] = function() {
        return (e2 || []).values();
      }), t2;
    }
    function vt(e2, t2) {
      return Array.isArray(e2) ? yt(e2) : void 0 === e2 || void 0 === t2 ? yt() : yt([[e2, t2]]);
    }
    function _t(e2, t2) {
      var i2, n2, r2 = 0;
      if (!t2)
        return 0;
      e2 && e2.length || (e2 = vt(0, 0));
      for (var a2 = 0; a2 < e2.length; a2++)
        i2 = e2.start(a2), r2 += (n2 = t2 < (n2 = e2.end(a2)) ? t2 : n2) - i2;
      return r2 / t2;
    }
    function bt(e2) {
      if (e2 instanceof bt)
        return e2;
      "number" == typeof e2 ? this.code = e2 : "string" == typeof e2 ? this.message = e2 : T(e2) && ("number" == typeof e2.code && (this.code = e2.code), b(this, e2)), this.message || (this.message = bt.defaultMessages[this.code] || "");
    }
    bt.prototype.code = 0, bt.prototype.message = "", bt.prototype.status = null, bt.errorTypes = ["MEDIA_ERR_CUSTOM", "MEDIA_ERR_ABORTED", "MEDIA_ERR_NETWORK", "MEDIA_ERR_DECODE", "MEDIA_ERR_SRC_NOT_SUPPORTED", "MEDIA_ERR_ENCRYPTED"], bt.defaultMessages = { 1: "You aborted the media playback", 2: "A network error caused the media download to fail part-way.", 3: "The media playback was aborted due to a corruption problem or because the media used features your browser did not support.", 4: "The media could not be loaded, either because the server or network failed or because the format is not supported.", 5: "The media is encrypted and we do not have the keys to decrypt it." };
    for (var Tt = 0; Tt < bt.errorTypes.length; Tt++)
      bt[bt.errorTypes[Tt]] = Tt, bt.prototype[bt.errorTypes[Tt]] = Tt;
    var wt = function(e2, t2) {
      var i2, n2 = null;
      try {
        i2 = JSON.parse(e2, t2);
      } catch (e3) {
        n2 = e3;
      }
      return [n2, i2];
    };
    function St(e2) {
      return null != e2 && "function" == typeof e2.then;
    }
    function Et(e2) {
      St(e2) && e2.then(null, function(e3) {
      });
    }
    function kt(n2) {
      return ["kind", "label", "language", "id", "inBandMetadataTrackDispatchType", "mode", "src"].reduce(function(e2, t2, i2) {
        return n2[t2] && (e2[t2] = n2[t2]), e2;
      }, { cues: n2.cues && Array.prototype.map.call(n2.cues, function(e2) {
        return { startTime: e2.startTime, endTime: e2.endTime, text: e2.text, id: e2.id };
      }) });
    }
    var Ct = function(e2) {
      var t2 = e2.$$("track"), i2 = Array.prototype.map.call(t2, function(e3) {
        return e3.track;
      });
      return Array.prototype.map.call(t2, function(e3) {
        var t3 = kt(e3.track);
        return e3.src && (t3.src = e3.src), t3;
      }).concat(Array.prototype.filter.call(e2.textTracks(), function(e3) {
        return -1 === i2.indexOf(e3);
      }).map(kt));
    }, It = function(e2, i2) {
      return e2.forEach(function(e3) {
        var t2 = i2.addRemoteTextTrack(e3).track;
        !e3.src && e3.cues && e3.cues.forEach(function(e4) {
          return t2.addCue(e4);
        });
      }), i2.textTracks();
    }, xt = "vjs-modal-dialog", At = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.handleKeyDown_ = function(e4) {
          return i2.handleKeyDown(e4);
        }, i2.close_ = function(e4) {
          return i2.close(e4);
        }, i2.opened_ = i2.hasBeenOpened_ = i2.hasBeenFilled_ = false, i2.closeable(!i2.options_.uncloseable), i2.content(i2.options_.content), i2.contentEl_ = $("div", { className: xt + "-content" }, { role: "document" }), i2.descEl_ = $("p", { className: xt + "-description vjs-control-text", id: i2.el().getAttribute("aria-describedby") }), J(i2.descEl_, i2.description()), i2.el_.appendChild(i2.descEl_), i2.el_.appendChild(i2.contentEl_), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        return n2.prototype.createEl.call(this, "div", { className: this.buildCSSClass(), tabIndex: -1 }, { "aria-describedby": this.id() + "_description", "aria-hidden": "true", "aria-label": this.label(), role: "dialog" });
      }, t2.dispose = function() {
        this.contentEl_ = null, this.descEl_ = null, this.previouslyActiveEl_ = null, n2.prototype.dispose.call(this);
      }, t2.buildCSSClass = function() {
        return xt + " vjs-hidden " + n2.prototype.buildCSSClass.call(this);
      }, t2.label = function() {
        return this.localize(this.options_.label || "Modal Window");
      }, t2.description = function() {
        var e3 = this.options_.description || this.localize("This is a modal window.");
        return this.closeable() && (e3 += " " + this.localize("This modal can be closed by pressing the Escape key or activating the close button.")), e3;
      }, t2.open = function() {
        var e3;
        this.opened_ || (e3 = this.player(), this.trigger("beforemodalopen"), this.opened_ = true, !this.options_.fillAlways && (this.hasBeenOpened_ || this.hasBeenFilled_) || this.fill(), this.wasPlaying_ = !e3.paused(), this.options_.pauseOnOpen && this.wasPlaying_ && e3.pause(), this.on("keydown", this.handleKeyDown_), this.hadControls_ = e3.controls(), e3.controls(false), this.show(), this.conditionalFocus_(), this.el().setAttribute("aria-hidden", "false"), this.trigger("modalopen"), this.hasBeenOpened_ = true);
      }, t2.opened = function(e3) {
        return "boolean" == typeof e3 && this[e3 ? "open" : "close"](), this.opened_;
      }, t2.close = function() {
        var e3;
        this.opened_ && (e3 = this.player(), this.trigger("beforemodalclose"), this.opened_ = false, this.wasPlaying_ && this.options_.pauseOnOpen && e3.play(), this.off("keydown", this.handleKeyDown_), this.hadControls_ && e3.controls(true), this.hide(), this.el().setAttribute("aria-hidden", "true"), this.trigger("modalclose"), this.conditionalBlur_(), this.options_.temporary && this.dispose());
      }, t2.closeable = function(e3) {
        var t3, i2;
        return "boolean" == typeof e3 && (t3 = this.closeable_ = !!e3, i2 = this.getChild("closeButton"), t3 && !i2 && (e3 = this.contentEl_, this.contentEl_ = this.el_, i2 = this.addChild("closeButton", { controlText: "Close Modal Dialog" }), this.contentEl_ = e3, this.on(i2, "close", this.close_)), !t3 && i2 && (this.off(i2, "close", this.close_), this.removeChild(i2), i2.dispose())), this.closeable_;
      }, t2.fill = function() {
        this.fillWith(this.content());
      }, t2.fillWith = function(e3) {
        var t3 = this.contentEl(), i2 = t3.parentNode, n3 = t3.nextSibling;
        this.trigger("beforemodalfill"), this.hasBeenFilled_ = true, i2.removeChild(t3), this.empty(), ve(t3, e3), this.trigger("modalfill"), n3 ? i2.insertBefore(t3, n3) : i2.appendChild(t3);
        t3 = this.getChild("closeButton");
        t3 && i2.appendChild(t3.el_);
      }, t2.empty = function() {
        this.trigger("beforemodalempty"), me(this.contentEl()), this.trigger("modalempty");
      }, t2.content = function(e3) {
        return "undefined" != typeof e3 && (this.content_ = e3), this.content_;
      }, t2.conditionalFocus_ = function() {
        var e3 = document.activeElement, t3 = this.player_.el_;
        this.previouslyActiveEl_ = null, !t3.contains(e3) && t3 !== e3 || (this.previouslyActiveEl_ = e3, this.focus());
      }, t2.conditionalBlur_ = function() {
        this.previouslyActiveEl_ && (this.previouslyActiveEl_.focus(), this.previouslyActiveEl_ = null);
      }, t2.handleKeyDown = function(e3) {
        if (e3.stopPropagation(), ht.isEventKey(e3, "Escape") && this.closeable())
          return e3.preventDefault(), void this.close();
        if (ht.isEventKey(e3, "Tab")) {
          for (var t3, i2 = this.focusableEls_(), n3 = this.el_.querySelector(":focus"), r2 = 0; r2 < i2.length; r2++)
            if (n3 === i2[r2]) {
              t3 = r2;
              break;
            }
          document.activeElement === this.el_ && (t3 = 0), e3.shiftKey && 0 === t3 ? (i2[i2.length - 1].focus(), e3.preventDefault()) : e3.shiftKey || t3 !== i2.length - 1 || (i2[0].focus(), e3.preventDefault());
        }
      }, t2.focusableEls_ = function() {
        var e3 = this.el_.querySelectorAll("*");
        return Array.prototype.filter.call(e3, function(e4) {
          return (e4 instanceof window.HTMLAnchorElement || e4 instanceof window.HTMLAreaElement) && e4.hasAttribute("href") || (e4 instanceof window.HTMLInputElement || e4 instanceof window.HTMLSelectElement || e4 instanceof window.HTMLTextAreaElement || e4 instanceof window.HTMLButtonElement) && !e4.hasAttribute("disabled") || e4 instanceof window.HTMLIFrameElement || e4 instanceof window.HTMLObjectElement || e4 instanceof window.HTMLEmbedElement || e4.hasAttribute("tabindex") && -1 !== e4.getAttribute("tabindex") || e4.hasAttribute("contenteditable");
        });
      }, e2;
    }(pt);
    At.prototype.options_ = { pauseOnOpen: true, temporary: true }, pt.registerComponent("ModalDialog", At);
    var Pt, Lt = function(n2) {
      function e2(e3) {
        var t3;
        void 0 === e3 && (e3 = []), (t3 = n2.call(this) || this).tracks_ = [], Object.defineProperty(ft(t3), "length", { get: function() {
          return this.tracks_.length;
        } });
        for (var i2 = 0; i2 < e3.length; i2++)
          t3.addTrack(e3[i2]);
        return t3;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.addTrack = function(e3) {
        var t3 = this, i2 = this.tracks_.length;
        "" + i2 in this || Object.defineProperty(this, i2, { get: function() {
          return this.tracks_[i2];
        } }), -1 === this.tracks_.indexOf(e3) && (this.tracks_.push(e3), this.trigger({ track: e3, type: "addtrack", target: this })), e3.labelchange_ = function() {
          t3.trigger({ track: e3, type: "labelchange", target: t3 });
        }, it(e3) && e3.addEventListener("labelchange", e3.labelchange_);
      }, t2.removeTrack = function(e3) {
        for (var t3, i2 = 0, n3 = this.length; i2 < n3; i2++)
          if (this[i2] === e3) {
            (t3 = this[i2]).off && t3.off(), this.tracks_.splice(i2, 1);
            break;
          }
        t3 && this.trigger({ track: t3, type: "removetrack", target: this });
      }, t2.getTrackById = function(e3) {
        for (var t3 = null, i2 = 0, n3 = this.length; i2 < n3; i2++) {
          var r2 = this[i2];
          if (r2.id === e3) {
            t3 = r2;
            break;
          }
        }
        return t3;
      }, e2;
    }(ze);
    for (Pt in Lt.prototype.allowedEvents_ = { change: "change", addtrack: "addtrack", removetrack: "removetrack", labelchange: "labelchange" }, Lt.prototype.allowedEvents_)
      Lt.prototype["on" + Pt] = null;
    function Ot(e2, t2) {
      for (var i2 = 0; i2 < e2.length; i2++)
        Object.keys(e2[i2]).length && t2.id !== e2[i2].id && (e2[i2].enabled = false);
    }
    function Dt(e2, t2) {
      for (var i2 = 0; i2 < e2.length; i2++)
        Object.keys(e2[i2]).length && t2.id !== e2[i2].id && (e2[i2].selected = false);
    }
    function Rt(e2) {
      var t2 = ["protocol", "hostname", "port", "pathname", "search", "hash", "host"], i2 = document.createElement("a");
      i2.href = e2;
      for (var n2 = {}, r2 = 0; r2 < t2.length; r2++)
        n2[t2[r2]] = i2[t2[r2]];
      return "http:" === n2.protocol && (n2.host = n2.host.replace(/:80$/, "")), "https:" === n2.protocol && (n2.host = n2.host.replace(/:443$/, "")), n2.protocol || (n2.protocol = window.location.protocol), n2.host || (n2.host = window.location.host), n2;
    }
    function Mt(e2) {
      var t2;
      return e2.match(/^https?:\/\//) || ((t2 = document.createElement("a")).href = e2, e2 = t2.href), e2;
    }
    function Nt(e2) {
      if ("string" == typeof e2) {
        e2 = /^(\/?)([\s\S]*?)((?:\.{1,2}|[^\/]+?)(\.([^\.\/\?]+)))(?:[\/]*|[\?].*)$/.exec(e2);
        if (e2)
          return e2.pop().toLowerCase();
      }
      return "";
    }
    function Ut(e2, t2) {
      return void 0 === t2 && (t2 = window.location), (":" === (e2 = Rt(e2)).protocol ? t2 : e2).protocol + e2.host !== t2.protocol + t2.host;
    }
    var Bt = function(n2) {
      function e2(e3) {
        for (var t3, i2 = (e3 = void 0 === e3 ? [] : e3).length - 1; 0 <= i2; i2--)
          if (e3[i2].enabled) {
            Ot(e3, e3[i2]);
            break;
          }
        return (t3 = n2.call(this, e3) || this).changing_ = false, t3;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.addTrack = function(e3) {
        var t3 = this;
        e3.enabled && Ot(this, e3), n2.prototype.addTrack.call(this, e3), e3.addEventListener && (e3.enabledChange_ = function() {
          t3.changing_ || (t3.changing_ = true, Ot(t3, e3), t3.changing_ = false, t3.trigger("change"));
        }, e3.addEventListener("enabledchange", e3.enabledChange_));
      }, t2.removeTrack = function(e3) {
        n2.prototype.removeTrack.call(this, e3), e3.removeEventListener && e3.enabledChange_ && (e3.removeEventListener("enabledchange", e3.enabledChange_), e3.enabledChange_ = null);
      }, e2;
    }(Lt), Ft = function(n2) {
      function e2(e3) {
        for (var t3, i2 = (e3 = void 0 === e3 ? [] : e3).length - 1; 0 <= i2; i2--)
          if (e3[i2].selected) {
            Dt(e3, e3[i2]);
            break;
          }
        return (t3 = n2.call(this, e3) || this).changing_ = false, Object.defineProperty(ft(t3), "selectedIndex", { get: function() {
          for (var e4 = 0; e4 < this.length; e4++)
            if (this[e4].selected)
              return e4;
          return -1;
        }, set: function() {
        } }), t3;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.addTrack = function(e3) {
        var t3 = this;
        e3.selected && Dt(this, e3), n2.prototype.addTrack.call(this, e3), e3.addEventListener && (e3.selectedChange_ = function() {
          t3.changing_ || (t3.changing_ = true, Dt(t3, e3), t3.changing_ = false, t3.trigger("change"));
        }, e3.addEventListener("selectedchange", e3.selectedChange_));
      }, t2.removeTrack = function(e3) {
        n2.prototype.removeTrack.call(this, e3), e3.removeEventListener && e3.selectedChange_ && (e3.removeEventListener("selectedchange", e3.selectedChange_), e3.selectedChange_ = null);
      }, e2;
    }(Lt), k = function(i2) {
      function e2() {
        return i2.apply(this, arguments) || this;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.addTrack = function(e3) {
        var t3 = this;
        i2.prototype.addTrack.call(this, e3), this.queueChange_ || (this.queueChange_ = function() {
          return t3.queueTrigger("change");
        }), this.triggerSelectedlanguagechange || (this.triggerSelectedlanguagechange_ = function() {
          return t3.trigger("selectedlanguagechange");
        }), e3.addEventListener("modechange", this.queueChange_);
        -1 === ["metadata", "chapters"].indexOf(e3.kind) && e3.addEventListener("modechange", this.triggerSelectedlanguagechange_);
      }, t2.removeTrack = function(e3) {
        i2.prototype.removeTrack.call(this, e3), e3.removeEventListener && (this.queueChange_ && e3.removeEventListener("modechange", this.queueChange_), this.selectedlanguagechange_ && e3.removeEventListener("modechange", this.triggerSelectedlanguagechange_));
      }, e2;
    }(Lt), jt = function() {
      function e2(e3) {
        void 0 === e3 && (e3 = []), this.trackElements_ = [], Object.defineProperty(this, "length", { get: function() {
          return this.trackElements_.length;
        } });
        for (var t3 = 0, i2 = e3.length; t3 < i2; t3++)
          this.addTrackElement_(e3[t3]);
      }
      var t2 = e2.prototype;
      return t2.addTrackElement_ = function(e3) {
        var t3 = this.trackElements_.length;
        "" + t3 in this || Object.defineProperty(this, t3, { get: function() {
          return this.trackElements_[t3];
        } }), -1 === this.trackElements_.indexOf(e3) && this.trackElements_.push(e3);
      }, t2.getTrackElementByTrack_ = function(e3) {
        for (var t3, i2 = 0, n2 = this.trackElements_.length; i2 < n2; i2++)
          if (e3 === this.trackElements_[i2].track) {
            t3 = this.trackElements_[i2];
            break;
          }
        return t3;
      }, t2.removeTrackElement_ = function(e3) {
        for (var t3 = 0, i2 = this.trackElements_.length; t3 < i2; t3++)
          if (e3 === this.trackElements_[t3]) {
            this.trackElements_[t3].track && "function" == typeof this.trackElements_[t3].track.off && this.trackElements_[t3].track.off(), "function" == typeof this.trackElements_[t3].off && this.trackElements_[t3].off(), this.trackElements_.splice(t3, 1);
            break;
          }
      }, e2;
    }(), Ht = function() {
      function t2(e3) {
        t2.prototype.setCues_.call(this, e3), Object.defineProperty(this, "length", { get: function() {
          return this.length_;
        } });
      }
      var e2 = t2.prototype;
      return e2.setCues_ = function(e3) {
        var t3 = this.length || 0, i2 = 0, n2 = e3.length;
        this.cues_ = e3, this.length_ = e3.length;
        function r2(e4) {
          "" + e4 in this || Object.defineProperty(this, "" + e4, { get: function() {
            return this.cues_[e4];
          } });
        }
        if (t3 < n2)
          for (i2 = t3; i2 < n2; i2++)
            r2.call(this, i2);
      }, e2.getCueById = function(e3) {
        for (var t3 = null, i2 = 0, n2 = this.length; i2 < n2; i2++) {
          var r2 = this[i2];
          if (r2.id === e3) {
            t3 = r2;
            break;
          }
        }
        return t3;
      }, t2;
    }(), Vt = { alternative: "alternative", captions: "captions", main: "main", sign: "sign", subtitles: "subtitles", commentary: "commentary" }, qt = { alternative: "alternative", descriptions: "descriptions", main: "main", "main-desc": "main-desc", translation: "translation", commentary: "commentary" }, Wt = { subtitles: "subtitles", captions: "captions", descriptions: "descriptions", chapters: "chapters", metadata: "metadata" }, Gt = { disabled: "disabled", hidden: "hidden", showing: "showing" }, C = function(a2) {
      function e2(e3) {
        void 0 === e3 && (e3 = {});
        var t2, i2 = a2.call(this) || this, n2 = { id: e3.id || "vjs_track_" + Pe++, kind: e3.kind || "", language: e3.language || "" }, r2 = e3.label || "";
        for (t2 in n2)
          !function(e4) {
            Object.defineProperty(ft(i2), e4, { get: function() {
              return n2[e4];
            }, set: function() {
            } });
          }(t2);
        return Object.defineProperty(ft(i2), "label", { get: function() {
          return r2;
        }, set: function(e4) {
          e4 !== r2 && (r2 = e4, this.trigger("labelchange"));
        } }), i2;
      }
      return mt(e2, a2), e2;
    }(ze), zt = Object.freeze({ __proto__: null, parseUrl: Rt, getAbsoluteURL: Mt, getFileExtension: Nt, isCrossOrigin: Ut }), Xt = "undefined" != typeof window ? window : "undefined" != typeof f ? f : "undefined" != typeof self ? self : {}, Kt = Xt, Yt = function(e2) {
      if (!e2)
        return false;
      var t2 = Qt.call(e2);
      return "[object Function]" === t2 || "function" == typeof e2 && "[object RegExp]" !== t2 || "undefined" != typeof window && (e2 === window.setTimeout || e2 === window.alert || e2 === window.confirm || e2 === window.prompt);
    }, Qt = Object.prototype.toString;
    ei.httpHandler = function(n2, r2) {
      return void 0 === r2 && (r2 = false), function(e2, t2, i2) {
        if (e2)
          n2(e2);
        else if (400 <= t2.statusCode && t2.statusCode <= 599) {
          e2 = i2;
          if (r2)
            if (Kt.TextDecoder) {
              t2 = function(e3) {
                void 0 === e3 && (e3 = "");
                return e3.toLowerCase().split(";").reduce(function(e4, t3) {
                  var i3 = t3.split("="), t3 = i3[0], i3 = i3[1];
                  return "charset" === t3.trim() ? i3.trim() : e4;
                }, "utf-8");
              }(t2.headers && t2.headers["content-type"]);
              try {
                e2 = new TextDecoder(t2).decode(i2);
              } catch (e3) {
              }
            } else
              e2 = String.fromCharCode.apply(null, new Uint8Array(i2));
          n2({ cause: e2 });
        } else
          n2(null, i2);
      };
    };
    /**
       * @license
       * slighly modified parse-headers 2.0.2 <https://github.com/kesla/parse-headers/>
       * Copyright (c) 2014 David Björklund
       * Available under the MIT license
       * <https://github.com/kesla/parse-headers/blob/master/LICENCE>
       */
    var $t = function(e2) {
      var n2 = {};
      return e2 && e2.trim().split("\n").forEach(function(e3) {
        var t2 = e3.indexOf(":"), i2 = e3.slice(0, t2).trim().toLowerCase(), t2 = e3.slice(t2 + 1).trim();
        "undefined" == typeof n2[i2] ? n2[i2] = t2 : Array.isArray(n2[i2]) ? n2[i2].push(t2) : n2[i2] = [n2[i2], t2];
      }), n2;
    }, Jt = ei, I = ei;
    function Zt(e2, t2, i2) {
      var n2 = e2;
      return Yt(t2) ? (i2 = t2, "string" == typeof e2 && (n2 = { uri: e2 })) : n2 = g({}, t2, { uri: e2 }), n2.callback = i2, n2;
    }
    function ei(e2, t2, i2) {
      return ti(t2 = Zt(e2, t2, i2));
    }
    function ti(n2) {
      if ("undefined" == typeof n2.callback)
        throw new Error("callback argument missing");
      var r2 = false, a2 = function(e3, t3, i3) {
        r2 || (r2 = true, n2.callback(e3, t3, i3));
      };
      function s2() {
        var e3 = void 0, e3 = l2.response || l2.responseText || function(e4) {
          try {
            if ("document" === e4.responseType)
              return e4.responseXML;
            var t3 = e4.responseXML && "parsererror" === e4.responseXML.documentElement.nodeName;
            if ("" === e4.responseType && !t3)
              return e4.responseXML;
          } catch (e5) {
          }
          return null;
        }(l2);
        if (m2)
          try {
            e3 = JSON.parse(e3);
          } catch (e4) {
          }
        return e3;
      }
      function t2(e3) {
        return clearTimeout(u2), (e3 = !(e3 instanceof Error) ? new Error("" + (e3 || "Unknown XMLHttpRequest Error")) : e3).statusCode = 0, a2(e3, g2);
      }
      function e2() {
        if (!o2) {
          clearTimeout(u2);
          var e3 = n2.useXDR && void 0 === l2.status ? 200 : 1223 === l2.status ? 204 : l2.status, t3 = g2, i3 = null;
          return 0 !== e3 ? (t3 = { body: s2(), statusCode: e3, method: c2, headers: {}, url: d2, rawRequest: l2 }, l2.getAllResponseHeaders && (t3.headers = $t(l2.getAllResponseHeaders()))) : i3 = new Error("Internal XMLHttpRequest Error"), a2(i3, t3, t3.body);
        }
      }
      var i2, o2, u2, l2 = n2.xhr || null, d2 = (l2 = l2 || new (n2.cors || n2.useXDR ? ei.XDomainRequest : ei.XMLHttpRequest)()).url = n2.uri || n2.url, c2 = l2.method = n2.method || "GET", h2 = n2.body || n2.data, p2 = l2.headers = n2.headers || {}, f2 = !!n2.sync, m2 = false, g2 = { body: void 0, headers: {}, statusCode: 0, method: c2, url: d2, rawRequest: l2 };
      if ("json" in n2 && false !== n2.json && (m2 = true, p2.accept || p2.Accept || (p2.Accept = "application/json"), "GET" !== c2 && "HEAD" !== c2 && (p2["content-type"] || p2["Content-Type"] || (p2["Content-Type"] = "application/json"), h2 = JSON.stringify(true === n2.json ? h2 : n2.json))), l2.onreadystatechange = function() {
        4 === l2.readyState && setTimeout(e2, 0);
      }, l2.onload = e2, l2.onerror = t2, l2.onprogress = function() {
      }, l2.onabort = function() {
        o2 = true;
      }, l2.ontimeout = t2, l2.open(c2, d2, !f2, n2.username, n2.password), f2 || (l2.withCredentials = !!n2.withCredentials), !f2 && 0 < n2.timeout && (u2 = setTimeout(function() {
        var e3;
        o2 || (o2 = true, l2.abort("timeout"), (e3 = new Error("XMLHttpRequest timeout")).code = "ETIMEDOUT", t2(e3));
      }, n2.timeout)), l2.setRequestHeader)
        for (i2 in p2)
          p2.hasOwnProperty(i2) && l2.setRequestHeader(i2, p2[i2]);
      else if (n2.headers && !function(e3) {
        for (var t3 in e3)
          if (e3.hasOwnProperty(t3))
            return;
        return 1;
      }(n2.headers))
        throw new Error("Headers cannot be set on an XDomainRequest object");
      return "responseType" in n2 && (l2.responseType = n2.responseType), "beforeSend" in n2 && "function" == typeof n2.beforeSend && n2.beforeSend(l2), l2.send(h2 || null), l2;
    }
    ei.XMLHttpRequest = Kt.XMLHttpRequest || function() {
    }, ei.XDomainRequest = "withCredentials" in new ei.XMLHttpRequest() ? ei.XMLHttpRequest : Kt.XDomainRequest, function(e2, t2) {
      for (var i2 = 0; i2 < e2.length; i2++)
        t2(e2[i2]);
    }(["get", "put", "post", "patch", "head", "delete"], function(n2) {
      ei["delete" === n2 ? "del" : n2] = function(e2, t2, i2) {
        return (t2 = Zt(e2, t2, i2)).method = n2.toUpperCase(), ti(t2);
      };
    }), Jt.default = I;
    function ii(e2, t2) {
      var i2 = new window.WebVTT.Parser(window, window.vttjs, window.WebVTT.StringDecoder()), n2 = [];
      i2.oncue = function(e3) {
        t2.addCue(e3);
      }, i2.onparsingerror = function(e3) {
        n2.push(e3);
      }, i2.onflush = function() {
        t2.trigger({ type: "loadeddata", target: t2 });
      }, i2.parse(e2), 0 < n2.length && (window.console && window.console.groupCollapsed && window.console.groupCollapsed("Text Track parsing errors for " + t2.src), n2.forEach(function(e3) {
        return h.error(e3);
      }), window.console && window.console.groupEnd && window.console.groupEnd()), i2.flush();
    }
    function ni(e2, n2) {
      var t2 = { uri: e2 };
      (e2 = Ut(e2)) && (t2.cors = e2), (e2 = "use-credentials" === n2.tech_.crossOrigin()) && (t2.withCredentials = e2), Jt(t2, qe(this, function(e3, t3, i2) {
        return e3 ? h.error(e3, t3) : (n2.loaded_ = true, void ("function" != typeof window.WebVTT ? n2.tech_ && n2.tech_.any(["vttjsloaded", "vttjserror"], function(e4) {
          return "vttjserror" !== e4.type ? ii(i2, n2) : void h.error("vttjs failed to load, stopping trying to process " + n2.src);
        }) : ii(i2, n2)));
      }));
    }
    var ri = function(a2) {
      function e2(e3) {
        var t3;
        if (!(e3 = void 0 === e3 ? {} : e3).tech)
          throw new Error("A tech was not provided.");
        var e3 = lt(e3, { kind: Wt[e3.kind] || "subtitles", language: e3.language || e3.srclang || "" }), i2 = Gt[e3.mode] || "disabled", n2 = e3.default;
        "metadata" !== e3.kind && "chapters" !== e3.kind || (i2 = "hidden"), (t3 = a2.call(this, e3) || this).tech_ = e3.tech, t3.cues_ = [], t3.activeCues_ = [], t3.preload_ = false !== t3.tech_.preloadTextTracks;
        var r2 = new Ht(t3.cues_), s2 = new Ht(t3.activeCues_), o2 = false;
        t3.timeupdateHandler = qe(ft(t3), function(e4) {
          void 0 === e4 && (e4 = {}), this.tech_.isDisposed() || (this.tech_.isReady_ && (this.activeCues = this.activeCues, o2 && (this.trigger("cuechange"), o2 = false)), "timeupdate" !== e4.type && (this.rvf_ = this.tech_.requestVideoFrameCallback(this.timeupdateHandler)));
        });
        return t3.tech_.one("dispose", function() {
          t3.stopTracking();
        }), "disabled" !== i2 && t3.startTracking(), Object.defineProperties(ft(t3), { default: { get: function() {
          return n2;
        }, set: function() {
        } }, mode: { get: function() {
          return i2;
        }, set: function(e4) {
          Gt[e4] && i2 !== e4 && (i2 = e4, this.preload_ || "disabled" === i2 || 0 !== this.cues.length || ni(this.src, this), this.stopTracking(), "disabled" !== i2 && this.startTracking(), this.trigger("modechange"));
        } }, cues: { get: function() {
          return this.loaded_ ? r2 : null;
        }, set: function() {
        } }, activeCues: { get: function() {
          if (!this.loaded_)
            return null;
          if (0 === this.cues.length)
            return s2;
          for (var e4 = this.tech_.currentTime(), t4 = [], i3 = 0, n3 = this.cues.length; i3 < n3; i3++) {
            var r3 = this.cues[i3];
            (r3.startTime <= e4 && r3.endTime >= e4 || r3.startTime === r3.endTime && r3.startTime <= e4 && r3.startTime + 0.5 >= e4) && t4.push(r3);
          }
          if (o2 = false, t4.length !== this.activeCues_.length)
            o2 = true;
          else
            for (var a3 = 0; a3 < t4.length; a3++)
              -1 === this.activeCues_.indexOf(t4[a3]) && (o2 = true);
          return this.activeCues_ = t4, s2.setCues_(this.activeCues_), s2;
        }, set: function() {
        } } }), e3.src ? (t3.src = e3.src, t3.preload_ || (t3.loaded_ = true), (t3.preload_ || "subtitles" !== e3.kind && "captions" !== e3.kind) && ni(t3.src, ft(t3))) : t3.loaded_ = true, t3;
      }
      mt(e2, a2);
      var t2 = e2.prototype;
      return t2.startTracking = function() {
        this.rvf_ = this.tech_.requestVideoFrameCallback(this.timeupdateHandler), this.tech_.on("timeupdate", this.timeupdateHandler);
      }, t2.stopTracking = function() {
        this.rvf_ && (this.tech_.cancelVideoFrameCallback(this.rvf_), this.rvf_ = void 0), this.tech_.off("timeupdate", this.timeupdateHandler);
      }, t2.addCue = function(e3) {
        var t3 = e3;
        if (window.vttjs && !(e3 instanceof window.vttjs.VTTCue)) {
          for (var i2 in t3 = new window.vttjs.VTTCue(e3.startTime, e3.endTime, e3.text), e3)
            i2 in t3 || (t3[i2] = e3[i2]);
          t3.id = e3.id, t3.originalCue_ = e3;
        }
        for (var n2 = this.tech_.textTracks(), r2 = 0; r2 < n2.length; r2++)
          n2[r2] !== this && n2[r2].removeCue(t3);
        this.cues_.push(t3), this.cues.setCues_(this.cues_);
      }, t2.removeCue = function(e3) {
        for (var t3 = this.cues_.length; t3--; ) {
          var i2 = this.cues_[t3];
          if (i2 === e3 || i2.originalCue_ && i2.originalCue_ === e3) {
            this.cues_.splice(t3, 1), this.cues.setCues_(this.cues_);
            break;
          }
        }
      }, e2;
    }(C);
    ri.prototype.allowedEvents_ = { cuechange: "cuechange" };
    x = function(n2) {
      function e2(e3) {
        var t2 = lt(e3 = void 0 === e3 ? {} : e3, { kind: qt[e3.kind] || "" }), e3 = n2.call(this, t2) || this, i2 = false;
        return Object.defineProperty(ft(e3), "enabled", { get: function() {
          return i2;
        }, set: function(e4) {
          "boolean" == typeof e4 && e4 !== i2 && (i2 = e4, this.trigger("enabledchange"));
        } }), t2.enabled && (e3.enabled = t2.enabled), e3.loaded_ = true, e3;
      }
      return mt(e2, n2), e2;
    }(C), U = function(n2) {
      function e2(e3) {
        var t2 = lt(e3 = void 0 === e3 ? {} : e3, { kind: Vt[e3.kind] || "" }), e3 = n2.call(this, t2) || this, i2 = false;
        return Object.defineProperty(ft(e3), "selected", { get: function() {
          return i2;
        }, set: function(e4) {
          "boolean" == typeof e4 && e4 !== i2 && (i2 = e4, this.trigger("selectedchange"));
        } }), t2.selected && (e3.selected = t2.selected), e3;
      }
      return mt(e2, n2), e2;
    }(C), j = function(r2) {
      function e2(e3) {
        var t2;
        void 0 === e3 && (e3 = {});
        var i2 = r2.call(this) || this, n2 = new ri(e3);
        return i2.kind = n2.kind, i2.src = n2.src, i2.srclang = n2.language, i2.label = n2.label, i2.default = n2.default, Object.defineProperties(ft(i2), { readyState: { get: function() {
          return t2;
        } }, track: { get: function() {
          return n2;
        } } }), t2 = 0, n2.addEventListener("loadeddata", function() {
          t2 = 2, i2.trigger({ type: "load", target: ft(i2) });
        }), i2;
      }
      return mt(e2, r2), e2;
    }(ze);
    j.prototype.allowedEvents_ = { load: "load" }, j.NONE = 0, j.LOADING = 1, j.LOADED = 2, j.ERROR = 3;
    var ai = { audio: { ListClass: Bt, TrackClass: x, capitalName: "Audio" }, video: { ListClass: Ft, TrackClass: U, capitalName: "Video" }, text: { ListClass: k, TrackClass: ri, capitalName: "Text" } };
    Object.keys(ai).forEach(function(e2) {
      ai[e2].getterName = e2 + "Tracks", ai[e2].privateName = e2 + "Tracks_";
    });
    var si = { remoteText: { ListClass: k, TrackClass: ri, capitalName: "RemoteText", getterName: "remoteTextTracks", privateName: "remoteTextTracks_" }, remoteTextEl: { ListClass: jt, TrackClass: j, capitalName: "RemoteTextTrackEls", getterName: "remoteTextTrackEls", privateName: "remoteTextTrackEls_" } }, oi = g({}, ai, si);
    si.names = Object.keys(si), ai.names = Object.keys(ai), oi.names = [].concat(si.names).concat(ai.names);
    var ui = "undefined" != typeof f ? f : "undefined" != typeof window ? window : {}, li = "undefined" != typeof document ? document : (li = ui["__GLOBAL_DOCUMENT_CACHE@4"]) || (ui["__GLOBAL_DOCUMENT_CACHE@4"] = {}), Xt = li, di = Object.create || function(e2) {
      if (1 !== arguments.length)
        throw new Error("Object.create shim only accepts one parameter.");
      return ci.prototype = e2, new ci();
    };
    function ci() {
    }
    function hi(e2, t2) {
      this.name = "ParsingError", this.code = e2.code, this.message = t2 || e2.message;
    }
    function pi(e2) {
      function t2(e3, t3, i2, n2) {
        return 3600 * (0 | e3) + 60 * (0 | t3) + (0 | i2) + (0 | n2) / 1e3;
      }
      e2 = e2.match(/^(\d+):(\d{1,2})(:\d{1,2})?\.(\d{3})/);
      return e2 ? e2[3] ? t2(e2[1], e2[2], e2[3].replace(":", ""), e2[4]) : 59 < e2[1] ? t2(e2[1], e2[2], 0, e2[4]) : t2(0, e2[1], e2[2], e2[4]) : null;
    }
    function fi() {
      this.values = di(null);
    }
    function mi(e2, t2, i2, n2) {
      var r2, a2, s2 = n2 ? e2.split(n2) : [e2];
      for (r2 in s2)
        "string" == typeof s2[r2] && (2 === (a2 = s2[r2].split(i2)).length && t2(a2[0].trim(), a2[1].trim()));
    }
    function gi(t2, e2, s2) {
      var i2 = t2;
      function n2() {
        var e3 = pi(t2);
        if (null === e3)
          throw new hi(hi.Errors.BadTimeStamp, "Malformed timestamp: " + i2);
        return t2 = t2.replace(/^[^\sa-zA-Z-]+/, ""), e3;
      }
      function r2() {
        t2 = t2.replace(/^\s+/, "");
      }
      if (r2(), e2.startTime = n2(), r2(), "-->" !== t2.substr(0, 3))
        throw new hi(hi.Errors.BadTimeStamp, "Malformed time stamp (time stamps must be separated by '-->'): " + i2);
      t2 = t2.substr(3), r2(), e2.endTime = n2(), r2(), function(e3, t3) {
        var a2 = new fi();
        mi(e3, function(e4, t4) {
          switch (e4) {
            case "region":
              for (var i3 = s2.length - 1; 0 <= i3; i3--)
                if (s2[i3].id === t4) {
                  a2.set(e4, s2[i3].region);
                  break;
                }
              break;
            case "vertical":
              a2.alt(e4, t4, ["rl", "lr"]);
              break;
            case "line":
              var n3 = t4.split(","), r3 = n3[0];
              a2.integer(e4, r3), a2.percent(e4, r3) && a2.set("snapToLines", false), a2.alt(e4, r3, ["auto"]), 2 === n3.length && a2.alt("lineAlign", n3[1], ["start", "center", "end"]);
              break;
            case "position":
              n3 = t4.split(","), a2.percent(e4, n3[0]), 2 === n3.length && a2.alt("positionAlign", n3[1], ["start", "center", "end"]);
              break;
            case "size":
              a2.percent(e4, t4);
              break;
            case "align":
              a2.alt(e4, t4, ["start", "center", "end", "left", "right"]);
          }
        }, /:/, /\s/), t3.region = a2.get("region", null), t3.vertical = a2.get("vertical", "");
        try {
          t3.line = a2.get("line", "auto");
        } catch (e4) {
        }
        t3.lineAlign = a2.get("lineAlign", "start"), t3.snapToLines = a2.get("snapToLines", true), t3.size = a2.get("size", 100);
        try {
          t3.align = a2.get("align", "center");
        } catch (e4) {
          t3.align = a2.get("align", "middle");
        }
        try {
          t3.position = a2.get("position", "auto");
        } catch (e4) {
          t3.position = a2.get("position", { start: 0, left: 0, center: 50, middle: 50, end: 100, right: 100 }, t3.align);
        }
        t3.positionAlign = a2.get("positionAlign", { start: "start", left: "start", center: "center", middle: "center", end: "end", right: "end" }, t3.align);
      }(t2, e2);
    }
    ((hi.prototype = di(Error.prototype)).constructor = hi).Errors = { BadSignature: { code: 0, message: "Malformed WebVTT signature." }, BadTimeStamp: { code: 1, message: "Malformed time stamp." } }, fi.prototype = { set: function(e2, t2) {
      this.get(e2) || "" === t2 || (this.values[e2] = t2);
    }, get: function(e2, t2, i2) {
      return i2 ? this.has(e2) ? this.values[e2] : t2[i2] : this.has(e2) ? this.values[e2] : t2;
    }, has: function(e2) {
      return e2 in this.values;
    }, alt: function(e2, t2, i2) {
      for (var n2 = 0; n2 < i2.length; ++n2)
        if (t2 === i2[n2]) {
          this.set(e2, t2);
          break;
        }
    }, integer: function(e2, t2) {
      /^-?\d+$/.test(t2) && this.set(e2, parseInt(t2, 10));
    }, percent: function(e2, t2) {
      return !!(t2.match(/^([\d]{1,3})(\.[\d]*)?%$/) && 0 <= (t2 = parseFloat(t2)) && t2 <= 100) && (this.set(e2, t2), true);
    } };
    var yi = Xt.createElement && Xt.createElement("textarea"), vi = { c: "span", i: "i", b: "b", u: "u", ruby: "ruby", rt: "rt", v: "span", lang: "span" }, _i = { white: "rgba(255,255,255,1)", lime: "rgba(0,255,0,1)", cyan: "rgba(0,255,255,1)", red: "rgba(255,0,0,1)", yellow: "rgba(255,255,0,1)", magenta: "rgba(255,0,255,1)", blue: "rgba(0,0,255,1)", black: "rgba(0,0,0,1)" }, bi = { v: "title", lang: "lang" }, Ti = { rt: "ruby" };
    function wi(e2, t2) {
      for (var i2, n2, r2, a2, s2, o2, u2, l2, d2, c2, h2 = e2.document.createElement("div"), p2 = h2, f2 = []; null !== (i2 = function() {
        if (!t2)
          return null;
        var e3 = t2.match(/^([^<]*)(<[^>]*>?)?/);
        return e3 = e3[1] || e3[2], t2 = t2.substr(e3.length), e3;
      }()); )
        "<" !== i2[0] ? p2.appendChild(e2.document.createTextNode((s2 = i2, yi.innerHTML = s2, s2 = yi.textContent, yi.textContent = "", s2))) : "/" !== i2[1] ? (a2 = pi(i2.substr(1, i2.length - 2))) ? (n2 = e2.document.createProcessingInstruction("timestamp", a2), p2.appendChild(n2)) : (r2 = i2.match(/^<([^.\s/0-9>]+)(\.[^\s\\>]+)?([^>\\]+)?(\\?)>?$/)) && (l2 = r2[1], d2 = r2[3], c2 = void 0, c2 = vi[l2], (n2 = c2 ? (c2 = e2.document.createElement(c2), (l2 = bi[l2]) && d2 && (c2[l2] = d2.trim()), c2) : null) && (o2 = p2, Ti[(u2 = n2).localName] && Ti[u2.localName] !== o2.localName || (r2[2] && ((a2 = r2[2].split(".")).forEach(function(e3) {
          var t3 = /^bg_/.test(e3), e3 = t3 ? e3.slice(3) : e3;
          _i.hasOwnProperty(e3) && (e3 = _i[e3], n2.style[t3 ? "background-color" : "color"] = e3);
        }), n2.className = a2.join(" ")), f2.push(r2[1]), p2.appendChild(n2), p2 = n2))) : f2.length && f2[f2.length - 1] === i2.substr(2).replace(">", "") && (f2.pop(), p2 = p2.parentNode);
      return h2;
    }
    var Si = [[1470, 1470], [1472, 1472], [1475, 1475], [1478, 1478], [1488, 1514], [1520, 1524], [1544, 1544], [1547, 1547], [1549, 1549], [1563, 1563], [1566, 1610], [1645, 1647], [1649, 1749], [1765, 1766], [1774, 1775], [1786, 1805], [1807, 1808], [1810, 1839], [1869, 1957], [1969, 1969], [1984, 2026], [2036, 2037], [2042, 2042], [2048, 2069], [2074, 2074], [2084, 2084], [2088, 2088], [2096, 2110], [2112, 2136], [2142, 2142], [2208, 2208], [2210, 2220], [8207, 8207], [64285, 64285], [64287, 64296], [64298, 64310], [64312, 64316], [64318, 64318], [64320, 64321], [64323, 64324], [64326, 64449], [64467, 64829], [64848, 64911], [64914, 64967], [65008, 65020], [65136, 65140], [65142, 65276], [67584, 67589], [67592, 67592], [67594, 67637], [67639, 67640], [67644, 67644], [67647, 67669], [67671, 67679], [67840, 67867], [67872, 67897], [67903, 67903], [67968, 68023], [68030, 68031], [68096, 68096], [68112, 68115], [68117, 68119], [68121, 68147], [68160, 68167], [68176, 68184], [68192, 68223], [68352, 68405], [68416, 68437], [68440, 68466], [68472, 68479], [68608, 68680], [126464, 126467], [126469, 126495], [126497, 126498], [126500, 126500], [126503, 126503], [126505, 126514], [126516, 126519], [126521, 126521], [126523, 126523], [126530, 126530], [126535, 126535], [126537, 126537], [126539, 126539], [126541, 126543], [126545, 126546], [126548, 126548], [126551, 126551], [126553, 126553], [126555, 126555], [126557, 126557], [126559, 126559], [126561, 126562], [126564, 126564], [126567, 126570], [126572, 126578], [126580, 126583], [126585, 126588], [126590, 126590], [126592, 126601], [126603, 126619], [126625, 126627], [126629, 126633], [126635, 126651], [1114109, 1114109]];
    function Ei(e2) {
      var t2 = [], i2 = "";
      if (!e2 || !e2.childNodes)
        return "ltr";
      function a2(e3, t3) {
        for (var i3 = t3.childNodes.length - 1; 0 <= i3; i3--)
          e3.push(t3.childNodes[i3]);
      }
      for (a2(t2, e2); i2 = function e3(t3) {
        if (!t3 || !t3.length)
          return null;
        var i3 = t3.pop(), n3 = i3.textContent || i3.innerText;
        if (n3) {
          var r2 = n3.match(/^.*(\n|\r)/);
          return r2 ? r2[t3.length = 0] : n3;
        }
        return "ruby" === i3.tagName ? e3(t3) : i3.childNodes ? (a2(t3, i3), e3(t3)) : void 0;
      }(t2); )
        for (var n2 = 0; n2 < i2.length; n2++)
          if (function(e3) {
            for (var t3 = 0; t3 < Si.length; t3++) {
              var i3 = Si[t3];
              if (e3 >= i3[0] && e3 <= i3[1])
                return 1;
            }
          }(i2.charCodeAt(n2)))
            return "rtl";
      return "ltr";
    }
    function ki() {
    }
    function Ci(e2, t2, i2) {
      ki.call(this), this.cue = t2, this.cueDiv = wi(e2, t2.text);
      var n2 = { color: "rgba(255, 255, 255, 1)", backgroundColor: "rgba(0, 0, 0, 0.8)", position: "relative", left: 0, right: 0, top: 0, bottom: 0, display: "inline", writingMode: "" === t2.vertical ? "horizontal-tb" : "lr" === t2.vertical ? "vertical-lr" : "vertical-rl", unicodeBidi: "plaintext" };
      this.applyStyles(n2, this.cueDiv), this.div = e2.document.createElement("div"), n2 = { direction: Ei(this.cueDiv), writingMode: "" === t2.vertical ? "horizontal-tb" : "lr" === t2.vertical ? "vertical-lr" : "vertical-rl", unicodeBidi: "plaintext", textAlign: "middle" === t2.align ? "center" : t2.align, font: i2.font, whiteSpace: "pre-line", position: "absolute" }, this.applyStyles(n2), this.div.appendChild(this.cueDiv);
      var r2 = 0;
      switch (t2.positionAlign) {
        case "start":
          r2 = t2.position;
          break;
        case "center":
          r2 = t2.position - t2.size / 2;
          break;
        case "end":
          r2 = t2.position - t2.size;
      }
      "" === t2.vertical ? this.applyStyles({ left: this.formatStyle(r2, "%"), width: this.formatStyle(t2.size, "%") }) : this.applyStyles({ top: this.formatStyle(r2, "%"), height: this.formatStyle(t2.size, "%") }), this.move = function(e3) {
        this.applyStyles({ top: this.formatStyle(e3.top, "px"), bottom: this.formatStyle(e3.bottom, "px"), left: this.formatStyle(e3.left, "px"), right: this.formatStyle(e3.right, "px"), height: this.formatStyle(e3.height, "px"), width: this.formatStyle(e3.width, "px") });
      };
    }
    function Ii(e2) {
      var t2, i2, n2, r2;
      e2.div && (t2 = e2.div.offsetHeight, i2 = e2.div.offsetWidth, n2 = e2.div.offsetTop, r2 = (r2 = e2.div.childNodes) && (r2 = r2[0]) && r2.getClientRects && r2.getClientRects(), e2 = e2.div.getBoundingClientRect(), r2 = r2 ? Math.max(r2[0] && r2[0].height || 0, e2.height / r2.length) : 0), this.left = e2.left, this.right = e2.right, this.top = e2.top || n2, this.height = e2.height || t2, this.bottom = e2.bottom || n2 + (e2.height || t2), this.width = e2.width || i2, this.lineHeight = void 0 !== r2 ? r2 : e2.lineHeight;
    }
    function xi(e2, t2, o2, u2) {
      var i2, n2 = new Ii(t2), r2 = t2.cue, a2 = function(e3) {
        if ("number" == typeof e3.line && (e3.snapToLines || 0 <= e3.line && e3.line <= 100))
          return e3.line;
        if (!e3.track || !e3.track.textTrackList || !e3.track.textTrackList.mediaElement)
          return -1;
        for (var t3 = e3.track, i3 = t3.textTrackList, n3 = 0, r3 = 0; r3 < i3.length && i3[r3] !== t3; r3++)
          "showing" === i3[r3].mode && n3++;
        return -1 * ++n3;
      }(r2), s2 = [];
      if (r2.snapToLines) {
        switch (r2.vertical) {
          case "":
            s2 = ["+y", "-y"], i2 = "height";
            break;
          case "rl":
            s2 = ["+x", "-x"], i2 = "width";
            break;
          case "lr":
            s2 = ["-x", "+x"], i2 = "width";
        }
        var l2 = n2.lineHeight, d2 = l2 * Math.round(a2), c2 = o2[i2] + l2, h2 = s2[0];
        Math.abs(d2) > c2 && (d2 = d2 < 0 ? -1 : 1, d2 *= Math.ceil(c2 / l2) * l2), a2 < 0 && (d2 += "" === r2.vertical ? o2.height : o2.width, s2 = s2.reverse()), n2.move(h2, d2);
      } else {
        var p2 = n2.lineHeight / o2.height * 100;
        switch (r2.lineAlign) {
          case "center":
            a2 -= p2 / 2;
            break;
          case "end":
            a2 -= p2;
        }
        switch (r2.vertical) {
          case "":
            t2.applyStyles({ top: t2.formatStyle(a2, "%") });
            break;
          case "rl":
            t2.applyStyles({ left: t2.formatStyle(a2, "%") });
            break;
          case "lr":
            t2.applyStyles({ right: t2.formatStyle(a2, "%") });
        }
        s2 = ["+y", "-x", "+x", "-y"], n2 = new Ii(t2);
      }
      n2 = function(e3, t3) {
        for (var i3, n3 = new Ii(e3), r3 = 1, a3 = 0; a3 < t3.length; a3++) {
          for (; e3.overlapsOppositeAxis(o2, t3[a3]) || e3.within(o2) && e3.overlapsAny(u2); )
            e3.move(t3[a3]);
          if (e3.within(o2))
            return e3;
          var s3 = e3.intersectPercentage(o2);
          s3 < r3 && (i3 = new Ii(e3), r3 = s3), e3 = new Ii(n3);
        }
        return i3 || n3;
      }(n2, s2);
      t2.move(n2.toCSSCompatValues(o2));
    }
    function Ai() {
    }
    ki.prototype.applyStyles = function(e2, t2) {
      for (var i2 in t2 = t2 || this.div, e2)
        e2.hasOwnProperty(i2) && (t2.style[i2] = e2[i2]);
    }, ki.prototype.formatStyle = function(e2, t2) {
      return 0 === e2 ? 0 : e2 + t2;
    }, (Ci.prototype = di(ki.prototype)).constructor = Ci, Ii.prototype.move = function(e2, t2) {
      switch (t2 = void 0 !== t2 ? t2 : this.lineHeight, e2) {
        case "+x":
          this.left += t2, this.right += t2;
          break;
        case "-x":
          this.left -= t2, this.right -= t2;
          break;
        case "+y":
          this.top += t2, this.bottom += t2;
          break;
        case "-y":
          this.top -= t2, this.bottom -= t2;
      }
    }, Ii.prototype.overlaps = function(e2) {
      return this.left < e2.right && this.right > e2.left && this.top < e2.bottom && this.bottom > e2.top;
    }, Ii.prototype.overlapsAny = function(e2) {
      for (var t2 = 0; t2 < e2.length; t2++)
        if (this.overlaps(e2[t2]))
          return true;
      return false;
    }, Ii.prototype.within = function(e2) {
      return this.top >= e2.top && this.bottom <= e2.bottom && this.left >= e2.left && this.right <= e2.right;
    }, Ii.prototype.overlapsOppositeAxis = function(e2, t2) {
      switch (t2) {
        case "+x":
          return this.left < e2.left;
        case "-x":
          return this.right > e2.right;
        case "+y":
          return this.top < e2.top;
        case "-y":
          return this.bottom > e2.bottom;
      }
    }, Ii.prototype.intersectPercentage = function(e2) {
      return Math.max(0, Math.min(this.right, e2.right) - Math.max(this.left, e2.left)) * Math.max(0, Math.min(this.bottom, e2.bottom) - Math.max(this.top, e2.top)) / (this.height * this.width);
    }, Ii.prototype.toCSSCompatValues = function(e2) {
      return { top: this.top - e2.top, bottom: e2.bottom - this.bottom, left: this.left - e2.left, right: e2.right - this.right, height: this.height, width: this.width };
    }, Ii.getSimpleBoxPosition = function(e2) {
      var t2 = e2.div ? e2.div.offsetHeight : e2.tagName ? e2.offsetHeight : 0, i2 = e2.div ? e2.div.offsetWidth : e2.tagName ? e2.offsetWidth : 0, n2 = e2.div ? e2.div.offsetTop : e2.tagName ? e2.offsetTop : 0;
      return { left: (e2 = e2.div ? e2.div.getBoundingClientRect() : e2.tagName ? e2.getBoundingClientRect() : e2).left, right: e2.right, top: e2.top || n2, height: e2.height || t2, bottom: e2.bottom || n2 + (e2.height || t2), width: e2.width || i2 };
    }, Ai.StringDecoder = function() {
      return { decode: function(e2) {
        if (!e2)
          return "";
        if ("string" != typeof e2)
          throw new Error("Error - expected string data.");
        return decodeURIComponent(encodeURIComponent(e2));
      } };
    }, Ai.convertCueToDOMTree = function(e2, t2) {
      return e2 && t2 ? wi(e2, t2) : null;
    };
    Ai.processCues = function(n2, r2, e2) {
      if (!n2 || !r2 || !e2)
        return null;
      for (; e2.firstChild; )
        e2.removeChild(e2.firstChild);
      var a2 = n2.document.createElement("div");
      if (a2.style.position = "absolute", a2.style.left = "0", a2.style.right = "0", a2.style.top = "0", a2.style.bottom = "0", a2.style.margin = "1.5%", e2.appendChild(a2), function(e3) {
        for (var t3 = 0; t3 < e3.length; t3++)
          if (e3[t3].hasBeenReset || !e3[t3].displayState)
            return 1;
      }(r2)) {
        var s2 = [], o2 = Ii.getSimpleBoxPosition(a2), u2 = { font: Math.round(0.05 * o2.height * 100) / 100 + "px sans-serif" };
        !function() {
          for (var e3, t3, i2 = 0; i2 < r2.length; i2++)
            t3 = r2[i2], e3 = new Ci(n2, t3, u2), a2.appendChild(e3.div), xi(0, e3, o2, s2), t3.displayState = e3.div, s2.push(Ii.getSimpleBoxPosition(e3));
        }();
      } else
        for (var t2 = 0; t2 < r2.length; t2++)
          a2.appendChild(r2[t2].displayState);
    }, (Ai.Parser = function(e2, t2, i2) {
      i2 || (i2 = t2, t2 = {}), t2 = t2 || {}, this.window = e2, this.vttjs = t2, this.state = "INITIAL", this.buffer = "", this.decoder = i2 || new TextDecoder("utf8"), this.regionList = [];
    }).prototype = { reportOrThrowError: function(e2) {
      if (!(e2 instanceof hi))
        throw e2;
      this.onparsingerror && this.onparsingerror(e2);
    }, parse: function(e2) {
      var n2 = this;
      function t2() {
        for (var e3 = n2.buffer, t3 = 0; t3 < e3.length && "\r" !== e3[t3] && "\n" !== e3[t3]; )
          ++t3;
        var i3 = e3.substr(0, t3);
        return "\r" === e3[t3] && ++t3, "\n" === e3[t3] && ++t3, n2.buffer = e3.substr(t3), i3;
      }
      function i2(e3) {
        e3.match(/X-TIMESTAMP-MAP/) ? mi(e3, function(e4, t3) {
          var i3;
          "X-TIMESTAMP-MAP" === e4 && (t3 = t3, i3 = new fi(), mi(t3, function(e5, t4) {
            switch (e5) {
              case "MPEGT":
                i3.integer(e5 + "S", t4);
                break;
              case "LOCA":
                i3.set(e5 + "L", pi(t4));
            }
          }, /[^\d]:/, /,/), n2.ontimestampmap && n2.ontimestampmap({ MPEGTS: i3.get("MPEGTS"), LOCAL: i3.get("LOCAL") }));
        }, /=/) : mi(e3, function(e4, t3) {
          var r3;
          "Region" === e4 && (t3 = t3, r3 = new fi(), mi(t3, function(e5, t4) {
            switch (e5) {
              case "id":
                r3.set(e5, t4);
                break;
              case "width":
                r3.percent(e5, t4);
                break;
              case "lines":
                r3.integer(e5, t4);
                break;
              case "regionanchor":
              case "viewportanchor":
                var i3 = t4.split(",");
                if (2 !== i3.length)
                  break;
                var n3 = new fi();
                if (n3.percent("x", i3[0]), n3.percent("y", i3[1]), !n3.has("x") || !n3.has("y"))
                  break;
                r3.set(e5 + "X", n3.get("x")), r3.set(e5 + "Y", n3.get("y"));
                break;
              case "scroll":
                r3.alt(e5, t4, ["up"]);
            }
          }, /=/, /\s/), r3.has("id") && ((t3 = new (n2.vttjs.VTTRegion || n2.window.VTTRegion)()).width = r3.get("width", 100), t3.lines = r3.get("lines", 3), t3.regionAnchorX = r3.get("regionanchorX", 0), t3.regionAnchorY = r3.get("regionanchorY", 100), t3.viewportAnchorX = r3.get("viewportanchorX", 0), t3.viewportAnchorY = r3.get("viewportanchorY", 100), t3.scroll = r3.get("scroll", ""), n2.onregion && n2.onregion(t3), n2.regionList.push({ id: r3.get("id"), region: t3 })));
        }, /:/);
      }
      e2 && (n2.buffer += n2.decoder.decode(e2, { stream: true }));
      try {
        if ("INITIAL" === n2.state) {
          if (!/\r\n|\n/.test(n2.buffer))
            return this;
          var r2, a2 = (r2 = t2()).match(/^WEBVTT([ \t].*)?$/);
          if (!a2 || !a2[0])
            throw new hi(hi.Errors.BadSignature);
          n2.state = "HEADER";
        }
        for (var s2 = false; n2.buffer; ) {
          if (!/\r\n|\n/.test(n2.buffer))
            return this;
          switch (s2 ? s2 = false : r2 = t2(), n2.state) {
            case "HEADER":
              /:/.test(r2) ? i2(r2) : r2 || (n2.state = "ID");
              continue;
            case "NOTE":
              r2 || (n2.state = "ID");
              continue;
            case "ID":
              if (/^NOTE($|[ \t])/.test(r2)) {
                n2.state = "NOTE";
                break;
              }
              if (!r2)
                continue;
              n2.cue = new (n2.vttjs.VTTCue || n2.window.VTTCue)(0, 0, "");
              try {
                n2.cue.align = "center";
              } catch (e3) {
                n2.cue.align = "middle";
              }
              if (n2.state = "CUE", -1 === r2.indexOf("-->")) {
                n2.cue.id = r2;
                continue;
              }
            case "CUE":
              try {
                gi(r2, n2.cue, n2.regionList);
              } catch (e3) {
                n2.reportOrThrowError(e3), n2.cue = null, n2.state = "BADCUE";
                continue;
              }
              n2.state = "CUETEXT";
              continue;
            case "CUETEXT":
              var o2 = -1 !== r2.indexOf("-->");
              if (!r2 || o2 && (s2 = true)) {
                n2.oncue && n2.oncue(n2.cue), n2.cue = null, n2.state = "ID";
                continue;
              }
              n2.cue.text && (n2.cue.text += "\n"), n2.cue.text += r2.replace(/\u2028/g, "\n").replace(/u2029/g, "\n");
              continue;
            case "BADCUE":
              r2 || (n2.state = "ID");
              continue;
          }
        }
      } catch (e3) {
        n2.reportOrThrowError(e3), "CUETEXT" === n2.state && n2.cue && n2.oncue && n2.oncue(n2.cue), n2.cue = null, n2.state = "INITIAL" === n2.state ? "BADWEBVTT" : "BADCUE";
      }
      return this;
    }, flush: function() {
      var t2 = this;
      try {
        if (t2.buffer += t2.decoder.decode(), !t2.cue && "HEADER" !== t2.state || (t2.buffer += "\n\n", t2.parse()), "INITIAL" === t2.state)
          throw new hi(hi.Errors.BadSignature);
      } catch (e2) {
        t2.reportOrThrowError(e2);
      }
      return t2.onflush && t2.onflush(), this;
    } };
    var Pi = Ai, Li = { "": 1, lr: 1, rl: 1 }, Oi = { start: 1, center: 1, end: 1, left: 1, right: 1, auto: 1, "line-left": 1, "line-right": 1 };
    function Di(e2) {
      return "string" == typeof e2 && (!!Oi[e2.toLowerCase()] && e2.toLowerCase());
    }
    function Ri(e2, t2, i2) {
      this.hasBeenReset = false;
      var n2 = "", r2 = false, a2 = e2, s2 = t2, o2 = i2, u2 = null, l2 = "", d2 = true, c2 = "auto", h2 = "start", p2 = "auto", f2 = "auto", m2 = 100, g2 = "center";
      Object.defineProperties(this, { id: { enumerable: true, get: function() {
        return n2;
      }, set: function(e3) {
        n2 = "" + e3;
      } }, pauseOnExit: { enumerable: true, get: function() {
        return r2;
      }, set: function(e3) {
        r2 = !!e3;
      } }, startTime: { enumerable: true, get: function() {
        return a2;
      }, set: function(e3) {
        if ("number" != typeof e3)
          throw new TypeError("Start time must be set to a number.");
        a2 = e3, this.hasBeenReset = true;
      } }, endTime: { enumerable: true, get: function() {
        return s2;
      }, set: function(e3) {
        if ("number" != typeof e3)
          throw new TypeError("End time must be set to a number.");
        s2 = e3, this.hasBeenReset = true;
      } }, text: { enumerable: true, get: function() {
        return o2;
      }, set: function(e3) {
        o2 = "" + e3, this.hasBeenReset = true;
      } }, region: { enumerable: true, get: function() {
        return u2;
      }, set: function(e3) {
        u2 = e3, this.hasBeenReset = true;
      } }, vertical: { enumerable: true, get: function() {
        return l2;
      }, set: function(e3) {
        e3 = "string" == typeof (e3 = e3) && (!!Li[e3.toLowerCase()] && e3.toLowerCase());
        if (false === e3)
          throw new SyntaxError("Vertical: an invalid or illegal direction string was specified.");
        l2 = e3, this.hasBeenReset = true;
      } }, snapToLines: { enumerable: true, get: function() {
        return d2;
      }, set: function(e3) {
        d2 = !!e3, this.hasBeenReset = true;
      } }, line: { enumerable: true, get: function() {
        return c2;
      }, set: function(e3) {
        if ("number" != typeof e3 && "auto" !== e3)
          throw new SyntaxError("Line: an invalid number or illegal string was specified.");
        c2 = e3, this.hasBeenReset = true;
      } }, lineAlign: { enumerable: true, get: function() {
        return h2;
      }, set: function(e3) {
        e3 = Di(e3);
        e3 && (h2 = e3, this.hasBeenReset = true);
      } }, position: { enumerable: true, get: function() {
        return p2;
      }, set: function(e3) {
        if (e3 < 0 || 100 < e3)
          throw new Error("Position must be between 0 and 100.");
        p2 = e3, this.hasBeenReset = true;
      } }, positionAlign: { enumerable: true, get: function() {
        return f2;
      }, set: function(e3) {
        e3 = Di(e3);
        e3 && (f2 = e3, this.hasBeenReset = true);
      } }, size: { enumerable: true, get: function() {
        return m2;
      }, set: function(e3) {
        if (e3 < 0 || 100 < e3)
          throw new Error("Size must be between 0 and 100.");
        m2 = e3, this.hasBeenReset = true;
      } }, align: { enumerable: true, get: function() {
        return g2;
      }, set: function(e3) {
        e3 = Di(e3);
        if (!e3)
          throw new SyntaxError("align: an invalid or illegal alignment string was specified.");
        g2 = e3, this.hasBeenReset = true;
      } } }), this.displayState = void 0;
    }
    Ri.prototype.getCueAsHTML = function() {
      return WebVTT.convertCueToDOMTree(window, this.text);
    };
    var Mi = Ri, Ni = { "": true, up: true };
    function Ui(e2) {
      return "number" == typeof e2 && 0 <= e2 && e2 <= 100;
    }
    function Bi() {
      var t2 = 100, i2 = 3, n2 = 0, r2 = 100, a2 = 0, s2 = 100, o2 = "";
      Object.defineProperties(this, { width: { enumerable: true, get: function() {
        return t2;
      }, set: function(e2) {
        if (!Ui(e2))
          throw new Error("Width must be between 0 and 100.");
        t2 = e2;
      } }, lines: { enumerable: true, get: function() {
        return i2;
      }, set: function(e2) {
        if ("number" != typeof e2)
          throw new TypeError("Lines must be set to a number.");
        i2 = e2;
      } }, regionAnchorY: { enumerable: true, get: function() {
        return r2;
      }, set: function(e2) {
        if (!Ui(e2))
          throw new Error("RegionAnchorX must be between 0 and 100.");
        r2 = e2;
      } }, regionAnchorX: { enumerable: true, get: function() {
        return n2;
      }, set: function(e2) {
        if (!Ui(e2))
          throw new Error("RegionAnchorY must be between 0 and 100.");
        n2 = e2;
      } }, viewportAnchorY: { enumerable: true, get: function() {
        return s2;
      }, set: function(e2) {
        if (!Ui(e2))
          throw new Error("ViewportAnchorY must be between 0 and 100.");
        s2 = e2;
      } }, viewportAnchorX: { enumerable: true, get: function() {
        return a2;
      }, set: function(e2) {
        if (!Ui(e2))
          throw new Error("ViewportAnchorX must be between 0 and 100.");
        a2 = e2;
      } }, scroll: { enumerable: true, get: function() {
        return o2;
      }, set: function(e2) {
        e2 = "string" == typeof (e2 = e2) && (!!Ni[e2.toLowerCase()] && e2.toLowerCase());
        false === e2 || (o2 = e2);
      } } });
    }
    var Fi = m(function(e2) {
      e2 = e2.exports = { WebVTT: Pi, VTTCue: Mi, VTTRegion: Bi };
      Kt.vttjs = e2, Kt.WebVTT = e2.WebVTT;
      var t2 = e2.VTTCue, i2 = e2.VTTRegion, n2 = Kt.VTTCue, r2 = Kt.VTTRegion;
      e2.shim = function() {
        Kt.VTTCue = t2, Kt.VTTRegion = i2;
      }, e2.restore = function() {
        Kt.VTTCue = n2, Kt.VTTRegion = r2;
      }, Kt.VTTCue || e2.shim();
    });
    Fi.WebVTT, Fi.VTTCue, Fi.VTTRegion;
    var ji = function(n2) {
      function i2(t2, e3) {
        var i3;
        return void 0 === e3 && (e3 = function() {
        }), (t2 = void 0 === t2 ? {} : t2).reportTouchActivity = false, (i3 = n2.call(this, null, t2, e3) || this).onDurationChange_ = function(e4) {
          return i3.onDurationChange(e4);
        }, i3.trackProgress_ = function(e4) {
          return i3.trackProgress(e4);
        }, i3.trackCurrentTime_ = function(e4) {
          return i3.trackCurrentTime(e4);
        }, i3.stopTrackingCurrentTime_ = function(e4) {
          return i3.stopTrackingCurrentTime(e4);
        }, i3.disposeSourceHandler_ = function(e4) {
          return i3.disposeSourceHandler(e4);
        }, i3.queuedHanders_ = /* @__PURE__ */ new Set(), i3.hasStarted_ = false, i3.on("playing", function() {
          this.hasStarted_ = true;
        }), i3.on("loadstart", function() {
          this.hasStarted_ = false;
        }), oi.names.forEach(function(e4) {
          e4 = oi[e4];
          t2 && t2[e4.getterName] && (i3[e4.privateName] = t2[e4.getterName]);
        }), i3.featuresProgressEvents || i3.manualProgressOn(), i3.featuresTimeupdateEvents || i3.manualTimeUpdatesOn(), ["Text", "Audio", "Video"].forEach(function(e4) {
          false === t2["native" + e4 + "Tracks"] && (i3["featuresNative" + e4 + "Tracks"] = false);
        }), false === t2.nativeCaptions || false === t2.nativeTextTracks ? i3.featuresNativeTextTracks = false : true !== t2.nativeCaptions && true !== t2.nativeTextTracks || (i3.featuresNativeTextTracks = true), i3.featuresNativeTextTracks || i3.emulateTextTracks(), i3.preloadTextTracks = false !== t2.preloadTextTracks, i3.autoRemoteTextTracks_ = new oi.text.ListClass(), i3.initTrackListeners(), t2.nativeControlsForTouch || i3.emitTapEvents(), i3.constructor && (i3.name_ = i3.constructor.name || "Unknown Tech"), i3;
      }
      mt(i2, n2);
      var e2 = i2.prototype;
      return e2.triggerSourceset = function(e3) {
        var t2 = this;
        this.isReady_ || this.one("ready", function() {
          return t2.setTimeout(function() {
            return t2.triggerSourceset(e3);
          }, 1);
        }), this.trigger({ src: e3, type: "sourceset" });
      }, e2.manualProgressOn = function() {
        this.on("durationchange", this.onDurationChange_), this.manualProgress = true, this.one("ready", this.trackProgress_);
      }, e2.manualProgressOff = function() {
        this.manualProgress = false, this.stopTrackingProgress(), this.off("durationchange", this.onDurationChange_);
      }, e2.trackProgress = function(e3) {
        this.stopTrackingProgress(), this.progressInterval = this.setInterval(qe(this, function() {
          var e4 = this.bufferedPercent();
          this.bufferedPercent_ !== e4 && this.trigger("progress"), 1 === (this.bufferedPercent_ = e4) && this.stopTrackingProgress();
        }), 500);
      }, e2.onDurationChange = function(e3) {
        this.duration_ = this.duration();
      }, e2.buffered = function() {
        return vt(0, 0);
      }, e2.bufferedPercent = function() {
        return _t(this.buffered(), this.duration_);
      }, e2.stopTrackingProgress = function() {
        this.clearInterval(this.progressInterval);
      }, e2.manualTimeUpdatesOn = function() {
        this.manualTimeUpdates = true, this.on("play", this.trackCurrentTime_), this.on("pause", this.stopTrackingCurrentTime_);
      }, e2.manualTimeUpdatesOff = function() {
        this.manualTimeUpdates = false, this.stopTrackingCurrentTime(), this.off("play", this.trackCurrentTime_), this.off("pause", this.stopTrackingCurrentTime_);
      }, e2.trackCurrentTime = function() {
        this.currentTimeInterval && this.stopTrackingCurrentTime(), this.currentTimeInterval = this.setInterval(function() {
          this.trigger({ type: "timeupdate", target: this, manuallyTriggered: true });
        }, 250);
      }, e2.stopTrackingCurrentTime = function() {
        this.clearInterval(this.currentTimeInterval), this.trigger({ type: "timeupdate", target: this, manuallyTriggered: true });
      }, e2.dispose = function() {
        this.clearTracks(ai.names), this.manualProgress && this.manualProgressOff(), this.manualTimeUpdates && this.manualTimeUpdatesOff(), n2.prototype.dispose.call(this);
      }, e2.clearTracks = function(e3) {
        var r2 = this;
        (e3 = [].concat(e3)).forEach(function(e4) {
          for (var t2 = r2[e4 + "Tracks"]() || [], i3 = t2.length; i3--; ) {
            var n3 = t2[i3];
            "text" === e4 && r2.removeRemoteTextTrack(n3), t2.removeTrack(n3);
          }
        });
      }, e2.cleanupAutoTextTracks = function() {
        for (var e3 = this.autoRemoteTextTracks_ || [], t2 = e3.length; t2--; ) {
          var i3 = e3[t2];
          this.removeRemoteTextTrack(i3);
        }
      }, e2.reset = function() {
      }, e2.crossOrigin = function() {
      }, e2.setCrossOrigin = function() {
      }, e2.error = function(e3) {
        return void 0 !== e3 && (this.error_ = new bt(e3), this.trigger("error")), this.error_;
      }, e2.played = function() {
        return this.hasStarted_ ? vt(0, 0) : vt();
      }, e2.play = function() {
      }, e2.setScrubbing = function() {
      }, e2.scrubbing = function() {
      }, e2.setCurrentTime = function() {
        this.manualTimeUpdates && this.trigger({ type: "timeupdate", target: this, manuallyTriggered: true });
      }, e2.initTrackListeners = function() {
        var r2 = this;
        ai.names.forEach(function(e3) {
          function t2() {
            r2.trigger(e3 + "trackchange");
          }
          var i3 = ai[e3], n3 = r2[i3.getterName]();
          n3.addEventListener("removetrack", t2), n3.addEventListener("addtrack", t2), r2.on("dispose", function() {
            n3.removeEventListener("removetrack", t2), n3.removeEventListener("addtrack", t2);
          });
        });
      }, e2.addWebVttScript_ = function() {
        var e3, t2 = this;
        window.WebVTT || (document.body.contains(this.el()) ? !this.options_["vtt.js"] && w(Fi) && 0 < Object.keys(Fi).length ? this.trigger("vttjsloaded") : ((e3 = document.createElement("script")).src = this.options_["vtt.js"] || "https://vjs.zencdn.net/vttjs/0.14.1/vtt.min.js", e3.onload = function() {
          t2.trigger("vttjsloaded");
        }, e3.onerror = function() {
          t2.trigger("vttjserror");
        }, this.on("dispose", function() {
          e3.onload = null, e3.onerror = null;
        }), window.WebVTT = true, this.el().parentNode.appendChild(e3)) : this.ready(this.addWebVttScript_));
      }, e2.emulateTextTracks = function() {
        function t2(e4) {
          return n3.addTrack(e4.track);
        }
        function i3(e4) {
          return n3.removeTrack(e4.track);
        }
        var e3 = this, n3 = this.textTracks(), r2 = this.remoteTextTracks();
        r2.on("addtrack", t2), r2.on("removetrack", i3), this.addWebVttScript_();
        function a2() {
          return e3.trigger("texttrackchange");
        }
        function s2() {
          a2();
          for (var e4 = 0; e4 < n3.length; e4++) {
            var t3 = n3[e4];
            t3.removeEventListener("cuechange", a2), "showing" === t3.mode && t3.addEventListener("cuechange", a2);
          }
        }
        s2(), n3.addEventListener("change", s2), n3.addEventListener("addtrack", s2), n3.addEventListener("removetrack", s2), this.on("dispose", function() {
          r2.off("addtrack", t2), r2.off("removetrack", i3), n3.removeEventListener("change", s2), n3.removeEventListener("addtrack", s2), n3.removeEventListener("removetrack", s2);
          for (var e4 = 0; e4 < n3.length; e4++)
            n3[e4].removeEventListener("cuechange", a2);
        });
      }, e2.addTextTrack = function(e3, t2, i3) {
        if (!e3)
          throw new Error("TextTrack kind is required but was not provided");
        return function(e4, t3, i4, n3, r2) {
          void 0 === r2 && (r2 = {});
          var a2 = e4.textTracks();
          return r2.kind = t3, i4 && (r2.label = i4), n3 && (r2.language = n3), r2.tech = e4, r2 = new oi.text.TrackClass(r2), a2.addTrack(r2), r2;
        }(this, e3, t2, i3);
      }, e2.createRemoteTextTrack = function(e3) {
        e3 = lt(e3, { tech: this });
        return new si.remoteTextEl.TrackClass(e3);
      }, e2.addRemoteTextTrack = function(e3, t2) {
        var i3 = this, n3 = this.createRemoteTextTrack(e3 = void 0 === e3 ? {} : e3);
        return true !== t2 && false !== t2 && (h.warn('Calling addRemoteTextTrack without explicitly setting the "manualCleanup" parameter to `true` is deprecated and default to `false` in future version of video.js'), t2 = true), this.remoteTextTrackEls().addTrackElement_(n3), this.remoteTextTracks().addTrack(n3.track), true !== t2 && this.ready(function() {
          return i3.autoRemoteTextTracks_.addTrack(n3.track);
        }), n3;
      }, e2.removeRemoteTextTrack = function(e3) {
        var t2 = this.remoteTextTrackEls().getTrackElementByTrack_(e3);
        this.remoteTextTrackEls().removeTrackElement_(t2), this.remoteTextTracks().removeTrack(e3), this.autoRemoteTextTracks_.removeTrack(e3);
      }, e2.getVideoPlaybackQuality = function() {
        return {};
      }, e2.requestPictureInPicture = function() {
        var e3 = this.options_.Promise || window.Promise;
        if (e3)
          return e3.reject();
      }, e2.disablePictureInPicture = function() {
        return true;
      }, e2.setDisablePictureInPicture = function() {
      }, e2.requestVideoFrameCallback = function(e3) {
        var t2 = this, i3 = Pe++;
        return !this.isReady_ || this.paused() ? (this.queuedHanders_.add(i3), this.one("playing", function() {
          t2.queuedHanders_.has(i3) && (t2.queuedHanders_.delete(i3), e3());
        })) : this.requestNamedAnimationFrame(i3, e3), i3;
      }, e2.cancelVideoFrameCallback = function(e3) {
        this.queuedHanders_.has(e3) ? this.queuedHanders_.delete(e3) : this.cancelNamedAnimationFrame(e3);
      }, e2.setPoster = function() {
      }, e2.playsinline = function() {
      }, e2.setPlaysinline = function() {
      }, e2.overrideNativeAudioTracks = function() {
      }, e2.overrideNativeVideoTracks = function() {
      }, e2.canPlayType = function() {
        return "";
      }, i2.canPlayType = function() {
        return "";
      }, i2.canPlaySource = function(e3, t2) {
        return i2.canPlayType(e3.type);
      }, i2.isTech = function(e3) {
        return e3.prototype instanceof i2 || e3 instanceof i2 || e3 === i2;
      }, i2.registerTech = function(e3, t2) {
        if (i2.techs_ || (i2.techs_ = {}), !i2.isTech(t2))
          throw new Error("Tech " + e3 + " must be a Tech");
        if (!i2.canPlayType)
          throw new Error("Techs must have a static canPlayType method on them");
        if (!i2.canPlaySource)
          throw new Error("Techs must have a static canPlaySource method on them");
        return e3 = ut(e3), i2.techs_[e3] = t2, i2.techs_[ot(e3)] = t2, "Tech" !== e3 && i2.defaultTechOrder_.push(e3), t2;
      }, i2.getTech = function(e3) {
        if (e3)
          return i2.techs_ && i2.techs_[e3] ? i2.techs_[e3] : (e3 = ut(e3), window && window.videojs && window.videojs[e3] ? (h.warn("The " + e3 + " tech was added to the videojs object when it should be registered using videojs.registerTech(name, tech)"), window.videojs[e3]) : void 0);
      }, i2;
    }(pt);
    oi.names.forEach(function(e2) {
      var t2 = oi[e2];
      ji.prototype[t2.getterName] = function() {
        return this[t2.privateName] = this[t2.privateName] || new t2.ListClass(), this[t2.privateName];
      };
    }), ji.prototype.featuresVolumeControl = true, ji.prototype.featuresMuteControl = true, ji.prototype.featuresFullscreenResize = false, ji.prototype.featuresPlaybackRate = false, ji.prototype.featuresProgressEvents = false, ji.prototype.featuresSourceset = false, ji.prototype.featuresTimeupdateEvents = false, ji.prototype.featuresNativeTextTracks = false, ji.prototype.featuresVideoFrameCallback = false, ji.withSourceHandlers = function(r2) {
      r2.registerSourceHandler = function(e2, t2) {
        var i2 = (i2 = r2.sourceHandlers) || (r2.sourceHandlers = []);
        void 0 === t2 && (t2 = i2.length), i2.splice(t2, 0, e2);
      }, r2.canPlayType = function(e2) {
        for (var t2, i2 = r2.sourceHandlers || [], n2 = 0; n2 < i2.length; n2++)
          if (t2 = i2[n2].canPlayType(e2))
            return t2;
        return "";
      }, r2.selectSourceHandler = function(e2, t2) {
        for (var i2 = r2.sourceHandlers || [], n2 = 0; n2 < i2.length; n2++)
          if (i2[n2].canHandleSource(e2, t2))
            return i2[n2];
        return null;
      }, r2.canPlaySource = function(e2, t2) {
        var i2 = r2.selectSourceHandler(e2, t2);
        return i2 ? i2.canHandleSource(e2, t2) : "";
      };
      ["seekable", "seeking", "duration"].forEach(function(e2) {
        var t2 = this[e2];
        "function" == typeof t2 && (this[e2] = function() {
          return this.sourceHandler_ && this.sourceHandler_[e2] ? this.sourceHandler_[e2].apply(this.sourceHandler_, arguments) : t2.apply(this, arguments);
        });
      }, r2.prototype), r2.prototype.setSource = function(e2) {
        var t2 = r2.selectSourceHandler(e2, this.options_);
        t2 || (r2.nativeSourceHandler ? t2 = r2.nativeSourceHandler : h.error("No source handler found for the current source.")), this.disposeSourceHandler(), this.off("dispose", this.disposeSourceHandler_), t2 !== r2.nativeSourceHandler && (this.currentSource_ = e2), this.sourceHandler_ = t2.handleSource(e2, this, this.options_), this.one("dispose", this.disposeSourceHandler_);
      }, r2.prototype.disposeSourceHandler = function() {
        this.currentSource_ && (this.clearTracks(["audio", "video"]), this.currentSource_ = null), this.cleanupAutoTextTracks(), this.sourceHandler_ && (this.sourceHandler_.dispose && this.sourceHandler_.dispose(), this.sourceHandler_ = null);
      };
    }, pt.registerComponent("Tech", ji), ji.registerTech("Tech", ji), ji.defaultTechOrder_ = [];
    var Hi = {}, Vi = {}, qi = {};
    function Wi(e2, t2, i2) {
      e2.setTimeout(function() {
        return function i3(n2, e3, r2, a2, s2, o2) {
          void 0 === n2 && (n2 = {});
          void 0 === e3 && (e3 = []);
          void 0 === s2 && (s2 = []);
          void 0 === o2 && (o2 = false);
          var t3 = e3, e3 = t3[0], u2 = t3.slice(1);
          if ("string" == typeof e3)
            i3(n2, Hi[e3], r2, a2, s2, o2);
          else if (e3) {
            var l2 = Qi(a2, e3);
            if (!l2.setSource)
              return s2.push(l2), i3(n2, u2, r2, a2, s2, o2);
            l2.setSource(b({}, n2), function(e4, t4) {
              return e4 ? i3(n2, u2, r2, a2, s2, o2) : (s2.push(l2), void i3(t4, n2.type === t4.type ? u2 : Hi[t4.type], r2, a2, s2, o2));
            });
          } else
            u2.length ? i3(n2, u2, r2, a2, s2, o2) : o2 ? r2(n2, s2) : i3(n2, Hi["*"], r2, a2, s2, true);
        }(t2, Hi[t2.type], i2, e2);
      }, 1);
    }
    function Gi(e2, t2, i2, n2) {
      void 0 === n2 && (n2 = null);
      var r2 = "call" + ut(i2), r2 = e2.reduce(Yi(r2), n2), n2 = r2 === qi, r2 = n2 ? null : t2[i2](r2);
      return function(e3, t3, i3, n3) {
        for (var r3 = e3.length - 1; 0 <= r3; r3--) {
          var a2 = e3[r3];
          a2[t3] && a2[t3](n3, i3);
        }
      }(e2, i2, r2, n2), r2;
    }
    var zi = { buffered: 1, currentTime: 1, duration: 1, muted: 1, played: 1, paused: 1, seekable: 1, volume: 1, ended: 1 }, Xi = { setCurrentTime: 1, setMuted: 1, setVolume: 1 }, Ki = { play: 1, pause: 1 };
    function Yi(i2) {
      return function(e2, t2) {
        return e2 === qi ? qi : t2[i2] ? t2[i2](e2) : e2;
      };
    }
    function Qi(e2, t2) {
      var i2 = Vi[e2.id()], n2 = null;
      if (null == i2)
        return n2 = t2(e2), Vi[e2.id()] = [[t2, n2]], n2;
      for (var r2 = 0; r2 < i2.length; r2++) {
        var a2 = i2[r2], s2 = a2[0], a2 = a2[1];
        s2 === t2 && (n2 = a2);
      }
      return null === n2 && (n2 = t2(e2), i2.push([t2, n2])), n2;
    }
    function $i(e2) {
      return e2 = Nt(e2 = void 0 === e2 ? "" : e2), Zi[e2.toLowerCase()] || "";
    }
    function Ji(e2) {
      var t2;
      return e2 = Array.isArray(e2) ? (t2 = [], e2.forEach(function(e3) {
        e3 = Ji(e3), Array.isArray(e3) ? t2 = t2.concat(e3) : T(e3) && t2.push(e3);
      }), t2) : "string" == typeof e2 && e2.trim() ? [en({ src: e2 })] : T(e2) && "string" == typeof e2.src && e2.src && e2.src.trim() ? [en(e2)] : [];
    }
    var Zi = { opus: "video/ogg", ogv: "video/ogg", mp4: "video/mp4", mov: "video/mp4", m4v: "video/mp4", mkv: "video/x-matroska", m4a: "audio/mp4", mp3: "audio/mpeg", aac: "audio/aac", caf: "audio/x-caf", flac: "audio/flac", oga: "audio/ogg", wav: "audio/wav", m3u8: "application/x-mpegURL", mpd: "application/dash+xml", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", png: "image/png", svg: "image/svg+xml", webp: "image/webp" };
    function en(e2) {
      var t2;
      return e2.type || (t2 = $i(e2.src)) && (e2.type = t2), e2;
    }
    I = function(u2) {
      function e2(e3, t2, i2) {
        var n2 = lt({ createEl: false }, t2), i2 = u2.call(this, e3, n2, i2) || this;
        if (t2.playerOptions.sources && 0 !== t2.playerOptions.sources.length)
          e3.src(t2.playerOptions.sources);
        else
          for (var r2 = 0, a2 = t2.playerOptions.techOrder; r2 < a2.length; r2++) {
            var s2 = ut(a2[r2]), o2 = ji.getTech(s2);
            if ((o2 = !s2 ? pt.getComponent(s2) : o2) && o2.isSupported()) {
              e3.loadTech_(s2);
              break;
            }
          }
        return i2;
      }
      return mt(e2, u2), e2;
    }(pt);
    pt.registerComponent("MediaLoader", I);
    C = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.options_.controlText && i2.controlText(i2.options_.controlText), i2.handleMouseOver_ = function(e4) {
          return i2.handleMouseOver(e4);
        }, i2.handleMouseOut_ = function(e4) {
          return i2.handleMouseOut(e4);
        }, i2.handleClick_ = function(e4) {
          return i2.handleClick(e4);
        }, i2.handleKeyDown_ = function(e4) {
          return i2.handleKeyDown(e4);
        }, i2.emitTapEvents(), i2.enable(), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.createEl = function(e3, t3, i2) {
        void 0 === e3 && (e3 = "div"), void 0 === t3 && (t3 = {}), void 0 === i2 && (i2 = {}), t3 = b({ className: this.buildCSSClass(), tabIndex: 0 }, t3), "button" === e3 && h.error("Creating a ClickableComponent with an HTML element of " + e3 + " is not supported; use a Button instead."), i2 = b({ role: "button" }, i2), this.tabIndex_ = t3.tabIndex;
        i2 = $(e3, t3, i2);
        return i2.appendChild($("span", { className: "vjs-icon-placeholder" }, { "aria-hidden": true })), this.createControlTextEl(i2), i2;
      }, t2.dispose = function() {
        this.controlTextEl_ = null, n2.prototype.dispose.call(this);
      }, t2.createControlTextEl = function(e3) {
        return this.controlTextEl_ = $("span", { className: "vjs-control-text" }, { "aria-live": "polite" }), e3 && e3.appendChild(this.controlTextEl_), this.controlText(this.controlText_, e3), this.controlTextEl_;
      }, t2.controlText = function(e3, t3) {
        if (void 0 === t3 && (t3 = this.el()), void 0 === e3)
          return this.controlText_ || "Need Text";
        var i2 = this.localize(e3);
        this.controlText_ = e3, J(this.controlTextEl_, i2), this.nonIconControl || this.player_.options_.noUITitleAttributes || t3.setAttribute("title", i2);
      }, t2.buildCSSClass = function() {
        return "vjs-control vjs-button " + n2.prototype.buildCSSClass.call(this);
      }, t2.enable = function() {
        this.enabled_ || (this.enabled_ = true, this.removeClass("vjs-disabled"), this.el_.setAttribute("aria-disabled", "false"), "undefined" != typeof this.tabIndex_ && this.el_.setAttribute("tabIndex", this.tabIndex_), this.on(["tap", "click"], this.handleClick_), this.on("keydown", this.handleKeyDown_));
      }, t2.disable = function() {
        this.enabled_ = false, this.addClass("vjs-disabled"), this.el_.setAttribute("aria-disabled", "true"), "undefined" != typeof this.tabIndex_ && this.el_.removeAttribute("tabIndex"), this.off("mouseover", this.handleMouseOver_), this.off("mouseout", this.handleMouseOut_), this.off(["tap", "click"], this.handleClick_), this.off("keydown", this.handleKeyDown_);
      }, t2.handleLanguagechange = function() {
        this.controlText(this.controlText_);
      }, t2.handleClick = function(e3) {
        this.options_.clickHandler && this.options_.clickHandler.call(this, arguments);
      }, t2.handleKeyDown = function(e3) {
        ht.isEventKey(e3, "Space") || ht.isEventKey(e3, "Enter") ? (e3.preventDefault(), e3.stopPropagation(), this.trigger("click")) : n2.prototype.handleKeyDown.call(this, e3);
      }, e2;
    }(pt);
    pt.registerComponent("ClickableComponent", C), pt.registerComponent("PosterImage", function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.update(), i2.update_ = function(e4) {
          return i2.update(e4);
        }, e3.on("posterchange", i2.update_), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.dispose = function() {
        this.player().off("posterchange", this.update_), n2.prototype.dispose.call(this);
      }, t2.createEl = function() {
        return $("div", { className: "vjs-poster", tabIndex: -1 });
      }, t2.update = function(e3) {
        var t3 = this.player().poster();
        this.setSrc(t3), t3 ? this.show() : this.hide();
      }, t2.setSrc = function(e3) {
        this.el_.style.backgroundImage = e3 ? 'url("' + e3 + '")' : "";
      }, t2.handleClick = function(e3) {
        var t3;
        this.player_.controls() && (t3 = this.player_.usingPlugin("eme") && this.player_.eme.sessions && 0 < this.player_.eme.sessions.length, !this.player_.tech(true) || (N || D) && t3 || this.player_.tech(true).focus(), this.player_.paused() ? Et(this.player_.play()) : this.player_.pause());
      }, e2;
    }(C));
    var tn = "#222", nn = { monospace: "monospace", sansSerif: "sans-serif", serif: "serif", monospaceSansSerif: '"Andale Mono", "Lucida Console", monospace', monospaceSerif: '"Courier New", monospace', proportionalSansSerif: "sans-serif", proportionalSerif: "serif", casual: '"Comic Sans MS", Impact, fantasy', script: '"Monotype Corsiva", cursive', smallcaps: '"Andale Mono", "Lucida Console", monospace, sans-serif' };
    function rn(e2, t2) {
      var i2;
      if (4 === e2.length)
        i2 = e2[1] + e2[1] + e2[2] + e2[2] + e2[3] + e2[3];
      else {
        if (7 !== e2.length)
          throw new Error("Invalid color code provided, " + e2 + "; must be formatted as e.g. #f0e or #f604e2.");
        i2 = e2.slice(1);
      }
      return "rgba(" + parseInt(i2.slice(0, 2), 16) + "," + parseInt(i2.slice(2, 4), 16) + "," + parseInt(i2.slice(4, 6), 16) + "," + t2 + ")";
    }
    function an(e2, t2, i2) {
      try {
        e2.style[t2] = i2;
      } catch (e3) {
        return;
      }
    }
    pt.registerComponent("TextTrackDisplay", function(a2) {
      function e2(i2, e3, t3) {
        function n2(e4) {
          return r2.updateDisplay(e4);
        }
        var r2 = a2.call(this, i2, e3, t3) || this;
        return i2.on("loadstart", function(e4) {
          return r2.toggleDisplay(e4);
        }), i2.on("texttrackchange", n2), i2.on("loadedmetadata", function(e4) {
          return r2.preselectTrack(e4);
        }), i2.ready(qe(ft(r2), function() {
          if (i2.tech_ && i2.tech_.featuresNativeTextTracks)
            this.hide();
          else {
            i2.on("fullscreenchange", n2), i2.on("playerresize", n2), window.addEventListener("orientationchange", n2), i2.on("dispose", function() {
              return window.removeEventListener("orientationchange", n2);
            });
            for (var e4 = this.options_.playerOptions.tracks || [], t4 = 0; t4 < e4.length; t4++)
              this.player_.addRemoteTextTrack(e4[t4], true);
            this.preselectTrack();
          }
        })), r2;
      }
      mt(e2, a2);
      var t2 = e2.prototype;
      return t2.preselectTrack = function() {
        for (var e3, t3, i2, n2 = { captions: 1, subtitles: 1 }, r2 = this.player_.textTracks(), a3 = this.player_.cache_.selectedLanguage, s2 = 0; s2 < r2.length; s2++) {
          var o2 = r2[s2];
          a3 && a3.enabled && a3.language && a3.language === o2.language && o2.kind in n2 ? i2 = o2.kind !== a3.kind && i2 || o2 : a3 && !a3.enabled ? t3 = e3 = i2 = null : o2.default && ("descriptions" !== o2.kind || e3 ? o2.kind in n2 && !t3 && (t3 = o2) : e3 = o2);
        }
        i2 ? i2.mode = "showing" : t3 ? t3.mode = "showing" : e3 && (e3.mode = "showing");
      }, t2.toggleDisplay = function() {
        this.player_.tech_ && this.player_.tech_.featuresNativeTextTracks ? this.hide() : this.show();
      }, t2.createEl = function() {
        return a2.prototype.createEl.call(this, "div", { className: "vjs-text-track-display" }, { translate: "yes", "aria-live": "off", "aria-atomic": "true" });
      }, t2.clearDisplay = function() {
        "function" == typeof window.WebVTT && window.WebVTT.processCues(window, [], this.el_);
      }, t2.updateDisplay = function() {
        var e3 = this.player_.textTracks(), t3 = this.options_.allowMultipleShowingTracks;
        if (this.clearDisplay(), t3) {
          for (var i2 = [], n2 = 0; n2 < e3.length; ++n2) {
            var r2 = e3[n2];
            "showing" === r2.mode && i2.push(r2);
          }
          this.updateForTrack(i2);
        } else {
          for (var a3 = null, s2 = null, o2 = e3.length; o2--; ) {
            var u2 = e3[o2];
            "showing" === u2.mode && ("descriptions" === u2.kind ? a3 = u2 : s2 = u2);
          }
          s2 ? ("off" !== this.getAttribute("aria-live") && this.setAttribute("aria-live", "off"), this.updateForTrack(s2)) : a3 && ("assertive" !== this.getAttribute("aria-live") && this.setAttribute("aria-live", "assertive"), this.updateForTrack(a3));
        }
      }, t2.updateDisplayState = function(e3) {
        for (var t3 = this.player_.textTrackSettings.getValues(), i2 = e3.activeCues, n2 = i2.length; n2--; ) {
          var r2, a3 = i2[n2];
          a3 && (r2 = a3.displayState, t3.color && (r2.firstChild.style.color = t3.color), t3.textOpacity && an(r2.firstChild, "color", rn(t3.color || "#fff", t3.textOpacity)), t3.backgroundColor && (r2.firstChild.style.backgroundColor = t3.backgroundColor), t3.backgroundOpacity && an(r2.firstChild, "backgroundColor", rn(t3.backgroundColor || "#000", t3.backgroundOpacity)), t3.windowColor && (t3.windowOpacity ? an(r2, "backgroundColor", rn(t3.windowColor, t3.windowOpacity)) : r2.style.backgroundColor = t3.windowColor), t3.edgeStyle && ("dropshadow" === t3.edgeStyle ? r2.firstChild.style.textShadow = "2px 2px 3px #222, 2px 2px 4px #222, 2px 2px 5px " + tn : "raised" === t3.edgeStyle ? r2.firstChild.style.textShadow = "1px 1px #222, 2px 2px #222, 3px 3px " + tn : "depressed" === t3.edgeStyle ? r2.firstChild.style.textShadow = "1px 1px #ccc, 0 1px #ccc, -1px -1px #222, 0 -1px " + tn : "uniform" === t3.edgeStyle && (r2.firstChild.style.textShadow = "0 0 4px #222, 0 0 4px #222, 0 0 4px #222, 0 0 4px " + tn)), t3.fontPercent && 1 !== t3.fontPercent && (a3 = window.parseFloat(r2.style.fontSize), r2.style.fontSize = a3 * t3.fontPercent + "px", r2.style.height = "auto", r2.style.top = "auto"), t3.fontFamily && "default" !== t3.fontFamily && ("small-caps" === t3.fontFamily ? r2.firstChild.style.fontVariant = "small-caps" : r2.firstChild.style.fontFamily = nn[t3.fontFamily]));
        }
      }, t2.updateForTrack = function(e3) {
        if (Array.isArray(e3) || (e3 = [e3]), "function" == typeof window.WebVTT && !e3.every(function(e4) {
          return !e4.activeCues;
        })) {
          for (var t3 = [], i2 = 0; i2 < e3.length; ++i2)
            for (var n2 = e3[i2], r2 = 0; r2 < n2.activeCues.length; ++r2)
              t3.push(n2.activeCues[r2]);
          window.WebVTT.processCues(window, t3, this.el_);
          for (var a3 = 0; a3 < e3.length; ++a3) {
            for (var s2 = e3[a3], o2 = 0; o2 < s2.activeCues.length; ++o2) {
              var u2 = s2.activeCues[o2].displayState;
              te(u2, "vjs-text-track-cue"), te(u2, "vjs-text-track-cue-" + (s2.language || a3)), s2.language && oe(u2, "lang", s2.language);
            }
            this.player_.textTrackSettings && this.updateDisplayState(s2);
          }
        }
      }, e2;
    }(pt)), pt.registerComponent("LoadingSpinner", function(i2) {
      function e2() {
        return i2.apply(this, arguments) || this;
      }
      return mt(e2, i2), e2.prototype.createEl = function() {
        var e3 = this.player_.isAudio(), t2 = this.localize(e3 ? "Audio Player" : "Video Player"), e3 = $("span", { className: "vjs-control-text", textContent: this.localize("{1} is loading.", [t2]) }), t2 = i2.prototype.createEl.call(this, "div", { className: "vjs-loading-spinner", dir: "ltr" });
        return t2.appendChild(e3), t2;
      }, e2;
    }(pt));
    var sn = function(t2) {
      function e2() {
        return t2.apply(this, arguments) || this;
      }
      mt(e2, t2);
      var i2 = e2.prototype;
      return i2.createEl = function(e3, t3, i3) {
        void 0 === t3 && (t3 = {}), void 0 === i3 && (i3 = {});
        i3 = $("button", t3 = b({ className: this.buildCSSClass() }, t3), i3 = b({ type: "button" }, i3));
        return i3.appendChild($("span", { className: "vjs-icon-placeholder" }, { "aria-hidden": true })), this.createControlTextEl(i3), i3;
      }, i2.addChild = function(e3, t3) {
        void 0 === t3 && (t3 = {});
        var i3 = this.constructor.name;
        return h.warn("Adding an actionable (user controllable) child to a Button (" + i3 + ") is not supported; use a ClickableComponent instead."), pt.prototype.addChild.call(this, e3, t3);
      }, i2.enable = function() {
        t2.prototype.enable.call(this), this.el_.removeAttribute("disabled");
      }, i2.disable = function() {
        t2.prototype.disable.call(this), this.el_.setAttribute("disabled", "disabled");
      }, i2.handleKeyDown = function(e3) {
        ht.isEventKey(e3, "Space") || ht.isEventKey(e3, "Enter") ? e3.stopPropagation() : t2.prototype.handleKeyDown.call(this, e3);
      }, e2;
    }(C);
    pt.registerComponent("Button", sn);
    Bt = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.mouseused_ = false, i2.on("mousedown", function(e4) {
          return i2.handleMouseDown(e4);
        }), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-big-play-button";
      }, t2.handleClick = function(e3) {
        var t3 = this.player_.play();
        if (this.mouseused_ && e3.clientX && e3.clientY) {
          var i2 = this.player_.usingPlugin("eme") && this.player_.eme.sessions && 0 < this.player_.eme.sessions.length;
          return Et(t3), void (!this.player_.tech(true) || (N || D) && i2 || this.player_.tech(true).focus());
        }
        var i2 = this.player_.getChild("controlBar"), n3 = i2 && i2.getChild("playToggle");
        n3 ? (i2 = function() {
          return n3.focus();
        }, St(t3) ? t3.then(i2, function() {
        }) : this.setTimeout(i2, 1)) : this.player_.tech(true).focus();
      }, t2.handleKeyDown = function(e3) {
        this.mouseused_ = false, n2.prototype.handleKeyDown.call(this, e3);
      }, t2.handleMouseDown = function(e3) {
        this.mouseused_ = true;
      }, e2;
    }(sn);
    Bt.prototype.controlText_ = "Play Video", pt.registerComponent("BigPlayButton", Bt), pt.registerComponent("CloseButton", function(i2) {
      function e2(e3, t3) {
        e3 = i2.call(this, e3, t3) || this;
        return e3.controlText(t3 && t3.controlText || e3.localize("Close")), e3;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-close-button " + i2.prototype.buildCSSClass.call(this);
      }, t2.handleClick = function(e3) {
        this.trigger({ type: "close", bubbles: false });
      }, t2.handleKeyDown = function(e3) {
        ht.isEventKey(e3, "Esc") ? (e3.preventDefault(), e3.stopPropagation(), this.trigger("click")) : i2.prototype.handleKeyDown.call(this, e3);
      }, e2;
    }(sn));
    Ft = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3 = void 0 === t3 ? {} : t3) || this;
        return t3.replay = void 0 === t3.replay || t3.replay, i2.on(e3, "play", function(e4) {
          return i2.handlePlay(e4);
        }), i2.on(e3, "pause", function(e4) {
          return i2.handlePause(e4);
        }), t3.replay && i2.on(e3, "ended", function(e4) {
          return i2.handleEnded(e4);
        }), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-play-control " + n2.prototype.buildCSSClass.call(this);
      }, t2.handleClick = function(e3) {
        this.player_.paused() ? Et(this.player_.play()) : this.player_.pause();
      }, t2.handleSeeked = function(e3) {
        this.removeClass("vjs-ended"), this.player_.paused() ? this.handlePause(e3) : this.handlePlay(e3);
      }, t2.handlePlay = function(e3) {
        this.removeClass("vjs-ended"), this.removeClass("vjs-paused"), this.addClass("vjs-playing"), this.controlText("Pause");
      }, t2.handlePause = function(e3) {
        this.removeClass("vjs-playing"), this.addClass("vjs-paused"), this.controlText("Play");
      }, t2.handleEnded = function(e3) {
        var t3 = this;
        this.removeClass("vjs-playing"), this.addClass("vjs-ended"), this.controlText("Replay"), this.one(this.player_, "seeked", function(e4) {
          return t3.handleSeeked(e4);
        });
      }, e2;
    }(sn);
    Ft.prototype.controlText_ = "Play", pt.registerComponent("PlayToggle", Ft);
    function on(e2, t2) {
      e2 = e2 < 0 ? 0 : e2;
      var i2 = Math.floor(e2 % 60), n2 = Math.floor(e2 / 60 % 60), r2 = Math.floor(e2 / 3600), a2 = Math.floor(t2 / 60 % 60), t2 = Math.floor(t2 / 3600);
      return (r2 = 0 < (r2 = isNaN(e2) || e2 === 1 / 0 ? n2 = i2 = "-" : r2) || 0 < t2 ? r2 + ":" : "") + (n2 = ((r2 || 10 <= a2) && n2 < 10 ? "0" + n2 : n2) + ":") + (i2 = i2 < 10 ? "0" + i2 : i2);
    }
    var un = on;
    function ln(e2, t2) {
      return un(e2, t2 = void 0 === t2 ? e2 : t2);
    }
    k = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.on(e3, ["timeupdate", "ended"], function(e4) {
          return i2.updateContent(e4);
        }), i2.updateTextNode_(), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        var e3 = this.buildCSSClass(), t3 = n2.prototype.createEl.call(this, "div", { className: e3 + " vjs-time-control vjs-control" }), i2 = $("span", { className: "vjs-control-text", textContent: this.localize(this.labelText_) + "\xA0" }, { role: "presentation" });
        return t3.appendChild(i2), this.contentEl_ = $("span", { className: e3 + "-display" }, { "aria-live": "off", role: "presentation" }), t3.appendChild(this.contentEl_), t3;
      }, t2.dispose = function() {
        this.contentEl_ = null, this.textNode_ = null, n2.prototype.dispose.call(this);
      }, t2.updateTextNode_ = function(e3) {
        var t3 = this;
        e3 = ln(e3 = void 0 === e3 ? 0 : e3), this.formattedTime_ !== e3 && (this.formattedTime_ = e3, this.requestNamedAnimationFrame("TimeDisplay#updateTextNode_", function() {
          var e4;
          t3.contentEl_ && ((e4 = t3.textNode_) && t3.contentEl_.firstChild !== e4 && (e4 = null, h.warn("TimeDisplay#updateTextnode_: Prevented replacement of text node element since it was no longer a child of this node. Appending a new node instead.")), t3.textNode_ = document.createTextNode(t3.formattedTime_), t3.textNode_ && (e4 ? t3.contentEl_.replaceChild(t3.textNode_, e4) : t3.contentEl_.appendChild(t3.textNode_)));
        }));
      }, t2.updateContent = function(e3) {
      }, e2;
    }(pt);
    k.prototype.labelText_ = "Time", k.prototype.controlText_ = "Time", pt.registerComponent("TimeDisplay", k);
    jt = function(e2) {
      function t2() {
        return e2.apply(this, arguments) || this;
      }
      mt(t2, e2);
      var i2 = t2.prototype;
      return i2.buildCSSClass = function() {
        return "vjs-current-time";
      }, i2.updateContent = function(e3) {
        var t3 = this.player_.ended() ? this.player_.duration() : this.player_.scrubbing() ? this.player_.getCache().currentTime : this.player_.currentTime();
        this.updateTextNode_(t3);
      }, t2;
    }(k);
    jt.prototype.labelText_ = "Current Time", jt.prototype.controlText_ = "Current Time", pt.registerComponent("CurrentTimeDisplay", jt);
    j = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this, t3 = function(e4) {
          return i2.updateContent(e4);
        };
        return i2.on(e3, "durationchange", t3), i2.on(e3, "loadstart", t3), i2.on(e3, "loadedmetadata", t3), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-duration";
      }, t2.updateContent = function(e3) {
        var t3 = this.player_.duration();
        this.updateTextNode_(t3);
      }, e2;
    }(k);
    j.prototype.labelText_ = "Duration", j.prototype.controlText_ = "Duration", pt.registerComponent("DurationDisplay", j), pt.registerComponent("TimeDivider", function(n2) {
      function e2() {
        return n2.apply(this, arguments) || this;
      }
      return mt(e2, n2), e2.prototype.createEl = function() {
        var e3 = n2.prototype.createEl.call(this, "div", { className: "vjs-time-control vjs-time-divider" }, { "aria-hidden": true }), t2 = n2.prototype.createEl.call(this, "div"), i2 = n2.prototype.createEl.call(this, "span", { textContent: "/" });
        return t2.appendChild(i2), e3.appendChild(t2), e3;
      }, e2;
    }(pt));
    f = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.on(e3, "durationchange", function(e4) {
          return i2.updateContent(e4);
        }), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-remaining-time";
      }, t2.createEl = function() {
        var e3 = n2.prototype.createEl.call(this);
        return false !== this.options_.displayNegative && e3.insertBefore($("span", {}, { "aria-hidden": true }, "-"), this.contentEl_), e3;
      }, t2.updateContent = function(e3) {
        var t3;
        "number" == typeof this.player_.duration() && (t3 = this.player_.ended() ? 0 : this.player_.remainingTimeDisplay ? this.player_.remainingTimeDisplay() : this.player_.remainingTime(), this.updateTextNode_(t3));
      }, e2;
    }(k);
    f.prototype.labelText_ = "Remaining Time", f.prototype.controlText_ = "Remaining Time", pt.registerComponent("RemainingTimeDisplay", f), pt.registerComponent("LiveDisplay", function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.updateShowing(), i2.on(i2.player(), "durationchange", function(e4) {
          return i2.updateShowing(e4);
        }), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        var e3 = n2.prototype.createEl.call(this, "div", { className: "vjs-live-control vjs-control" });
        return this.contentEl_ = $("div", { className: "vjs-live-display" }, { "aria-live": "off" }), this.contentEl_.appendChild($("span", { className: "vjs-control-text", textContent: this.localize("Stream Type") + "\xA0" })), this.contentEl_.appendChild(document.createTextNode(this.localize("LIVE"))), e3.appendChild(this.contentEl_), e3;
      }, t2.dispose = function() {
        this.contentEl_ = null, n2.prototype.dispose.call(this);
      }, t2.updateShowing = function(e3) {
        this.player().duration() === 1 / 0 ? this.show() : this.hide();
      }, e2;
    }(pt));
    ui = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.updateLiveEdgeStatus(), i2.player_.liveTracker && (i2.updateLiveEdgeStatusHandler_ = function(e4) {
          return i2.updateLiveEdgeStatus(e4);
        }, i2.on(i2.player_.liveTracker, "liveedgechange", i2.updateLiveEdgeStatusHandler_)), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        var e3 = n2.prototype.createEl.call(this, "button", { className: "vjs-seek-to-live-control vjs-control" });
        return this.textEl_ = $("span", { className: "vjs-seek-to-live-text", textContent: this.localize("LIVE") }, { "aria-hidden": "true" }), e3.appendChild(this.textEl_), e3;
      }, t2.updateLiveEdgeStatus = function() {
        !this.player_.liveTracker || this.player_.liveTracker.atLiveEdge() ? (this.setAttribute("aria-disabled", true), this.addClass("vjs-at-live-edge"), this.controlText("Seek to live, currently playing live")) : (this.setAttribute("aria-disabled", false), this.removeClass("vjs-at-live-edge"), this.controlText("Seek to live, currently behind live"));
      }, t2.handleClick = function() {
        this.player_.liveTracker.seekToLiveEdge();
      }, t2.dispose = function() {
        this.player_.liveTracker && this.off(this.player_.liveTracker, "liveedgechange", this.updateLiveEdgeStatusHandler_), this.textEl_ = null, n2.prototype.dispose.call(this);
      }, e2;
    }(sn);
    ui.prototype.controlText_ = "Seek to live, currently playing live", pt.registerComponent("SeekToLive", ui);
    function dn(e2, t2, i2) {
      return e2 = Number(e2), Math.min(i2, Math.max(t2, isNaN(e2) ? t2 : e2));
    }
    li = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.handleMouseDown_ = function(e4) {
          return i2.handleMouseDown(e4);
        }, i2.handleMouseUp_ = function(e4) {
          return i2.handleMouseUp(e4);
        }, i2.handleKeyDown_ = function(e4) {
          return i2.handleKeyDown(e4);
        }, i2.handleClick_ = function(e4) {
          return i2.handleClick(e4);
        }, i2.handleMouseMove_ = function(e4) {
          return i2.handleMouseMove(e4);
        }, i2.update_ = function(e4) {
          return i2.update(e4);
        }, i2.bar = i2.getChild(i2.options_.barName), i2.vertical(!!i2.options_.vertical), i2.enable(), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.enabled = function() {
        return this.enabled_;
      }, t2.enable = function() {
        this.enabled() || (this.on("mousedown", this.handleMouseDown_), this.on("touchstart", this.handleMouseDown_), this.on("keydown", this.handleKeyDown_), this.on("click", this.handleClick_), this.on(this.player_, "controlsvisible", this.update), this.playerEvent && this.on(this.player_, this.playerEvent, this.update), this.removeClass("disabled"), this.setAttribute("tabindex", 0), this.enabled_ = true);
      }, t2.disable = function() {
        var e3;
        this.enabled() && (e3 = this.bar.el_.ownerDocument, this.off("mousedown", this.handleMouseDown_), this.off("touchstart", this.handleMouseDown_), this.off("keydown", this.handleKeyDown_), this.off("click", this.handleClick_), this.off(this.player_, "controlsvisible", this.update_), this.off(e3, "mousemove", this.handleMouseMove_), this.off(e3, "mouseup", this.handleMouseUp_), this.off(e3, "touchmove", this.handleMouseMove_), this.off(e3, "touchend", this.handleMouseUp_), this.removeAttribute("tabindex"), this.addClass("disabled"), this.playerEvent && this.off(this.player_, this.playerEvent, this.update), this.enabled_ = false);
      }, t2.createEl = function(e3, t3, i2) {
        return void 0 === i2 && (i2 = {}), (t3 = void 0 === t3 ? {} : t3).className = t3.className + " vjs-slider", t3 = b({ tabIndex: 0 }, t3), i2 = b({ role: "slider", "aria-valuenow": 0, "aria-valuemin": 0, "aria-valuemax": 100, tabIndex: 0 }, i2), n2.prototype.createEl.call(this, e3, t3, i2);
      }, t2.handleMouseDown = function(e3) {
        var t3 = this.bar.el_.ownerDocument;
        "mousedown" === e3.type && e3.preventDefault(), "touchstart" !== e3.type || R || e3.preventDefault(), le(), this.addClass("vjs-sliding"), this.trigger("slideractive"), this.on(t3, "mousemove", this.handleMouseMove_), this.on(t3, "mouseup", this.handleMouseUp_), this.on(t3, "touchmove", this.handleMouseMove_), this.on(t3, "touchend", this.handleMouseUp_), this.handleMouseMove(e3, true);
      }, t2.handleMouseMove = function(e3) {
      }, t2.handleMouseUp = function() {
        var e3 = this.bar.el_.ownerDocument;
        de(), this.removeClass("vjs-sliding"), this.trigger("sliderinactive"), this.off(e3, "mousemove", this.handleMouseMove_), this.off(e3, "mouseup", this.handleMouseUp_), this.off(e3, "touchmove", this.handleMouseMove_), this.off(e3, "touchend", this.handleMouseUp_), this.update();
      }, t2.update = function() {
        var t3 = this;
        if (this.el_ && this.bar) {
          var i2 = this.getProgress();
          return i2 === this.progress_ ? i2 : (this.progress_ = i2, this.requestNamedAnimationFrame("Slider#update", function() {
            var e3 = t3.vertical() ? "height" : "width";
            t3.bar.el().style[e3] = (100 * i2).toFixed(2) + "%";
          }), i2);
        }
      }, t2.getProgress = function() {
        return Number(dn(this.getPercent(), 0, 1).toFixed(4));
      }, t2.calculateDistance = function(e3) {
        e3 = pe(this.el_, e3);
        return this.vertical() ? e3.y : e3.x;
      }, t2.handleKeyDown = function(e3) {
        ht.isEventKey(e3, "Left") || ht.isEventKey(e3, "Down") ? (e3.preventDefault(), e3.stopPropagation(), this.stepBack()) : ht.isEventKey(e3, "Right") || ht.isEventKey(e3, "Up") ? (e3.preventDefault(), e3.stopPropagation(), this.stepForward()) : n2.prototype.handleKeyDown.call(this, e3);
      }, t2.handleClick = function(e3) {
        e3.stopPropagation(), e3.preventDefault();
      }, t2.vertical = function(e3) {
        if (void 0 === e3)
          return this.vertical_ || false;
        this.vertical_ = !!e3, this.vertical_ ? this.addClass("vjs-slider-vertical") : this.addClass("vjs-slider-horizontal");
      }, e2;
    }(pt);
    pt.registerComponent("Slider", li);
    function cn(e2, t2) {
      return dn(e2 / t2 * 100, 0, 100).toFixed(2) + "%";
    }
    pt.registerComponent("LoadProgressBar", function(r2) {
      function e2(e3, t3) {
        var i2 = r2.call(this, e3, t3) || this;
        return i2.partEls_ = [], i2.on(e3, "progress", function(e4) {
          return i2.update(e4);
        }), i2;
      }
      mt(e2, r2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        var e3 = r2.prototype.createEl.call(this, "div", { className: "vjs-load-progress" }), t3 = $("span", { className: "vjs-control-text" }), i2 = $("span", { textContent: this.localize("Loaded") }), n2 = document.createTextNode(": ");
        return this.percentageEl_ = $("span", { className: "vjs-control-text-loaded-percentage", textContent: "0%" }), e3.appendChild(t3), t3.appendChild(i2), t3.appendChild(n2), t3.appendChild(this.percentageEl_), e3;
      }, t2.dispose = function() {
        this.partEls_ = null, this.percentageEl_ = null, r2.prototype.dispose.call(this);
      }, t2.update = function(e3) {
        var l2 = this;
        this.requestNamedAnimationFrame("LoadProgressBar#update", function() {
          var e4 = l2.player_.liveTracker, t3 = l2.player_.buffered(), e4 = e4 && e4.isLive() ? e4.seekableEnd() : l2.player_.duration(), i2 = l2.player_.bufferedEnd(), n2 = l2.partEls_, e4 = cn(i2, e4);
          l2.percent_ !== e4 && (l2.el_.style.width = e4, J(l2.percentageEl_, e4), l2.percent_ = e4);
          for (var r3 = 0; r3 < t3.length; r3++) {
            var a2 = t3.start(r3), s2 = t3.end(r3), o2 = n2[r3];
            o2 || (o2 = l2.el_.appendChild($()), n2[r3] = o2), o2.dataset.start === a2 && o2.dataset.end === s2 || (o2.dataset.start = a2, o2.dataset.end = s2, o2.style.left = cn(a2, i2), o2.style.width = cn(s2 - a2, i2));
          }
          for (var u2 = n2.length; u2 > t3.length; u2--)
            l2.el_.removeChild(n2[u2 - 1]);
          n2.length = t3.length;
        });
      }, e2;
    }(pt)), pt.registerComponent("TimeTooltip", function(i2) {
      function e2(e3, t3) {
        t3 = i2.call(this, e3, t3) || this;
        return t3.update = We(qe(ft(t3), t3.update), 30), t3;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        return i2.prototype.createEl.call(this, "div", { className: "vjs-time-tooltip" }, { "aria-hidden": "true" });
      }, t2.update = function(e3, t3, i3) {
        var n2 = he(this.el_), r2 = ce(this.player_.el()), a2 = e3.width * t3;
        r2 && n2 && (t3 = e3.left - r2.left + a2, r2 = e3.width - a2 + (r2.right - e3.right), t3 < (e3 = n2.width / 2) ? e3 += e3 - t3 : r2 < e3 && (e3 = r2), e3 < 0 ? e3 = 0 : e3 > n2.width && (e3 = n2.width), e3 = Math.round(e3), this.el_.style.right = "-" + e3 + "px", this.write(i3));
      }, t2.write = function(e3) {
        J(this.el_, e3);
      }, t2.updateTime = function(n2, r2, a2, s2) {
        var o2 = this;
        this.requestNamedAnimationFrame("TimeTooltip#updateTime", function() {
          var e3, t3, i3 = o2.player_.duration();
          i3 = o2.player_.liveTracker && o2.player_.liveTracker.isLive() ? ((t3 = (e3 = o2.player_.liveTracker.liveWindow()) - r2 * e3) < 1 ? "" : "-") + ln(t3, e3) : ln(a2, i3), o2.update(n2, r2, i3), s2 && s2();
        });
      }, e2;
    }(pt));
    Xt = function(i2) {
      function e2(e3, t3) {
        t3 = i2.call(this, e3, t3) || this;
        return t3.update = We(qe(ft(t3), t3.update), 30), t3;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        return i2.prototype.createEl.call(this, "div", { className: "vjs-play-progress vjs-slider-bar" }, { "aria-hidden": "true" });
      }, t2.update = function(e3, t3) {
        var i3, n2 = this.getChild("timeTooltip");
        n2 && (i3 = this.player_.scrubbing() ? this.player_.getCache().currentTime : this.player_.currentTime(), n2.updateTime(e3, t3, i3));
      }, e2;
    }(pt);
    Xt.prototype.options_ = { children: [] }, V || A || Xt.prototype.options_.children.push("timeTooltip"), pt.registerComponent("PlayProgressBar", Xt);
    I = function(i2) {
      function e2(e3, t3) {
        t3 = i2.call(this, e3, t3) || this;
        return t3.update = We(qe(ft(t3), t3.update), 30), t3;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        return i2.prototype.createEl.call(this, "div", { className: "vjs-mouse-display" });
      }, t2.update = function(e3, t3) {
        var i3 = this, n2 = t3 * this.player_.duration();
        this.getChild("timeTooltip").updateTime(e3, t3, n2, function() {
          i3.el_.style.left = e3.width * t3 + "px";
        });
      }, e2;
    }(pt);
    I.prototype.options_ = { children: ["timeTooltip"] }, pt.registerComponent("MouseTimeDisplay", I);
    Bt = function(a2) {
      function e2(e3, t3) {
        t3 = a2.call(this, e3, t3) || this;
        return t3.setEventHandlers_(), t3;
      }
      mt(e2, a2);
      var t2 = e2.prototype;
      return t2.setEventHandlers_ = function() {
        var t3 = this;
        this.update_ = qe(this, this.update), this.update = We(this.update_, 30), this.on(this.player_, ["ended", "durationchange", "timeupdate"], this.update), this.player_.liveTracker && this.on(this.player_.liveTracker, "liveedgechange", this.update), this.updateInterval = null, this.enableIntervalHandler_ = function(e3) {
          return t3.enableInterval_(e3);
        }, this.disableIntervalHandler_ = function(e3) {
          return t3.disableInterval_(e3);
        }, this.on(this.player_, ["playing"], this.enableIntervalHandler_), this.on(this.player_, ["ended", "pause", "waiting"], this.disableIntervalHandler_), "hidden" in document && "visibilityState" in document && this.on(document, "visibilitychange", this.toggleVisibility_);
      }, t2.toggleVisibility_ = function(e3) {
        "hidden" === document.visibilityState ? (this.cancelNamedAnimationFrame("SeekBar#update"), this.cancelNamedAnimationFrame("Slider#update"), this.disableInterval_(e3)) : (this.player_.ended() || this.player_.paused() || this.enableInterval_(), this.update());
      }, t2.enableInterval_ = function() {
        this.updateInterval || (this.updateInterval = this.setInterval(this.update, 30));
      }, t2.disableInterval_ = function(e3) {
        this.player_.liveTracker && this.player_.liveTracker.isLive() && e3 && "ended" !== e3.type || this.updateInterval && (this.clearInterval(this.updateInterval), this.updateInterval = null);
      }, t2.createEl = function() {
        return a2.prototype.createEl.call(this, "div", { className: "vjs-progress-holder" }, { "aria-label": this.localize("Progress Bar") });
      }, t2.update = function(e3) {
        var n2 = this;
        if ("hidden" !== document.visibilityState) {
          var r2 = a2.prototype.update.call(this);
          return this.requestNamedAnimationFrame("SeekBar#update", function() {
            var e4 = n2.player_.ended() ? n2.player_.duration() : n2.getCurrentTime_(), t3 = n2.player_.liveTracker, i2 = n2.player_.duration();
            t3 && t3.isLive() && (i2 = n2.player_.liveTracker.liveCurrentTime()), n2.percent_ !== r2 && (n2.el_.setAttribute("aria-valuenow", (100 * r2).toFixed(2)), n2.percent_ = r2), n2.currentTime_ === e4 && n2.duration_ === i2 || (n2.el_.setAttribute("aria-valuetext", n2.localize("progress bar timing: currentTime={1} duration={2}", [ln(e4, i2), ln(i2, i2)], "{1} of {2}")), n2.currentTime_ = e4, n2.duration_ = i2), n2.bar && n2.bar.update(ce(n2.el()), n2.getProgress());
          }), r2;
        }
      }, t2.userSeek_ = function(e3) {
        this.player_.liveTracker && this.player_.liveTracker.isLive() && this.player_.liveTracker.nextSeekedFromUser(), this.player_.currentTime(e3);
      }, t2.getCurrentTime_ = function() {
        return this.player_.scrubbing() ? this.player_.getCache().currentTime : this.player_.currentTime();
      }, t2.getPercent = function() {
        var e3, t3 = this.getCurrentTime_(), i2 = this.player_.liveTracker;
        return i2 && i2.isLive() ? (e3 = (t3 - i2.seekableStart()) / i2.liveWindow(), i2.atLiveEdge() && (e3 = 1)) : e3 = t3 / this.player_.duration(), e3;
      }, t2.handleMouseDown = function(e3) {
        _e(e3) && (e3.stopPropagation(), this.videoWasPlaying = !this.player_.paused(), this.player_.pause(), a2.prototype.handleMouseDown.call(this, e3));
      }, t2.handleMouseMove = function(e3, t3) {
        if (void 0 === t3 && (t3 = false), _e(e3)) {
          t3 || this.player_.scrubbing() || this.player_.scrubbing(true);
          var i2 = this.calculateDistance(e3), n2 = this.player_.liveTracker;
          if (n2 && n2.isLive()) {
            if (0.99 <= i2)
              return void n2.seekToLiveEdge();
            var r2, t3 = n2.seekableStart(), e3 = n2.liveCurrentTime();
            if ((r2 = (r2 = e3 <= (r2 = t3 + i2 * n2.liveWindow()) ? e3 : r2) <= t3 ? t3 + 0.1 : r2) === 1 / 0)
              return;
          } else
            (r2 = i2 * this.player_.duration()) === this.player_.duration() && (r2 -= 0.1);
          this.userSeek_(r2);
        }
      }, t2.enable = function() {
        a2.prototype.enable.call(this);
        var e3 = this.getChild("mouseTimeDisplay");
        e3 && e3.show();
      }, t2.disable = function() {
        a2.prototype.disable.call(this);
        var e3 = this.getChild("mouseTimeDisplay");
        e3 && e3.hide();
      }, t2.handleMouseUp = function(e3) {
        a2.prototype.handleMouseUp.call(this, e3), e3 && e3.stopPropagation(), this.player_.scrubbing(false), this.player_.trigger({ type: "timeupdate", target: this, manuallyTriggered: true }), this.videoWasPlaying ? Et(this.player_.play()) : this.update_();
      }, t2.stepForward = function() {
        this.userSeek_(this.player_.currentTime() + 5);
      }, t2.stepBack = function() {
        this.userSeek_(this.player_.currentTime() - 5);
      }, t2.handleAction = function(e3) {
        this.player_.paused() ? this.player_.play() : this.player_.pause();
      }, t2.handleKeyDown = function(e3) {
        var t3, i2 = this.player_.liveTracker;
        ht.isEventKey(e3, "Space") || ht.isEventKey(e3, "Enter") ? (e3.preventDefault(), e3.stopPropagation(), this.handleAction(e3)) : ht.isEventKey(e3, "Home") ? (e3.preventDefault(), e3.stopPropagation(), this.userSeek_(0)) : ht.isEventKey(e3, "End") ? (e3.preventDefault(), e3.stopPropagation(), i2 && i2.isLive() ? this.userSeek_(i2.liveCurrentTime()) : this.userSeek_(this.player_.duration())) : /^[0-9]$/.test(ht(e3)) ? (e3.preventDefault(), e3.stopPropagation(), t3 = 10 * (ht.codes[ht(e3)] - ht.codes[0]) / 100, i2 && i2.isLive() ? this.userSeek_(i2.seekableStart() + i2.liveWindow() * t3) : this.userSeek_(this.player_.duration() * t3)) : ht.isEventKey(e3, "PgDn") ? (e3.preventDefault(), e3.stopPropagation(), this.userSeek_(this.player_.currentTime() - 60)) : ht.isEventKey(e3, "PgUp") ? (e3.preventDefault(), e3.stopPropagation(), this.userSeek_(this.player_.currentTime() + 60)) : a2.prototype.handleKeyDown.call(this, e3);
      }, t2.dispose = function() {
        this.disableInterval_(), this.off(this.player_, ["ended", "durationchange", "timeupdate"], this.update), this.player_.liveTracker && this.off(this.player_.liveTracker, "liveedgechange", this.update), this.off(this.player_, ["playing"], this.enableIntervalHandler_), this.off(this.player_, ["ended", "pause", "waiting"], this.disableIntervalHandler_), "hidden" in document && "visibilityState" in document && this.off(document, "visibilitychange", this.toggleVisibility_), a2.prototype.dispose.call(this);
      }, e2;
    }(li);
    Bt.prototype.options_ = { children: ["loadProgressBar", "playProgressBar"], barName: "playProgressBar" }, V || A || Bt.prototype.options_.children.splice(1, 0, "mouseTimeDisplay"), pt.registerComponent("SeekBar", Bt);
    Ft = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.handleMouseMove = We(qe(ft(i2), i2.handleMouseMove), 30), i2.throttledHandleMouseSeek = We(qe(ft(i2), i2.handleMouseSeek), 30), i2.handleMouseUpHandler_ = function(e4) {
          return i2.handleMouseUp(e4);
        }, i2.handleMouseDownHandler_ = function(e4) {
          return i2.handleMouseDown(e4);
        }, i2.enable(), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        return n2.prototype.createEl.call(this, "div", { className: "vjs-progress-control vjs-control" });
      }, t2.handleMouseMove = function(e3) {
        var t3, i2, n3, r2, a2 = this.getChild("seekBar");
        a2 && (t3 = a2.getChild("playProgressBar"), i2 = a2.getChild("mouseTimeDisplay"), (t3 || i2) && (r2 = he(n3 = a2.el()), e3 = pe(n3, e3).x, e3 = dn(e3, 0, 1), i2 && i2.update(r2, e3), t3 && t3.update(r2, a2.getProgress())));
      }, t2.handleMouseSeek = function(e3) {
        var t3 = this.getChild("seekBar");
        t3 && t3.handleMouseMove(e3);
      }, t2.enabled = function() {
        return this.enabled_;
      }, t2.disable = function() {
        var e3;
        this.children().forEach(function(e4) {
          return e4.disable && e4.disable();
        }), this.enabled() && (this.off(["mousedown", "touchstart"], this.handleMouseDownHandler_), this.off(this.el_, "mousemove", this.handleMouseMove), this.removeListenersAddedOnMousedownAndTouchstart(), this.addClass("disabled"), this.enabled_ = false, this.player_.scrubbing() && (e3 = this.getChild("seekBar"), this.player_.scrubbing(false), e3.videoWasPlaying && Et(this.player_.play())));
      }, t2.enable = function() {
        this.children().forEach(function(e3) {
          return e3.enable && e3.enable();
        }), this.enabled() || (this.on(["mousedown", "touchstart"], this.handleMouseDownHandler_), this.on(this.el_, "mousemove", this.handleMouseMove), this.removeClass("disabled"), this.enabled_ = true);
      }, t2.removeListenersAddedOnMousedownAndTouchstart = function() {
        var e3 = this.el_.ownerDocument;
        this.off(e3, "mousemove", this.throttledHandleMouseSeek), this.off(e3, "touchmove", this.throttledHandleMouseSeek), this.off(e3, "mouseup", this.handleMouseUpHandler_), this.off(e3, "touchend", this.handleMouseUpHandler_);
      }, t2.handleMouseDown = function(e3) {
        var t3 = this.el_.ownerDocument, i2 = this.getChild("seekBar");
        i2 && i2.handleMouseDown(e3), this.on(t3, "mousemove", this.throttledHandleMouseSeek), this.on(t3, "touchmove", this.throttledHandleMouseSeek), this.on(t3, "mouseup", this.handleMouseUpHandler_), this.on(t3, "touchend", this.handleMouseUpHandler_);
      }, t2.handleMouseUp = function(e3) {
        var t3 = this.getChild("seekBar");
        t3 && t3.handleMouseUp(e3), this.removeListenersAddedOnMousedownAndTouchstart();
      }, e2;
    }(pt);
    Ft.prototype.options_ = { children: ["seekBar"] }, pt.registerComponent("ProgressControl", Ft);
    jt = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.on(e3, ["enterpictureinpicture", "leavepictureinpicture"], function(e4) {
          return i2.handlePictureInPictureChange(e4);
        }), i2.on(e3, ["disablepictureinpicturechanged", "loadedmetadata"], function(e4) {
          return i2.handlePictureInPictureEnabledChange(e4);
        }), i2.on(e3, ["loadedmetadata", "audioonlymodechange", "audiopostermodechange"], function() {
          "audio" === e3.currentType().substring(0, 5) || e3.audioPosterMode() || e3.audioOnlyMode() ? (e3.isInPictureInPicture() && e3.exitPictureInPicture(), i2.hide()) : i2.show();
        }), i2.disable(), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-picture-in-picture-control " + n2.prototype.buildCSSClass.call(this);
      }, t2.handlePictureInPictureEnabledChange = function() {
        document.pictureInPictureEnabled && false === this.player_.disablePictureInPicture() ? this.enable() : this.disable();
      }, t2.handlePictureInPictureChange = function(e3) {
        this.player_.isInPictureInPicture() ? this.controlText("Exit Picture-in-Picture") : this.controlText("Picture-in-Picture"), this.handlePictureInPictureEnabledChange();
      }, t2.handleClick = function(e3) {
        this.player_.isInPictureInPicture() ? this.player_.exitPictureInPicture() : this.player_.requestPictureInPicture();
      }, e2;
    }(sn);
    jt.prototype.controlText_ = "Picture-in-Picture", pt.registerComponent("PictureInPictureToggle", jt);
    j = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.on(e3, "fullscreenchange", function(e4) {
          return i2.handleFullscreenChange(e4);
        }), false === document[e3.fsApi_.fullscreenEnabled] && i2.disable(), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-fullscreen-control " + n2.prototype.buildCSSClass.call(this);
      }, t2.handleFullscreenChange = function(e3) {
        this.player_.isFullscreen() ? this.controlText("Non-Fullscreen") : this.controlText("Fullscreen");
      }, t2.handleClick = function(e3) {
        this.player_.isFullscreen() ? this.player_.exitFullscreen() : this.player_.requestFullscreen();
      }, e2;
    }(sn);
    j.prototype.controlText_ = "Fullscreen", pt.registerComponent("FullscreenToggle", j);
    pt.registerComponent("VolumeLevel", function(t2) {
      function e2() {
        return t2.apply(this, arguments) || this;
      }
      return mt(e2, t2), e2.prototype.createEl = function() {
        var e3 = t2.prototype.createEl.call(this, "div", { className: "vjs-volume-level" });
        return e3.appendChild(t2.prototype.createEl.call(this, "span", { className: "vjs-control-text" })), e3;
      }, e2;
    }(pt)), pt.registerComponent("VolumeLevelTooltip", function(i2) {
      function e2(e3, t3) {
        t3 = i2.call(this, e3, t3) || this;
        return t3.update = We(qe(ft(t3), t3.update), 30), t3;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        return i2.prototype.createEl.call(this, "div", { className: "vjs-volume-tooltip" }, { "aria-hidden": "true" });
      }, t2.update = function(e3, t3, i3, n2) {
        if (!i3) {
          var r2 = ce(this.el_), a2 = ce(this.player_.el()), i3 = e3.width * t3;
          if (!a2 || !r2)
            return;
          t3 = e3.left - a2.left + i3, a2 = e3.width - i3 + (a2.right - e3.right), e3 = r2.width / 2;
          t3 < e3 ? e3 += e3 - t3 : a2 < e3 && (e3 = a2), e3 < 0 ? e3 = 0 : e3 > r2.width && (e3 = r2.width), this.el_.style.right = "-" + e3 + "px";
        }
        this.write(n2 + "%");
      }, t2.write = function(e3) {
        J(this.el_, e3);
      }, t2.updateVolume = function(e3, t3, i3, n2, r2) {
        var a2 = this;
        this.requestNamedAnimationFrame("VolumeLevelTooltip#updateVolume", function() {
          a2.update(e3, t3, i3, n2.toFixed(0)), r2 && r2();
        });
      }, e2;
    }(pt));
    k = function(i2) {
      function e2(e3, t3) {
        t3 = i2.call(this, e3, t3) || this;
        return t3.update = We(qe(ft(t3), t3.update), 30), t3;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        return i2.prototype.createEl.call(this, "div", { className: "vjs-mouse-display" });
      }, t2.update = function(e3, t3, i3) {
        var n2 = this, r2 = 100 * t3;
        this.getChild("volumeLevelTooltip").updateVolume(e3, t3, i3, r2, function() {
          i3 ? n2.el_.style.bottom = e3.height * t3 + "px" : n2.el_.style.left = e3.width * t3 + "px";
        });
      }, e2;
    }(pt);
    k.prototype.options_ = { children: ["volumeLevelTooltip"] }, pt.registerComponent("MouseVolumeLevelDisplay", k);
    f = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.on("slideractive", function(e4) {
          return i2.updateLastVolume_(e4);
        }), i2.on(e3, "volumechange", function(e4) {
          return i2.updateARIAAttributes(e4);
        }), e3.ready(function() {
          return i2.updateARIAAttributes();
        }), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        return n2.prototype.createEl.call(this, "div", { className: "vjs-volume-bar vjs-slider-bar" }, { "aria-label": this.localize("Volume Level"), "aria-live": "polite" });
      }, t2.handleMouseDown = function(e3) {
        _e(e3) && n2.prototype.handleMouseDown.call(this, e3);
      }, t2.handleMouseMove = function(e3) {
        var t3, i2, n3, r2 = this.getChild("mouseVolumeLevelDisplay");
        r2 && (t3 = ce(n3 = this.el()), i2 = this.vertical(), n3 = pe(n3, e3), n3 = i2 ? n3.y : n3.x, n3 = dn(n3, 0, 1), r2.update(t3, n3, i2)), _e(e3) && (this.checkMuted(), this.player_.volume(this.calculateDistance(e3)));
      }, t2.checkMuted = function() {
        this.player_.muted() && this.player_.muted(false);
      }, t2.getPercent = function() {
        return this.player_.muted() ? 0 : this.player_.volume();
      }, t2.stepForward = function() {
        this.checkMuted(), this.player_.volume(this.player_.volume() + 0.1);
      }, t2.stepBack = function() {
        this.checkMuted(), this.player_.volume(this.player_.volume() - 0.1);
      }, t2.updateARIAAttributes = function(e3) {
        var t3 = this.player_.muted() ? 0 : this.volumeAsPercentage_();
        this.el_.setAttribute("aria-valuenow", t3), this.el_.setAttribute("aria-valuetext", t3 + "%");
      }, t2.volumeAsPercentage_ = function() {
        return Math.round(100 * this.player_.volume());
      }, t2.updateLastVolume_ = function() {
        var e3 = this, t3 = this.player_.volume();
        this.one("sliderinactive", function() {
          0 === e3.player_.volume() && e3.player_.lastVolume_(t3);
        });
      }, e2;
    }(li);
    f.prototype.options_ = { children: ["volumeLevel"], barName: "volumeLevel" }, V || A || f.prototype.options_.children.splice(0, 0, "mouseVolumeLevelDisplay"), f.prototype.playerEvent = "volumechange", pt.registerComponent("VolumeBar", f);
    ui = function(a2) {
      function e2(e3, t3) {
        var i2, n2, r2;
        return (t3 = void 0 === t3 ? {} : t3).vertical = t3.vertical || false, "undefined" != typeof t3.volumeBar && !w(t3.volumeBar) || (t3.volumeBar = t3.volumeBar || {}, t3.volumeBar.vertical = t3.vertical), i2 = a2.call(this, e3, t3) || this, n2 = ft(i2), (r2 = e3).tech_ && !r2.tech_.featuresVolumeControl && n2.addClass("vjs-hidden"), n2.on(r2, "loadstart", function() {
          r2.tech_.featuresVolumeControl ? n2.removeClass("vjs-hidden") : n2.addClass("vjs-hidden");
        }), i2.throttledHandleMouseMove = We(qe(ft(i2), i2.handleMouseMove), 30), i2.handleMouseUpHandler_ = function(e4) {
          return i2.handleMouseUp(e4);
        }, i2.on("mousedown", function(e4) {
          return i2.handleMouseDown(e4);
        }), i2.on("touchstart", function(e4) {
          return i2.handleMouseDown(e4);
        }), i2.on("mousemove", function(e4) {
          return i2.handleMouseMove(e4);
        }), i2.on(i2.volumeBar, ["focus", "slideractive"], function() {
          i2.volumeBar.addClass("vjs-slider-active"), i2.addClass("vjs-slider-active"), i2.trigger("slideractive");
        }), i2.on(i2.volumeBar, ["blur", "sliderinactive"], function() {
          i2.volumeBar.removeClass("vjs-slider-active"), i2.removeClass("vjs-slider-active"), i2.trigger("sliderinactive");
        }), i2;
      }
      mt(e2, a2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        var e3 = "vjs-volume-horizontal";
        return this.options_.vertical && (e3 = "vjs-volume-vertical"), a2.prototype.createEl.call(this, "div", { className: "vjs-volume-control vjs-control " + e3 });
      }, t2.handleMouseDown = function(e3) {
        var t3 = this.el_.ownerDocument;
        this.on(t3, "mousemove", this.throttledHandleMouseMove), this.on(t3, "touchmove", this.throttledHandleMouseMove), this.on(t3, "mouseup", this.handleMouseUpHandler_), this.on(t3, "touchend", this.handleMouseUpHandler_);
      }, t2.handleMouseUp = function(e3) {
        var t3 = this.el_.ownerDocument;
        this.off(t3, "mousemove", this.throttledHandleMouseMove), this.off(t3, "touchmove", this.throttledHandleMouseMove), this.off(t3, "mouseup", this.handleMouseUpHandler_), this.off(t3, "touchend", this.handleMouseUpHandler_);
      }, t2.handleMouseMove = function(e3) {
        this.volumeBar.handleMouseMove(e3);
      }, e2;
    }(pt);
    ui.prototype.options_ = { children: ["volumeBar"] }, pt.registerComponent("VolumeControl", ui);
    Xt = function(a2) {
      function e2(e3, t3) {
        var i2, n2, r2 = a2.call(this, e3, t3) || this;
        return i2 = ft(r2), (n2 = e3).tech_ && !n2.tech_.featuresMuteControl && i2.addClass("vjs-hidden"), i2.on(n2, "loadstart", function() {
          n2.tech_.featuresMuteControl ? i2.removeClass("vjs-hidden") : i2.addClass("vjs-hidden");
        }), r2.on(e3, ["loadstart", "volumechange"], function(e4) {
          return r2.update(e4);
        }), r2;
      }
      mt(e2, a2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-mute-control " + a2.prototype.buildCSSClass.call(this);
      }, t2.handleClick = function(e3) {
        var t3 = this.player_.volume(), i2 = this.player_.lastVolume_();
        0 === t3 ? (this.player_.volume(i2 < 0.1 ? 0.1 : i2), this.player_.muted(false)) : this.player_.muted(!this.player_.muted());
      }, t2.update = function(e3) {
        this.updateIcon_(), this.updateControlText_();
      }, t2.updateIcon_ = function() {
        var e3 = this.player_.volume(), t3 = 3;
        V && this.player_.tech_ && this.player_.tech_.el_ && this.player_.muted(this.player_.tech_.el_.muted), 0 === e3 || this.player_.muted() ? t3 = 0 : e3 < 0.33 ? t3 = 1 : e3 < 0.67 && (t3 = 2);
        for (var i2 = 0; i2 < 4; i2++)
          ie(this.el_, "vjs-vol-" + i2);
        te(this.el_, "vjs-vol-" + t3);
      }, t2.updateControlText_ = function() {
        var e3 = this.player_.muted() || 0 === this.player_.volume() ? "Unmute" : "Mute";
        this.controlText() !== e3 && this.controlText(e3);
      }, e2;
    }(sn);
    Xt.prototype.controlText_ = "Mute", pt.registerComponent("MuteToggle", Xt);
    I = function(n2) {
      function e2(e3, t3) {
        var i2;
        return "undefined" != typeof (t3 = void 0 === t3 ? {} : t3).inline ? t3.inline = t3.inline : t3.inline = true, "undefined" != typeof t3.volumeControl && !w(t3.volumeControl) || (t3.volumeControl = t3.volumeControl || {}, t3.volumeControl.vertical = !t3.inline), (i2 = n2.call(this, e3, t3) || this).handleKeyPressHandler_ = function(e4) {
          return i2.handleKeyPress(e4);
        }, i2.on(e3, ["loadstart"], function(e4) {
          return i2.volumePanelState_(e4);
        }), i2.on(i2.muteToggle, "keyup", function(e4) {
          return i2.handleKeyPress(e4);
        }), i2.on(i2.volumeControl, "keyup", function(e4) {
          return i2.handleVolumeControlKeyUp(e4);
        }), i2.on("keydown", function(e4) {
          return i2.handleKeyPress(e4);
        }), i2.on("mouseover", function(e4) {
          return i2.handleMouseOver(e4);
        }), i2.on("mouseout", function(e4) {
          return i2.handleMouseOut(e4);
        }), i2.on(i2.volumeControl, ["slideractive"], i2.sliderActive_), i2.on(i2.volumeControl, ["sliderinactive"], i2.sliderInactive_), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.sliderActive_ = function() {
        this.addClass("vjs-slider-active");
      }, t2.sliderInactive_ = function() {
        this.removeClass("vjs-slider-active");
      }, t2.volumePanelState_ = function() {
        this.volumeControl.hasClass("vjs-hidden") && this.muteToggle.hasClass("vjs-hidden") && this.addClass("vjs-hidden"), this.volumeControl.hasClass("vjs-hidden") && !this.muteToggle.hasClass("vjs-hidden") && this.addClass("vjs-mute-toggle-only");
      }, t2.createEl = function() {
        var e3 = "vjs-volume-panel-horizontal";
        return this.options_.inline || (e3 = "vjs-volume-panel-vertical"), n2.prototype.createEl.call(this, "div", { className: "vjs-volume-panel vjs-control " + e3 });
      }, t2.dispose = function() {
        this.handleMouseOut(), n2.prototype.dispose.call(this);
      }, t2.handleVolumeControlKeyUp = function(e3) {
        ht.isEventKey(e3, "Esc") && this.muteToggle.focus();
      }, t2.handleMouseOver = function(e3) {
        this.addClass("vjs-hover"), Be(document, "keyup", this.handleKeyPressHandler_);
      }, t2.handleMouseOut = function(e3) {
        this.removeClass("vjs-hover"), Fe(document, "keyup", this.handleKeyPressHandler_);
      }, t2.handleKeyPress = function(e3) {
        ht.isEventKey(e3, "Esc") && this.handleMouseOut();
      }, e2;
    }(pt);
    I.prototype.options_ = { children: ["muteToggle", "volumeControl"] }, pt.registerComponent("VolumePanel", I);
    var hn = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return t3 && (i2.menuButton_ = t3.menuButton), i2.focusedChild_ = -1, i2.on("keydown", function(e4) {
          return i2.handleKeyDown(e4);
        }), i2.boundHandleBlur_ = function(e4) {
          return i2.handleBlur(e4);
        }, i2.boundHandleTapClick_ = function(e4) {
          return i2.handleTapClick(e4);
        }, i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.addEventListenerForItem = function(e3) {
        e3 instanceof pt && (this.on(e3, "blur", this.boundHandleBlur_), this.on(e3, ["tap", "click"], this.boundHandleTapClick_));
      }, t2.removeEventListenerForItem = function(e3) {
        e3 instanceof pt && (this.off(e3, "blur", this.boundHandleBlur_), this.off(e3, ["tap", "click"], this.boundHandleTapClick_));
      }, t2.removeChild = function(e3) {
        "string" == typeof e3 && (e3 = this.getChild(e3)), this.removeEventListenerForItem(e3), n2.prototype.removeChild.call(this, e3);
      }, t2.addItem = function(e3) {
        e3 = this.addChild(e3);
        e3 && this.addEventListenerForItem(e3);
      }, t2.createEl = function() {
        var e3 = this.options_.contentElType || "ul";
        this.contentEl_ = $(e3, { className: "vjs-menu-content" }), this.contentEl_.setAttribute("role", "menu");
        e3 = n2.prototype.createEl.call(this, "div", { append: this.contentEl_, className: "vjs-menu" });
        return e3.appendChild(this.contentEl_), Be(e3, "click", function(e4) {
          e4.preventDefault(), e4.stopImmediatePropagation();
        }), e3;
      }, t2.dispose = function() {
        this.contentEl_ = null, this.boundHandleBlur_ = null, this.boundHandleTapClick_ = null, n2.prototype.dispose.call(this);
      }, t2.handleBlur = function(e3) {
        var t3 = e3.relatedTarget || document.activeElement;
        this.children().some(function(e4) {
          return e4.el() === t3;
        }) || (e3 = this.menuButton_) && e3.buttonPressed_ && t3 !== e3.el().firstChild && e3.unpressButton();
      }, t2.handleTapClick = function(t3) {
        var e3;
        this.menuButton_ && (this.menuButton_.unpressButton(), e3 = this.children(), !Array.isArray(e3) || (e3 = e3.filter(function(e4) {
          return e4.el() === t3.target;
        })[0]) && "CaptionSettingsMenuItem" !== e3.name() && this.menuButton_.focus());
      }, t2.handleKeyDown = function(e3) {
        ht.isEventKey(e3, "Left") || ht.isEventKey(e3, "Down") ? (e3.preventDefault(), e3.stopPropagation(), this.stepForward()) : (ht.isEventKey(e3, "Right") || ht.isEventKey(e3, "Up")) && (e3.preventDefault(), e3.stopPropagation(), this.stepBack());
      }, t2.stepForward = function() {
        var e3 = 0;
        void 0 !== this.focusedChild_ && (e3 = this.focusedChild_ + 1), this.focus(e3);
      }, t2.stepBack = function() {
        var e3 = 0;
        void 0 !== this.focusedChild_ && (e3 = this.focusedChild_ - 1), this.focus(e3);
      }, t2.focus = function(e3) {
        void 0 === e3 && (e3 = 0);
        var t3 = this.children().slice();
        t3.length && t3[0].hasClass("vjs-menu-title") && t3.shift(), 0 < t3.length && (e3 < 0 ? e3 = 0 : e3 >= t3.length && (e3 = t3.length - 1), t3[this.focusedChild_ = e3].el_.focus());
      }, e2;
    }(pt);
    pt.registerComponent("Menu", hn);
    Bt = function(n2) {
      function e2(e3, t3) {
        var i2;
        (i2 = n2.call(this, e3, t3 = void 0 === t3 ? {} : t3) || this).menuButton_ = new sn(e3, t3), i2.menuButton_.controlText(i2.controlText_), i2.menuButton_.el_.setAttribute("aria-haspopup", "true");
        t3 = sn.prototype.buildCSSClass();
        i2.menuButton_.el_.className = i2.buildCSSClass() + " " + t3, i2.menuButton_.removeClass("vjs-control"), i2.addChild(i2.menuButton_), i2.update(), i2.enabled_ = true;
        t3 = function(e4) {
          return i2.handleClick(e4);
        };
        return i2.handleMenuKeyUp_ = function(e4) {
          return i2.handleMenuKeyUp(e4);
        }, i2.on(i2.menuButton_, "tap", t3), i2.on(i2.menuButton_, "click", t3), i2.on(i2.menuButton_, "keydown", function(e4) {
          return i2.handleKeyDown(e4);
        }), i2.on(i2.menuButton_, "mouseenter", function() {
          i2.addClass("vjs-hover"), i2.menu.show(), Be(document, "keyup", i2.handleMenuKeyUp_);
        }), i2.on("mouseleave", function(e4) {
          return i2.handleMouseLeave(e4);
        }), i2.on("keydown", function(e4) {
          return i2.handleSubmenuKeyDown(e4);
        }), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.update = function() {
        var e3 = this.createMenu();
        this.menu && (this.menu.dispose(), this.removeChild(this.menu)), this.menu = e3, this.addChild(e3), this.buttonPressed_ = false, this.menuButton_.el_.setAttribute("aria-expanded", "false"), this.items && this.items.length <= this.hideThreshold_ ? (this.hide(), this.menu.contentEl_.removeAttribute("role")) : (this.show(), this.menu.contentEl_.setAttribute("role", "menu"));
      }, t2.createMenu = function() {
        var e3, t3 = new hn(this.player_, { menuButton: this });
        if (this.hideThreshold_ = 0, this.options_.title && (e3 = $("li", { className: "vjs-menu-title", textContent: ut(this.options_.title), tabIndex: -1 }), e3 = new pt(this.player_, { el: e3 }), t3.addItem(e3)), this.items = this.createItems(), this.items)
          for (var i2 = 0; i2 < this.items.length; i2++)
            t3.addItem(this.items[i2]);
        return t3;
      }, t2.createItems = function() {
      }, t2.createEl = function() {
        return n2.prototype.createEl.call(this, "div", { className: this.buildWrapperCSSClass() }, {});
      }, t2.buildWrapperCSSClass = function() {
        var e3 = "vjs-menu-button";
        return true === this.options_.inline ? e3 += "-inline" : e3 += "-popup", "vjs-menu-button " + e3 + " " + sn.prototype.buildCSSClass() + " " + n2.prototype.buildCSSClass.call(this);
      }, t2.buildCSSClass = function() {
        var e3 = "vjs-menu-button";
        return true === this.options_.inline ? e3 += "-inline" : e3 += "-popup", "vjs-menu-button " + e3 + " " + n2.prototype.buildCSSClass.call(this);
      }, t2.controlText = function(e3, t3) {
        return void 0 === t3 && (t3 = this.menuButton_.el()), this.menuButton_.controlText(e3, t3);
      }, t2.dispose = function() {
        this.handleMouseLeave(), n2.prototype.dispose.call(this);
      }, t2.handleClick = function(e3) {
        this.buttonPressed_ ? this.unpressButton() : this.pressButton();
      }, t2.handleMouseLeave = function(e3) {
        this.removeClass("vjs-hover"), Fe(document, "keyup", this.handleMenuKeyUp_);
      }, t2.focus = function() {
        this.menuButton_.focus();
      }, t2.blur = function() {
        this.menuButton_.blur();
      }, t2.handleKeyDown = function(e3) {
        ht.isEventKey(e3, "Esc") || ht.isEventKey(e3, "Tab") ? (this.buttonPressed_ && this.unpressButton(), ht.isEventKey(e3, "Tab") || (e3.preventDefault(), this.menuButton_.focus())) : (ht.isEventKey(e3, "Up") || ht.isEventKey(e3, "Down")) && (this.buttonPressed_ || (e3.preventDefault(), this.pressButton()));
      }, t2.handleMenuKeyUp = function(e3) {
        (ht.isEventKey(e3, "Esc") || ht.isEventKey(e3, "Tab")) && this.removeClass("vjs-hover");
      }, t2.handleSubmenuKeyPress = function(e3) {
        this.handleSubmenuKeyDown(e3);
      }, t2.handleSubmenuKeyDown = function(e3) {
        (ht.isEventKey(e3, "Esc") || ht.isEventKey(e3, "Tab")) && (this.buttonPressed_ && this.unpressButton(), ht.isEventKey(e3, "Tab") || (e3.preventDefault(), this.menuButton_.focus()));
      }, t2.pressButton = function() {
        this.enabled_ && (this.buttonPressed_ = true, this.menu.show(), this.menu.lockShowing(), this.menuButton_.el_.setAttribute("aria-expanded", "true"), V && Y() || this.menu.focus());
      }, t2.unpressButton = function() {
        this.enabled_ && (this.buttonPressed_ = false, this.menu.unlockShowing(), this.menu.hide(), this.menuButton_.el_.setAttribute("aria-expanded", "false"));
      }, t2.disable = function() {
        this.unpressButton(), this.enabled_ = false, this.addClass("vjs-disabled"), this.menuButton_.disable();
      }, t2.enable = function() {
        this.enabled_ = true, this.removeClass("vjs-disabled"), this.menuButton_.enable();
      }, e2;
    }(pt);
    pt.registerComponent("MenuButton", Bt);
    Ft = function(r2) {
      function e2(e3, t2) {
        var i2 = t2.tracks, t2 = r2.call(this, e3, t2) || this;
        if (t2.items.length <= 1 && t2.hide(), !i2)
          return ft(t2);
        var n2 = qe(ft(t2), t2.update);
        return i2.addEventListener("removetrack", n2), i2.addEventListener("addtrack", n2), i2.addEventListener("labelchange", n2), t2.player_.on("ready", n2), t2.player_.on("dispose", function() {
          i2.removeEventListener("removetrack", n2), i2.removeEventListener("addtrack", n2), i2.removeEventListener("labelchange", n2);
        }), t2;
      }
      return mt(e2, r2), e2;
    }(Bt);
    pt.registerComponent("TrackButton", Ft);
    var pn = ["Tab", "Esc", "Up", "Down", "Right", "Left"], jt = function(n2) {
      function e2(e3, t3) {
        e3 = n2.call(this, e3, t3) || this;
        return e3.selectable = t3.selectable, e3.isSelected_ = t3.selected || false, e3.multiSelectable = t3.multiSelectable, e3.selected(e3.isSelected_), e3.selectable ? e3.multiSelectable ? e3.el_.setAttribute("role", "menuitemcheckbox") : e3.el_.setAttribute("role", "menuitemradio") : e3.el_.setAttribute("role", "menuitem"), e3;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.createEl = function(e3, t3, i2) {
        this.nonIconControl = true;
        i2 = n2.prototype.createEl.call(this, "li", b({ className: "vjs-menu-item", tabIndex: -1 }, t3), i2);
        return i2.replaceChild($("span", { className: "vjs-menu-item-text", textContent: this.localize(this.options_.label) }), i2.querySelector(".vjs-icon-placeholder")), i2;
      }, t2.handleKeyDown = function(t3) {
        pn.some(function(e3) {
          return ht.isEventKey(t3, e3);
        }) || n2.prototype.handleKeyDown.call(this, t3);
      }, t2.handleClick = function(e3) {
        this.selected(true);
      }, t2.selected = function(e3) {
        this.selectable && (e3 ? (this.addClass("vjs-selected"), this.el_.setAttribute("aria-checked", "true"), this.controlText(", selected"), this.isSelected_ = true) : (this.removeClass("vjs-selected"), this.el_.setAttribute("aria-checked", "false"), this.controlText(""), this.isSelected_ = false));
      }, e2;
    }(C);
    pt.registerComponent("MenuItem", jt);
    var fn = function(u2) {
      function e2(e3, t3) {
        var n2, i2 = t3.track, r2 = e3.textTracks();
        t3.label = i2.label || i2.language || "Unknown", t3.selected = "showing" === i2.mode, (n2 = u2.call(this, e3, t3) || this).track = i2, n2.kinds = (t3.kinds || [t3.kind || n2.track.kind]).filter(Boolean);
        function a2() {
          for (var e4 = arguments.length, t4 = new Array(e4), i3 = 0; i3 < e4; i3++)
            t4[i3] = arguments[i3];
          n2.handleTracksChange.apply(ft(n2), t4);
        }
        function s2() {
          for (var e4 = arguments.length, t4 = new Array(e4), i3 = 0; i3 < e4; i3++)
            t4[i3] = arguments[i3];
          n2.handleSelectedLanguageChange.apply(ft(n2), t4);
        }
        var o2;
        return e3.on(["loadstart", "texttrackchange"], a2), r2.addEventListener("change", a2), r2.addEventListener("selectedlanguagechange", s2), n2.on("dispose", function() {
          e3.off(["loadstart", "texttrackchange"], a2), r2.removeEventListener("change", a2), r2.removeEventListener("selectedlanguagechange", s2);
        }), void 0 === r2.onchange && n2.on(["tap", "click"], function() {
          if ("object" != typeof window.Event)
            try {
              o2 = new window.Event("change");
            } catch (e4) {
            }
          o2 || (o2 = document.createEvent("Event")).initEvent("change", true, true), r2.dispatchEvent(o2);
        }), n2.handleTracksChange(), n2;
      }
      mt(e2, u2);
      var t2 = e2.prototype;
      return t2.handleClick = function(e3) {
        var t3 = this.track, i2 = this.player_.textTracks();
        if (u2.prototype.handleClick.call(this, e3), i2)
          for (var n2 = 0; n2 < i2.length; n2++) {
            var r2 = i2[n2];
            -1 !== this.kinds.indexOf(r2.kind) && (r2 === t3 ? "showing" !== r2.mode && (r2.mode = "showing") : "disabled" !== r2.mode && (r2.mode = "disabled"));
          }
      }, t2.handleTracksChange = function(e3) {
        var t3 = "showing" === this.track.mode;
        t3 !== this.isSelected_ && this.selected(t3);
      }, t2.handleSelectedLanguageChange = function(e3) {
        var t3;
        "showing" === this.track.mode && ((t3 = this.player_.cache_.selectedLanguage) && t3.enabled && t3.language === this.track.language && t3.kind !== this.track.kind || (this.player_.cache_.selectedLanguage = { enabled: true, language: this.track.language, kind: this.track.kind }));
      }, t2.dispose = function() {
        this.track = null, u2.prototype.dispose.call(this);
      }, e2;
    }(jt);
    pt.registerComponent("TextTrackMenuItem", fn);
    var mn = function(i2) {
      function e2(e3, t3) {
        return t3.track = { player: e3, kind: t3.kind, kinds: t3.kinds, default: false, mode: "disabled" }, t3.kinds || (t3.kinds = [t3.kind]), t3.label ? t3.track.label = t3.label : t3.track.label = t3.kinds.join(" and ") + " off", t3.selectable = true, t3.multiSelectable = false, i2.call(this, e3, t3) || this;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.handleTracksChange = function(e3) {
        for (var t3 = this.player().textTracks(), i3 = true, n2 = 0, r2 = t3.length; n2 < r2; n2++) {
          var a2 = t3[n2];
          if (-1 < this.options_.kinds.indexOf(a2.kind) && "showing" === a2.mode) {
            i3 = false;
            break;
          }
        }
        i3 !== this.isSelected_ && this.selected(i3);
      }, t2.handleSelectedLanguageChange = function(e3) {
        for (var t3 = this.player().textTracks(), i3 = true, n2 = 0, r2 = t3.length; n2 < r2; n2++) {
          var a2 = t3[n2];
          if (-1 < ["captions", "descriptions", "subtitles"].indexOf(a2.kind) && "showing" === a2.mode) {
            i3 = false;
            break;
          }
        }
        i3 && (this.player_.cache_.selectedLanguage = { enabled: false });
      }, e2;
    }(fn);
    pt.registerComponent("OffTextTrackMenuItem", mn);
    j = function(i2) {
      function e2(e3, t2) {
        return (t2 = void 0 === t2 ? {} : t2).tracks = e3.textTracks(), i2.call(this, e3, t2) || this;
      }
      return mt(e2, i2), e2.prototype.createItems = function(e3, t2) {
        var i3;
        void 0 === t2 && (t2 = fn), this.label_ && (i3 = this.label_ + " off"), (e3 = void 0 === e3 ? [] : e3).push(new mn(this.player_, { kinds: this.kinds_, kind: this.kind_, label: i3 })), this.hideThreshold_ += 1;
        var n2 = this.player_.textTracks();
        Array.isArray(this.kinds_) || (this.kinds_ = [this.kind_]);
        for (var r2 = 0; r2 < n2.length; r2++) {
          var a2, s2 = n2[r2];
          -1 < this.kinds_.indexOf(s2.kind) && ((a2 = new t2(this.player_, { track: s2, kinds: this.kinds_, kind: this.kind_, selectable: true, multiSelectable: false })).addClass("vjs-" + s2.kind + "-menu-item"), e3.push(a2));
        }
        return e3;
      }, e2;
    }(Ft);
    pt.registerComponent("TextTrackButton", j);
    var gn = function(a2) {
      function e2(e3, t2) {
        var i2 = t2.track, n2 = t2.cue, r2 = e3.currentTime();
        return t2.selectable = true, t2.multiSelectable = false, t2.label = n2.text, t2.selected = n2.startTime <= r2 && r2 < n2.endTime, (t2 = a2.call(this, e3, t2) || this).track = i2, t2.cue = n2, t2;
      }
      return mt(e2, a2), e2.prototype.handleClick = function(e3) {
        a2.prototype.handleClick.call(this), this.player_.currentTime(this.cue.startTime);
      }, e2;
    }(jt);
    pt.registerComponent("ChaptersTrackMenuItem", gn);
    k = function(r2) {
      function e2(e3, t3, i2) {
        var n2 = r2.call(this, e3, t3, i2) || this;
        return n2.selectCurrentItem_ = function() {
          n2.items.forEach(function(e4) {
            e4.selected(n2.track_.activeCues[0] === e4.cue);
          });
        }, n2;
      }
      mt(e2, r2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-chapters-button " + r2.prototype.buildCSSClass.call(this);
      }, t2.buildWrapperCSSClass = function() {
        return "vjs-chapters-button " + r2.prototype.buildWrapperCSSClass.call(this);
      }, t2.update = function(e3) {
        e3 && e3.track && "chapters" !== e3.track.kind || ((e3 = this.findChaptersTrack()) !== this.track_ ? (this.setTrack(e3), r2.prototype.update.call(this)) : (!this.items || e3 && e3.cues && e3.cues.length !== this.items.length) && r2.prototype.update.call(this));
      }, t2.setTrack = function(e3) {
        var t3;
        this.track_ !== e3 && (this.updateHandler_ || (this.updateHandler_ = this.update.bind(this)), this.track_ && ((t3 = this.player_.remoteTextTrackEls().getTrackElementByTrack_(this.track_)) && t3.removeEventListener("load", this.updateHandler_), this.track_.removeEventListener("cuechange", this.selectCurrentItem_), this.track_ = null), this.track_ = e3, this.track_ && (this.track_.mode = "hidden", (e3 = this.player_.remoteTextTrackEls().getTrackElementByTrack_(this.track_)) && e3.addEventListener("load", this.updateHandler_), this.track_.addEventListener("cuechange", this.selectCurrentItem_)));
      }, t2.findChaptersTrack = function() {
        for (var e3 = this.player_.textTracks() || [], t3 = e3.length - 1; 0 <= t3; t3--) {
          var i2 = e3[t3];
          if (i2.kind === this.kind_)
            return i2;
        }
      }, t2.getMenuCaption = function() {
        return this.track_ && this.track_.label ? this.track_.label : this.localize(ut(this.kind_));
      }, t2.createMenu = function() {
        return this.options_.title = this.getMenuCaption(), r2.prototype.createMenu.call(this);
      }, t2.createItems = function() {
        var e3 = [];
        if (!this.track_)
          return e3;
        var t3 = this.track_.cues;
        if (!t3)
          return e3;
        for (var i2 = 0, n2 = t3.length; i2 < n2; i2++) {
          var r3 = t3[i2], r3 = new gn(this.player_, { track: this.track_, cue: r3 });
          e3.push(r3);
        }
        return e3;
      }, e2;
    }(j);
    k.prototype.kind_ = "chapters", k.prototype.controlText_ = "Chapters", pt.registerComponent("ChaptersButton", k);
    li = function(a2) {
      function e2(e3, t3, i2) {
        var i2 = a2.call(this, e3, t3, i2) || this, n2 = e3.textTracks(), r2 = qe(ft(i2), i2.handleTracksChange);
        return n2.addEventListener("change", r2), i2.on("dispose", function() {
          n2.removeEventListener("change", r2);
        }), i2;
      }
      mt(e2, a2);
      var t2 = e2.prototype;
      return t2.handleTracksChange = function(e3) {
        for (var t3 = this.player().textTracks(), i2 = false, n2 = 0, r2 = t3.length; n2 < r2; n2++) {
          var a3 = t3[n2];
          if (a3.kind !== this.kind_ && "showing" === a3.mode) {
            i2 = true;
            break;
          }
        }
        i2 ? this.disable() : this.enable();
      }, t2.buildCSSClass = function() {
        return "vjs-descriptions-button " + a2.prototype.buildCSSClass.call(this);
      }, t2.buildWrapperCSSClass = function() {
        return "vjs-descriptions-button " + a2.prototype.buildWrapperCSSClass.call(this);
      }, e2;
    }(j);
    li.prototype.kind_ = "descriptions", li.prototype.controlText_ = "Descriptions", pt.registerComponent("DescriptionsButton", li);
    f = function(n2) {
      function e2(e3, t3, i2) {
        return n2.call(this, e3, t3, i2) || this;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-subtitles-button " + n2.prototype.buildCSSClass.call(this);
      }, t2.buildWrapperCSSClass = function() {
        return "vjs-subtitles-button " + n2.prototype.buildWrapperCSSClass.call(this);
      }, e2;
    }(j);
    f.prototype.kind_ = "subtitles", f.prototype.controlText_ = "Subtitles", pt.registerComponent("SubtitlesButton", f);
    var yn = function(i2) {
      function e2(e3, t2) {
        return t2.track = { player: e3, kind: t2.kind, label: t2.kind + " settings", selectable: false, default: false, mode: "disabled" }, t2.selectable = false, t2.name = "CaptionSettingsMenuItem", (e3 = i2.call(this, e3, t2) || this).addClass("vjs-texttrack-settings"), e3.controlText(", opens " + t2.kind + " settings dialog"), e3;
      }
      return mt(e2, i2), e2.prototype.handleClick = function(e3) {
        this.player().getChild("textTrackSettings").open();
      }, e2;
    }(fn);
    pt.registerComponent("CaptionSettingsMenuItem", yn);
    ui = function(n2) {
      function e2(e3, t3, i2) {
        return n2.call(this, e3, t3, i2) || this;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-captions-button " + n2.prototype.buildCSSClass.call(this);
      }, t2.buildWrapperCSSClass = function() {
        return "vjs-captions-button " + n2.prototype.buildWrapperCSSClass.call(this);
      }, t2.createItems = function() {
        var e3 = [];
        return this.player().tech_ && this.player().tech_.featuresNativeTextTracks || !this.player().getChild("textTrackSettings") || (e3.push(new yn(this.player_, { kind: this.kind_ })), this.hideThreshold_ += 1), n2.prototype.createItems.call(this, e3);
      }, e2;
    }(j);
    ui.prototype.kind_ = "captions", ui.prototype.controlText_ = "Captions", pt.registerComponent("CaptionsButton", ui);
    var vn = function(n2) {
      function e2() {
        return n2.apply(this, arguments) || this;
      }
      return mt(e2, n2), e2.prototype.createEl = function(e3, t2, i2) {
        t2 = n2.prototype.createEl.call(this, e3, t2, i2), i2 = t2.querySelector(".vjs-menu-item-text");
        return "captions" === this.options_.track.kind && (i2.appendChild($("span", { className: "vjs-icon-placeholder" }, { "aria-hidden": true })), i2.appendChild($("span", { className: "vjs-control-text", textContent: " " + this.localize("Captions") }))), t2;
      }, e2;
    }(fn);
    pt.registerComponent("SubsCapsMenuItem", vn);
    Xt = function(i2) {
      function e2(e3, t3) {
        return (t3 = i2.call(this, e3, t3 = void 0 === t3 ? {} : t3) || this).label_ = "subtitles", -1 < ["en", "en-us", "en-ca", "fr-ca"].indexOf(t3.player_.language_) && (t3.label_ = "captions"), t3.menuButton_.controlText(ut(t3.label_)), t3;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-subs-caps-button " + i2.prototype.buildCSSClass.call(this);
      }, t2.buildWrapperCSSClass = function() {
        return "vjs-subs-caps-button " + i2.prototype.buildWrapperCSSClass.call(this);
      }, t2.createItems = function() {
        var e3 = [];
        return this.player().tech_ && this.player().tech_.featuresNativeTextTracks || !this.player().getChild("textTrackSettings") || (e3.push(new yn(this.player_, { kind: this.label_ })), this.hideThreshold_ += 1), e3 = i2.prototype.createItems.call(this, e3, vn);
      }, e2;
    }(j);
    Xt.prototype.kinds_ = ["captions", "subtitles"], Xt.prototype.controlText_ = "Subtitles", pt.registerComponent("SubsCapsButton", Xt);
    var _n = function(s2) {
      function e2(e3, t3) {
        var n2, i2 = t3.track, r2 = e3.audioTracks();
        t3.label = i2.label || i2.language || "Unknown", t3.selected = i2.enabled, (n2 = s2.call(this, e3, t3) || this).track = i2, n2.addClass("vjs-" + i2.kind + "-menu-item");
        function a2() {
          for (var e4 = arguments.length, t4 = new Array(e4), i3 = 0; i3 < e4; i3++)
            t4[i3] = arguments[i3];
          n2.handleTracksChange.apply(ft(n2), t4);
        }
        return r2.addEventListener("change", a2), n2.on("dispose", function() {
          r2.removeEventListener("change", a2);
        }), n2;
      }
      mt(e2, s2);
      var t2 = e2.prototype;
      return t2.createEl = function(e3, t3, i2) {
        t3 = s2.prototype.createEl.call(this, e3, t3, i2), i2 = t3.querySelector(".vjs-menu-item-text");
        return "main-desc" === this.options_.track.kind && (i2.appendChild($("span", { className: "vjs-icon-placeholder" }, { "aria-hidden": true })), i2.appendChild($("span", { className: "vjs-control-text", textContent: " " + this.localize("Descriptions") }))), t3;
      }, t2.handleClick = function(e3) {
        if (s2.prototype.handleClick.call(this, e3), this.track.enabled = true, this.player_.tech_.featuresNativeAudioTracks)
          for (var t3 = this.player_.audioTracks(), i2 = 0; i2 < t3.length; i2++) {
            var n2 = t3[i2];
            n2 !== this.track && (n2.enabled = n2 === this.track);
          }
      }, t2.handleTracksChange = function(e3) {
        this.selected(this.track.enabled);
      }, e2;
    }(jt);
    pt.registerComponent("AudioTrackMenuItem", _n);
    I = function(i2) {
      function e2(e3, t3) {
        return (t3 = void 0 === t3 ? {} : t3).tracks = e3.audioTracks(), i2.call(this, e3, t3) || this;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-audio-button " + i2.prototype.buildCSSClass.call(this);
      }, t2.buildWrapperCSSClass = function() {
        return "vjs-audio-button " + i2.prototype.buildWrapperCSSClass.call(this);
      }, t2.createItems = function(e3) {
        void 0 === e3 && (e3 = []), this.hideThreshold_ = 1;
        for (var t3 = this.player_.audioTracks(), i3 = 0; i3 < t3.length; i3++) {
          var n2 = t3[i3];
          e3.push(new _n(this.player_, { track: n2, selectable: true, multiSelectable: false }));
        }
        return e3;
      }, e2;
    }(Ft);
    I.prototype.controlText_ = "Audio Track", pt.registerComponent("AudioTrackButton", I);
    var bn = function(a2) {
      function e2(e3, t3) {
        var i2, n2 = t3.rate, r2 = parseFloat(n2, 10);
        return t3.label = n2, t3.selected = r2 === e3.playbackRate(), t3.selectable = true, t3.multiSelectable = false, (i2 = a2.call(this, e3, t3) || this).label = n2, i2.rate = r2, i2.on(e3, "ratechange", function(e4) {
          return i2.update(e4);
        }), i2;
      }
      mt(e2, a2);
      var t2 = e2.prototype;
      return t2.handleClick = function(e3) {
        a2.prototype.handleClick.call(this), this.player().playbackRate(this.rate);
      }, t2.update = function(e3) {
        this.selected(this.player().playbackRate() === this.rate);
      }, e2;
    }(jt);
    bn.prototype.contentElType = "button", pt.registerComponent("PlaybackRateMenuItem", bn);
    C = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.menuButton_.el_.setAttribute("aria-describedby", i2.labelElId_), i2.updateVisibility(), i2.updateLabel(), i2.on(e3, "loadstart", function(e4) {
          return i2.updateVisibility(e4);
        }), i2.on(e3, "ratechange", function(e4) {
          return i2.updateLabel(e4);
        }), i2.on(e3, "playbackrateschange", function(e4) {
          return i2.handlePlaybackRateschange(e4);
        }), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        var e3 = n2.prototype.createEl.call(this);
        return this.labelElId_ = "vjs-playback-rate-value-label-" + this.id_, this.labelEl_ = $("div", { className: "vjs-playback-rate-value", id: this.labelElId_, textContent: "1x" }), e3.appendChild(this.labelEl_), e3;
      }, t2.dispose = function() {
        this.labelEl_ = null, n2.prototype.dispose.call(this);
      }, t2.buildCSSClass = function() {
        return "vjs-playback-rate " + n2.prototype.buildCSSClass.call(this);
      }, t2.buildWrapperCSSClass = function() {
        return "vjs-playback-rate " + n2.prototype.buildWrapperCSSClass.call(this);
      }, t2.createItems = function() {
        for (var e3 = this.playbackRates(), t3 = [], i2 = e3.length - 1; 0 <= i2; i2--)
          t3.push(new bn(this.player(), { rate: e3[i2] + "x" }));
        return t3;
      }, t2.updateARIAAttributes = function() {
        this.el().setAttribute("aria-valuenow", this.player().playbackRate());
      }, t2.handleClick = function(e3) {
        var t3 = this.player().playbackRate(), i2 = this.playbackRates(), t3 = (i2.indexOf(t3) + 1) % i2.length;
        this.player().playbackRate(i2[t3]);
      }, t2.handlePlaybackRateschange = function(e3) {
        this.update();
      }, t2.playbackRates = function() {
        var e3 = this.player();
        return e3.playbackRates && e3.playbackRates() || [];
      }, t2.playbackRateSupported = function() {
        return this.player().tech_ && this.player().tech_.featuresPlaybackRate && this.playbackRates() && 0 < this.playbackRates().length;
      }, t2.updateVisibility = function(e3) {
        this.playbackRateSupported() ? this.removeClass("vjs-hidden") : this.addClass("vjs-hidden");
      }, t2.updateLabel = function(e3) {
        this.playbackRateSupported() && (this.labelEl_.textContent = this.player().playbackRate() + "x");
      }, e2;
    }(Bt);
    C.prototype.controlText_ = "Playback Rate", pt.registerComponent("PlaybackRateMenuButton", C);
    k = function(n2) {
      function e2() {
        return n2.apply(this, arguments) || this;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-spacer " + n2.prototype.buildCSSClass.call(this);
      }, t2.createEl = function(e3, t3, i2) {
        return void 0 === e3 && (e3 = "div"), void 0 === i2 && (i2 = {}), (t3 = void 0 === t3 ? {} : t3).className || (t3.className = this.buildCSSClass()), n2.prototype.createEl.call(this, e3, t3, i2);
      }, e2;
    }(pt);
    pt.registerComponent("Spacer", k), pt.registerComponent("CustomControlSpacer", function(e2) {
      function t2() {
        return e2.apply(this, arguments) || this;
      }
      mt(t2, e2);
      var i2 = t2.prototype;
      return i2.buildCSSClass = function() {
        return "vjs-custom-control-spacer " + e2.prototype.buildCSSClass.call(this);
      }, i2.createEl = function() {
        return e2.prototype.createEl.call(this, "div", { className: this.buildCSSClass(), textContent: "\xA0" });
      }, t2;
    }(k));
    li = function(e2) {
      function t2() {
        return e2.apply(this, arguments) || this;
      }
      return mt(t2, e2), t2.prototype.createEl = function() {
        return e2.prototype.createEl.call(this, "div", { className: "vjs-control-bar", dir: "ltr" });
      }, t2;
    }(pt);
    li.prototype.options_ = { children: ["playToggle", "volumePanel", "currentTimeDisplay", "timeDivider", "durationDisplay", "progressControl", "liveDisplay", "seekToLive", "remainingTimeDisplay", "customControlSpacer", "playbackRateMenuButton", "chaptersButton", "descriptionsButton", "subsCapsButton", "audioTrackButton", "fullscreenToggle"] }, "exitPictureInPicture" in document && li.prototype.options_.children.splice(li.prototype.options_.children.length - 1, 0, "pictureInPictureToggle"), pt.registerComponent("ControlBar", li);
    f = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this, e3, t3) || this;
        return i2.on(e3, "error", function(e4) {
          return i2.open(e4);
        }), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.buildCSSClass = function() {
        return "vjs-error-display " + n2.prototype.buildCSSClass.call(this);
      }, t2.content = function() {
        var e3 = this.player().error();
        return e3 ? this.localize(e3.message) : "";
      }, e2;
    }(At);
    f.prototype.options_ = g({}, At.prototype.options_, { pauseOnOpen: false, fillAlways: true, temporary: false, uncloseable: true }), pt.registerComponent("ErrorDisplay", f);
    var Tn = "vjs-text-track-settings", ui = ["#000", "Black"], j = ["#00F", "Blue"], Xt = ["#0FF", "Cyan"], Ft = ["#0F0", "Green"], I = ["#F0F", "Magenta"], jt = ["#F00", "Red"], Bt = ["#FFF", "White"], C = ["#FF0", "Yellow"], k = ["1", "Opaque"], li = ["0.5", "Semi-Transparent"], f = ["0", "Transparent"], wn = { backgroundColor: { selector: ".vjs-bg-color > select", id: "captions-background-color-%s", label: "Color", options: [ui, Bt, jt, Ft, j, C, I, Xt] }, backgroundOpacity: { selector: ".vjs-bg-opacity > select", id: "captions-background-opacity-%s", label: "Transparency", options: [k, li, f] }, color: { selector: ".vjs-fg-color > select", id: "captions-foreground-color-%s", label: "Color", options: [Bt, ui, jt, Ft, j, C, I, Xt] }, edgeStyle: { selector: ".vjs-edge-style > select", id: "%s", label: "Text Edge Style", options: [["none", "None"], ["raised", "Raised"], ["depressed", "Depressed"], ["uniform", "Uniform"], ["dropshadow", "Dropshadow"]] }, fontFamily: { selector: ".vjs-font-family > select", id: "captions-font-family-%s", label: "Font Family", options: [["proportionalSansSerif", "Proportional Sans-Serif"], ["monospaceSansSerif", "Monospace Sans-Serif"], ["proportionalSerif", "Proportional Serif"], ["monospaceSerif", "Monospace Serif"], ["casual", "Casual"], ["script", "Script"], ["small-caps", "Small Caps"]] }, fontPercent: { selector: ".vjs-font-percent > select", id: "captions-font-size-%s", label: "Font Size", options: [["0.50", "50%"], ["0.75", "75%"], ["1.00", "100%"], ["1.25", "125%"], ["1.50", "150%"], ["1.75", "175%"], ["2.00", "200%"], ["3.00", "300%"], ["4.00", "400%"]], default: 2, parser: function(e2) {
      return "1.00" === e2 ? null : Number(e2);
    } }, textOpacity: { selector: ".vjs-text-opacity > select", id: "captions-foreground-opacity-%s", label: "Transparency", options: [k, li] }, windowColor: { selector: ".vjs-window-color > select", id: "captions-window-color-%s", label: "Color" }, windowOpacity: { selector: ".vjs-window-opacity > select", id: "captions-window-opacity-%s", label: "Transparency", options: [f, li, k] } };
    function Sn(e2, t2) {
      if ((e2 = t2 ? t2(e2) : e2) && "none" !== e2)
        return e2;
    }
    wn.windowColor.options = wn.backgroundColor.options, pt.registerComponent("TextTrackSettings", function(n2) {
      function e2(e3, t3) {
        var i2;
        return t3.temporary = false, (i2 = n2.call(this, e3, t3) || this).updateDisplay = i2.updateDisplay.bind(ft(i2)), i2.fill(), i2.hasBeenOpened_ = i2.hasBeenFilled_ = true, i2.endDialog = $("p", { className: "vjs-control-text", textContent: i2.localize("End of dialog window.") }), i2.el().appendChild(i2.endDialog), i2.setDefaults(), void 0 === t3.persistTextTrackSettings && (i2.options_.persistTextTrackSettings = i2.options_.playerOptions.persistTextTrackSettings), i2.on(i2.$(".vjs-done-button"), "click", function() {
          i2.saveSettings(), i2.close();
        }), i2.on(i2.$(".vjs-default-button"), "click", function() {
          i2.setDefaults(), i2.updateDisplay();
        }), _(wn, function(e4) {
          i2.on(i2.$(e4.selector), "change", i2.updateDisplay);
        }), i2.options_.persistTextTrackSettings && i2.restoreSettings(), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.dispose = function() {
        this.endDialog = null, n2.prototype.dispose.call(this);
      }, t2.createElSelect_ = function(e3, t3, i2) {
        var n3 = this;
        void 0 === t3 && (t3 = ""), void 0 === i2 && (i2 = "label");
        var e3 = wn[e3], r2 = e3.id.replace("%s", this.id_), a2 = [t3, r2].join(" ").trim();
        return ["<" + i2 + ' id="' + r2 + '" class="' + ("label" === i2 ? "vjs-label" : "") + '">', this.localize(e3.label), "</" + i2 + ">", '<select aria-labelledby="' + a2 + '">'].concat(e3.options.map(function(e4) {
          var t4 = r2 + "-" + e4[1].replace(/\W+/g, "");
          return ['<option id="' + t4 + '" value="' + e4[0] + '" ', 'aria-labelledby="' + a2 + " " + t4 + '">', n3.localize(e4[1]), "</option>"].join("");
        })).concat("</select>").join("");
      }, t2.createElFgColor_ = function() {
        var e3 = "captions-text-legend-" + this.id_;
        return ['<fieldset class="vjs-fg-color vjs-track-setting">', '<legend id="' + e3 + '">', this.localize("Text"), "</legend>", this.createElSelect_("color", e3), '<span class="vjs-text-opacity vjs-opacity">', this.createElSelect_("textOpacity", e3), "</span>", "</fieldset>"].join("");
      }, t2.createElBgColor_ = function() {
        var e3 = "captions-background-" + this.id_;
        return ['<fieldset class="vjs-bg-color vjs-track-setting">', '<legend id="' + e3 + '">', this.localize("Background"), "</legend>", this.createElSelect_("backgroundColor", e3), '<span class="vjs-bg-opacity vjs-opacity">', this.createElSelect_("backgroundOpacity", e3), "</span>", "</fieldset>"].join("");
      }, t2.createElWinColor_ = function() {
        var e3 = "captions-window-" + this.id_;
        return ['<fieldset class="vjs-window-color vjs-track-setting">', '<legend id="' + e3 + '">', this.localize("Window"), "</legend>", this.createElSelect_("windowColor", e3), '<span class="vjs-window-opacity vjs-opacity">', this.createElSelect_("windowOpacity", e3), "</span>", "</fieldset>"].join("");
      }, t2.createElColors_ = function() {
        return $("div", { className: "vjs-track-settings-colors", innerHTML: [this.createElFgColor_(), this.createElBgColor_(), this.createElWinColor_()].join("") });
      }, t2.createElFont_ = function() {
        return $("div", { className: "vjs-track-settings-font", innerHTML: ['<fieldset class="vjs-font-percent vjs-track-setting">', this.createElSelect_("fontPercent", "", "legend"), "</fieldset>", '<fieldset class="vjs-edge-style vjs-track-setting">', this.createElSelect_("edgeStyle", "", "legend"), "</fieldset>", '<fieldset class="vjs-font-family vjs-track-setting">', this.createElSelect_("fontFamily", "", "legend"), "</fieldset>"].join("") });
      }, t2.createElControls_ = function() {
        var e3 = this.localize("restore all settings to the default values");
        return $("div", { className: "vjs-track-settings-controls", innerHTML: ['<button type="button" class="vjs-default-button" title="' + e3 + '">', this.localize("Reset"), '<span class="vjs-control-text"> ' + e3 + "</span>", "</button>", '<button type="button" class="vjs-done-button">' + this.localize("Done") + "</button>"].join("") });
      }, t2.content = function() {
        return [this.createElColors_(), this.createElFont_(), this.createElControls_()];
      }, t2.label = function() {
        return this.localize("Caption Settings Dialog");
      }, t2.description = function() {
        return this.localize("Beginning of dialog window. Escape will cancel and close the window.");
      }, t2.buildCSSClass = function() {
        return n2.prototype.buildCSSClass.call(this) + " vjs-text-track-settings";
      }, t2.getValues = function() {
        var i2, n3, e3, r2 = this;
        return n3 = function(e4, t3, i3) {
          var n4, t3 = (n4 = r2.$(t3.selector), t3 = t3.parser, Sn(n4.options[n4.options.selectedIndex].value, t3));
          return void 0 !== t3 && (e4[i3] = t3), e4;
        }, void 0 === (e3 = {}) && (e3 = 0), v(i2 = wn).reduce(function(e4, t3) {
          return n3(e4, i2[t3], t3);
        }, e3);
      }, t2.setValues = function(i2) {
        var n3 = this;
        _(wn, function(e3, t3) {
          !function(e4, t4, i3) {
            if (t4) {
              for (var n4 = 0; n4 < e4.options.length; n4++)
                if (Sn(e4.options[n4].value, i3) === t4) {
                  e4.selectedIndex = n4;
                  break;
                }
            }
          }(n3.$(e3.selector), i2[t3], e3.parser);
        });
      }, t2.setDefaults = function() {
        var i2 = this;
        _(wn, function(e3) {
          var t3 = e3.hasOwnProperty("default") ? e3.default : 0;
          i2.$(e3.selector).selectedIndex = t3;
        });
      }, t2.restoreSettings = function() {
        var e3;
        try {
          e3 = JSON.parse(window.localStorage.getItem(Tn));
        } catch (e4) {
          h.warn(e4);
        }
        e3 && this.setValues(e3);
      }, t2.saveSettings = function() {
        if (this.options_.persistTextTrackSettings) {
          var e3 = this.getValues();
          try {
            Object.keys(e3).length ? window.localStorage.setItem(Tn, JSON.stringify(e3)) : window.localStorage.removeItem(Tn);
          } catch (e4) {
            h.warn(e4);
          }
        }
      }, t2.updateDisplay = function() {
        var e3 = this.player_.getChild("textTrackDisplay");
        e3 && e3.updateDisplay();
      }, t2.conditionalBlur_ = function() {
        this.previouslyActiveEl_ = null;
        var e3 = this.player_.controlBar, t3 = e3 && e3.subsCapsButton, e3 = e3 && e3.captionsButton;
        t3 ? t3.focus() : e3 && e3.focus();
      }, e2;
    }(At)), pt.registerComponent("ResizeManager", function(a2) {
      function e2(e3, t3) {
        var i2, n2 = t3.ResizeObserver || window.ResizeObserver, r2 = lt({ createEl: !(n2 = null === t3.ResizeObserver ? false : n2), reportTouchActivity: false }, t3);
        return (i2 = a2.call(this, e3, r2) || this).ResizeObserver = t3.ResizeObserver || window.ResizeObserver, i2.loadListener_ = null, i2.resizeObserver_ = null, i2.debouncedHandler_ = Ge(function() {
          i2.resizeHandler();
        }, 100, false, ft(i2)), n2 ? (i2.resizeObserver_ = new i2.ResizeObserver(i2.debouncedHandler_), i2.resizeObserver_.observe(e3.el())) : (i2.loadListener_ = function() {
          var e4, t4;
          i2.el_ && i2.el_.contentWindow && (e4 = i2.debouncedHandler_, t4 = i2.unloadListener_ = function() {
            Fe(this, "resize", e4), Fe(this, "unload", t4), t4 = null;
          }, Be(i2.el_.contentWindow, "unload", t4), Be(i2.el_.contentWindow, "resize", e4));
        }, i2.one("load", i2.loadListener_)), i2;
      }
      mt(e2, a2);
      var t2 = e2.prototype;
      return t2.createEl = function() {
        return a2.prototype.createEl.call(this, "iframe", { className: "vjs-resize-manager", tabIndex: -1, title: this.localize("No content") }, { "aria-hidden": "true" });
      }, t2.resizeHandler = function() {
        this.player_ && this.player_.trigger && this.player_.trigger("playerresize");
      }, t2.dispose = function() {
        this.debouncedHandler_ && this.debouncedHandler_.cancel(), this.resizeObserver_ && (this.player_.el() && this.resizeObserver_.unobserve(this.player_.el()), this.resizeObserver_.disconnect()), this.loadListener_ && this.off("load", this.loadListener_), this.el_ && this.el_.contentWindow && this.unloadListener_ && this.unloadListener_.call(this.el_.contentWindow), this.ResizeObserver = null, this.resizeObserver = null, this.debouncedHandler_ = null, this.loadListener_ = null, a2.prototype.dispose.call(this);
      }, e2;
    }(pt));
    var En = { trackingThreshold: 20, liveTolerance: 15 };
    pt.registerComponent("LiveTracker", function(n2) {
      function e2(e3, t3) {
        var t3 = lt(En, t3, { createEl: false }), i2 = n2.call(this, e3, t3) || this;
        return i2.handleVisibilityChange_ = function(e4) {
          return i2.handleVisibilityChange(e4);
        }, i2.trackLiveHandler_ = function() {
          return i2.trackLive_();
        }, i2.handlePlay_ = function(e4) {
          return i2.handlePlay(e4);
        }, i2.handleFirstTimeupdate_ = function(e4) {
          return i2.handleFirstTimeupdate(e4);
        }, i2.handleSeeked_ = function(e4) {
          return i2.handleSeeked(e4);
        }, i2.seekToLiveEdge_ = function(e4) {
          return i2.seekToLiveEdge(e4);
        }, i2.reset_(), i2.on(i2.player_, "durationchange", function(e4) {
          return i2.handleDurationchange(e4);
        }), i2.on(i2.player_, "canplay", function() {
          return i2.toggleTracking();
        }), N && "hidden" in document && "visibilityState" in document && i2.on(document, "visibilitychange", i2.handleVisibilityChange_), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.handleVisibilityChange = function() {
        this.player_.duration() === 1 / 0 && (document.hidden ? this.stopTracking() : this.startTracking());
      }, t2.trackLive_ = function() {
        var e3, t3 = this.player_.seekable();
        t3 && t3.length && (e3 = Number(window.performance.now().toFixed(4)), t3 = -1 === this.lastTime_ ? 0 : (e3 - this.lastTime_) / 1e3, this.lastTime_ = e3, this.pastSeekEnd_ = this.pastSeekEnd() + t3, e3 = this.liveCurrentTime(), t3 = this.player_.currentTime(), t3 = this.player_.paused() || this.seekedBehindLive_ || Math.abs(e3 - t3) > this.options_.liveTolerance, (t3 = !this.timeupdateSeen_ || e3 === 1 / 0 ? false : t3) !== this.behindLiveEdge_ && (this.behindLiveEdge_ = t3, this.trigger("liveedgechange")));
      }, t2.handleDurationchange = function() {
        this.toggleTracking();
      }, t2.toggleTracking = function() {
        this.player_.duration() === 1 / 0 && this.liveWindow() >= this.options_.trackingThreshold ? (this.player_.options_.liveui && this.player_.addClass("vjs-liveui"), this.startTracking()) : (this.player_.removeClass("vjs-liveui"), this.stopTracking());
      }, t2.startTracking = function() {
        this.isTracking() || (this.timeupdateSeen_ || (this.timeupdateSeen_ = this.player_.hasStarted()), this.trackingInterval_ = this.setInterval(this.trackLiveHandler_, 30), this.trackLive_(), this.on(this.player_, ["play", "pause"], this.trackLiveHandler_), this.timeupdateSeen_ ? this.on(this.player_, "seeked", this.handleSeeked_) : (this.one(this.player_, "play", this.handlePlay_), this.one(this.player_, "timeupdate", this.handleFirstTimeupdate_)));
      }, t2.handleFirstTimeupdate = function() {
        this.timeupdateSeen_ = true, this.on(this.player_, "seeked", this.handleSeeked_);
      }, t2.handleSeeked = function() {
        var e3 = Math.abs(this.liveCurrentTime() - this.player_.currentTime());
        this.seekedBehindLive_ = this.nextSeekedFromUser_ && 2 < e3, this.nextSeekedFromUser_ = false, this.trackLive_();
      }, t2.handlePlay = function() {
        this.one(this.player_, "timeupdate", this.seekToLiveEdge_);
      }, t2.reset_ = function() {
        this.lastTime_ = -1, this.pastSeekEnd_ = 0, this.lastSeekEnd_ = -1, this.behindLiveEdge_ = true, this.timeupdateSeen_ = false, this.seekedBehindLive_ = false, this.nextSeekedFromUser_ = false, this.clearInterval(this.trackingInterval_), this.trackingInterval_ = null, this.off(this.player_, ["play", "pause"], this.trackLiveHandler_), this.off(this.player_, "seeked", this.handleSeeked_), this.off(this.player_, "play", this.handlePlay_), this.off(this.player_, "timeupdate", this.handleFirstTimeupdate_), this.off(this.player_, "timeupdate", this.seekToLiveEdge_);
      }, t2.nextSeekedFromUser = function() {
        this.nextSeekedFromUser_ = true;
      }, t2.stopTracking = function() {
        this.isTracking() && (this.reset_(), this.trigger("liveedgechange"));
      }, t2.seekableEnd = function() {
        for (var e3 = this.player_.seekable(), t3 = [], i2 = e3 ? e3.length : 0; i2--; )
          t3.push(e3.end(i2));
        return t3.length ? t3.sort()[t3.length - 1] : 1 / 0;
      }, t2.seekableStart = function() {
        for (var e3 = this.player_.seekable(), t3 = [], i2 = e3 ? e3.length : 0; i2--; )
          t3.push(e3.start(i2));
        return t3.length ? t3.sort()[0] : 0;
      }, t2.liveWindow = function() {
        var e3 = this.liveCurrentTime();
        return e3 === 1 / 0 ? 0 : e3 - this.seekableStart();
      }, t2.isLive = function() {
        return this.isTracking();
      }, t2.atLiveEdge = function() {
        return !this.behindLiveEdge();
      }, t2.liveCurrentTime = function() {
        return this.pastSeekEnd() + this.seekableEnd();
      }, t2.pastSeekEnd = function() {
        var e3 = this.seekableEnd();
        return -1 !== this.lastSeekEnd_ && e3 !== this.lastSeekEnd_ && (this.pastSeekEnd_ = 0), this.lastSeekEnd_ = e3, this.pastSeekEnd_;
      }, t2.behindLiveEdge = function() {
        return this.behindLiveEdge_;
      }, t2.isTracking = function() {
        return "number" == typeof this.trackingInterval_;
      }, t2.seekToLiveEdge = function() {
        this.seekedBehindLive_ = false, this.atLiveEdge() || (this.nextSeekedFromUser_ = false, this.player_.currentTime(this.liveCurrentTime()));
      }, t2.dispose = function() {
        this.off(document, "visibilitychange", this.handleVisibilityChange_), this.stopTracking(), n2.prototype.dispose.call(this);
      }, e2;
    }(pt));
    function kn(e2) {
      if ((n2 = e2.el()).hasAttribute("src"))
        return e2.triggerSourceset(n2.src), 1;
      var t2 = e2.$$("source"), i2 = [], n2 = "";
      if (t2.length) {
        for (var r2 = 0; r2 < t2.length; r2++) {
          var a2 = t2[r2].src;
          a2 && -1 === i2.indexOf(a2) && i2.push(a2);
        }
        return !!i2.length && (1 === i2.length && (n2 = i2[0]), e2.triggerSourceset(n2), true);
      }
    }
    function Cn(e2, t2) {
      for (var i2 = {}, n2 = 0; n2 < e2.length && !((i2 = Object.getOwnPropertyDescriptor(e2[n2], t2)) && i2.set && i2.get); n2++)
        ;
      return i2.enumerable = true, i2.configurable = true, i2;
    }
    function In(a2) {
      var t2, e2, i2, s2 = a2.el();
      s2.resetSourceWatch_ || (t2 = {}, e2 = Cn([a2.el(), window.HTMLMediaElement.prototype, window.Element.prototype, Ln], "innerHTML"), i2 = function(r2) {
        return function() {
          for (var e3 = arguments.length, t3 = new Array(e3), i3 = 0; i3 < e3; i3++)
            t3[i3] = arguments[i3];
          var n2 = r2.apply(s2, t3);
          return kn(a2), n2;
        };
      }, ["append", "appendChild", "insertAdjacentHTML"].forEach(function(e3) {
        s2[e3] && (t2[e3] = s2[e3], s2[e3] = i2(t2[e3]));
      }), Object.defineProperty(s2, "innerHTML", lt(e2, { set: i2(e2.set) })), s2.resetSourceWatch_ = function() {
        s2.resetSourceWatch_ = null, Object.keys(t2).forEach(function(e3) {
          s2[e3] = t2[e3];
        }), Object.defineProperty(s2, "innerHTML", e2);
      }, a2.one("sourceset", s2.resetSourceWatch_));
    }
    function xn(i2) {
      var n2, t2, r2, a2;
      i2.featuresSourceset && ((n2 = i2.el()).resetSourceset_ || (t2 = Cn([i2.el(), window.HTMLMediaElement.prototype, On], "src"), r2 = n2.setAttribute, a2 = n2.load, Object.defineProperty(n2, "src", lt(t2, { set: function(e2) {
        e2 = t2.set.call(n2, e2);
        return i2.triggerSourceset(n2.src), e2;
      } })), n2.setAttribute = function(e2, t3) {
        t3 = r2.call(n2, e2, t3);
        return /src/i.test(e2) && i2.triggerSourceset(n2.src), t3;
      }, n2.load = function() {
        var e2 = a2.call(n2);
        return kn(i2) || (i2.triggerSourceset(""), In(i2)), e2;
      }, n2.currentSrc ? i2.triggerSourceset(n2.currentSrc) : kn(i2) || In(i2), n2.resetSourceset_ = function() {
        n2.resetSourceset_ = null, n2.load = a2, n2.setAttribute = r2, Object.defineProperty(n2, "src", t2), n2.resetSourceWatch_ && n2.resetSourceWatch_();
      }));
    }
    function An(t2, i2, n2, e2) {
      function r2(e3) {
        return Object.defineProperty(t2, i2, { value: e3, enumerable: true, writable: true });
      }
      var a2 = { configurable: true, enumerable: true, get: function() {
        var e3 = n2();
        return r2(e3), e3;
      } };
      return (e2 = void 0 === e2 ? true : e2) && (a2.set = r2), Object.defineProperty(t2, i2, a2);
    }
    var Pn, Ln = Object.defineProperty({}, "innerHTML", { get: function() {
      return this.cloneNode(true).innerHTML;
    }, set: function(e2) {
      var t2 = document.createElement(this.nodeName.toLowerCase());
      t2.innerHTML = e2;
      for (var i2 = document.createDocumentFragment(); t2.childNodes.length; )
        i2.appendChild(t2.childNodes[0]);
      return this.innerText = "", window.Element.prototype.appendChild.call(this, i2), this.innerHTML;
    } }), On = Object.defineProperty({}, "src", { get: function() {
      return this.hasAttribute("src") ? Mt(window.Element.prototype.getAttribute.call(this, "src")) : "";
    }, set: function(e2) {
      return window.Element.prototype.setAttribute.call(this, "src", e2), e2;
    } }), Dn = function(l2) {
      function s2(e3, t2) {
        var i2 = l2.call(this, e3, t2) || this, t2 = e3.source, n2 = false;
        if (i2.featuresVideoFrameCallback = i2.featuresVideoFrameCallback && "VIDEO" === i2.el_.tagName, t2 && (i2.el_.currentSrc !== t2.src || e3.tag && 3 === e3.tag.initNetworkState_) ? i2.setSource(t2) : i2.handleLateInit_(i2.el_), e3.enableSourceset && i2.setupSourcesetHandling_(), i2.isScrubbing_ = false, i2.el_.hasChildNodes()) {
          for (var r2 = i2.el_.childNodes, a2 = r2.length, s3 = []; a2--; ) {
            var o2 = r2[a2];
            "track" === o2.nodeName.toLowerCase() && (i2.featuresNativeTextTracks ? (i2.remoteTextTrackEls().addTrackElement_(o2), i2.remoteTextTracks().addTrack(o2.track), i2.textTracks().addTrack(o2.track), n2 || i2.el_.hasAttribute("crossorigin") || !Ut(o2.src) || (n2 = true)) : s3.push(o2));
          }
          for (var u2 = 0; u2 < s3.length; u2++)
            i2.el_.removeChild(s3[u2]);
        }
        return i2.proxyNativeTracks_(), i2.featuresNativeTextTracks && n2 && h.warn("Text Tracks are being loaded from another origin but the crossorigin attribute isn't used.\nThis may prevent text tracks from loading."), i2.restoreMetadataTracksInIOSNativePlayer_(), (F || H || L) && true === e3.nativeControlsForTouch && i2.setControls(true), i2.proxyWebkitFullscreen_(), i2.triggerReady(), i2;
      }
      mt(s2, l2);
      var e2 = s2.prototype;
      return e2.dispose = function() {
        this.el_ && this.el_.resetSourceset_ && this.el_.resetSourceset_(), s2.disposeMediaElement(this.el_), this.options_ = null, l2.prototype.dispose.call(this);
      }, e2.setupSourcesetHandling_ = function() {
        xn(this);
      }, e2.restoreMetadataTracksInIOSNativePlayer_ = function() {
        function e3() {
          i2 = [];
          for (var e4 = 0; e4 < n2.length; e4++) {
            var t2 = n2[e4];
            "metadata" === t2.kind && i2.push({ track: t2, storedMode: t2.mode });
          }
        }
        var i2, n2 = this.textTracks();
        e3(), n2.addEventListener("change", e3), this.on("dispose", function() {
          return n2.removeEventListener("change", e3);
        });
        function r2() {
          for (var e4 = 0; e4 < i2.length; e4++) {
            var t2 = i2[e4];
            "disabled" === t2.track.mode && t2.track.mode !== t2.storedMode && (t2.track.mode = t2.storedMode);
          }
          n2.removeEventListener("change", r2);
        }
        this.on("webkitbeginfullscreen", function() {
          n2.removeEventListener("change", e3), n2.removeEventListener("change", r2), n2.addEventListener("change", r2);
        }), this.on("webkitendfullscreen", function() {
          n2.removeEventListener("change", e3), n2.addEventListener("change", e3), n2.removeEventListener("change", r2);
        });
      }, e2.overrideNative_ = function(e3, t2) {
        var i2, n2 = this;
        t2 === this["featuresNative" + e3 + "Tracks"] && (this[(i2 = e3.toLowerCase()) + "TracksListeners_"] && Object.keys(this[i2 + "TracksListeners_"]).forEach(function(e4) {
          n2.el()[i2 + "Tracks"].removeEventListener(e4, n2[i2 + "TracksListeners_"][e4]);
        }), this["featuresNative" + e3 + "Tracks"] = !t2, this[i2 + "TracksListeners_"] = null, this.proxyNativeTracksForType_(i2));
      }, e2.overrideNativeAudioTracks = function(e3) {
        this.overrideNative_("Audio", e3);
      }, e2.overrideNativeVideoTracks = function(e3) {
        this.overrideNative_("Video", e3);
      }, e2.proxyNativeTracksForType_ = function(i2) {
        var e3, t2, n2 = this, r2 = ai[i2], a2 = this.el()[r2.getterName], s3 = this[r2.getterName]();
        this["featuresNative" + r2.capitalName + "Tracks"] && a2 && a2.addEventListener && (t2 = function() {
          for (var e4 = [], t3 = 0; t3 < s3.length; t3++) {
            for (var i3 = false, n3 = 0; n3 < a2.length; n3++)
              if (a2[n3] === s3[t3]) {
                i3 = true;
                break;
              }
            i3 || e4.push(s3[t3]);
          }
          for (; e4.length; )
            s3.removeTrack(e4.shift());
        }, this[r2.getterName + "Listeners_"] = e3 = { change: function(e4) {
          var t3 = { type: "change", target: s3, currentTarget: s3, srcElement: s3 };
          s3.trigger(t3), "text" === i2 && n2[si.remoteText.getterName]().trigger(t3);
        }, addtrack: function(e4) {
          s3.addTrack(e4.track);
        }, removetrack: function(e4) {
          s3.removeTrack(e4.track);
        } }, Object.keys(e3).forEach(function(t3) {
          var i3 = e3[t3];
          a2.addEventListener(t3, i3), n2.on("dispose", function(e4) {
            return a2.removeEventListener(t3, i3);
          });
        }), this.on("loadstart", t2), this.on("dispose", function(e4) {
          return n2.off("loadstart", t2);
        }));
      }, e2.proxyNativeTracks_ = function() {
        var t2 = this;
        ai.names.forEach(function(e3) {
          t2.proxyNativeTracksForType_(e3);
        });
      }, e2.createEl = function() {
        var e3, t2 = this.options_.tag;
        t2 && (this.options_.playerElIngest || this.movingMediaElementInDOM) || (t2 ? (e3 = t2.cloneNode(true), t2.parentNode && t2.parentNode.insertBefore(e3, t2), s2.disposeMediaElement(t2), t2 = e3) : (t2 = document.createElement("video"), e3 = lt({}, this.options_.tag && ae(this.options_.tag)), F && true === this.options_.nativeControlsForTouch || delete e3.controls, re(t2, b(e3, { id: this.options_.techId, class: "vjs-tech" }))), t2.playerId = this.options_.playerId), "undefined" != typeof this.options_.preload && oe(t2, "preload", this.options_.preload), void 0 !== this.options_.disablePictureInPicture && (t2.disablePictureInPicture = this.options_.disablePictureInPicture);
        for (var i2 = ["loop", "muted", "playsinline", "autoplay"], n2 = 0; n2 < i2.length; n2++) {
          var r2 = i2[n2], a2 = this.options_[r2];
          "undefined" != typeof a2 && (a2 ? oe(t2, r2, r2) : ue(t2, r2), t2[r2] = a2);
        }
        return t2;
      }, e2.handleLateInit_ = function(e3) {
        if (0 !== e3.networkState && 3 !== e3.networkState) {
          if (0 === e3.readyState) {
            var t2 = false, i2 = function() {
              t2 = true;
            };
            this.on("loadstart", i2);
            var n2 = function() {
              t2 || this.trigger("loadstart");
            };
            return this.on("loadedmetadata", n2), void this.ready(function() {
              this.off("loadstart", i2), this.off("loadedmetadata", n2), t2 || this.trigger("loadstart");
            });
          }
          var r2 = ["loadstart"];
          r2.push("loadedmetadata"), 2 <= e3.readyState && r2.push("loadeddata"), 3 <= e3.readyState && r2.push("canplay"), 4 <= e3.readyState && r2.push("canplaythrough"), this.ready(function() {
            r2.forEach(function(e4) {
              this.trigger(e4);
            }, this);
          });
        }
      }, e2.setScrubbing = function(e3) {
        this.isScrubbing_ = e3;
      }, e2.scrubbing = function() {
        return this.isScrubbing_;
      }, e2.setCurrentTime = function(e3) {
        try {
          this.isScrubbing_ && this.el_.fastSeek && q ? this.el_.fastSeek(e3) : this.el_.currentTime = e3;
        } catch (e4) {
          h(e4, "Video is not ready. (Video.js)");
        }
      }, e2.duration = function() {
        var t2 = this;
        return this.el_.duration === 1 / 0 && A && R && 0 === this.el_.currentTime ? (this.on("timeupdate", function e3() {
          0 < t2.el_.currentTime && (t2.el_.duration === 1 / 0 && t2.trigger("durationchange"), t2.off("timeupdate", e3));
        }), NaN) : this.el_.duration || NaN;
      }, e2.width = function() {
        return this.el_.offsetWidth;
      }, e2.height = function() {
        return this.el_.offsetHeight;
      }, e2.proxyWebkitFullscreen_ = function() {
        var e3, t2, i2 = this;
        "webkitDisplayingFullscreen" in this.el_ && (e3 = function() {
          this.trigger("fullscreenchange", { isFullscreen: false }), this.el_.controls && !this.options_.nativeControlsForTouch && this.controls() && (this.el_.controls = false);
        }, t2 = function() {
          "webkitPresentationMode" in this.el_ && "picture-in-picture" !== this.el_.webkitPresentationMode && (this.one("webkitendfullscreen", e3), this.trigger("fullscreenchange", { isFullscreen: true, nativeIOSFullscreen: true }));
        }, this.on("webkitbeginfullscreen", t2), this.on("dispose", function() {
          i2.off("webkitbeginfullscreen", t2), i2.off("webkitendfullscreen", e3);
        }));
      }, e2.supportsFullScreen = function() {
        if ("function" == typeof this.el_.webkitEnterFullScreen) {
          var e3 = window.navigator && window.navigator.userAgent || "";
          if (/Android/.test(e3) || !/Chrome|Mac OS X 10.5/.test(e3))
            return true;
        }
        return false;
      }, e2.enterFullScreen = function() {
        var e3 = this.el_;
        if (e3.paused && e3.networkState <= e3.HAVE_METADATA)
          Et(this.el_.play()), this.setTimeout(function() {
            e3.pause();
            try {
              e3.webkitEnterFullScreen();
            } catch (e4) {
              this.trigger("fullscreenerror", e4);
            }
          }, 0);
        else
          try {
            e3.webkitEnterFullScreen();
          } catch (e4) {
            this.trigger("fullscreenerror", e4);
          }
      }, e2.exitFullScreen = function() {
        this.el_.webkitDisplayingFullscreen ? this.el_.webkitExitFullScreen() : this.trigger("fullscreenerror", new Error("The video is not fullscreen"));
      }, e2.requestPictureInPicture = function() {
        return this.el_.requestPictureInPicture();
      }, e2.requestVideoFrameCallback = function(e3) {
        return this.featuresVideoFrameCallback && !this.el_.webkitKeys ? this.el_.requestVideoFrameCallback(e3) : l2.prototype.requestVideoFrameCallback.call(this, e3);
      }, e2.cancelVideoFrameCallback = function(e3) {
        this.featuresVideoFrameCallback && !this.el_.webkitKeys ? this.el_.cancelVideoFrameCallback(e3) : l2.prototype.cancelVideoFrameCallback.call(this, e3);
      }, e2.src = function(e3) {
        if (void 0 === e3)
          return this.el_.src;
        this.setSrc(e3);
      }, e2.reset = function() {
        s2.resetMediaElement(this.el_);
      }, e2.currentSrc = function() {
        return this.currentSource_ ? this.currentSource_.src : this.el_.currentSrc;
      }, e2.setControls = function(e3) {
        this.el_.controls = !!e3;
      }, e2.addTextTrack = function(e3, t2, i2) {
        return this.featuresNativeTextTracks ? this.el_.addTextTrack(e3, t2, i2) : l2.prototype.addTextTrack.call(this, e3, t2, i2);
      }, e2.createRemoteTextTrack = function(e3) {
        if (!this.featuresNativeTextTracks)
          return l2.prototype.createRemoteTextTrack.call(this, e3);
        var t2 = document.createElement("track");
        return e3.kind && (t2.kind = e3.kind), e3.label && (t2.label = e3.label), (e3.language || e3.srclang) && (t2.srclang = e3.language || e3.srclang), e3.default && (t2.default = e3.default), e3.id && (t2.id = e3.id), e3.src && (t2.src = e3.src), t2;
      }, e2.addRemoteTextTrack = function(e3, t2) {
        t2 = l2.prototype.addRemoteTextTrack.call(this, e3, t2);
        return this.featuresNativeTextTracks && this.el().appendChild(t2), t2;
      }, e2.removeRemoteTextTrack = function(e3) {
        if (l2.prototype.removeRemoteTextTrack.call(this, e3), this.featuresNativeTextTracks)
          for (var t2 = this.$$("track"), i2 = t2.length; i2--; )
            e3 !== t2[i2] && e3 !== t2[i2].track || this.el().removeChild(t2[i2]);
      }, e2.getVideoPlaybackQuality = function() {
        if ("function" == typeof this.el().getVideoPlaybackQuality)
          return this.el().getVideoPlaybackQuality();
        var e3 = {};
        return "undefined" != typeof this.el().webkitDroppedFrameCount && "undefined" != typeof this.el().webkitDecodedFrameCount && (e3.droppedVideoFrames = this.el().webkitDroppedFrameCount, e3.totalVideoFrames = this.el().webkitDecodedFrameCount), window.performance && "function" == typeof window.performance.now ? e3.creationTime = window.performance.now() : window.performance && window.performance.timing && "number" == typeof window.performance.timing.navigationStart && (e3.creationTime = window.Date.now() - window.performance.timing.navigationStart), e3;
      }, s2;
    }(ji);
    An(Dn, "TEST_VID", function() {
      if (X()) {
        var e2 = document.createElement("video"), t2 = document.createElement("track");
        return t2.kind = "captions", t2.srclang = "en", t2.label = "English", e2.appendChild(t2), e2;
      }
    }), Dn.isSupported = function() {
      try {
        Dn.TEST_VID.volume = 0.5;
      } catch (e2) {
        return false;
      }
      return !(!Dn.TEST_VID || !Dn.TEST_VID.canPlayType);
    }, Dn.canPlayType = function(e2) {
      return Dn.TEST_VID.canPlayType(e2);
    }, Dn.canPlaySource = function(e2, t2) {
      return Dn.canPlayType(e2.type);
    }, Dn.canControlVolume = function() {
      try {
        var e2 = Dn.TEST_VID.volume;
        Dn.TEST_VID.volume = e2 / 2 + 0.1;
        var t2 = e2 !== Dn.TEST_VID.volume;
        return t2 && V ? (window.setTimeout(function() {
          Dn && Dn.prototype && (Dn.prototype.featuresVolumeControl = e2 !== Dn.TEST_VID.volume);
        }), false) : t2;
      } catch (e3) {
        return false;
      }
    }, Dn.canMuteVolume = function() {
      try {
        var e2 = Dn.TEST_VID.muted;
        return Dn.TEST_VID.muted = !e2, Dn.TEST_VID.muted ? oe(Dn.TEST_VID, "muted", "muted") : ue(Dn.TEST_VID, "muted"), e2 !== Dn.TEST_VID.muted;
      } catch (e3) {
        return false;
      }
    }, Dn.canControlPlaybackRate = function() {
      if (A && R && M < 58)
        return false;
      try {
        var e2 = Dn.TEST_VID.playbackRate;
        return Dn.TEST_VID.playbackRate = e2 / 2 + 0.1, e2 !== Dn.TEST_VID.playbackRate;
      } catch (e3) {
        return false;
      }
    }, Dn.canOverrideAttributes = function() {
      try {
        var e2 = function() {
        };
        Object.defineProperty(document.createElement("video"), "src", { get: e2, set: e2 }), Object.defineProperty(document.createElement("audio"), "src", { get: e2, set: e2 }), Object.defineProperty(document.createElement("video"), "innerHTML", { get: e2, set: e2 }), Object.defineProperty(document.createElement("audio"), "innerHTML", { get: e2, set: e2 });
      } catch (e3) {
        return false;
      }
      return true;
    }, Dn.supportsNativeTextTracks = function() {
      return q || V && R;
    }, Dn.supportsNativeVideoTracks = function() {
      return !(!Dn.TEST_VID || !Dn.TEST_VID.videoTracks);
    }, Dn.supportsNativeAudioTracks = function() {
      return !(!Dn.TEST_VID || !Dn.TEST_VID.audioTracks);
    }, Dn.Events = ["loadstart", "suspend", "abort", "error", "emptied", "stalled", "loadedmetadata", "loadeddata", "canplay", "canplaythrough", "playing", "waiting", "seeking", "seeked", "ended", "durationchange", "timeupdate", "progress", "play", "pause", "ratechange", "resize", "volumechange"], [["featuresMuteControl", "canMuteVolume"], ["featuresPlaybackRate", "canControlPlaybackRate"], ["featuresSourceset", "canOverrideAttributes"], ["featuresNativeTextTracks", "supportsNativeTextTracks"], ["featuresNativeVideoTracks", "supportsNativeVideoTracks"], ["featuresNativeAudioTracks", "supportsNativeAudioTracks"]].forEach(function(e2) {
      var t2 = e2[0], i2 = e2[1];
      An(Dn.prototype, t2, function() {
        return Dn[i2]();
      }, true);
    }), Dn.prototype.featuresVolumeControl = Dn.canControlVolume(), Dn.prototype.movingMediaElementInDOM = !V, Dn.prototype.featuresFullscreenResize = true, Dn.prototype.featuresProgressEvents = true, Dn.prototype.featuresTimeupdateEvents = true, Dn.prototype.featuresVideoFrameCallback = !(!Dn.TEST_VID || !Dn.TEST_VID.requestVideoFrameCallback), Dn.patchCanPlayType = function() {
      4 <= P && !O && !R && (Pn = Dn.TEST_VID && Dn.TEST_VID.constructor.prototype.canPlayType, Dn.TEST_VID.constructor.prototype.canPlayType = function(e2) {
        return e2 && /^application\/(?:x-|vnd\.apple\.)mpegurl/i.test(e2) ? "maybe" : Pn.call(this, e2);
      });
    }, Dn.unpatchCanPlayType = function() {
      var e2 = Dn.TEST_VID.constructor.prototype.canPlayType;
      return Pn && (Dn.TEST_VID.constructor.prototype.canPlayType = Pn), e2;
    }, Dn.patchCanPlayType(), Dn.disposeMediaElement = function(e2) {
      if (e2) {
        for (e2.parentNode && e2.parentNode.removeChild(e2); e2.hasChildNodes(); )
          e2.removeChild(e2.firstChild);
        e2.removeAttribute("src"), "function" == typeof e2.load && function() {
          try {
            e2.load();
          } catch (e3) {
          }
        }();
      }
    }, Dn.resetMediaElement = function(e2) {
      if (e2) {
        for (var t2 = e2.querySelectorAll("source"), i2 = t2.length; i2--; )
          e2.removeChild(t2[i2]);
        e2.removeAttribute("src"), "function" == typeof e2.load && function() {
          try {
            e2.load();
          } catch (e3) {
          }
        }();
      }
    }, ["muted", "defaultMuted", "autoplay", "controls", "loop", "playsinline"].forEach(function(e2) {
      Dn.prototype[e2] = function() {
        return this.el_[e2] || this.el_.hasAttribute(e2);
      };
    }), ["muted", "defaultMuted", "autoplay", "loop", "playsinline"].forEach(function(t2) {
      Dn.prototype["set" + ut(t2)] = function(e2) {
        (this.el_[t2] = e2) ? this.el_.setAttribute(t2, t2) : this.el_.removeAttribute(t2);
      };
    }), ["paused", "currentTime", "buffered", "volume", "poster", "preload", "error", "seeking", "seekable", "ended", "playbackRate", "defaultPlaybackRate", "disablePictureInPicture", "played", "networkState", "readyState", "videoWidth", "videoHeight", "crossOrigin"].forEach(function(e2) {
      Dn.prototype[e2] = function() {
        return this.el_[e2];
      };
    }), ["volume", "src", "poster", "preload", "playbackRate", "defaultPlaybackRate", "disablePictureInPicture", "crossOrigin"].forEach(function(t2) {
      Dn.prototype["set" + ut(t2)] = function(e2) {
        this.el_[t2] = e2;
      };
    }), ["pause", "load", "play"].forEach(function(e2) {
      Dn.prototype[e2] = function() {
        return this.el_[e2]();
      };
    }), ji.withSourceHandlers(Dn), Dn.nativeSourceHandler = {}, Dn.nativeSourceHandler.canPlayType = function(e2) {
      try {
        return Dn.TEST_VID.canPlayType(e2);
      } catch (e3) {
        return "";
      }
    }, Dn.nativeSourceHandler.canHandleSource = function(e2, t2) {
      if (e2.type)
        return Dn.nativeSourceHandler.canPlayType(e2.type);
      if (e2.src) {
        e2 = Nt(e2.src);
        return Dn.nativeSourceHandler.canPlayType("video/" + e2);
      }
      return "";
    }, Dn.nativeSourceHandler.handleSource = function(e2, t2, i2) {
      t2.setSrc(e2.src);
    }, Dn.nativeSourceHandler.dispose = function() {
    }, Dn.registerSourceHandler(Dn.nativeSourceHandler), ji.registerTech("Html5", Dn);
    var Rn = ["progress", "abort", "suspend", "emptied", "stalled", "loadedmetadata", "loadeddata", "timeupdate", "resize", "volumechange", "texttrackchange"], Mn = { canplay: "CanPlay", canplaythrough: "CanPlayThrough", playing: "Playing", seeked: "Seeked" }, Nn = ["tiny", "xsmall", "small", "medium", "large", "xlarge", "huge"], Un = {};
    Nn.forEach(function(e2) {
      var t2 = "x" === e2.charAt(0) ? "x-" + e2.substring(1) : e2;
      Un[e2] = "vjs-layout-" + t2;
    });
    var Bn = { tiny: 210, xsmall: 320, small: 425, medium: 768, large: 1440, xlarge: 2560, huge: 1 / 0 }, Fn = function(d2) {
      function o2(e3, t2, i2) {
        var n2, r2;
        if (e3.id = e3.id || t2.id || "vjs_video_" + Pe++, (t2 = b(o2.getTagSettings(e3), t2)).initChildren = false, t2.createEl = false, t2.evented = false, t2.reportTouchActivity = false, !t2.language)
          if ("function" == typeof e3.closest) {
            var a2 = e3.closest("[lang]");
            a2 && a2.getAttribute && (t2.language = a2.getAttribute("lang"));
          } else
            for (var s2 = e3; s2 && 1 === s2.nodeType; ) {
              if (ae(s2).hasOwnProperty("lang")) {
                t2.language = s2.getAttribute("lang");
                break;
              }
              s2 = s2.parentNode;
            }
        if ((n2 = d2.call(this, null, t2, i2) || this).boundDocumentFullscreenChange_ = function(e4) {
          return n2.documentFullscreenChange_(e4);
        }, n2.boundFullWindowOnEscKey_ = function(e4) {
          return n2.fullWindowOnEscKey(e4);
        }, n2.boundUpdateStyleEl_ = function(e4) {
          return n2.updateStyleEl_(e4);
        }, n2.boundApplyInitTime_ = function(e4) {
          return n2.applyInitTime_(e4);
        }, n2.boundUpdateCurrentBreakpoint_ = function(e4) {
          return n2.updateCurrentBreakpoint_(e4);
        }, n2.boundHandleTechClick_ = function(e4) {
          return n2.handleTechClick_(e4);
        }, n2.boundHandleTechDoubleClick_ = function(e4) {
          return n2.handleTechDoubleClick_(e4);
        }, n2.boundHandleTechTouchStart_ = function(e4) {
          return n2.handleTechTouchStart_(e4);
        }, n2.boundHandleTechTouchMove_ = function(e4) {
          return n2.handleTechTouchMove_(e4);
        }, n2.boundHandleTechTouchEnd_ = function(e4) {
          return n2.handleTechTouchEnd_(e4);
        }, n2.boundHandleTechTap_ = function(e4) {
          return n2.handleTechTap_(e4);
        }, n2.isFullscreen_ = false, n2.log = p(n2.id_), n2.fsApi_ = l, n2.isPosterFromTech_ = false, n2.queuedCallbacks_ = [], n2.isReady_ = false, n2.hasStarted_ = false, n2.userActive_ = false, n2.debugEnabled_ = false, n2.audioOnlyMode_ = false, n2.audioPosterMode_ = false, n2.audioOnlyCache_ = { playerHeight: null, hiddenChildren: [] }, !n2.options_ || !n2.options_.techOrder || !n2.options_.techOrder.length)
          throw new Error("No techOrder specified. Did you overwrite videojs.options instead of just changing the properties you want to override?");
        n2.tag = e3, n2.tagAttributes = e3 && ae(e3), n2.language(n2.options_.language), t2.languages ? (r2 = {}, Object.getOwnPropertyNames(t2.languages).forEach(function(e4) {
          r2[e4.toLowerCase()] = t2.languages[e4];
        }), n2.languages_ = r2) : n2.languages_ = o2.prototype.options_.languages, n2.resetCache_(), n2.poster_ = t2.poster || "", n2.controls_ = !!t2.controls, e3.controls = false, e3.removeAttribute("controls"), n2.changingSrc_ = false, n2.playCallbacks_ = [], n2.playTerminatedQueue_ = [], e3.hasAttribute("autoplay") ? n2.autoplay(true) : n2.autoplay(n2.options_.autoplay), t2.plugins && Object.keys(t2.plugins).forEach(function(e4) {
          if ("function" != typeof n2[e4])
            throw new Error('plugin "' + e4 + '" does not exist');
        }), n2.scrubbing_ = false, n2.el_ = n2.createEl(), rt(ft(n2), { eventBusKey: "el_" }), n2.fsApi_.requestFullscreen && (Be(document, n2.fsApi_.fullscreenchange, n2.boundDocumentFullscreenChange_), n2.on(n2.fsApi_.fullscreenchange, n2.boundDocumentFullscreenChange_)), n2.fluid_ && n2.on(["playerreset", "resize"], n2.boundUpdateStyleEl_);
        i2 = lt(n2.options_);
        t2.plugins && Object.keys(t2.plugins).forEach(function(e4) {
          n2[e4](t2.plugins[e4]);
        }), t2.debug && n2.debug(true), n2.options_.playerOptions = i2, n2.middleware_ = [], n2.playbackRates(t2.playbackRates), n2.initChildren(), n2.isAudio("audio" === e3.nodeName.toLowerCase()), n2.controls() ? n2.addClass("vjs-controls-enabled") : n2.addClass("vjs-controls-disabled"), n2.el_.setAttribute("role", "region"), n2.isAudio() ? n2.el_.setAttribute("aria-label", n2.localize("Audio Player")) : n2.el_.setAttribute("aria-label", n2.localize("Video Player")), n2.isAudio() && n2.addClass("vjs-audio"), n2.flexNotSupported_() && n2.addClass("vjs-no-flex"), F && n2.addClass("vjs-touch-enabled"), V || n2.addClass("vjs-workinghover"), o2.players[n2.id_] = ft(n2);
        e3 = u.split(".")[0];
        return n2.addClass("vjs-v" + e3), n2.userActive(true), n2.reportUserActivity(), n2.one("play", function(e4) {
          return n2.listenForUserActivity_(e4);
        }), n2.on("stageclick", function(e4) {
          return n2.handleStageClick_(e4);
        }), n2.on("keydown", function(e4) {
          return n2.handleKeyDown(e4);
        }), n2.on("languagechange", function(e4) {
          return n2.handleLanguagechange(e4);
        }), n2.breakpoints(n2.options_.breakpoints), n2.responsive(n2.options_.responsive), n2.on("ready", function() {
          n2.audioPosterMode(n2.options_.audioPosterMode), n2.audioOnlyMode(n2.options_.audioOnlyMode);
        }), n2;
      }
      mt(o2, d2);
      var e2 = o2.prototype;
      return e2.dispose = function() {
        var t2 = this;
        this.trigger("dispose"), this.off("dispose"), Fe(document, this.fsApi_.fullscreenchange, this.boundDocumentFullscreenChange_), Fe(document, "keydown", this.boundFullWindowOnEscKey_), this.styleEl_ && this.styleEl_.parentNode && (this.styleEl_.parentNode.removeChild(this.styleEl_), this.styleEl_ = null), o2.players[this.id_] = null, this.tag && this.tag.player && (this.tag.player = null), this.el_ && this.el_.player && (this.el_.player = null), this.tech_ && (this.tech_.dispose(), this.isPosterFromTech_ = false, this.poster_ = ""), this.playerElIngest_ && (this.playerElIngest_ = null), this.tag && (this.tag = null), Vi[this.id()] = null, oi.names.forEach(function(e3) {
          e3 = oi[e3], e3 = t2[e3.getterName]();
          e3 && e3.off && e3.off();
        }), d2.prototype.dispose.call(this, { restoreEl: this.options_.restoreEl });
      }, e2.createEl = function() {
        var t2, i2 = this.tag, e3 = this.playerElIngest_ = i2.parentNode && i2.parentNode.hasAttribute && i2.parentNode.hasAttribute("data-vjs-player"), n2 = "video-js" === this.tag.tagName.toLowerCase();
        e3 ? t2 = this.el_ = i2.parentNode : n2 || (t2 = this.el_ = d2.prototype.createEl.call(this, "div"));
        var r2, a2, s2 = ae(i2);
        if (n2) {
          for (t2 = this.el_ = i2, i2 = this.tag = document.createElement("video"); t2.children.length; )
            i2.appendChild(t2.firstChild);
          ee(t2, "video-js") || te(t2, "video-js"), t2.appendChild(i2), e3 = this.playerElIngest_ = t2, Object.keys(t2).forEach(function(e4) {
            try {
              i2[e4] = t2[e4];
            } catch (e5) {
            }
          });
        }
        i2.setAttribute("tabindex", "-1"), s2.tabindex = "-1", (N || R && B) && (i2.setAttribute("role", "application"), s2.role = "application"), i2.removeAttribute("width"), i2.removeAttribute("height"), "width" in s2 && delete s2.width, "height" in s2 && delete s2.height, Object.getOwnPropertyNames(s2).forEach(function(e4) {
          n2 && "class" === e4 || t2.setAttribute(e4, s2[e4]), n2 && i2.setAttribute(e4, s2[e4]);
        }), i2.playerId = i2.id, i2.id += "_html5_api", i2.className = "vjs-tech", (i2.player = t2.player = this).addClass("vjs-paused"), true !== window.VIDEOJS_NO_DYNAMIC_STYLE && (this.styleEl_ = xe("vjs-styles-dimensions"), r2 = Te(".vjs-styles-defaults"), (a2 = Te("head")).insertBefore(this.styleEl_, r2 ? r2.nextSibling : a2.firstChild)), this.fill_ = false, this.fluid_ = false, this.width(this.options_.width), this.height(this.options_.height), this.fill(this.options_.fill), this.fluid(this.options_.fluid), this.aspectRatio(this.options_.aspectRatio), this.crossOrigin(this.options_.crossOrigin || this.options_.crossorigin);
        for (var o3 = i2.getElementsByTagName("a"), u2 = 0; u2 < o3.length; u2++) {
          var l2 = o3.item(u2);
          te(l2, "vjs-hidden"), l2.setAttribute("hidden", "hidden");
        }
        return i2.initNetworkState_ = i2.networkState, i2.parentNode && !e3 && i2.parentNode.insertBefore(t2, i2), Z(i2, t2), this.children_.unshift(i2), this.el_.setAttribute("lang", this.language_), this.el_.setAttribute("translate", "no"), this.el_ = t2;
      }, e2.crossOrigin = function(e3) {
        if (!e3)
          return this.techGet_("crossOrigin");
        "anonymous" === e3 || "use-credentials" === e3 ? this.techCall_("setCrossOrigin", e3) : h.warn('crossOrigin must be "anonymous" or "use-credentials", given "' + e3 + '"');
      }, e2.width = function(e3) {
        return this.dimension("width", e3);
      }, e2.height = function(e3) {
        return this.dimension("height", e3);
      }, e2.dimension = function(e3, t2) {
        var i2 = e3 + "_";
        if (void 0 === t2)
          return this[i2] || 0;
        if ("" === t2 || "auto" === t2)
          return this[i2] = void 0, void this.updateStyleEl_();
        var n2 = parseFloat(t2);
        isNaN(n2) ? h.error('Improper value "' + t2 + '" supplied for for ' + e3) : (this[i2] = n2, this.updateStyleEl_());
      }, e2.fluid = function(e3) {
        var t2, i2 = this;
        if (void 0 === e3)
          return !!this.fluid_;
        this.fluid_ = !!e3, it(this) && this.off(["playerreset", "resize"], this.boundUpdateStyleEl_), e3 ? (this.addClass("vjs-fluid"), this.fill(false), t2 = function() {
          i2.on(["playerreset", "resize"], i2.boundUpdateStyleEl_);
        }, it(e3 = this) ? t2() : (e3.eventedCallbacks || (e3.eventedCallbacks = []), e3.eventedCallbacks.push(t2))) : this.removeClass("vjs-fluid"), this.updateStyleEl_();
      }, e2.fill = function(e3) {
        if (void 0 === e3)
          return !!this.fill_;
        this.fill_ = !!e3, e3 ? (this.addClass("vjs-fill"), this.fluid(false)) : this.removeClass("vjs-fill");
      }, e2.aspectRatio = function(e3) {
        if (void 0 === e3)
          return this.aspectRatio_;
        if (!/^\d+\:\d+$/.test(e3))
          throw new Error("Improper value supplied for aspect ratio. The format should be width:height, for example 16:9.");
        this.aspectRatio_ = e3, this.fluid(true), this.updateStyleEl_();
      }, e2.updateStyleEl_ = function() {
        var e3, t2, i2, n2;
        true !== window.VIDEOJS_NO_DYNAMIC_STYLE ? (n2 = (i2 = (void 0 !== this.aspectRatio_ && "auto" !== this.aspectRatio_ ? this.aspectRatio_ : 0 < this.videoWidth() ? this.videoWidth() + ":" + this.videoHeight() : "16:9").split(":"))[1] / i2[0], e3 = void 0 !== this.width_ ? this.width_ : void 0 !== this.height_ ? this.height_ / n2 : this.videoWidth() || 300, t2 = void 0 !== this.height_ ? this.height_ : e3 * n2, i2 = /^[^a-zA-Z]/.test(this.id()) ? "dimensions-" + this.id() : this.id() + "-dimensions", this.addClass(i2), Ae(this.styleEl_, "\n      ." + i2 + " {\n        width: " + e3 + "px;\n        height: " + t2 + "px;\n      }\n\n      ." + i2 + ".vjs-fluid:not(.vjs-audio-only-mode) {\n        padding-top: " + 100 * n2 + "%;\n      }\n    ")) : (t2 = "number" == typeof this.width_ ? this.width_ : this.options_.width, i2 = "number" == typeof this.height_ ? this.height_ : this.options_.height, (n2 = this.tech_ && this.tech_.el()) && (0 <= t2 && (n2.width = t2), 0 <= i2 && (n2.height = i2)));
      }, e2.loadTech_ = function(e3, t2) {
        var i2 = this;
        this.tech_ && this.unloadTech_();
        var n2 = ut(e3), r2 = e3.charAt(0).toLowerCase() + e3.slice(1);
        "Html5" !== n2 && this.tag && (ji.getTech("Html5").disposeMediaElement(this.tag), this.tag.player = null, this.tag = null), this.techName_ = n2, this.isReady_ = false;
        var a2 = this.autoplay(), s2 = { source: t2, autoplay: a2 = "string" == typeof this.autoplay() || true === this.autoplay() && this.options_.normalizeAutoplay ? false : a2, nativeControlsForTouch: this.options_.nativeControlsForTouch, playerId: this.id(), techId: this.id() + "_" + r2 + "_api", playsinline: this.options_.playsinline, preload: this.options_.preload, loop: this.options_.loop, disablePictureInPicture: this.options_.disablePictureInPicture, muted: this.options_.muted, poster: this.poster(), language: this.language(), playerElIngest: this.playerElIngest_ || false, "vtt.js": this.options_["vtt.js"], canOverridePoster: !!this.options_.techCanOverridePoster, enableSourceset: this.options_.enableSourceset, Promise: this.options_.Promise };
        oi.names.forEach(function(e4) {
          e4 = oi[e4];
          s2[e4.getterName] = i2[e4.privateName];
        }), b(s2, this.options_[n2]), b(s2, this.options_[r2]), b(s2, this.options_[e3.toLowerCase()]), this.tag && (s2.tag = this.tag), t2 && t2.src === this.cache_.src && 0 < this.cache_.currentTime && (s2.startTime = this.cache_.currentTime);
        e3 = ji.getTech(e3);
        if (!e3)
          throw new Error("No Tech named '" + n2 + "' exists! '" + n2 + "' should be registered using videojs.registerTech()'");
        this.tech_ = new e3(s2), this.tech_.ready(qe(this, this.handleTechReady_), true), It(this.textTracksJson_ || [], this.tech_), Rn.forEach(function(t3) {
          i2.on(i2.tech_, t3, function(e4) {
            return i2["handleTech" + ut(t3) + "_"](e4);
          });
        }), Object.keys(Mn).forEach(function(t3) {
          i2.on(i2.tech_, t3, function(e4) {
            0 === i2.tech_.playbackRate() && i2.tech_.seeking() ? i2.queuedCallbacks_.push({ callback: i2["handleTech" + Mn[t3] + "_"].bind(i2), event: e4 }) : i2["handleTech" + Mn[t3] + "_"](e4);
          });
        }), this.on(this.tech_, "loadstart", function(e4) {
          return i2.handleTechLoadStart_(e4);
        }), this.on(this.tech_, "sourceset", function(e4) {
          return i2.handleTechSourceset_(e4);
        }), this.on(this.tech_, "waiting", function(e4) {
          return i2.handleTechWaiting_(e4);
        }), this.on(this.tech_, "ended", function(e4) {
          return i2.handleTechEnded_(e4);
        }), this.on(this.tech_, "seeking", function(e4) {
          return i2.handleTechSeeking_(e4);
        }), this.on(this.tech_, "play", function(e4) {
          return i2.handleTechPlay_(e4);
        }), this.on(this.tech_, "firstplay", function(e4) {
          return i2.handleTechFirstPlay_(e4);
        }), this.on(this.tech_, "pause", function(e4) {
          return i2.handleTechPause_(e4);
        }), this.on(this.tech_, "durationchange", function(e4) {
          return i2.handleTechDurationChange_(e4);
        }), this.on(this.tech_, "fullscreenchange", function(e4, t3) {
          return i2.handleTechFullscreenChange_(e4, t3);
        }), this.on(this.tech_, "fullscreenerror", function(e4, t3) {
          return i2.handleTechFullscreenError_(e4, t3);
        }), this.on(this.tech_, "enterpictureinpicture", function(e4) {
          return i2.handleTechEnterPictureInPicture_(e4);
        }), this.on(this.tech_, "leavepictureinpicture", function(e4) {
          return i2.handleTechLeavePictureInPicture_(e4);
        }), this.on(this.tech_, "error", function(e4) {
          return i2.handleTechError_(e4);
        }), this.on(this.tech_, "posterchange", function(e4) {
          return i2.handleTechPosterChange_(e4);
        }), this.on(this.tech_, "textdata", function(e4) {
          return i2.handleTechTextData_(e4);
        }), this.on(this.tech_, "ratechange", function(e4) {
          return i2.handleTechRateChange_(e4);
        }), this.on(this.tech_, "loadedmetadata", this.boundUpdateStyleEl_), this.usingNativeControls(this.techGet_("controls")), this.controls() && !this.usingNativeControls() && this.addTechControlsListeners_(), this.tech_.el().parentNode === this.el() || "Html5" === n2 && this.tag || Z(this.tech_.el(), this.el()), this.tag && (this.tag.player = null, this.tag = null);
      }, e2.unloadTech_ = function() {
        var t2 = this;
        oi.names.forEach(function(e3) {
          e3 = oi[e3];
          t2[e3.privateName] = t2[e3.getterName]();
        }), this.textTracksJson_ = Ct(this.tech_), this.isReady_ = false, this.tech_.dispose(), this.tech_ = false, this.isPosterFromTech_ && (this.poster_ = "", this.trigger("posterchange")), this.isPosterFromTech_ = false;
      }, e2.tech = function(e3) {
        return void 0 === e3 && h.warn("Using the tech directly can be dangerous. I hope you know what you're doing.\nSee https://github.com/videojs/video.js/issues/2617 for more info.\n"), this.tech_;
      }, e2.addTechControlsListeners_ = function() {
        this.removeTechControlsListeners_(), this.on(this.tech_, "click", this.boundHandleTechClick_), this.on(this.tech_, "dblclick", this.boundHandleTechDoubleClick_), this.on(this.tech_, "touchstart", this.boundHandleTechTouchStart_), this.on(this.tech_, "touchmove", this.boundHandleTechTouchMove_), this.on(this.tech_, "touchend", this.boundHandleTechTouchEnd_), this.on(this.tech_, "tap", this.boundHandleTechTap_);
      }, e2.removeTechControlsListeners_ = function() {
        this.off(this.tech_, "tap", this.boundHandleTechTap_), this.off(this.tech_, "touchstart", this.boundHandleTechTouchStart_), this.off(this.tech_, "touchmove", this.boundHandleTechTouchMove_), this.off(this.tech_, "touchend", this.boundHandleTechTouchEnd_), this.off(this.tech_, "click", this.boundHandleTechClick_), this.off(this.tech_, "dblclick", this.boundHandleTechDoubleClick_);
      }, e2.handleTechReady_ = function() {
        this.triggerReady(), this.cache_.volume && this.techCall_("setVolume", this.cache_.volume), this.handleTechPosterChange_(), this.handleTechDurationChange_();
      }, e2.handleTechLoadStart_ = function() {
        this.removeClass("vjs-ended"), this.removeClass("vjs-seeking"), this.error(null), this.handleTechDurationChange_(), this.paused() ? (this.hasStarted(false), this.trigger("loadstart")) : (this.trigger("loadstart"), this.trigger("firstplay")), this.manualAutoplay_(true === this.autoplay() && this.options_.normalizeAutoplay ? "play" : this.autoplay());
      }, e2.manualAutoplay_ = function(e3) {
        var n2 = this;
        if (this.tech_ && "string" == typeof e3) {
          var t2, i2 = function() {
            var e4 = n2.muted();
            n2.muted(true);
            function t3() {
              n2.muted(e4);
            }
            n2.playTerminatedQueue_.push(t3);
            var i3 = n2.play();
            if (St(i3))
              return i3.catch(function(e5) {
                throw t3(), new Error("Rejection at manualAutoplay. Restoring muted value. " + (e5 || ""));
              });
          };
          if ("any" !== e3 || this.muted() ? t2 = "muted" !== e3 || this.muted() ? this.play() : i2() : St(t2 = this.play()) && (t2 = t2.catch(i2)), St(t2))
            return t2.then(function() {
              n2.trigger({ type: "autoplay-success", autoplay: e3 });
            }).catch(function() {
              n2.trigger({ type: "autoplay-failure", autoplay: e3 });
            });
        }
      }, e2.updateSourceCaches_ = function(e3) {
        var t2 = e3 = void 0 === e3 ? "" : e3, i2 = "";
        "string" != typeof t2 && (t2 = e3.src, i2 = e3.type), this.cache_.source = this.cache_.source || {}, this.cache_.sources = this.cache_.sources || [], t2 && !i2 && (i2 = function(e4, t3) {
          if (!t3)
            return "";
          if (e4.cache_.source.src === t3 && e4.cache_.source.type)
            return e4.cache_.source.type;
          var i3 = e4.cache_.sources.filter(function(e5) {
            return e5.src === t3;
          });
          if (i3.length)
            return i3[0].type;
          for (var n3 = e4.$$("source"), r3 = 0; r3 < n3.length; r3++) {
            var a3 = n3[r3];
            if (a3.type && a3.src && a3.src === t3)
              return a3.type;
          }
          return $i(t3);
        }(this, t2)), this.cache_.source = lt({}, e3, { src: t2, type: i2 });
        for (var i2 = this.cache_.sources.filter(function(e4) {
          return e4.src && e4.src === t2;
        }), n2 = [], r2 = this.$$("source"), a2 = [], s2 = 0; s2 < r2.length; s2++) {
          var o3 = ae(r2[s2]);
          n2.push(o3), o3.src && o3.src === t2 && a2.push(o3.src);
        }
        a2.length && !i2.length ? this.cache_.sources = n2 : i2.length || (this.cache_.sources = [this.cache_.source]), this.cache_.src = t2;
      }, e2.handleTechSourceset_ = function(e3) {
        var t2, i2, n2, r2 = this;
        this.changingSrc_ || (t2 = function(e4) {
          return r2.updateSourceCaches_(e4);
        }, i2 = this.currentSource().src, n2 = e3.src, i2 && !/^blob:/.test(i2) && /^blob:/.test(n2) && (this.lastSource_ && (this.lastSource_.tech === n2 || this.lastSource_.player === i2) || (t2 = function() {
        })), t2(n2), e3.src || this.tech_.any(["sourceset", "loadstart"], function(e4) {
          "sourceset" !== e4.type && (e4 = r2.techGet("currentSrc"), r2.lastSource_.tech = e4, r2.updateSourceCaches_(e4));
        })), this.lastSource_ = { player: this.currentSource().src, tech: e3.src }, this.trigger({ src: e3.src, type: "sourceset" });
      }, e2.hasStarted = function(e3) {
        if (void 0 === e3)
          return this.hasStarted_;
        e3 !== this.hasStarted_ && (this.hasStarted_ = e3, this.hasStarted_ ? (this.addClass("vjs-has-started"), this.trigger("firstplay")) : this.removeClass("vjs-has-started"));
      }, e2.handleTechPlay_ = function() {
        this.removeClass("vjs-ended"), this.removeClass("vjs-paused"), this.addClass("vjs-playing"), this.hasStarted(true), this.trigger("play");
      }, e2.handleTechRateChange_ = function() {
        0 < this.tech_.playbackRate() && 0 === this.cache_.lastPlaybackRate && (this.queuedCallbacks_.forEach(function(e3) {
          return e3.callback(e3.event);
        }), this.queuedCallbacks_ = []), this.cache_.lastPlaybackRate = this.tech_.playbackRate(), this.trigger("ratechange");
      }, e2.handleTechWaiting_ = function() {
        var t2 = this;
        this.addClass("vjs-waiting"), this.trigger("waiting");
        var i2 = this.currentTime();
        this.on("timeupdate", function e3() {
          i2 !== t2.currentTime() && (t2.removeClass("vjs-waiting"), t2.off("timeupdate", e3));
        });
      }, e2.handleTechCanPlay_ = function() {
        this.removeClass("vjs-waiting"), this.trigger("canplay");
      }, e2.handleTechCanPlayThrough_ = function() {
        this.removeClass("vjs-waiting"), this.trigger("canplaythrough");
      }, e2.handleTechPlaying_ = function() {
        this.removeClass("vjs-waiting"), this.trigger("playing");
      }, e2.handleTechSeeking_ = function() {
        this.addClass("vjs-seeking"), this.trigger("seeking");
      }, e2.handleTechSeeked_ = function() {
        this.removeClass("vjs-seeking"), this.removeClass("vjs-ended"), this.trigger("seeked");
      }, e2.handleTechFirstPlay_ = function() {
        this.options_.starttime && (h.warn("Passing the `starttime` option to the player will be deprecated in 6.0"), this.currentTime(this.options_.starttime)), this.addClass("vjs-has-started"), this.trigger("firstplay");
      }, e2.handleTechPause_ = function() {
        this.removeClass("vjs-playing"), this.addClass("vjs-paused"), this.trigger("pause");
      }, e2.handleTechEnded_ = function() {
        this.addClass("vjs-ended"), this.removeClass("vjs-waiting"), this.options_.loop ? (this.currentTime(0), this.play()) : this.paused() || this.pause(), this.trigger("ended");
      }, e2.handleTechDurationChange_ = function() {
        this.duration(this.techGet_("duration"));
      }, e2.handleTechClick_ = function(e3) {
        this.controls_ && (void 0 !== this.options_ && void 0 !== this.options_.userActions && void 0 !== this.options_.userActions.click && false === this.options_.userActions.click || (void 0 !== this.options_ && void 0 !== this.options_.userActions && "function" == typeof this.options_.userActions.click ? this.options_.userActions.click.call(this, e3) : this.paused() ? Et(this.play()) : this.pause()));
      }, e2.handleTechDoubleClick_ = function(t2) {
        this.controls_ && (Array.prototype.some.call(this.$$(".vjs-control-bar, .vjs-modal-dialog"), function(e3) {
          return e3.contains(t2.target);
        }) || void 0 !== this.options_ && void 0 !== this.options_.userActions && void 0 !== this.options_.userActions.doubleClick && false === this.options_.userActions.doubleClick || (void 0 !== this.options_ && void 0 !== this.options_.userActions && "function" == typeof this.options_.userActions.doubleClick ? this.options_.userActions.doubleClick.call(this, t2) : this.isFullscreen() ? this.exitFullscreen() : this.requestFullscreen()));
      }, e2.handleTechTap_ = function() {
        this.userActive(!this.userActive());
      }, e2.handleTechTouchStart_ = function() {
        this.userWasActive = this.userActive();
      }, e2.handleTechTouchMove_ = function() {
        this.userWasActive && this.reportUserActivity();
      }, e2.handleTechTouchEnd_ = function(e3) {
        e3.cancelable && e3.preventDefault();
      }, e2.handleStageClick_ = function() {
        this.reportUserActivity();
      }, e2.toggleFullscreenClass_ = function() {
        this.isFullscreen() ? this.addClass("vjs-fullscreen") : this.removeClass("vjs-fullscreen");
      }, e2.documentFullscreenChange_ = function(e3) {
        var t2 = e3.target.player;
        t2 && t2 !== this || (e3 = this.el(), !(t2 = document[this.fsApi_.fullscreenElement] === e3) && e3.matches ? t2 = e3.matches(":" + this.fsApi_.fullscreen) : !t2 && e3.msMatchesSelector && (t2 = e3.msMatchesSelector(":" + this.fsApi_.fullscreen)), this.isFullscreen(t2));
      }, e2.handleTechFullscreenChange_ = function(e3, t2) {
        var i2 = this;
        t2 && (t2.nativeIOSFullscreen && (this.addClass("vjs-ios-native-fs"), this.tech_.one("webkitendfullscreen", function() {
          i2.removeClass("vjs-ios-native-fs");
        })), this.isFullscreen(t2.isFullscreen));
      }, e2.handleTechFullscreenError_ = function(e3, t2) {
        this.trigger("fullscreenerror", t2);
      }, e2.togglePictureInPictureClass_ = function() {
        this.isInPictureInPicture() ? this.addClass("vjs-picture-in-picture") : this.removeClass("vjs-picture-in-picture");
      }, e2.handleTechEnterPictureInPicture_ = function(e3) {
        this.isInPictureInPicture(true);
      }, e2.handleTechLeavePictureInPicture_ = function(e3) {
        this.isInPictureInPicture(false);
      }, e2.handleTechError_ = function() {
        var e3 = this.tech_.error();
        this.error(e3);
      }, e2.handleTechTextData_ = function() {
        this.trigger("textdata", 1 < arguments.length ? arguments[1] : null);
      }, e2.getCache = function() {
        return this.cache_;
      }, e2.resetCache_ = function() {
        this.cache_ = { currentTime: 0, initTime: 0, inactivityTimeout: this.options_.inactivityTimeout, duration: NaN, lastVolume: 1, lastPlaybackRate: this.defaultPlaybackRate(), media: null, src: "", source: {}, sources: [], playbackRates: [], volume: 1 };
      }, e2.techCall_ = function(n2, r2) {
        this.ready(function() {
          if (n2 in Xi)
            return e3 = this.middleware_, t2 = this.tech_, i2 = r2, t2[t2 = n2](e3.reduce(Yi(t2), i2));
          if (n2 in Ki)
            return Gi(this.middleware_, this.tech_, n2, r2);
          var e3, t2, i2;
          try {
            this.tech_ && this.tech_[n2](r2);
          } catch (e4) {
            throw h(e4), e4;
          }
        }, true);
      }, e2.techGet_ = function(t2) {
        if (this.tech_ && this.tech_.isReady_) {
          if (t2 in zi)
            return e3 = this.middleware_, i2 = this.tech_, n2 = t2, e3.reduceRight(Yi(n2), i2[n2]());
          if (t2 in Ki)
            return Gi(this.middleware_, this.tech_, t2);
          var e3, i2, n2;
          try {
            return this.tech_[t2]();
          } catch (e4) {
            if (void 0 === this.tech_[t2])
              throw h("Video.js: " + t2 + " method not defined for " + this.techName_ + " playback technology.", e4), e4;
            if ("TypeError" === e4.name)
              throw h("Video.js: " + t2 + " unavailable on " + this.techName_ + " playback technology element.", e4), this.tech_.isReady_ = false, e4;
            throw h(e4), e4;
          }
        }
      }, e2.play = function() {
        var t2 = this, e3 = this.options_.Promise || window.Promise;
        return e3 ? new e3(function(e4) {
          t2.play_(e4);
        }) : this.play_();
      }, e2.play_ = function(e3) {
        var t2 = this;
        this.playCallbacks_.push(e3 = void 0 === e3 ? Et : e3);
        var i2 = Boolean(!this.changingSrc_ && (this.src() || this.currentSrc())), e3 = Boolean(q || V);
        if (this.waitToPlay_ && (this.off(["ready", "loadstart"], this.waitToPlay_), this.waitToPlay_ = null), !this.isReady_ || !i2)
          return this.waitToPlay_ = function(e4) {
            t2.play_();
          }, this.one(["ready", "loadstart"], this.waitToPlay_), void (!i2 && e3 && this.load());
        i2 = this.techGet_("play");
        e3 && this.hasClass("vjs-ended") && this.resetProgressBar_(), null === i2 ? this.runPlayTerminatedQueue_() : this.runPlayCallbacks_(i2);
      }, e2.runPlayTerminatedQueue_ = function() {
        var e3 = this.playTerminatedQueue_.slice(0);
        this.playTerminatedQueue_ = [], e3.forEach(function(e4) {
          e4();
        });
      }, e2.runPlayCallbacks_ = function(t2) {
        var e3 = this.playCallbacks_.slice(0);
        this.playCallbacks_ = [], this.playTerminatedQueue_ = [], e3.forEach(function(e4) {
          e4(t2);
        });
      }, e2.pause = function() {
        this.techCall_("pause");
      }, e2.paused = function() {
        return false !== this.techGet_("paused");
      }, e2.played = function() {
        return this.techGet_("played") || vt(0, 0);
      }, e2.scrubbing = function(e3) {
        if ("undefined" == typeof e3)
          return this.scrubbing_;
        this.scrubbing_ = !!e3, this.techCall_("setScrubbing", this.scrubbing_), e3 ? this.addClass("vjs-scrubbing") : this.removeClass("vjs-scrubbing");
      }, e2.currentTime = function(e3) {
        return "undefined" != typeof e3 ? (e3 < 0 && (e3 = 0), this.isReady_ && !this.changingSrc_ && this.tech_ && this.tech_.isReady_ ? (this.techCall_("setCurrentTime", e3), void (this.cache_.initTime = 0)) : (this.cache_.initTime = e3, this.off("canplay", this.boundApplyInitTime_), void this.one("canplay", this.boundApplyInitTime_))) : (this.cache_.currentTime = this.techGet_("currentTime") || 0, this.cache_.currentTime);
      }, e2.applyInitTime_ = function() {
        this.currentTime(this.cache_.initTime);
      }, e2.duration = function(e3) {
        if (void 0 === e3)
          return void 0 !== this.cache_.duration ? this.cache_.duration : NaN;
        (e3 = (e3 = parseFloat(e3)) < 0 ? 1 / 0 : e3) !== this.cache_.duration && ((this.cache_.duration = e3) === 1 / 0 ? this.addClass("vjs-live") : this.removeClass("vjs-live"), isNaN(e3) || this.trigger("durationchange"));
      }, e2.remainingTime = function() {
        return this.duration() - this.currentTime();
      }, e2.remainingTimeDisplay = function() {
        return Math.floor(this.duration()) - Math.floor(this.currentTime());
      }, e2.buffered = function() {
        var e3;
        return e3 = !(e3 = this.techGet_("buffered")) || !e3.length ? vt(0, 0) : e3;
      }, e2.bufferedPercent = function() {
        return _t(this.buffered(), this.duration());
      }, e2.bufferedEnd = function() {
        var e3 = this.buffered(), t2 = this.duration(), e3 = e3.end(e3.length - 1);
        return e3 = t2 < e3 ? t2 : e3;
      }, e2.volume = function(e3) {
        var t2;
        return void 0 !== e3 ? (t2 = Math.max(0, Math.min(1, parseFloat(e3))), this.cache_.volume = t2, this.techCall_("setVolume", t2), void (0 < t2 && this.lastVolume_(t2))) : (t2 = parseFloat(this.techGet_("volume")), isNaN(t2) ? 1 : t2);
      }, e2.muted = function(e3) {
        if (void 0 === e3)
          return this.techGet_("muted") || false;
        this.techCall_("setMuted", e3);
      }, e2.defaultMuted = function(e3) {
        return void 0 !== e3 ? this.techCall_("setDefaultMuted", e3) : this.techGet_("defaultMuted") || false;
      }, e2.lastVolume_ = function(e3) {
        if (void 0 === e3 || 0 === e3)
          return this.cache_.lastVolume;
        this.cache_.lastVolume = e3;
      }, e2.supportsFullScreen = function() {
        return this.techGet_("supportsFullScreen") || false;
      }, e2.isFullscreen = function(e3) {
        if (void 0 === e3)
          return this.isFullscreen_;
        var t2 = this.isFullscreen_;
        this.isFullscreen_ = Boolean(e3), this.isFullscreen_ !== t2 && this.fsApi_.prefixed && this.trigger("fullscreenchange"), this.toggleFullscreenClass_();
      }, e2.requestFullscreen = function(s2) {
        var e3 = this.options_.Promise || window.Promise;
        if (e3) {
          var o3 = this;
          return new e3(function(e4, i2) {
            function n2() {
              o3.off("fullscreenerror", r2), o3.off("fullscreenchange", t2);
            }
            function t2() {
              n2(), e4();
            }
            function r2(e5, t3) {
              n2(), i2(t3);
            }
            o3.one("fullscreenchange", t2), o3.one("fullscreenerror", r2);
            var a2 = o3.requestFullscreenHelper_(s2);
            a2 && (a2.then(n2, n2), a2.then(e4, i2));
          });
        }
        return this.requestFullscreenHelper_();
      }, e2.requestFullscreenHelper_ = function(e3) {
        var t2 = this;
        if (this.fsApi_.prefixed || (i2 = this.options_.fullscreen && this.options_.fullscreen.options || {}, void 0 !== e3 && (i2 = e3)), this.fsApi_.requestFullscreen) {
          var i2 = this.el_[this.fsApi_.requestFullscreen](i2);
          return i2 && i2.then(function() {
            return t2.isFullscreen(true);
          }, function() {
            return t2.isFullscreen(false);
          }), i2;
        }
        this.tech_.supportsFullScreen() && true == !this.options_.preferFullWindow ? this.techCall_("enterFullScreen") : this.enterFullWindow();
      }, e2.exitFullscreen = function() {
        var e3 = this.options_.Promise || window.Promise;
        if (e3) {
          var s2 = this;
          return new e3(function(e4, i2) {
            function n2() {
              s2.off("fullscreenerror", r2), s2.off("fullscreenchange", t2);
            }
            function t2() {
              n2(), e4();
            }
            function r2(e5, t3) {
              n2(), i2(t3);
            }
            s2.one("fullscreenchange", t2), s2.one("fullscreenerror", r2);
            var a2 = s2.exitFullscreenHelper_();
            a2 && (a2.then(n2, n2), a2.then(e4, i2));
          });
        }
        return this.exitFullscreenHelper_();
      }, e2.exitFullscreenHelper_ = function() {
        var e3 = this;
        if (this.fsApi_.requestFullscreen) {
          var t2 = document[this.fsApi_.exitFullscreen]();
          return t2 && Et(t2.then(function() {
            return e3.isFullscreen(false);
          })), t2;
        }
        this.tech_.supportsFullScreen() && true == !this.options_.preferFullWindow ? this.techCall_("exitFullScreen") : this.exitFullWindow();
      }, e2.enterFullWindow = function() {
        this.isFullscreen(true), this.isFullWindow = true, this.docOrigOverflow = document.documentElement.style.overflow, Be(document, "keydown", this.boundFullWindowOnEscKey_), document.documentElement.style.overflow = "hidden", te(document.body, "vjs-full-window"), this.trigger("enterFullWindow");
      }, e2.fullWindowOnEscKey = function(e3) {
        ht.isEventKey(e3, "Esc") && true === this.isFullscreen() && (this.isFullWindow ? this.exitFullWindow() : this.exitFullscreen());
      }, e2.exitFullWindow = function() {
        this.isFullscreen(false), this.isFullWindow = false, Fe(document, "keydown", this.boundFullWindowOnEscKey_), document.documentElement.style.overflow = this.docOrigOverflow, ie(document.body, "vjs-full-window"), this.trigger("exitFullWindow");
      }, e2.disablePictureInPicture = function(e3) {
        if (void 0 === e3)
          return this.techGet_("disablePictureInPicture");
        this.techCall_("setDisablePictureInPicture", e3), this.options_.disablePictureInPicture = e3, this.trigger("disablepictureinpicturechanged");
      }, e2.isInPictureInPicture = function(e3) {
        return void 0 !== e3 ? (this.isInPictureInPicture_ = !!e3, void this.togglePictureInPictureClass_()) : !!this.isInPictureInPicture_;
      }, e2.requestPictureInPicture = function() {
        if ("pictureInPictureEnabled" in document && false === this.disablePictureInPicture())
          return this.techGet_("requestPictureInPicture");
      }, e2.exitPictureInPicture = function() {
        if ("pictureInPictureEnabled" in document)
          return document.exitPictureInPicture();
      }, e2.handleKeyDown = function(e3) {
        var t2 = this.options_.userActions;
        t2 && t2.hotkeys && (function(e4) {
          var t3 = e4.tagName.toLowerCase();
          if (e4.isContentEditable)
            return true;
          if ("input" === t3)
            return -1 === ["button", "checkbox", "hidden", "radio", "reset", "submit"].indexOf(e4.type);
          return -1 !== ["textarea"].indexOf(t3);
        }(this.el_.ownerDocument.activeElement) || ("function" == typeof t2.hotkeys ? t2.hotkeys.call(this, e3) : this.handleHotkeys(e3)));
      }, e2.handleHotkeys = function(e3) {
        var t2 = this.options_.userActions ? this.options_.userActions.hotkeys : {}, i2 = t2.fullscreenKey, n2 = t2.muteKey, n2 = void 0 === n2 ? function(e4) {
          return ht.isEventKey(e4, "m");
        } : n2, t2 = t2.playPauseKey, t2 = void 0 === t2 ? function(e4) {
          return ht.isEventKey(e4, "k") || ht.isEventKey(e4, "Space");
        } : t2;
        (void 0 === i2 ? function(e4) {
          return ht.isEventKey(e4, "f");
        } : i2).call(this, e3) ? (e3.preventDefault(), e3.stopPropagation(), i2 = pt.getComponent("FullscreenToggle"), false !== document[this.fsApi_.fullscreenEnabled] && i2.prototype.handleClick.call(this, e3)) : n2.call(this, e3) ? (e3.preventDefault(), e3.stopPropagation(), pt.getComponent("MuteToggle").prototype.handleClick.call(this, e3)) : t2.call(this, e3) && (e3.preventDefault(), e3.stopPropagation(), pt.getComponent("PlayToggle").prototype.handleClick.call(this, e3));
      }, e2.canPlayType = function(e3) {
        for (var t2, i2 = 0, n2 = this.options_.techOrder; i2 < n2.length; i2++) {
          var r2 = n2[i2], a2 = ji.getTech(r2);
          if (a2 = a2 || pt.getComponent(r2)) {
            if (a2.isSupported() && (t2 = a2.canPlayType(e3)))
              return t2;
          } else
            h.error('The "' + r2 + '" tech is undefined. Skipped browser support check for that tech.');
        }
        return "";
      }, e2.selectSource = function(e3) {
        function t2(e4, i3, n3) {
          var r3;
          return e4.some(function(t3) {
            return i3.some(function(e5) {
              if (r3 = n3(t3, e5))
                return true;
            });
          }), r3;
        }
        var i2, n2 = this, r2 = this.options_.techOrder.map(function(e4) {
          return [e4, ji.getTech(e4)];
        }).filter(function(e4) {
          var t3 = e4[0], e4 = e4[1];
          return e4 ? e4.isSupported() : (h.error('The "' + t3 + '" tech is undefined. Skipped browser support check for that tech.'), false);
        }), a2 = function(e4, t3) {
          var i3 = e4[0];
          if (e4[1].canPlaySource(t3, n2.options_[i3.toLowerCase()]))
            return { source: t3, tech: i3 };
        }, a2 = this.options_.sourceOrder ? t2(e3, r2, (i2 = a2, function(e4, t3) {
          return i2(t3, e4);
        })) : t2(r2, e3, a2);
        return a2 || false;
      }, e2.handleSrc_ = function(e3, n2) {
        var r2 = this;
        if ("undefined" == typeof e3)
          return this.cache_.src || "";
        this.resetRetryOnError_ && this.resetRetryOnError_();
        var t2, i2, a2 = Ji(e3);
        a2.length ? (this.changingSrc_ = true, n2 || (this.cache_.sources = a2), this.updateSourceCaches_(a2[0]), Wi(this, a2[0], function(e4, t3) {
          var i3;
          return r2.middleware_ = t3, n2 || (r2.cache_.sources = a2), r2.updateSourceCaches_(e4), r2.src_(e4) ? 1 < a2.length ? r2.handleSrc_(a2.slice(1)) : (r2.changingSrc_ = false, r2.setTimeout(function() {
            this.error({ code: 4, message: this.options_.notSupportedMessage });
          }, 0), void r2.triggerReady()) : (t3 = t3, i3 = r2.tech_, void t3.forEach(function(e5) {
            return e5.setTech && e5.setTech(i3);
          }));
        }), this.options_.retryOnError && 1 < a2.length && (i2 = function() {
          r2.off("error", t2);
        }, this.one("error", t2 = function() {
          r2.error(null), r2.handleSrc_(a2.slice(1), true);
        }), this.one("playing", i2), this.resetRetryOnError_ = function() {
          r2.off("error", t2), r2.off("playing", i2);
        })) : this.setTimeout(function() {
          this.error({ code: 4, message: this.options_.notSupportedMessage });
        }, 0);
      }, e2.src = function(e3) {
        return this.handleSrc_(e3, false);
      }, e2.src_ = function(e3) {
        var t2, i2, n2 = this, r2 = this.selectSource([e3]);
        return !r2 || (t2 = r2.tech, i2 = this.techName_, ut(t2) !== ut(i2) ? (this.changingSrc_ = true, this.loadTech_(r2.tech, r2.source), this.tech_.ready(function() {
          n2.changingSrc_ = false;
        })) : this.ready(function() {
          this.tech_.constructor.prototype.hasOwnProperty("setSource") ? this.techCall_("setSource", e3) : this.techCall_("src", e3.src), this.changingSrc_ = false;
        }, true), false);
      }, e2.load = function() {
        this.techCall_("load");
      }, e2.reset = function() {
        var e3 = this, t2 = this.options_.Promise || window.Promise;
        this.paused() || !t2 ? this.doReset_() : Et(this.play().then(function() {
          return e3.doReset_();
        }));
      }, e2.doReset_ = function() {
        this.tech_ && this.tech_.clearTracks("text"), this.resetCache_(), this.poster(""), this.loadTech_(this.options_.techOrder[0], null), this.techCall_("reset"), this.resetControlBarUI_(), it(this) && this.trigger("playerreset");
      }, e2.resetControlBarUI_ = function() {
        this.resetProgressBar_(), this.resetPlaybackRate_(), this.resetVolumeBar_();
      }, e2.resetProgressBar_ = function() {
        this.currentTime(0);
        var e3 = this.controlBar || {}, t2 = e3.durationDisplay, e3 = e3.remainingTimeDisplay;
        t2 && t2.updateContent(), e3 && e3.updateContent();
      }, e2.resetPlaybackRate_ = function() {
        this.playbackRate(this.defaultPlaybackRate()), this.handleTechRateChange_();
      }, e2.resetVolumeBar_ = function() {
        this.volume(1), this.trigger("volumechange");
      }, e2.currentSources = function() {
        var e3 = this.currentSource(), t2 = [];
        return 0 !== Object.keys(e3).length && t2.push(e3), this.cache_.sources || t2;
      }, e2.currentSource = function() {
        return this.cache_.source || {};
      }, e2.currentSrc = function() {
        return this.currentSource() && this.currentSource().src || "";
      }, e2.currentType = function() {
        return this.currentSource() && this.currentSource().type || "";
      }, e2.preload = function(e3) {
        return void 0 !== e3 ? (this.techCall_("setPreload", e3), void (this.options_.preload = e3)) : this.techGet_("preload");
      }, e2.autoplay = function(e3) {
        if (void 0 === e3)
          return this.options_.autoplay || false;
        var t2;
        "string" == typeof e3 && /(any|play|muted)/.test(e3) || true === e3 && this.options_.normalizeAutoplay ? (this.options_.autoplay = e3, this.manualAutoplay_("string" == typeof e3 ? e3 : "play"), t2 = false) : this.options_.autoplay = !!e3, t2 = "undefined" == typeof t2 ? this.options_.autoplay : t2, this.tech_ && this.techCall_("setAutoplay", t2);
      }, e2.playsinline = function(e3) {
        return void 0 !== e3 ? (this.techCall_("setPlaysinline", e3), this.options_.playsinline = e3, this) : this.techGet_("playsinline");
      }, e2.loop = function(e3) {
        return void 0 !== e3 ? (this.techCall_("setLoop", e3), void (this.options_.loop = e3)) : this.techGet_("loop");
      }, e2.poster = function(e3) {
        if (void 0 === e3)
          return this.poster_;
        (e3 = e3 || "") !== this.poster_ && (this.poster_ = e3, this.techCall_("setPoster", e3), this.isPosterFromTech_ = false, this.trigger("posterchange"));
      }, e2.handleTechPosterChange_ = function() {
        var e3;
        this.poster_ && !this.options_.techCanOverridePoster || !this.tech_ || !this.tech_.poster || (e3 = this.tech_.poster() || "") !== this.poster_ && (this.poster_ = e3, this.isPosterFromTech_ = true, this.trigger("posterchange"));
      }, e2.controls = function(e3) {
        if (void 0 === e3)
          return !!this.controls_;
        this.controls_ !== (e3 = !!e3) && (this.controls_ = e3, this.usingNativeControls() && this.techCall_("setControls", e3), this.controls_ ? (this.removeClass("vjs-controls-disabled"), this.addClass("vjs-controls-enabled"), this.trigger("controlsenabled"), this.usingNativeControls() || this.addTechControlsListeners_()) : (this.removeClass("vjs-controls-enabled"), this.addClass("vjs-controls-disabled"), this.trigger("controlsdisabled"), this.usingNativeControls() || this.removeTechControlsListeners_()));
      }, e2.usingNativeControls = function(e3) {
        if (void 0 === e3)
          return !!this.usingNativeControls_;
        this.usingNativeControls_ !== (e3 = !!e3) && (this.usingNativeControls_ = e3, this.usingNativeControls_ ? (this.addClass("vjs-using-native-controls"), this.trigger("usingnativecontrols")) : (this.removeClass("vjs-using-native-controls"), this.trigger("usingcustomcontrols")));
      }, e2.error = function(t2) {
        var i2 = this;
        if (void 0 === t2)
          return this.error_ || null;
        if (a("beforeerror").forEach(function(e4) {
          e4 = e4(i2, t2);
          T(e4) && !Array.isArray(e4) || "string" == typeof e4 || "number" == typeof e4 || null === e4 ? t2 = e4 : i2.log.error("please return a value that MediaError expects in beforeerror hooks");
        }), this.options_.suppressNotSupportedError && t2 && 4 === t2.code) {
          var e3 = function() {
            this.error(t2);
          };
          return this.options_.suppressNotSupportedError = false, this.any(["click", "touchstart"], e3), void this.one("loadstart", function() {
            this.off(["click", "touchstart"], e3);
          });
        }
        if (null === t2)
          return this.error_ = t2, this.removeClass("vjs-error"), void (this.errorDisplay && this.errorDisplay.close());
        this.error_ = new bt(t2), this.addClass("vjs-error"), h.error("(CODE:" + this.error_.code + " " + bt.errorTypes[this.error_.code] + ")", this.error_.message, this.error_), this.trigger("error"), a("error").forEach(function(e4) {
          return e4(i2, i2.error_);
        });
      }, e2.reportUserActivity = function(e3) {
        this.userActivity_ = true;
      }, e2.userActive = function(e3) {
        if (void 0 === e3)
          return this.userActive_;
        if ((e3 = !!e3) !== this.userActive_) {
          if (this.userActive_ = e3, this.userActive_)
            return this.userActivity_ = true, this.removeClass("vjs-user-inactive"), this.addClass("vjs-user-active"), void this.trigger("useractive");
          this.tech_ && this.tech_.one("mousemove", function(e4) {
            e4.stopPropagation(), e4.preventDefault();
          }), this.userActivity_ = false, this.removeClass("vjs-user-active"), this.addClass("vjs-user-inactive"), this.trigger("userinactive");
        }
      }, e2.listenForUserActivity_ = function() {
        var t2, i2, n2, r2 = qe(this, this.reportUserActivity), e3 = function(e4) {
          r2(), this.clearInterval(t2);
        };
        this.on("mousedown", function() {
          r2(), this.clearInterval(t2), t2 = this.setInterval(r2, 250);
        }), this.on("mousemove", function(e4) {
          e4.screenX === i2 && e4.screenY === n2 || (i2 = e4.screenX, n2 = e4.screenY, r2());
        }), this.on("mouseup", e3), this.on("mouseleave", e3);
        var a2, e3 = this.getChild("controlBar");
        !e3 || V || A || (e3.on("mouseenter", function(e4) {
          0 !== this.player().options_.inactivityTimeout && (this.player().cache_.inactivityTimeout = this.player().options_.inactivityTimeout), this.player().options_.inactivityTimeout = 0;
        }), e3.on("mouseleave", function(e4) {
          this.player().options_.inactivityTimeout = this.player().cache_.inactivityTimeout;
        })), this.on("keydown", r2), this.on("keyup", r2), this.setInterval(function() {
          var e4;
          this.userActivity_ && (this.userActivity_ = false, this.userActive(true), this.clearTimeout(a2), (e4 = this.options_.inactivityTimeout) <= 0 || (a2 = this.setTimeout(function() {
            this.userActivity_ || this.userActive(false);
          }, e4)));
        }, 250);
      }, e2.playbackRate = function(e3) {
        if (void 0 === e3)
          return this.tech_ && this.tech_.featuresPlaybackRate ? this.cache_.lastPlaybackRate || this.techGet_("playbackRate") : 1;
        this.techCall_("setPlaybackRate", e3);
      }, e2.defaultPlaybackRate = function(e3) {
        return void 0 !== e3 ? this.techCall_("setDefaultPlaybackRate", e3) : this.tech_ && this.tech_.featuresPlaybackRate ? this.techGet_("defaultPlaybackRate") : 1;
      }, e2.isAudio = function(e3) {
        if (void 0 === e3)
          return !!this.isAudio_;
        this.isAudio_ = !!e3;
      }, e2.enableAudioOnlyUI_ = function() {
        var t2 = this;
        this.addClass("vjs-audio-only-mode");
        var e3 = this.children(), i2 = this.getChild("ControlBar"), n2 = i2 && i2.currentHeight();
        e3.forEach(function(e4) {
          e4 !== i2 && e4.el_ && !e4.hasClass("vjs-hidden") && (e4.hide(), t2.audioOnlyCache_.hiddenChildren.push(e4));
        }), this.audioOnlyCache_.playerHeight = this.currentHeight(), this.height(n2), this.trigger("audioonlymodechange");
      }, e2.disableAudioOnlyUI_ = function() {
        this.removeClass("vjs-audio-only-mode"), this.audioOnlyCache_.hiddenChildren.forEach(function(e3) {
          return e3.show();
        }), this.height(this.audioOnlyCache_.playerHeight), this.trigger("audioonlymodechange");
      }, e2.audioOnlyMode = function(e3) {
        var t2 = this;
        if ("boolean" != typeof e3 || e3 === this.audioOnlyMode_)
          return this.audioOnlyMode_;
        this.audioOnlyMode_ = e3;
        var i2 = this.options_.Promise || window.Promise;
        if (i2) {
          if (e3) {
            var n2 = [];
            return this.isInPictureInPicture() && n2.push(this.exitPictureInPicture()), this.isFullscreen() && n2.push(this.exitFullscreen()), this.audioPosterMode() && n2.push(this.audioPosterMode(false)), i2.all(n2).then(function() {
              return t2.enableAudioOnlyUI_();
            });
          }
          return i2.resolve().then(function() {
            return t2.disableAudioOnlyUI_();
          });
        }
        e3 ? (this.isInPictureInPicture() && this.exitPictureInPicture(), this.isFullscreen() && this.exitFullscreen(), this.enableAudioOnlyUI_()) : this.disableAudioOnlyUI_();
      }, e2.enablePosterModeUI_ = function() {
        (this.tech_ && this.tech_).hide(), this.addClass("vjs-audio-poster-mode"), this.trigger("audiopostermodechange");
      }, e2.disablePosterModeUI_ = function() {
        (this.tech_ && this.tech_).show(), this.removeClass("vjs-audio-poster-mode"), this.trigger("audiopostermodechange");
      }, e2.audioPosterMode = function(e3) {
        var t2 = this;
        if ("boolean" != typeof e3 || e3 === this.audioPosterMode_)
          return this.audioPosterMode_;
        this.audioPosterMode_ = e3;
        var i2 = this.options_.Promise || window.Promise;
        return i2 ? e3 ? (this.audioOnlyMode() ? this.audioOnlyMode(false) : i2.resolve()).then(function() {
          t2.enablePosterModeUI_();
        }) : i2.resolve().then(function() {
          t2.disablePosterModeUI_();
        }) : e3 ? (this.audioOnlyMode() && this.audioOnlyMode(false), void this.enablePosterModeUI_()) : void this.disablePosterModeUI_();
      }, e2.addTextTrack = function(e3, t2, i2) {
        if (this.tech_)
          return this.tech_.addTextTrack(e3, t2, i2);
      }, e2.addRemoteTextTrack = function(e3, t2) {
        if (this.tech_)
          return this.tech_.addRemoteTextTrack(e3, t2);
      }, e2.removeRemoteTextTrack = function(e3) {
        var t2 = (t2 = (e3 = void 0 === e3 ? {} : e3).track) || e3;
        if (this.tech_)
          return this.tech_.removeRemoteTextTrack(t2);
      }, e2.getVideoPlaybackQuality = function() {
        return this.techGet_("getVideoPlaybackQuality");
      }, e2.videoWidth = function() {
        return this.tech_ && this.tech_.videoWidth && this.tech_.videoWidth() || 0;
      }, e2.videoHeight = function() {
        return this.tech_ && this.tech_.videoHeight && this.tech_.videoHeight() || 0;
      }, e2.language = function(e3) {
        if (void 0 === e3)
          return this.language_;
        this.language_ !== String(e3).toLowerCase() && (this.language_ = String(e3).toLowerCase(), it(this) && this.trigger("languagechange"));
      }, e2.languages = function() {
        return lt(o2.prototype.options_.languages, this.languages_);
      }, e2.toJSON = function() {
        var e3 = lt(this.options_), t2 = e3.tracks;
        e3.tracks = [];
        for (var i2 = 0; i2 < t2.length; i2++) {
          var n2 = t2[i2];
          (n2 = lt(n2)).player = void 0, e3.tracks[i2] = n2;
        }
        return e3;
      }, e2.createModal = function(e3, t2) {
        var i2 = this;
        (t2 = t2 || {}).content = e3 || "";
        var n2 = new At(this, t2);
        return this.addChild(n2), n2.on("dispose", function() {
          i2.removeChild(n2);
        }), n2.open(), n2;
      }, e2.updateCurrentBreakpoint_ = function() {
        if (this.responsive())
          for (var e3 = this.currentBreakpoint(), t2 = this.currentWidth(), i2 = 0; i2 < Nn.length; i2++) {
            var n2 = Nn[i2];
            if (t2 <= this.breakpoints_[n2]) {
              if (e3 === n2)
                return;
              e3 && this.removeClass(Un[e3]), this.addClass(Un[n2]), this.breakpoint_ = n2;
              break;
            }
          }
      }, e2.removeCurrentBreakpoint_ = function() {
        var e3 = this.currentBreakpointClass();
        this.breakpoint_ = "", e3 && this.removeClass(e3);
      }, e2.breakpoints = function(e3) {
        return void 0 === e3 || (this.breakpoint_ = "", this.breakpoints_ = b({}, Bn, e3), this.updateCurrentBreakpoint_()), b(this.breakpoints_);
      }, e2.responsive = function(e3) {
        return void 0 === e3 ? this.responsive_ : (e3 = Boolean(e3)) !== this.responsive_ ? ((this.responsive_ = e3) ? (this.on("playerresize", this.boundUpdateCurrentBreakpoint_), this.updateCurrentBreakpoint_()) : (this.off("playerresize", this.boundUpdateCurrentBreakpoint_), this.removeCurrentBreakpoint_()), e3) : void 0;
      }, e2.currentBreakpoint = function() {
        return this.breakpoint_;
      }, e2.currentBreakpointClass = function() {
        return Un[this.breakpoint_] || "";
      }, e2.loadMedia = function(e3, t2) {
        var i2, n2, r2, a2 = this;
        e3 && "object" == typeof e3 && (this.reset(), this.cache_.media = lt(e3), i2 = (r2 = this.cache_.media).artwork, n2 = r2.poster, e3 = r2.src, r2 = r2.textTracks, !i2 && n2 && (this.cache_.media.artwork = [{ src: n2, type: $i(n2) }]), e3 && this.src(e3), n2 && this.poster(n2), Array.isArray(r2) && r2.forEach(function(e4) {
          return a2.addRemoteTextTrack(e4, false);
        }), this.ready(t2));
      }, e2.getMedia = function() {
        if (this.cache_.media)
          return lt(this.cache_.media);
        var e3 = this.poster(), t2 = { src: this.currentSources(), textTracks: Array.prototype.map.call(this.remoteTextTracks(), function(e4) {
          return { kind: e4.kind, label: e4.label, language: e4.language, src: e4.src };
        }) };
        return e3 && (t2.poster = e3, t2.artwork = [{ src: t2.poster, type: $i(t2.poster) }]), t2;
      }, o2.getTagSettings = function(e3) {
        var t2, i2 = { sources: [], tracks: [] }, n2 = ae(e3), r2 = n2["data-setup"];
        if (ee(e3, "vjs-fill") && (n2.fill = true), ee(e3, "vjs-fluid") && (n2.fluid = true), null !== r2 && (r2 = (t2 = wt(r2 || "{}"))[0], t2 = t2[1], r2 && h.error(r2), b(n2, t2)), b(i2, n2), e3.hasChildNodes())
          for (var a2 = e3.childNodes, s2 = 0, o3 = a2.length; s2 < o3; s2++) {
            var u2 = a2[s2], l2 = u2.nodeName.toLowerCase();
            "source" === l2 ? i2.sources.push(ae(u2)) : "track" === l2 && i2.tracks.push(ae(u2));
          }
        return i2;
      }, e2.flexNotSupported_ = function() {
        var e3 = document.createElement("i");
        return !("flexBasis" in e3.style || "webkitFlexBasis" in e3.style || "mozFlexBasis" in e3.style || "msFlexBasis" in e3.style || "msFlexOrder" in e3.style);
      }, e2.debug = function(e3) {
        if (void 0 === e3)
          return this.debugEnabled_;
        e3 ? (this.trigger("debugon"), this.previousLogLevel_ = this.log.level, this.log.level("debug"), this.debugEnabled_ = true) : (this.trigger("debugoff"), this.log.level(this.previousLogLevel_), this.previousLogLevel_ = void 0, this.debugEnabled_ = false);
      }, e2.playbackRates = function(e3) {
        if (void 0 === e3)
          return this.cache_.playbackRates;
        Array.isArray(e3) && e3.every(function(e4) {
          return "number" == typeof e4;
        }) && (this.cache_.playbackRates = e3, this.trigger("playbackrateschange"));
      }, o2;
    }(pt);
    oi.names.forEach(function(e2) {
      var t2 = oi[e2];
      Fn.prototype[t2.getterName] = function() {
        return this.tech_ ? this.tech_[t2.getterName]() : (this[t2.privateName] = this[t2.privateName] || new t2.ListClass(), this[t2.privateName]);
      };
    }), Fn.prototype.crossorigin = Fn.prototype.crossOrigin, Fn.players = {};
    k = window.navigator;
    Fn.prototype.options_ = { techOrder: ji.defaultTechOrder_, html5: {}, inactivityTimeout: 2e3, playbackRates: [], liveui: false, children: ["mediaLoader", "posterImage", "textTrackDisplay", "loadingSpinner", "bigPlayButton", "liveTracker", "controlBar", "errorDisplay", "textTrackSettings", "resizeManager"], language: k && (k.languages && k.languages[0] || k.userLanguage || k.language) || "en", languages: {}, notSupportedMessage: "No compatible source was found for this media.", normalizeAutoplay: false, fullscreen: { options: { navigationUI: "hide" } }, breakpoints: {}, responsive: false, audioOnlyMode: false, audioPosterMode: false }, ["ended", "seeking", "seekable", "networkState", "readyState"].forEach(function(e2) {
      Fn.prototype[e2] = function() {
        return this.techGet_(e2);
      };
    }), Rn.forEach(function(e2) {
      Fn.prototype["handleTech" + ut(e2) + "_"] = function() {
        return this.trigger(e2);
      };
    }), pt.registerComponent("Player", Fn);
    var jn = m(function(i2) {
      function n2(e2, t2) {
        return i2.exports = n2 = Object.setPrototypeOf || function(e3, t3) {
          return e3.__proto__ = t3, e3;
        }, n2(e2, t2);
      }
      i2.exports = n2;
    });
    function Hn(e2) {
      return Qn.hasOwnProperty(e2);
    }
    function Vn(e2) {
      return Hn(e2) ? Qn[e2] : void 0;
    }
    function qn(e2, t2, i2) {
      i2 = (i2 ? "before" : "") + "pluginsetup", e2.trigger(i2, t2), e2.trigger(i2 + ":" + t2.name, t2);
    }
    function Wn(t2, i2) {
      function n2() {
        qn(this, { name: t2, plugin: i2, instance: null }, true);
        var e2 = i2.apply(this, arguments);
        return $n(this, t2), qn(this, { name: t2, plugin: i2, instance: e2 }), e2;
      }
      return Object.keys(i2).forEach(function(e2) {
        n2[e2] = i2[e2];
      }), n2;
    }
    function Gn(r2, a2) {
      return a2.prototype.name = r2, function() {
        qn(this, { name: r2, plugin: a2, instance: null }, true);
        for (var e2 = arguments.length, t2 = new Array(e2), i2 = 0; i2 < e2; i2++)
          t2[i2] = arguments[i2];
        var n2 = Xn(a2, [this].concat(t2));
        return this[r2] = function() {
          return n2;
        }, qn(this, n2.getEventHash()), n2;
      };
    }
    var zn = function() {
      if ("undefined" == typeof Reflect || !Reflect.construct)
        return false;
      if (Reflect.construct.sham)
        return false;
      if ("function" == typeof Proxy)
        return true;
      try {
        return Date.prototype.toString.call(Reflect.construct(Date, [], function() {
        })), true;
      } catch (e2) {
        return false;
      }
    }, Xn = m(function(n2) {
      function r2(e2, t2, i2) {
        return zn() ? n2.exports = r2 = Reflect.construct : n2.exports = r2 = function(e3, t3, i3) {
          var n3 = [null];
          n3.push.apply(n3, t3);
          n3 = new (Function.bind.apply(e3, n3))();
          return i3 && jn(n3, i3.prototype), n3;
        }, r2.apply(null, arguments);
      }
      n2.exports = r2;
    }), Kn = "plugin", Yn = "activePlugins_", Qn = {}, $n = function(e2, t2) {
      e2[Yn] = e2[Yn] || {}, e2[Yn][t2] = true;
    }, Jn = function() {
      function i2(e3) {
        if (this.constructor === i2)
          throw new Error("Plugin must be sub-classed; not directly instantiated.");
        this.player = e3, this.log || (this.log = this.player.log.createLogger(this.name)), rt(this), delete this.trigger, st(this, this.constructor.defaultState), $n(e3, this.name), this.dispose = this.dispose.bind(this), e3.on("dispose", this.dispose);
      }
      var e2 = i2.prototype;
      return e2.version = function() {
        return this.constructor.VERSION;
      }, e2.getEventHash = function(e3) {
        return (e3 = void 0 === e3 ? {} : e3).name = this.name, e3.plugin = this.constructor, e3.instance = this, e3;
      }, e2.trigger = function(e3, t2) {
        return je(this.eventBusEl_, e3, this.getEventHash(t2 = void 0 === t2 ? {} : t2));
      }, e2.handleStateChanged = function(e3) {
      }, e2.dispose = function() {
        var e3 = this.name, t2 = this.player;
        this.trigger("dispose"), this.off(), t2.off("dispose", this.dispose), t2[Yn][e3] = false, this.player = this.state = null, t2[e3] = Gn(e3, Qn[e3]);
      }, i2.isBasic = function(e3) {
        e3 = "string" == typeof e3 ? Vn(e3) : e3;
        return "function" == typeof e3 && !i2.prototype.isPrototypeOf(e3.prototype);
      }, i2.registerPlugin = function(e3, t2) {
        if ("string" != typeof e3)
          throw new Error('Illegal plugin name, "' + e3 + '", must be a string, was ' + typeof e3 + ".");
        if (Hn(e3))
          h.warn('A plugin named "' + e3 + '" already exists. You may want to avoid re-registering plugins!');
        else if (Fn.prototype.hasOwnProperty(e3))
          throw new Error('Illegal plugin name, "' + e3 + '", cannot share a name with an existing player method!');
        if ("function" != typeof t2)
          throw new Error('Illegal plugin for "' + e3 + '", must be a function, was ' + typeof t2 + ".");
        return Qn[e3] = t2, e3 !== Kn && (i2.isBasic(t2) ? Fn.prototype[e3] = Wn(e3, t2) : Fn.prototype[e3] = Gn(e3, t2)), t2;
      }, i2.deregisterPlugin = function(e3) {
        if (e3 === Kn)
          throw new Error("Cannot de-register base plugin.");
        Hn(e3) && (delete Qn[e3], delete Fn.prototype[e3]);
      }, i2.getPlugins = function(e3) {
        var i3;
        return (e3 = void 0 === e3 ? Object.keys(Qn) : e3).forEach(function(e4) {
          var t2 = Vn(e4);
          t2 && ((i3 = i3 || {})[e4] = t2);
        }), i3;
      }, i2.getPluginVersion = function(e3) {
        e3 = Vn(e3);
        return e3 && e3.VERSION || "";
      }, i2;
    }();
    Jn.getPlugin = Vn, Jn.BASE_PLUGIN_NAME = Kn, Jn.registerPlugin(Kn, Jn), Fn.prototype.usingPlugin = function(e2) {
      return !!this[Yn] && true === this[Yn][e2];
    }, Fn.prototype.hasPlugin = function(e2) {
      return !!Hn(e2);
    };
    var Zn = function(e2, t2) {
      if ("function" != typeof t2 && null !== t2)
        throw new TypeError("Super expression must either be null or a function");
      e2.prototype = Object.create(t2 && t2.prototype, { constructor: { value: e2, writable: true, configurable: true } }), t2 && jn(e2, t2);
    }, er = false, tr = function(e2) {
      return 0 === e2.indexOf("#") ? e2.slice(1) : e2;
    };
    function ir(e2, t2, i2) {
      if (r2 = ir.getPlayer(e2))
        return t2 && h.warn('Player "' + e2 + '" is already initialised. Options will not be applied.'), i2 && r2.ready(i2), r2;
      var n2 = "string" == typeof e2 ? Te("#" + tr(e2)) : e2;
      if (!K(n2))
        throw new TypeError("The element or ID supplied is not valid. (videojs)");
      n2.ownerDocument.defaultView && n2.ownerDocument.body.contains(n2) || h.warn("The element supplied is not included in the DOM"), true === (t2 = t2 || {}).restoreEl && (t2.restoreEl = (n2.parentNode && n2.parentNode.hasAttribute("data-vjs-player") ? n2.parentNode : n2).cloneNode(true)), a("beforesetup").forEach(function(e3) {
        e3 = e3(n2, lt(t2));
        T(e3) && !Array.isArray(e3) ? t2 = lt(t2, e3) : h.error("please return an object in beforesetup hooks");
      });
      var r2 = new (pt.getComponent("Player"))(n2, t2, i2);
      return a("setup").forEach(function(e3) {
        return e3(r2);
      }), r2;
    }
    ir.hooks_ = i, ir.hooks = a, ir.hook = function(e2, t2) {
      a(e2, t2);
    }, ir.hookOnce = function(i2, e2) {
      a(i2, [].concat(e2).map(function(t2) {
        return function e3() {
          return n(i2, e3), t2.apply(void 0, arguments);
        };
      }));
    }, ir.removeHook = n, true !== window.VIDEOJS_NO_DYNAMIC_STYLE && X() && ((Qr = Te(".vjs-styles-defaults")) || (Qr = xe("vjs-styles-defaults"), (ar = Te("head")) && ar.insertBefore(Qr, ar.firstChild), Ae(Qr, "\n      .video-js {\n        width: 300px;\n        height: 150px;\n      }\n\n      .vjs-fluid:not(.vjs-audio-only-mode) {\n        padding-top: 56.25%\n      }\n    "))), Ce(1, ir), ir.VERSION = u, ir.options = Fn.prototype.options_, ir.getPlayers = function() {
      return Fn.players;
    }, ir.getPlayer = function(e2) {
      var t2 = Fn.players;
      if ("string" == typeof e2) {
        var i2 = tr(e2), n2 = t2[i2];
        if (n2)
          return n2;
        i2 = Te("#" + i2);
      } else
        i2 = e2;
      if (K(i2)) {
        e2 = i2.player, i2 = i2.playerId;
        if (e2 || t2[i2])
          return e2 || t2[i2];
      }
    }, ir.getAllPlayers = function() {
      return Object.keys(Fn.players).map(function(e2) {
        return Fn.players[e2];
      }).filter(Boolean);
    }, ir.players = Fn.players, ir.getComponent = pt.getComponent, ir.registerComponent = function(e2, t2) {
      ji.isTech(t2) && h.warn("The " + e2 + " tech was registered as a component. It should instead be registered using videojs.registerTech(name, tech)"), pt.registerComponent.call(pt, e2, t2);
    }, ir.getTech = ji.getTech, ir.registerTech = ji.registerTech, ir.use = function(e2, t2) {
      Hi[e2] = Hi[e2] || [], Hi[e2].push(t2);
    }, Object.defineProperty(ir, "middleware", { value: {}, writeable: false, enumerable: true }), Object.defineProperty(ir.middleware, "TERMINATOR", { value: qi, writeable: false, enumerable: true }), ir.browser = W, ir.TOUCH_ENABLED = F, ir.extend = function(e2, t2) {
      void 0 === t2 && (t2 = {}), er || (h.warn("videojs.extend is deprecated as of Video.js 7.22.0 and will be removed in Video.js 8.0.0"), er = true);
      var i2, n2 = function() {
        e2.apply(this, arguments);
      }, r2 = {};
      for (i2 in "object" == typeof t2 ? (t2.constructor !== Object.prototype.constructor && (n2 = t2.constructor), r2 = t2) : "function" == typeof t2 && (n2 = t2), Zn(n2, e2), e2 && (n2.super_ = e2), r2)
        r2.hasOwnProperty(i2) && (n2.prototype[i2] = r2[i2]);
      return n2;
    }, ir.mergeOptions = lt, ir.bind = qe, ir.registerPlugin = Jn.registerPlugin, ir.deregisterPlugin = Jn.deregisterPlugin, ir.plugin = function(e2, t2) {
      return h.warn("videojs.plugin() is deprecated; use videojs.registerPlugin() instead"), Jn.registerPlugin(e2, t2);
    }, ir.getPlugins = Jn.getPlugins, ir.getPlugin = Jn.getPlugin, ir.getPluginVersion = Jn.getPluginVersion, ir.addLanguage = function(e2, t2) {
      var i2;
      return e2 = ("" + e2).toLowerCase(), ir.options.languages = lt(ir.options.languages, ((i2 = {})[e2] = t2, i2)), ir.options.languages[e2];
    }, ir.log = h, ir.createLogger = p, ir.createTimeRange = ir.createTimeRanges = vt, ir.formatTime = ln, ir.setFormatTime = function(e2) {
      un = e2;
    }, ir.resetFormatTime = function() {
      un = on;
    }, ir.parseUrl = Rt, ir.isCrossOrigin = Ut, ir.EventTarget = ze, ir.on = Be, ir.one = He, ir.off = Fe, ir.trigger = je, ir.xhr = Jt, ir.TextTrack = ri, ir.AudioTrack = x, ir.VideoTrack = U, ["isEl", "isTextNode", "createEl", "hasClass", "addClass", "removeClass", "toggleClass", "setAttributes", "getAttributes", "emptyEl", "appendContent", "insertContent"].forEach(function(e2) {
      ir[e2] = function() {
        return h.warn("videojs." + e2 + "() is deprecated; use videojs.dom." + e2 + "() instead"), Se[e2].apply(null, arguments);
      };
    }), ir.computedStyle = S, ir.dom = Se, ir.url = zt, ir.defineLazyProperty = An, ir.addLanguage("en", { "Non-Fullscreen": "Exit Fullscreen" });
    var nr = m(function(e2, t2) {
      var i2, a2, n2, r2, s2;
      i2 = /^((?:[a-zA-Z0-9+\-.]+:)?)(\/\/[^\/?#]*)?((?:[^\/?#]*\/)*[^;?#]*)?(;[^?#]*)?(\?[^#]*)?(#[^]*)?$/, a2 = /^([^\/?#]*)([^]*)$/, n2 = /(?:\/|^)\.(?=\/)/g, r2 = /(?:\/|^)\.\.\/(?!\.\.\/)[^\/]*(?=\/)/g, s2 = { buildAbsoluteURL: function(e3, t3, i3) {
        if (i3 = i3 || {}, e3 = e3.trim(), !(t3 = t3.trim())) {
          if (!i3.alwaysNormalize)
            return e3;
          var n3 = s2.parseURL(e3);
          if (!n3)
            throw new Error("Error trying to parse base URL.");
          return n3.path = s2.normalizePath(n3.path), s2.buildURLFromParts(n3);
        }
        n3 = s2.parseURL(t3);
        if (!n3)
          throw new Error("Error trying to parse relative URL.");
        if (n3.scheme)
          return i3.alwaysNormalize ? (n3.path = s2.normalizePath(n3.path), s2.buildURLFromParts(n3)) : t3;
        t3 = s2.parseURL(e3);
        if (!t3)
          throw new Error("Error trying to parse base URL.");
        !t3.netLoc && t3.path && "/" !== t3.path[0] && (r3 = a2.exec(t3.path), t3.netLoc = r3[1], t3.path = r3[2]), t3.netLoc && !t3.path && (t3.path = "/");
        var r3, e3 = { scheme: t3.scheme, netLoc: n3.netLoc, path: null, params: n3.params, query: n3.query, fragment: n3.fragment };
        return n3.netLoc || (e3.netLoc = t3.netLoc, "/" !== n3.path[0] && (n3.path ? (r3 = (r3 = t3.path).substring(0, r3.lastIndexOf("/") + 1) + n3.path, e3.path = s2.normalizePath(r3)) : (e3.path = t3.path, n3.params || (e3.params = t3.params, n3.query || (e3.query = t3.query))))), null === e3.path && (e3.path = i3.alwaysNormalize ? s2.normalizePath(n3.path) : n3.path), s2.buildURLFromParts(e3);
      }, parseURL: function(e3) {
        e3 = i2.exec(e3);
        return e3 ? { scheme: e3[1] || "", netLoc: e3[2] || "", path: e3[3] || "", params: e3[4] || "", query: e3[5] || "", fragment: e3[6] || "" } : null;
      }, normalizePath: function(e3) {
        for (e3 = e3.split("").reverse().join("").replace(n2, ""); e3.length !== (e3 = e3.replace(r2, "")).length; )
          ;
        return e3.split("").reverse().join("");
      }, buildURLFromParts: function(e3) {
        return e3.scheme + e3.netLoc + e3.path + e3.params + e3.query + e3.fragment;
      } }, e2.exports = s2;
    }), rr = "http://example.com", ar = function() {
      function e2() {
        this.listeners = {};
      }
      var t2 = e2.prototype;
      return t2.on = function(e3, t3) {
        this.listeners[e3] || (this.listeners[e3] = []), this.listeners[e3].push(t3);
      }, t2.off = function(e3, t3) {
        if (!this.listeners[e3])
          return false;
        t3 = this.listeners[e3].indexOf(t3);
        return this.listeners[e3] = this.listeners[e3].slice(0), this.listeners[e3].splice(t3, 1), -1 < t3;
      }, t2.trigger = function(e3) {
        var t3 = this.listeners[e3];
        if (t3)
          if (2 === arguments.length)
            for (var i2 = t3.length, n2 = 0; n2 < i2; ++n2)
              t3[n2].call(this, arguments[1]);
          else
            for (var r2 = Array.prototype.slice.call(arguments, 1), a2 = t3.length, s2 = 0; s2 < a2; ++s2)
              t3[s2].apply(this, r2);
      }, t2.dispose = function() {
        this.listeners = {};
      }, t2.pipe = function(t3) {
        this.on("data", function(e3) {
          t3.push(e3);
        });
      }, e2;
    }(), sr = function(e2) {
      return window.atob ? window.atob(e2) : Buffer.from(e2, "base64").toString("binary");
    };
    function or(e2) {
      var t2 = /([0-9.]*)?@?([0-9.]*)?/.exec(e2 || ""), e2 = {};
      return t2[1] && (e2.length = parseInt(t2[1], 10)), t2[2] && (e2.offset = parseInt(t2[2], 10)), e2;
    }
    function ur(e2) {
      for (var t2, i2 = e2.split(new RegExp('(?:^|,)((?:[^=]*)=(?:"[^"]*"|[^,]*))')), n2 = {}, r2 = i2.length; r2--; )
        "" !== i2[r2] && ((t2 = /([^=]*)=(.*)/.exec(i2[r2]).slice(1))[0] = t2[0].replace(/^\s+|\s+$/g, ""), t2[1] = t2[1].replace(/^\s+|\s+$/g, ""), t2[1] = t2[1].replace(/^['"](.*)['"]$/g, "$1"), n2[t2[0]] = t2[1]);
      return n2;
    }
    function lr(t2) {
      var i2 = {};
      return Object.keys(t2).forEach(function(e2) {
        i2[e2.toLowerCase().replace(/-(\w)/g, function(e3) {
          return e3[1].toUpperCase();
        })] = t2[e2];
      }), i2;
    }
    function dr(e2) {
      var t2, i2, n2, r2, a2 = e2.serverControl, s2 = e2.targetDuration, o2 = e2.partTargetDuration;
      a2 && (t2 = "#EXT-X-SERVER-CONTROL", i2 = "holdBack", n2 = "partHoldBack", r2 = s2 && 3 * s2, e2 = o2 && 2 * o2, s2 && !a2.hasOwnProperty(i2) && (a2[i2] = r2, this.trigger("info", { message: t2 + " defaulting HOLD-BACK to targetDuration * 3 (" + r2 + ")." })), r2 && a2[i2] < r2 && (this.trigger("warn", { message: t2 + " clamping HOLD-BACK (" + a2[i2] + ") to targetDuration * 3 (" + r2 + ")" }), a2[i2] = r2), o2 && !a2.hasOwnProperty(n2) && (a2[n2] = 3 * o2, this.trigger("info", { message: t2 + " defaulting PART-HOLD-BACK to partTargetDuration * 3 (" + a2[n2] + ")." })), o2 && a2[n2] < e2 && (this.trigger("warn", { message: t2 + " clamping PART-HOLD-BACK (" + a2[n2] + ") to partTargetDuration * 2 (" + e2 + ")." }), a2[n2] = e2));
    }
    function cr(e2) {
      return e2 && e2.replace(/avc1\.(\d+)\.(\d+)/i, function(e3, t2, i2) {
        return "avc1." + ("00" + Number(t2).toString(16)).slice(-2) + "00" + ("00" + Number(i2).toString(16)).slice(-2);
      });
    }
    function hr(e2) {
      var e2 = (e2 = void 0 === e2 ? "" : e2).split(","), a2 = [];
      return e2.forEach(function(n2) {
        var r2;
        n2 = n2.trim(), Ar.forEach(function(e3) {
          var t2, i2 = xr[e3].exec(n2.toLowerCase());
          !i2 || i2.length <= 1 || (r2 = e3, t2 = n2.substring(0, i2[1].length), i2 = n2.replace(t2, ""), a2.push({ type: t2, details: i2, mediaType: e3 }));
        }), r2 || a2.push({ type: n2, details: "", mediaType: "unknown" });
      }), a2;
    }
    function pr(e2) {
      return xr.audio.test((e2 = void 0 === e2 ? "" : e2).trim().toLowerCase());
    }
    function fr(e2) {
      if (e2 && "string" == typeof e2) {
        var t2 = e2.toLowerCase().split(",").map(function(e3) {
          return cr(e3.trim());
        }), i2 = "video";
        1 === t2.length && pr(t2[0]) ? i2 = "audio" : 1 === t2.length && (n2 = t2[0], xr.text.test((n2 = void 0 === n2 ? "" : n2).trim().toLowerCase())) && (i2 = "application");
        var n2 = "mp4";
        return t2.every(function(e3) {
          return xr.mp4.test(e3);
        }) ? n2 = "mp4" : t2.every(function(e3) {
          return xr.webm.test(e3);
        }) ? n2 = "webm" : t2.every(function(e3) {
          return xr.ogg.test(e3);
        }) && (n2 = "ogg"), i2 + "/" + n2 + ';codecs="' + e2 + '"';
      }
    }
    function mr(e2) {
      return void 0 === e2 && (e2 = ""), window.MediaSource && window.MediaSource.isTypeSupported && window.MediaSource.isTypeSupported(fr(e2)) || false;
    }
    function gr(e2) {
      return (e2 = void 0 === e2 ? "" : e2).toLowerCase().split(",").every(function(e3) {
        e3 = e3.trim();
        for (var t2 = 0; t2 < Pr.length; t2++)
          if (xr["muxer" + Pr[t2]].test(e3))
            return true;
        return false;
      });
    }
    function yr(e2) {
      return Or.test(e2) ? "hls" : Dr.test(e2) ? "dash" : "application/vnd.videojs.vhs+json" === e2 ? "vhs-json" : null;
    }
    function vr(e2) {
      return "function" === ArrayBuffer.isView ? ArrayBuffer.isView(e2) : e2 && e2.buffer instanceof ArrayBuffer;
    }
    function _r(e2) {
      return e2 instanceof Uint8Array ? e2 : (Array.isArray(e2) || Rr(e2) || e2 instanceof ArrayBuffer || (e2 = "number" != typeof e2 || "number" == typeof e2 && e2 != e2 ? 0 : [e2]), new Uint8Array(e2 && e2.buffer || e2, e2 && e2.byteOffset || 0, e2 && e2.byteLength || 0));
    }
    function br(e2, t2) {
      var i2 = void 0 !== (t2 = (void 0 === t2 ? {} : t2).le) && t2;
      e2 = Mr(e2 = "bigint" != typeof e2 && "number" != typeof e2 || "number" == typeof e2 && e2 != e2 ? 0 : e2);
      for (var n2 = (t2 = e2, Math.ceil(t2.toString(2).length / 8)), r2 = new Uint8Array(new ArrayBuffer(n2)), a2 = 0; a2 < n2; a2++) {
        var s2 = i2 ? a2 : Math.abs(a2 + 1 - r2.length);
        r2[s2] = Number(e2 / Nr[a2] & Mr(255)), e2 < 0 && (r2[s2] = Math.abs(~r2[s2]), r2[s2] -= 0 === a2 ? 1 : 2);
      }
      return r2;
    }
    function Tr(e2, t2) {
      if ("string" != typeof (e2 = "string" != typeof e2 && e2 && "function" == typeof e2.toString ? e2.toString() : e2))
        return new Uint8Array();
      t2 || (e2 = unescape(encodeURIComponent(e2)));
      for (var i2 = new Uint8Array(e2.length), n2 = 0; n2 < e2.length; n2++)
        i2[n2] = e2.charCodeAt(n2);
      return i2;
    }
    function wr(i2, e2, t2) {
      var n2 = void 0 === t2 ? {} : t2, r2 = void 0 === (t2 = n2.offset) ? 0 : t2, a2 = void 0 === (n2 = n2.mask) ? [] : n2;
      return i2 = _r(i2), n2 = (e2 = _r(e2)).every || Array.prototype.every, e2.length && i2.length - r2 >= e2.length && n2.call(e2, function(e3, t3) {
        return e3 === (a2[t3] ? a2[t3] & i2[r2 + t3] : i2[r2 + t3]);
      });
    }
    function Sr(e2, t2) {
      if (/^[a-z]+:/i.test(t2))
        return t2;
      /^data:/.test(e2) && (e2 = window.location && window.location.href || "");
      var i2 = "function" == typeof window.URL, n2 = /^\/\//.test(e2), r2 = !window.location && !/\/\//i.test(e2);
      if (i2 ? e2 = new window.URL(e2, window.location || Ur) : /\/\//i.test(e2) || (e2 = nr.buildAbsoluteURL(window.location && window.location.href || "", e2)), i2) {
        i2 = new URL(t2, e2);
        return r2 ? i2.href.slice(Ur.length) : n2 ? i2.href.slice(i2.protocol.length) : i2.href;
      }
      return nr.buildAbsoluteURL(e2, t2);
    }
    /*! @name m3u8-parser @version 4.8.0 @license Apache-2.0 */
    var Er = function(t2) {
      function e2() {
        var e3 = t2.call(this) || this;
        return e3.buffer = "", e3;
      }
      return mt(e2, t2), e2.prototype.push = function(e3) {
        var t3;
        for (this.buffer += e3, t3 = this.buffer.indexOf("\n"); -1 < t3; t3 = this.buffer.indexOf("\n"))
          this.trigger("data", this.buffer.substring(0, t3)), this.buffer = this.buffer.substring(t3 + 1);
      }, e2;
    }(ar), kr = String.fromCharCode(9), Cr = function(t2) {
      function e2() {
        var e3 = t2.call(this) || this;
        return e3.customParsers = [], e3.tagMappers = [], e3;
      }
      mt(e2, t2);
      var i2 = e2.prototype;
      return i2.push = function(i3) {
        var r2, a2, s2 = this;
        0 !== (i3 = i3.trim()).length && ("#" === i3[0] ? this.tagMappers.reduce(function(e3, t3) {
          t3 = t3(i3);
          return t3 === i3 ? e3 : e3.concat([t3]);
        }, [i3]).forEach(function(e3) {
          for (var t3, i4, n2 = 0; n2 < s2.customParsers.length; n2++)
            if (s2.customParsers[n2].call(s2, e3))
              return;
          if (0 === e3.indexOf("#EXT"))
            if (e3 = e3.replace("\r", ""), r2 = /^#EXTM3U/.exec(e3))
              s2.trigger("data", { type: "tag", tagType: "m3u" });
            else {
              if (r2 = /^#EXTINF:?([0-9\.]*)?,?(.*)?$/.exec(e3))
                return a2 = { type: "tag", tagType: "inf" }, r2[1] && (a2.duration = parseFloat(r2[1])), r2[2] && (a2.title = r2[2]), void s2.trigger("data", a2);
              if (r2 = /^#EXT-X-TARGETDURATION:?([0-9.]*)?/.exec(e3))
                return a2 = { type: "tag", tagType: "targetduration" }, r2[1] && (a2.duration = parseInt(r2[1], 10)), void s2.trigger("data", a2);
              if (r2 = /^#EXT-X-VERSION:?([0-9.]*)?/.exec(e3))
                return a2 = { type: "tag", tagType: "version" }, r2[1] && (a2.version = parseInt(r2[1], 10)), void s2.trigger("data", a2);
              if (r2 = /^#EXT-X-MEDIA-SEQUENCE:?(\-?[0-9.]*)?/.exec(e3))
                return a2 = { type: "tag", tagType: "media-sequence" }, r2[1] && (a2.number = parseInt(r2[1], 10)), void s2.trigger("data", a2);
              if (r2 = /^#EXT-X-DISCONTINUITY-SEQUENCE:?(\-?[0-9.]*)?/.exec(e3))
                return a2 = { type: "tag", tagType: "discontinuity-sequence" }, r2[1] && (a2.number = parseInt(r2[1], 10)), void s2.trigger("data", a2);
              if (r2 = /^#EXT-X-PLAYLIST-TYPE:?(.*)?$/.exec(e3))
                return a2 = { type: "tag", tagType: "playlist-type" }, r2[1] && (a2.playlistType = r2[1]), void s2.trigger("data", a2);
              if (r2 = /^#EXT-X-BYTERANGE:?(.*)?$/.exec(e3))
                return a2 = g(or(r2[1]), { type: "tag", tagType: "byterange" }), void s2.trigger("data", a2);
              if (r2 = /^#EXT-X-ALLOW-CACHE:?(YES|NO)?/.exec(e3))
                return a2 = { type: "tag", tagType: "allow-cache" }, r2[1] && (a2.allowed = !/NO/.test(r2[1])), void s2.trigger("data", a2);
              if (r2 = /^#EXT-X-MAP:?(.*)$/.exec(e3))
                return a2 = { type: "tag", tagType: "map" }, r2[1] && ((t3 = ur(r2[1])).URI && (a2.uri = t3.URI), t3.BYTERANGE && (a2.byterange = or(t3.BYTERANGE))), void s2.trigger("data", a2);
              if (r2 = /^#EXT-X-STREAM-INF:?(.*)$/.exec(e3))
                return a2 = { type: "tag", tagType: "stream-inf" }, r2[1] && (a2.attributes = ur(r2[1]), a2.attributes.RESOLUTION && (i4 = {}, (t3 = a2.attributes.RESOLUTION.split("x"))[0] && (i4.width = parseInt(t3[0], 10)), t3[1] && (i4.height = parseInt(t3[1], 10)), a2.attributes.RESOLUTION = i4), a2.attributes.BANDWIDTH && (a2.attributes.BANDWIDTH = parseInt(a2.attributes.BANDWIDTH, 10)), a2.attributes["FRAME-RATE"] && (a2.attributes["FRAME-RATE"] = parseFloat(a2.attributes["FRAME-RATE"])), a2.attributes["PROGRAM-ID"] && (a2.attributes["PROGRAM-ID"] = parseInt(a2.attributes["PROGRAM-ID"], 10))), void s2.trigger("data", a2);
              if (r2 = /^#EXT-X-MEDIA:?(.*)$/.exec(e3))
                return a2 = { type: "tag", tagType: "media" }, r2[1] && (a2.attributes = ur(r2[1])), void s2.trigger("data", a2);
              if (r2 = /^#EXT-X-ENDLIST/.exec(e3))
                s2.trigger("data", { type: "tag", tagType: "endlist" });
              else {
                if (!(r2 = /^#EXT-X-DISCONTINUITY/.exec(e3)))
                  return (r2 = /^#EXT-X-PROGRAM-DATE-TIME:?(.*)$/.exec(e3)) ? (a2 = { type: "tag", tagType: "program-date-time" }, r2[1] && (a2.dateTimeString = r2[1], a2.dateTimeObject = new Date(r2[1])), void s2.trigger("data", a2)) : (r2 = /^#EXT-X-KEY:?(.*)$/.exec(e3)) ? (a2 = { type: "tag", tagType: "key" }, r2[1] && (a2.attributes = ur(r2[1]), a2.attributes.IV && ("0x" === a2.attributes.IV.substring(0, 2).toLowerCase() && (a2.attributes.IV = a2.attributes.IV.substring(2)), a2.attributes.IV = a2.attributes.IV.match(/.{8}/g), a2.attributes.IV[0] = parseInt(a2.attributes.IV[0], 16), a2.attributes.IV[1] = parseInt(a2.attributes.IV[1], 16), a2.attributes.IV[2] = parseInt(a2.attributes.IV[2], 16), a2.attributes.IV[3] = parseInt(a2.attributes.IV[3], 16), a2.attributes.IV = new Uint32Array(a2.attributes.IV))), void s2.trigger("data", a2)) : (r2 = /^#EXT-X-START:?(.*)$/.exec(e3)) ? (a2 = { type: "tag", tagType: "start" }, r2[1] && (a2.attributes = ur(r2[1]), a2.attributes["TIME-OFFSET"] = parseFloat(a2.attributes["TIME-OFFSET"]), a2.attributes.PRECISE = /YES/.test(a2.attributes.PRECISE)), void s2.trigger("data", a2)) : (r2 = /^#EXT-X-CUE-OUT-CONT:?(.*)?$/.exec(e3)) ? (a2 = { type: "tag", tagType: "cue-out-cont" }, r2[1] ? a2.data = r2[1] : a2.data = "", void s2.trigger("data", a2)) : (r2 = /^#EXT-X-CUE-OUT:?(.*)?$/.exec(e3)) ? (a2 = { type: "tag", tagType: "cue-out" }, r2[1] ? a2.data = r2[1] : a2.data = "", void s2.trigger("data", a2)) : (r2 = /^#EXT-X-CUE-IN:?(.*)?$/.exec(e3)) ? (a2 = { type: "tag", tagType: "cue-in" }, r2[1] ? a2.data = r2[1] : a2.data = "", void s2.trigger("data", a2)) : (r2 = /^#EXT-X-SKIP:(.*)$/.exec(e3)) && r2[1] ? ((a2 = { type: "tag", tagType: "skip" }).attributes = ur(r2[1]), a2.attributes.hasOwnProperty("SKIPPED-SEGMENTS") && (a2.attributes["SKIPPED-SEGMENTS"] = parseInt(a2.attributes["SKIPPED-SEGMENTS"], 10)), a2.attributes.hasOwnProperty("RECENTLY-REMOVED-DATERANGES") && (a2.attributes["RECENTLY-REMOVED-DATERANGES"] = a2.attributes["RECENTLY-REMOVED-DATERANGES"].split(kr)), void s2.trigger("data", a2)) : (r2 = /^#EXT-X-PART:(.*)$/.exec(e3)) && r2[1] ? ((a2 = { type: "tag", tagType: "part" }).attributes = ur(r2[1]), ["DURATION"].forEach(function(e4) {
                    a2.attributes.hasOwnProperty(e4) && (a2.attributes[e4] = parseFloat(a2.attributes[e4]));
                  }), ["INDEPENDENT", "GAP"].forEach(function(e4) {
                    a2.attributes.hasOwnProperty(e4) && (a2.attributes[e4] = /YES/.test(a2.attributes[e4]));
                  }), a2.attributes.hasOwnProperty("BYTERANGE") && (a2.attributes.byterange = or(a2.attributes.BYTERANGE)), void s2.trigger("data", a2)) : (r2 = /^#EXT-X-SERVER-CONTROL:(.*)$/.exec(e3)) && r2[1] ? ((a2 = { type: "tag", tagType: "server-control" }).attributes = ur(r2[1]), ["CAN-SKIP-UNTIL", "PART-HOLD-BACK", "HOLD-BACK"].forEach(function(e4) {
                    a2.attributes.hasOwnProperty(e4) && (a2.attributes[e4] = parseFloat(a2.attributes[e4]));
                  }), ["CAN-SKIP-DATERANGES", "CAN-BLOCK-RELOAD"].forEach(function(e4) {
                    a2.attributes.hasOwnProperty(e4) && (a2.attributes[e4] = /YES/.test(a2.attributes[e4]));
                  }), void s2.trigger("data", a2)) : (r2 = /^#EXT-X-PART-INF:(.*)$/.exec(e3)) && r2[1] ? ((a2 = { type: "tag", tagType: "part-inf" }).attributes = ur(r2[1]), ["PART-TARGET"].forEach(function(e4) {
                    a2.attributes.hasOwnProperty(e4) && (a2.attributes[e4] = parseFloat(a2.attributes[e4]));
                  }), void s2.trigger("data", a2)) : (r2 = /^#EXT-X-PRELOAD-HINT:(.*)$/.exec(e3)) && r2[1] ? ((a2 = { type: "tag", tagType: "preload-hint" }).attributes = ur(r2[1]), ["BYTERANGE-START", "BYTERANGE-LENGTH"].forEach(function(e4) {
                    var t4;
                    a2.attributes.hasOwnProperty(e4) && (a2.attributes[e4] = parseInt(a2.attributes[e4], 10), t4 = "BYTERANGE-LENGTH" === e4 ? "length" : "offset", a2.attributes.byterange = a2.attributes.byterange || {}, a2.attributes.byterange[t4] = a2.attributes[e4], delete a2.attributes[e4]);
                  }), void s2.trigger("data", a2)) : (r2 = /^#EXT-X-RENDITION-REPORT:(.*)$/.exec(e3)) && r2[1] ? ((a2 = { type: "tag", tagType: "rendition-report" }).attributes = ur(r2[1]), ["LAST-MSN", "LAST-PART"].forEach(function(e4) {
                    a2.attributes.hasOwnProperty(e4) && (a2.attributes[e4] = parseInt(a2.attributes[e4], 10));
                  }), void s2.trigger("data", a2)) : void s2.trigger("data", { type: "tag", data: e3.slice(4) });
                s2.trigger("data", { type: "tag", tagType: "discontinuity" });
              }
            }
          else
            s2.trigger("data", { type: "comment", text: e3.slice(1) });
        }) : this.trigger("data", { type: "uri", uri: i3 }));
      }, i2.addParser = function(e3) {
        var t3 = this, i3 = e3.expression, n2 = e3.customType, r2 = e3.dataParser, a2 = e3.segment;
        "function" != typeof r2 && (r2 = function(e4) {
          return e4;
        }), this.customParsers.push(function(e4) {
          if (i3.exec(e4))
            return t3.trigger("data", { type: "custom", data: r2(e4), customType: n2, segment: a2 }), true;
        });
      }, i2.addTagMapper = function(e3) {
        var t3 = e3.expression, i3 = e3.map;
        this.tagMappers.push(function(e4) {
          return t3.test(e4) ? i3(e4) : e4;
        });
      }, e2;
    }(ar), Ir = function(t2) {
      function e2() {
        var e3 = t2.call(this) || this;
        e3.lineStream = new Er(), e3.parseStream = new Cr(), e3.lineStream.pipe(e3.parseStream);
        var n2, r2, a2 = ft(e3), o2 = [], u2 = {}, l2 = false, d2 = { AUDIO: {}, VIDEO: {}, "CLOSED-CAPTIONS": {}, SUBTITLES: {} }, c2 = 0;
        e3.manifest = { allowCache: true, discontinuityStarts: [], segments: [] };
        var h2 = 0, p2 = 0;
        return e3.on("end", function() {
          u2.uri || !u2.parts && !u2.preloadHints || (!u2.map && n2 && (u2.map = n2), !u2.key && r2 && (u2.key = r2), u2.timeline || "number" != typeof c2 || (u2.timeline = c2), e3.manifest.preloadSegment = u2);
        }), e3.parseStream.on("data", function(s2) {
          var t3, i3;
          ({ tag: function() {
            ({ version: function() {
              s2.version && (this.manifest.version = s2.version);
            }, "allow-cache": function() {
              this.manifest.allowCache = s2.allowed, "allowed" in s2 || (this.trigger("info", { message: "defaulting allowCache to YES" }), this.manifest.allowCache = true);
            }, byterange: function() {
              var e4 = {};
              "length" in s2 && ((u2.byterange = e4).length = s2.length, "offset" in s2 || (s2.offset = h2)), "offset" in s2 && ((u2.byterange = e4).offset = s2.offset), h2 = e4.offset + e4.length;
            }, endlist: function() {
              this.manifest.endList = true;
            }, inf: function() {
              "mediaSequence" in this.manifest || (this.manifest.mediaSequence = 0, this.trigger("info", { message: "defaulting media sequence to zero" })), "discontinuitySequence" in this.manifest || (this.manifest.discontinuitySequence = 0, this.trigger("info", { message: "defaulting discontinuity sequence to zero" })), 0 < s2.duration && (u2.duration = s2.duration), 0 === s2.duration && (u2.duration = 0.01, this.trigger("info", { message: "updating zero segment duration to a small value" })), this.manifest.segments = o2;
            }, key: function() {
              if (s2.attributes)
                if ("NONE" !== s2.attributes.METHOD)
                  if (s2.attributes.URI) {
                    if ("com.apple.streamingkeydelivery" === s2.attributes.KEYFORMAT)
                      return this.manifest.contentProtection = this.manifest.contentProtection || {}, void (this.manifest.contentProtection["com.apple.fps.1_0"] = { attributes: s2.attributes });
                    if ("com.microsoft.playready" === s2.attributes.KEYFORMAT)
                      return this.manifest.contentProtection = this.manifest.contentProtection || {}, void (this.manifest.contentProtection["com.microsoft.playready"] = { uri: s2.attributes.URI });
                    if ("urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed" === s2.attributes.KEYFORMAT)
                      return -1 === ["SAMPLE-AES", "SAMPLE-AES-CTR", "SAMPLE-AES-CENC"].indexOf(s2.attributes.METHOD) ? void this.trigger("warn", { message: "invalid key method provided for Widevine" }) : ("SAMPLE-AES-CENC" === s2.attributes.METHOD && this.trigger("warn", { message: "SAMPLE-AES-CENC is deprecated, please use SAMPLE-AES-CTR instead" }), "data:text/plain;base64," !== s2.attributes.URI.substring(0, 23) ? void this.trigger("warn", { message: "invalid key URI provided for Widevine" }) : s2.attributes.KEYID && "0x" === s2.attributes.KEYID.substring(0, 2) ? (this.manifest.contentProtection = this.manifest.contentProtection || {}, void (this.manifest.contentProtection["com.widevine.alpha"] = { attributes: { schemeIdUri: s2.attributes.KEYFORMAT, keyId: s2.attributes.KEYID.substring(2) }, pssh: function(e4) {
                        for (var t4 = sr(e4), i4 = new Uint8Array(t4.length), n3 = 0; n3 < t4.length; n3++)
                          i4[n3] = t4.charCodeAt(n3);
                        return i4;
                      }(s2.attributes.URI.split(",")[1]) })) : void this.trigger("warn", { message: "invalid key ID provided for Widevine" }));
                    s2.attributes.METHOD || this.trigger("warn", { message: "defaulting key method to AES-128" }), r2 = { method: s2.attributes.METHOD || "AES-128", uri: s2.attributes.URI }, "undefined" != typeof s2.attributes.IV && (r2.iv = s2.attributes.IV);
                  } else
                    this.trigger("warn", { message: "ignoring key declaration without URI" });
                else
                  r2 = null;
              else
                this.trigger("warn", { message: "ignoring key declaration without attribute list" });
            }, "media-sequence": function() {
              isFinite(s2.number) ? this.manifest.mediaSequence = s2.number : this.trigger("warn", { message: "ignoring invalid media sequence: " + s2.number });
            }, "discontinuity-sequence": function() {
              isFinite(s2.number) ? (this.manifest.discontinuitySequence = s2.number, c2 = s2.number) : this.trigger("warn", { message: "ignoring invalid discontinuity sequence: " + s2.number });
            }, "playlist-type": function() {
              /VOD|EVENT/.test(s2.playlistType) ? this.manifest.playlistType = s2.playlistType : this.trigger("warn", { message: "ignoring unknown playlist type: " + s2.playlist });
            }, map: function() {
              n2 = {}, s2.uri && (n2.uri = s2.uri), s2.byterange && (n2.byterange = s2.byterange), r2 && (n2.key = r2);
            }, "stream-inf": function() {
              this.manifest.playlists = o2, this.manifest.mediaGroups = this.manifest.mediaGroups || d2, s2.attributes ? (u2.attributes || (u2.attributes = {}), g(u2.attributes, s2.attributes)) : this.trigger("warn", { message: "ignoring empty stream-inf attributes" });
            }, media: function() {
              var e4;
              this.manifest.mediaGroups = this.manifest.mediaGroups || d2, s2.attributes && s2.attributes.TYPE && s2.attributes["GROUP-ID"] && s2.attributes.NAME ? ((e4 = this.manifest.mediaGroups[s2.attributes.TYPE])[s2.attributes["GROUP-ID"]] = e4[s2.attributes["GROUP-ID"]] || {}, t3 = e4[s2.attributes["GROUP-ID"]], (i3 = { default: /yes/i.test(s2.attributes.DEFAULT) }).default ? i3.autoselect = true : i3.autoselect = /yes/i.test(s2.attributes.AUTOSELECT), s2.attributes.LANGUAGE && (i3.language = s2.attributes.LANGUAGE), s2.attributes.URI && (i3.uri = s2.attributes.URI), s2.attributes["INSTREAM-ID"] && (i3.instreamId = s2.attributes["INSTREAM-ID"]), s2.attributes.CHARACTERISTICS && (i3.characteristics = s2.attributes.CHARACTERISTICS), s2.attributes.FORCED && (i3.forced = /yes/i.test(s2.attributes.FORCED)), t3[s2.attributes.NAME] = i3) : this.trigger("warn", { message: "ignoring incomplete or missing media group" });
            }, discontinuity: function() {
              c2 += 1, u2.discontinuity = true, this.manifest.discontinuityStarts.push(o2.length);
            }, "program-date-time": function() {
              "undefined" == typeof this.manifest.dateTimeString && (this.manifest.dateTimeString = s2.dateTimeString, this.manifest.dateTimeObject = s2.dateTimeObject), u2.dateTimeString = s2.dateTimeString, u2.dateTimeObject = s2.dateTimeObject;
            }, targetduration: function() {
              !isFinite(s2.duration) || s2.duration < 0 ? this.trigger("warn", { message: "ignoring invalid target duration: " + s2.duration }) : (this.manifest.targetDuration = s2.duration, dr.call(this, this.manifest));
            }, start: function() {
              s2.attributes && !isNaN(s2.attributes["TIME-OFFSET"]) ? this.manifest.start = { timeOffset: s2.attributes["TIME-OFFSET"], precise: s2.attributes.PRECISE } : this.trigger("warn", { message: "ignoring start declaration without appropriate attribute list" });
            }, "cue-out": function() {
              u2.cueOut = s2.data;
            }, "cue-out-cont": function() {
              u2.cueOutCont = s2.data;
            }, "cue-in": function() {
              u2.cueIn = s2.data;
            }, skip: function() {
              this.manifest.skip = lr(s2.attributes), this.warnOnMissingAttributes_("#EXT-X-SKIP", s2.attributes, ["SKIPPED-SEGMENTS"]);
            }, part: function() {
              var i4 = this;
              l2 = true;
              var e4 = this.manifest.segments.length, t4 = lr(s2.attributes);
              u2.parts = u2.parts || [], u2.parts.push(t4), t4.byterange && (t4.byterange.hasOwnProperty("offset") || (t4.byterange.offset = p2), p2 = t4.byterange.offset + t4.byterange.length);
              var n3 = u2.parts.length - 1;
              this.warnOnMissingAttributes_("#EXT-X-PART #" + n3 + " for segment #" + e4, s2.attributes, ["URI", "DURATION"]), this.manifest.renditionReports && this.manifest.renditionReports.forEach(function(e5, t5) {
                e5.hasOwnProperty("lastPart") || i4.trigger("warn", { message: "#EXT-X-RENDITION-REPORT #" + t5 + " lacks required attribute(s): LAST-PART" });
              });
            }, "server-control": function() {
              var e4 = this.manifest.serverControl = lr(s2.attributes);
              e4.hasOwnProperty("canBlockReload") || (e4.canBlockReload = false, this.trigger("info", { message: "#EXT-X-SERVER-CONTROL defaulting CAN-BLOCK-RELOAD to false" })), dr.call(this, this.manifest), e4.canSkipDateranges && !e4.hasOwnProperty("canSkipUntil") && this.trigger("warn", { message: "#EXT-X-SERVER-CONTROL lacks required attribute CAN-SKIP-UNTIL which is required when CAN-SKIP-DATERANGES is set" });
            }, "preload-hint": function() {
              var e4 = this.manifest.segments.length, t4 = lr(s2.attributes), i4 = t4.type && "PART" === t4.type;
              u2.preloadHints = u2.preloadHints || [], u2.preloadHints.push(t4), t4.byterange && (t4.byterange.hasOwnProperty("offset") || (t4.byterange.offset = i4 ? p2 : 0, i4 && (p2 = t4.byterange.offset + t4.byterange.length)));
              var n3 = u2.preloadHints.length - 1;
              if (this.warnOnMissingAttributes_("#EXT-X-PRELOAD-HINT #" + n3 + " for segment #" + e4, s2.attributes, ["TYPE", "URI"]), t4.type)
                for (var r3 = 0; r3 < u2.preloadHints.length - 1; r3++) {
                  var a3 = u2.preloadHints[r3];
                  a3.type && a3.type === t4.type && this.trigger("warn", { message: "#EXT-X-PRELOAD-HINT #" + n3 + " for segment #" + e4 + " has the same TYPE " + t4.type + " as preload hint #" + r3 });
                }
            }, "rendition-report": function() {
              var e4 = lr(s2.attributes);
              this.manifest.renditionReports = this.manifest.renditionReports || [], this.manifest.renditionReports.push(e4);
              var t4 = this.manifest.renditionReports.length - 1, e4 = ["LAST-MSN", "URI"];
              l2 && e4.push("LAST-PART"), this.warnOnMissingAttributes_("#EXT-X-RENDITION-REPORT #" + t4, s2.attributes, e4);
            }, "part-inf": function() {
              this.manifest.partInf = lr(s2.attributes), this.warnOnMissingAttributes_("#EXT-X-PART-INF", s2.attributes, ["PART-TARGET"]), this.manifest.partInf.partTarget && (this.manifest.partTargetDuration = this.manifest.partInf.partTarget), dr.call(this, this.manifest);
            } }[s2.tagType] || function() {
            }).call(a2);
          }, uri: function() {
            u2.uri = s2.uri, o2.push(u2), !this.manifest.targetDuration || "duration" in u2 || (this.trigger("warn", { message: "defaulting segment duration to the target duration" }), u2.duration = this.manifest.targetDuration), r2 && (u2.key = r2), u2.timeline = c2, n2 && (u2.map = n2), p2 = 0, u2 = {};
          }, comment: function() {
          }, custom: function() {
            s2.segment ? (u2.custom = u2.custom || {}, u2.custom[s2.customType] = s2.data) : (this.manifest.custom = this.manifest.custom || {}, this.manifest.custom[s2.customType] = s2.data);
          } })[s2.type].call(a2);
        }), e3;
      }
      mt(e2, t2);
      var i2 = e2.prototype;
      return i2.warnOnMissingAttributes_ = function(e3, t3, i3) {
        var n2 = [];
        i3.forEach(function(e4) {
          t3.hasOwnProperty(e4) || n2.push(e4);
        }), n2.length && this.trigger("warn", { message: e3 + " lacks required attribute(s): " + n2.join(", ") });
      }, i2.push = function(e3) {
        this.lineStream.push(e3);
      }, i2.end = function() {
        this.lineStream.push("\n"), this.trigger("end");
      }, i2.addParser = function(e3) {
        this.parseStream.addParser(e3);
      }, i2.addTagMapper = function(e3) {
        this.parseStream.addTagMapper(e3);
      }, e2;
    }(ar), xr = { mp4: /^(av0?1|avc0?[1234]|vp0?9|flac|opus|mp3|mp4a|mp4v|stpp.ttml.im1t)/, webm: /^(vp0?[89]|av0?1|opus|vorbis)/, ogg: /^(vp0?[89]|theora|flac|opus|vorbis)/, video: /^(av0?1|avc0?[1234]|vp0?[89]|hvc1|hev1|theora|mp4v)/, audio: /^(mp4a|flac|vorbis|opus|ac-[34]|ec-3|alac|mp3|speex|aac)/, text: /^(stpp.ttml.im1t)/, muxerVideo: /^(avc0?1)/, muxerAudio: /^(mp4a)/, muxerText: /a^/ }, Ar = ["video", "audio", "text"], Pr = ["Video", "Audio", "Text"], Lr = "mp4a.40.2", Or = /^(audio|video|application)\/(x-|vnd\.apple\.)?mpegurl/i, Dr = /^application\/dash\+xml/i, Rr = vr, Mr = window.BigInt || Number, Nr = [Mr("0x1"), Mr("0x100"), Mr("0x10000"), Mr("0x1000000"), Mr("0x100000000"), Mr("0x10000000000"), Mr("0x1000000000000"), Mr("0x100000000000000"), Mr("0x10000000000000000")], Ur = "http://example.com";
    function Br(e2) {
      for (var t2 = (e2 = e2, window.atob ? window.atob(e2) : Buffer.from(e2, "base64").toString("binary")), i2 = new Uint8Array(t2.length), n2 = 0; n2 < t2.length; n2++)
        i2[n2] = t2.charCodeAt(n2);
      return i2;
    }
    function Fr(e2, t2) {
      return (t2 = void 0 === t2 ? Object : t2) && "function" == typeof t2.freeze ? t2.freeze(e2) : e2;
    }
    var jr = Fr({ HTML: "text/html", isHTML: function(e2) {
      return e2 === jr.HTML;
    }, XML_APPLICATION: "application/xml", XML_TEXT: "text/xml", XML_XHTML_APPLICATION: "application/xhtml+xml", XML_SVG_IMAGE: "image/svg+xml" }), Hr = Fr({ HTML: "http://www.w3.org/1999/xhtml", isHTML: function(e2) {
      return e2 === Hr.HTML;
    }, SVG: "http://www.w3.org/2000/svg", XML: "http://www.w3.org/XML/1998/namespace", XMLNS: "http://www.w3.org/2000/xmlns/" }), Vr = { assign: function(e2, t2) {
      if (null === e2 || "object" != typeof e2)
        throw new TypeError("target is not an object");
      for (var i2 in t2)
        Object.prototype.hasOwnProperty.call(t2, i2) && (e2[i2] = t2[i2]);
      return e2;
    }, find: function(e2, t2, i2) {
      if (void 0 === i2 && (i2 = Array.prototype), e2 && "function" == typeof i2.find)
        return i2.find.call(e2, t2);
      for (var n2 = 0; n2 < e2.length; n2++)
        if (Object.prototype.hasOwnProperty.call(e2, n2)) {
          var r2 = e2[n2];
          if (t2.call(void 0, r2, n2, e2))
            return r2;
        }
    }, freeze: Fr, MIME_TYPE: jr, NAMESPACE: Hr }, qr = Vr.find, Wr = Vr.NAMESPACE;
    function Gr(e2) {
      return "" !== e2;
    }
    function zr(e2, t2) {
      return e2.hasOwnProperty(t2) || (e2[t2] = true), e2;
    }
    function Xr(e2) {
      if (!e2)
        return [];
      e2 = (e2 = e2) ? e2.split(/[\t\n\f\r ]+/).filter(Gr) : [];
      return Object.keys(e2.reduce(zr, {}));
    }
    function Kr(e2, t2) {
      for (var i2 in e2)
        Object.prototype.hasOwnProperty.call(e2, i2) && (t2[i2] = e2[i2]);
    }
    function Yr(e2, t2) {
      var i2, n2 = e2.prototype;
      n2 instanceof t2 || ((i2 = function() {
      }).prototype = t2.prototype, Kr(n2, i2 = new i2()), e2.prototype = n2 = i2), n2.constructor != e2 && (n2.constructor = e2);
    }
    var Qr = {}, $r = Qr.ELEMENT_NODE = 1, Jr = Qr.ATTRIBUTE_NODE = 2, Zr = Qr.TEXT_NODE = 3, ea = Qr.CDATA_SECTION_NODE = 4, ta = Qr.ENTITY_REFERENCE_NODE = 5, ia = (Qr.ENTITY_NODE = 6, Qr.PROCESSING_INSTRUCTION_NODE = 7), na = Qr.COMMENT_NODE = 8, ra = Qr.DOCUMENT_NODE = 9, aa = Qr.DOCUMENT_TYPE_NODE = 10, sa = Qr.DOCUMENT_FRAGMENT_NODE = 11, W = (Qr.NOTATION_NODE = 12, {}), oa = {};
    W.INDEX_SIZE_ERR = (oa[1] = "Index size error", 1), W.DOMSTRING_SIZE_ERR = (oa[2] = "DOMString size error", 2);
    var ua = W.HIERARCHY_REQUEST_ERR = (oa[3] = "Hierarchy request error", 3);
    W.WRONG_DOCUMENT_ERR = (oa[4] = "Wrong document", 4), W.INVALID_CHARACTER_ERR = (oa[5] = "Invalid character", 5), W.NO_DATA_ALLOWED_ERR = (oa[6] = "No data allowed", 6), W.NO_MODIFICATION_ALLOWED_ERR = (oa[7] = "No modification allowed", 7);
    var la = W.NOT_FOUND_ERR = (oa[8] = "Not found", 8);
    W.NOT_SUPPORTED_ERR = (oa[9] = "Not supported", 9);
    var da;
    W.INUSE_ATTRIBUTE_ERR = (oa[10] = "Attribute in use", 10);
    function ca(e2, t2) {
      var i2;
      return t2 instanceof Error ? i2 = t2 : (i2 = this, Error.call(this, oa[e2]), this.message = oa[e2], Error.captureStackTrace && Error.captureStackTrace(this, ca)), i2.code = e2, t2 && (this.message = this.message + ": " + t2), i2;
    }
    function ha() {
    }
    function pa(e2, t2) {
      this._node = e2, this._refresh = t2, fa(this);
    }
    function fa(e2) {
      var t2, i2 = e2._node._inc || e2._node.ownerDocument._inc;
      e2._inc != i2 && (t2 = e2._refresh(e2._node), Za(e2, "length", t2.length), Kr(t2, e2), e2._inc = i2);
    }
    function ma() {
    }
    function ga(e2, t2) {
      for (var i2 = e2.length; i2--; )
        if (e2[i2] === t2)
          return i2;
    }
    function ya(e2, t2, i2, n2) {
      n2 ? t2[ga(t2, n2)] = i2 : t2[t2.length++] = i2, !e2 || (t2 = (i2.ownerElement = e2).ownerDocument) && (n2 && Ea(t2, e2, n2), e2 = e2, i2 = i2, (t2 = t2) && t2._inc++, i2.namespaceURI === Wr.XMLNS && (e2._nsMap[i2.prefix ? i2.localName : ""] = i2.value));
    }
    function va(e2, t2, i2) {
      var n2 = ga(t2, i2);
      if (!(0 <= n2))
        throw new ca(la, new Error(e2.tagName + "@" + i2));
      for (var r2, a2 = t2.length - 1; n2 < a2; )
        t2[n2] = t2[++n2];
      t2.length = a2, !e2 || (r2 = e2.ownerDocument) && (Ea(r2, e2, i2), i2.ownerElement = null);
    }
    function _a() {
    }
    function ba() {
    }
    function Ta(e2) {
      return ("<" == e2 ? "&lt;" : ">" == e2 && "&gt;") || "&" == e2 && "&amp;" || '"' == e2 && "&quot;" || "&#" + e2.charCodeAt() + ";";
    }
    function wa(e2, t2) {
      if (t2(e2))
        return 1;
      if (e2 = e2.firstChild)
        do {
          if (wa(e2, t2))
            return 1;
        } while (e2 = e2.nextSibling);
    }
    function Sa() {
      this.ownerDocument = this;
    }
    function Ea(e2, t2, i2) {
      e2 && e2._inc++, i2.namespaceURI === Wr.XMLNS && delete t2._nsMap[i2.prefix ? i2.localName : ""];
    }
    function ka(e2, t2, i2) {
      if (e2 && e2._inc) {
        e2._inc++;
        var n2 = t2.childNodes;
        if (i2)
          n2[n2.length++] = i2;
        else {
          for (var r2 = t2.firstChild, a2 = 0; r2; )
            r2 = (n2[a2++] = r2).nextSibling;
          n2.length = a2, delete n2[n2.length];
        }
      }
    }
    function Ca(e2, t2) {
      var i2 = t2.previousSibling, n2 = t2.nextSibling;
      return i2 ? i2.nextSibling = n2 : e2.firstChild = n2, n2 ? n2.previousSibling = i2 : e2.lastChild = i2, t2.parentNode = null, t2.previousSibling = null, t2.nextSibling = null, ka(e2.ownerDocument, e2), t2;
    }
    function Ia(e2) {
      return e2 && e2.nodeType === ba.DOCUMENT_TYPE_NODE;
    }
    function xa(e2) {
      return e2 && e2.nodeType === ba.ELEMENT_NODE;
    }
    function Aa(e2) {
      return e2 && e2.nodeType === ba.TEXT_NODE;
    }
    function Pa(e2, t2) {
      var i2 = e2.childNodes || [];
      if (!qr(i2, xa) && !Ia(t2)) {
        e2 = qr(i2, Ia);
        return !(t2 && e2 && i2.indexOf(e2) > i2.indexOf(t2));
      }
    }
    function La(e2, t2) {
      var i2 = e2.childNodes || [];
      if (!qr(i2, function(e3) {
        return xa(e3) && e3 !== t2;
      })) {
        e2 = qr(i2, Ia);
        return !(t2 && e2 && i2.indexOf(e2) > i2.indexOf(t2));
      }
    }
    function Oa(e2, t2, i2) {
      if (!(n2 = e2) || n2.nodeType !== ba.DOCUMENT_NODE && n2.nodeType !== ba.DOCUMENT_FRAGMENT_NODE && n2.nodeType !== ba.ELEMENT_NODE)
        throw new ca(ua, "Unexpected parent node type " + e2.nodeType);
      var n2;
      if (i2 && i2.parentNode !== e2)
        throw new ca(la, "child not in parent");
      if (!(i2 = t2) || !(xa(i2) || Aa(i2) || Ia(i2) || i2.nodeType === ba.DOCUMENT_FRAGMENT_NODE || i2.nodeType === ba.COMMENT_NODE || i2.nodeType === ba.PROCESSING_INSTRUCTION_NODE) || Ia(t2) && e2.nodeType !== ba.DOCUMENT_NODE)
        throw new ca(ua, "Unexpected node type " + t2.nodeType + " for parent node type " + e2.nodeType);
    }
    function Da(e2, t2, i2) {
      var n2 = e2.childNodes || [], r2 = t2.childNodes || [];
      if (t2.nodeType === ba.DOCUMENT_FRAGMENT_NODE) {
        var a2 = r2.filter(xa);
        if (1 < a2.length || qr(r2, Aa))
          throw new ca(ua, "More than one element or text in fragment");
        if (1 === a2.length && !Pa(e2, i2))
          throw new ca(ua, "Element in fragment can not be inserted before doctype");
      }
      if (xa(t2) && !Pa(e2, i2))
        throw new ca(ua, "Only one element can be added and only after doctype");
      if (Ia(t2)) {
        if (qr(n2, Ia))
          throw new ca(ua, "Only one doctype is allowed");
        t2 = qr(n2, xa);
        if (i2 && n2.indexOf(t2) < n2.indexOf(i2))
          throw new ca(ua, "Doctype can only be inserted before an element");
        if (!i2 && t2)
          throw new ca(ua, "Doctype can not be appended since element is present");
      }
    }
    function Ra(e2, t2, i2) {
      var n2 = e2.childNodes || [], r2 = t2.childNodes || [];
      if (t2.nodeType === ba.DOCUMENT_FRAGMENT_NODE) {
        var a2 = r2.filter(xa);
        if (1 < a2.length || qr(r2, Aa))
          throw new ca(ua, "More than one element or text in fragment");
        if (1 === a2.length && !La(e2, i2))
          throw new ca(ua, "Element in fragment can not be inserted before doctype");
      }
      if (xa(t2) && !La(e2, i2))
        throw new ca(ua, "Only one element can be added and only after doctype");
      if (Ia(t2)) {
        if (qr(n2, function(e3) {
          return Ia(e3) && e3 !== i2;
        }))
          throw new ca(ua, "Only one doctype is allowed");
        t2 = qr(n2, xa);
        if (i2 && n2.indexOf(t2) < n2.indexOf(i2))
          throw new ca(ua, "Doctype can only be inserted before an element");
      }
    }
    function Ma(e2, t2, i2, n2) {
      Oa(e2, t2, i2), e2.nodeType === ba.DOCUMENT_NODE && (n2 || Da)(e2, t2, i2);
      n2 = t2.parentNode;
      if (n2 && n2.removeChild(t2), t2.nodeType === sa) {
        var r2 = t2.firstChild;
        if (null == r2)
          return t2;
        var a2 = t2.lastChild;
      } else
        r2 = a2 = t2;
      n2 = i2 ? i2.previousSibling : e2.lastChild;
      for (r2.previousSibling = n2, a2.nextSibling = i2, n2 ? n2.nextSibling = r2 : e2.firstChild = r2, null == i2 ? e2.lastChild = a2 : i2.previousSibling = a2; r2.parentNode = e2, r2 !== a2 && (r2 = r2.nextSibling); )
        ;
      return ka(e2.ownerDocument || e2, e2), t2.nodeType == sa && (t2.firstChild = t2.lastChild = null), t2;
    }
    function Na() {
      this._nsMap = {};
    }
    function Ua() {
    }
    function Ba() {
    }
    function Fa() {
    }
    function ja() {
    }
    function Ha() {
    }
    function Va() {
    }
    function qa() {
    }
    function Wa() {
    }
    function Ga() {
    }
    function za() {
    }
    function Xa() {
    }
    function Ka() {
    }
    function Ya(e2, t2) {
      var i2, n2 = [], r2 = 9 == this.nodeType && this.documentElement || this, a2 = r2.prefix, s2 = r2.namespaceURI;
      return Ja(this, n2, e2, t2, i2 = s2 && null == a2 && null == (a2 = r2.lookupPrefix(s2)) ? [{ namespace: s2, prefix: null }] : i2), n2.join("");
    }
    function Qa(e2, t2, i2) {
      var n2 = e2.prefix || "", r2 = e2.namespaceURI;
      if (r2 && ("xml" !== n2 || r2 !== Wr.XML) && r2 !== Wr.XMLNS) {
        for (var a2 = i2.length; a2--; ) {
          var s2 = i2[a2];
          if (s2.prefix === n2)
            return s2.namespace !== r2;
        }
        return 1;
      }
    }
    function $a(e2, t2, i2) {
      e2.push(" ", t2, '="', i2.replace(/[<>&"\t\n\r]/g, Ta), '"');
    }
    function Ja(e2, t2, i2, n2, r2) {
      if (r2 = r2 || [], n2) {
        if (!(e2 = n2(e2)))
          return;
        if ("string" == typeof e2)
          return void t2.push(e2);
      }
      switch (e2.nodeType) {
        case $r:
          var a2 = e2.attributes, s2 = a2.length, o2 = e2.firstChild, u2 = e2.tagName, l2 = u2;
          if (!(i2 = Wr.isHTML(e2.namespaceURI) || i2) && !e2.prefix && e2.namespaceURI) {
            for (var d2, c2 = 0; c2 < a2.length; c2++)
              if ("xmlns" === a2.item(c2).name) {
                d2 = a2.item(c2).value;
                break;
              }
            if (!d2) {
              for (var h2 = r2.length - 1; 0 <= h2; h2--)
                if ("" === (p2 = r2[h2]).prefix && p2.namespace === e2.namespaceURI) {
                  d2 = p2.namespace;
                  break;
                }
            }
            if (d2 !== e2.namespaceURI) {
              for (var p2, h2 = r2.length - 1; 0 <= h2; h2--)
                if ((p2 = r2[h2]).namespace === e2.namespaceURI) {
                  p2.prefix && (l2 = p2.prefix + ":" + u2);
                  break;
                }
            }
          }
          t2.push("<", l2);
          for (var f2 = 0; f2 < s2; f2++)
            "xmlns" == (m2 = a2.item(f2)).prefix ? r2.push({ prefix: m2.localName, namespace: m2.value }) : "xmlns" == m2.nodeName && r2.push({ prefix: "", namespace: m2.value });
          for (var m2, g2, y2, f2 = 0; f2 < s2; f2++)
            Qa(m2 = a2.item(f2), 0, r2) && ($a(t2, (g2 = m2.prefix || "") ? "xmlns:" + g2 : "xmlns", y2 = m2.namespaceURI), r2.push({ prefix: g2, namespace: y2 })), Ja(m2, t2, i2, n2, r2);
          if (u2 === l2 && Qa(e2, 0, r2) && ($a(t2, (g2 = e2.prefix || "") ? "xmlns:" + g2 : "xmlns", y2 = e2.namespaceURI), r2.push({ prefix: g2, namespace: y2 })), o2 || i2 && !/^(?:meta|link|img|br|hr|input)$/i.test(u2)) {
            if (t2.push(">"), i2 && /^script$/i.test(u2))
              for (; o2; )
                o2.data ? t2.push(o2.data) : Ja(o2, t2, i2, n2, r2.slice()), o2 = o2.nextSibling;
            else
              for (; o2; )
                Ja(o2, t2, i2, n2, r2.slice()), o2 = o2.nextSibling;
            t2.push("</", l2, ">");
          } else
            t2.push("/>");
          return;
        case ra:
        case sa:
          for (o2 = e2.firstChild; o2; )
            Ja(o2, t2, i2, n2, r2.slice()), o2 = o2.nextSibling;
          return;
        case Jr:
          return $a(t2, e2.name, e2.value), 0;
        case Zr:
          return t2.push(e2.data.replace(/[<&>]/g, Ta));
        case ea:
          return t2.push("<![CDATA[", e2.data, "]]>");
        case na:
          return t2.push("<!--", e2.data, "-->");
        case aa:
          var v2 = e2.publicId, _2 = e2.systemId;
          return t2.push("<!DOCTYPE ", e2.name), void (v2 ? (t2.push(" PUBLIC ", v2), _2 && "." != _2 && t2.push(" ", _2), t2.push(">")) : _2 && "." != _2 ? t2.push(" SYSTEM ", _2, ">") : ((_2 = e2.internalSubset) && t2.push(" [", _2, "]"), t2.push(">")));
        case ia:
          return t2.push("<?", e2.target, " ", e2.data, "?>");
        case ta:
          return t2.push("&", e2.nodeName, ";");
        default:
          t2.push("??", e2.nodeName);
      }
    }
    function Za(e2, t2, i2) {
      e2[t2] = i2;
    }
    W.INVALID_STATE_ERR = (oa[11] = "Invalid state", 11), W.SYNTAX_ERR = (oa[12] = "Syntax error", 12), W.INVALID_MODIFICATION_ERR = (oa[13] = "Invalid modification", 13), W.NAMESPACE_ERR = (oa[14] = "Invalid namespace", 14), W.INVALID_ACCESS_ERR = (oa[15] = "Invalid access", 15), ca.prototype = Error.prototype, Kr(W, ca), ha.prototype = { length: 0, item: function(e2) {
      return this[e2] || null;
    }, toString: function(e2, t2) {
      for (var i2 = [], n2 = 0; n2 < this.length; n2++)
        Ja(this[n2], i2, e2, t2);
      return i2.join("");
    }, filter: function(e2) {
      return Array.prototype.filter.call(this, e2);
    }, indexOf: function(e2) {
      return Array.prototype.indexOf.call(this, e2);
    } }, pa.prototype.item = function(e2) {
      return fa(this), this[e2];
    }, Yr(pa, ha), ma.prototype = { length: 0, item: ha.prototype.item, getNamedItem: function(e2) {
      for (var t2 = this.length; t2--; ) {
        var i2 = this[t2];
        if (i2.nodeName == e2)
          return i2;
      }
    }, setNamedItem: function(e2) {
      var t2 = e2.ownerElement;
      if (t2 && t2 != this._ownerElement)
        throw new ca(10);
      t2 = this.getNamedItem(e2.nodeName);
      return ya(this._ownerElement, this, e2, t2), t2;
    }, setNamedItemNS: function(e2) {
      var t2 = e2.ownerElement;
      if (t2 && t2 != this._ownerElement)
        throw new ca(10);
      return t2 = this.getNamedItemNS(e2.namespaceURI, e2.localName), ya(this._ownerElement, this, e2, t2), t2;
    }, removeNamedItem: function(e2) {
      e2 = this.getNamedItem(e2);
      return va(this._ownerElement, this, e2), e2;
    }, removeNamedItemNS: function(e2, t2) {
      t2 = this.getNamedItemNS(e2, t2);
      return va(this._ownerElement, this, t2), t2;
    }, getNamedItemNS: function(e2, t2) {
      for (var i2 = this.length; i2--; ) {
        var n2 = this[i2];
        if (n2.localName == t2 && n2.namespaceURI == e2)
          return n2;
      }
      return null;
    } }, _a.prototype = { hasFeature: function(e2, t2) {
      return true;
    }, createDocument: function(e2, t2, i2) {
      var n2 = new Sa();
      return n2.implementation = this, n2.childNodes = new ha(), n2.doctype = i2 || null, i2 && n2.appendChild(i2), t2 && (t2 = n2.createElementNS(e2, t2), n2.appendChild(t2)), n2;
    }, createDocumentType: function(e2, t2, i2) {
      var n2 = new Va();
      return n2.name = e2, n2.nodeName = e2, n2.publicId = t2 || "", n2.systemId = i2 || "", n2;
    } }, ba.prototype = { firstChild: null, lastChild: null, previousSibling: null, nextSibling: null, attributes: null, parentNode: null, childNodes: null, ownerDocument: null, nodeValue: null, namespaceURI: null, prefix: null, localName: null, insertBefore: function(e2, t2) {
      return Ma(this, e2, t2);
    }, replaceChild: function(e2, t2) {
      Ma(this, e2, t2, Ra), t2 && this.removeChild(t2);
    }, removeChild: function(e2) {
      return Ca(this, e2);
    }, appendChild: function(e2) {
      return this.insertBefore(e2, null);
    }, hasChildNodes: function() {
      return null != this.firstChild;
    }, cloneNode: function(e2) {
      return function e3(t2, i2, n2) {
        var r2 = new i2.constructor();
        for (var a2 in i2) {
          var s2;
          !Object.prototype.hasOwnProperty.call(i2, a2) || "object" != typeof (s2 = i2[a2]) && s2 != r2[a2] && (r2[a2] = s2);
        }
        i2.childNodes && (r2.childNodes = new ha());
        r2.ownerDocument = t2;
        switch (r2.nodeType) {
          case $r:
            var o2 = i2.attributes, u2 = r2.attributes = new ma(), l2 = o2.length;
            u2._ownerElement = r2;
            for (var d2 = 0; d2 < l2; d2++)
              r2.setAttributeNode(e3(t2, o2.item(d2), true));
            break;
          case Jr:
            n2 = true;
        }
        if (n2)
          for (var c2 = i2.firstChild; c2; )
            r2.appendChild(e3(t2, c2, n2)), c2 = c2.nextSibling;
        return r2;
      }(this.ownerDocument || this, this, e2);
    }, normalize: function() {
      for (var e2 = this.firstChild; e2; ) {
        var t2 = e2.nextSibling;
        t2 && t2.nodeType == Zr && e2.nodeType == Zr ? (this.removeChild(t2), e2.appendData(t2.data)) : (e2.normalize(), e2 = t2);
      }
    }, isSupported: function(e2, t2) {
      return this.ownerDocument.implementation.hasFeature(e2, t2);
    }, hasAttributes: function() {
      return 0 < this.attributes.length;
    }, lookupPrefix: function(e2) {
      for (var t2 = this; t2; ) {
        var i2 = t2._nsMap;
        if (i2) {
          for (var n2 in i2)
            if (Object.prototype.hasOwnProperty.call(i2, n2) && i2[n2] === e2)
              return n2;
        }
        t2 = t2.nodeType == Jr ? t2.ownerDocument : t2.parentNode;
      }
      return null;
    }, lookupNamespaceURI: function(e2) {
      for (var t2 = this; t2; ) {
        var i2 = t2._nsMap;
        if (i2 && Object.prototype.hasOwnProperty.call(i2, e2))
          return i2[e2];
        t2 = t2.nodeType == Jr ? t2.ownerDocument : t2.parentNode;
      }
      return null;
    }, isDefaultNamespace: function(e2) {
      return null == this.lookupPrefix(e2);
    } }, Kr(Qr, ba), Kr(Qr, ba.prototype), Sa.prototype = { nodeName: "#document", nodeType: ra, doctype: null, documentElement: null, _inc: 1, insertBefore: function(e2, t2) {
      if (e2.nodeType != sa)
        return Ma(this, e2, t2), null === (e2.ownerDocument = this).documentElement && e2.nodeType === $r && (this.documentElement = e2), e2;
      for (var i2 = e2.firstChild; i2; ) {
        var n2 = i2.nextSibling;
        this.insertBefore(i2, t2), i2 = n2;
      }
      return e2;
    }, removeChild: function(e2) {
      return this.documentElement == e2 && (this.documentElement = null), Ca(this, e2);
    }, replaceChild: function(e2, t2) {
      Ma(this, e2, t2, Ra), e2.ownerDocument = this, t2 && this.removeChild(t2), xa(e2) && (this.documentElement = e2);
    }, importNode: function(e2, t2) {
      return function e3(t3, i2, n2) {
        var r2;
        switch (i2.nodeType) {
          case $r:
            (r2 = i2.cloneNode(false)).ownerDocument = t3;
          case sa:
            break;
          case Jr:
            n2 = true;
        }
        r2 = r2 || i2.cloneNode(false);
        r2.ownerDocument = t3;
        r2.parentNode = null;
        if (n2)
          for (var a2 = i2.firstChild; a2; )
            r2.appendChild(e3(t3, a2, n2)), a2 = a2.nextSibling;
        return r2;
      }(this, e2, t2);
    }, getElementById: function(t2) {
      var i2 = null;
      return wa(this.documentElement, function(e2) {
        if (e2.nodeType == $r && e2.getAttribute("id") == t2)
          return i2 = e2, true;
      }), i2;
    }, getElementsByClassName: function(s2) {
      var o2 = Xr(s2);
      return new pa(this, function(r2) {
        var a2 = [];
        return 0 < o2.length && wa(r2.documentElement, function(e2) {
          var t2, i2, n2;
          e2 === r2 || e2.nodeType !== $r || (t2 = e2.getAttribute("class")) && ((i2 = s2 === t2) || (t2 = Xr(t2), i2 = o2.every((n2 = t2, function(e3) {
            return n2 && -1 !== n2.indexOf(e3);
          }))), i2 && a2.push(e2));
        }), a2;
      });
    }, createElement: function(e2) {
      var t2 = new Na();
      return t2.ownerDocument = this, t2.nodeName = e2, t2.tagName = e2, t2.localName = e2, t2.childNodes = new ha(), (t2.attributes = new ma())._ownerElement = t2;
    }, createDocumentFragment: function() {
      var e2 = new za();
      return e2.ownerDocument = this, e2.childNodes = new ha(), e2;
    }, createTextNode: function(e2) {
      var t2 = new Fa();
      return t2.ownerDocument = this, t2.appendData(e2), t2;
    }, createComment: function(e2) {
      var t2 = new ja();
      return t2.ownerDocument = this, t2.appendData(e2), t2;
    }, createCDATASection: function(e2) {
      var t2 = new Ha();
      return t2.ownerDocument = this, t2.appendData(e2), t2;
    }, createProcessingInstruction: function(e2, t2) {
      var i2 = new Xa();
      return i2.ownerDocument = this, i2.tagName = i2.target = e2, i2.nodeValue = i2.data = t2, i2;
    }, createAttribute: function(e2) {
      var t2 = new Ua();
      return t2.ownerDocument = this, t2.name = e2, t2.nodeName = e2, t2.localName = e2, t2.specified = true, t2;
    }, createEntityReference: function(e2) {
      var t2 = new Ga();
      return t2.ownerDocument = this, t2.nodeName = e2, t2;
    }, createElementNS: function(e2, t2) {
      var i2 = new Na(), n2 = t2.split(":"), r2 = i2.attributes = new ma();
      return i2.childNodes = new ha(), i2.ownerDocument = this, i2.nodeName = t2, i2.tagName = t2, i2.namespaceURI = e2, 2 == n2.length ? (i2.prefix = n2[0], i2.localName = n2[1]) : i2.localName = t2, r2._ownerElement = i2;
    }, createAttributeNS: function(e2, t2) {
      var i2 = new Ua(), n2 = t2.split(":");
      return i2.ownerDocument = this, i2.nodeName = t2, i2.name = t2, i2.namespaceURI = e2, i2.specified = true, 2 == n2.length ? (i2.prefix = n2[0], i2.localName = n2[1]) : i2.localName = t2, i2;
    } }, Yr(Sa, ba), Sa.prototype.getElementsByTagName = (Na.prototype = { nodeType: $r, hasAttribute: function(e2) {
      return null != this.getAttributeNode(e2);
    }, getAttribute: function(e2) {
      e2 = this.getAttributeNode(e2);
      return e2 && e2.value || "";
    }, getAttributeNode: function(e2) {
      return this.attributes.getNamedItem(e2);
    }, setAttribute: function(e2, t2) {
      e2 = this.ownerDocument.createAttribute(e2);
      e2.value = e2.nodeValue = "" + t2, this.setAttributeNode(e2);
    }, removeAttribute: function(e2) {
      e2 = this.getAttributeNode(e2);
      e2 && this.removeAttributeNode(e2);
    }, appendChild: function(e2) {
      return e2.nodeType === sa ? this.insertBefore(e2, null) : (t2 = this, (e2 = e2).parentNode && e2.parentNode.removeChild(e2), e2.parentNode = t2, e2.previousSibling = t2.lastChild, e2.nextSibling = null, e2.previousSibling ? e2.previousSibling.nextSibling = e2 : t2.firstChild = e2, t2.lastChild = e2, ka(t2.ownerDocument, t2, e2), e2);
      var t2;
    }, setAttributeNode: function(e2) {
      return this.attributes.setNamedItem(e2);
    }, setAttributeNodeNS: function(e2) {
      return this.attributes.setNamedItemNS(e2);
    }, removeAttributeNode: function(e2) {
      return this.attributes.removeNamedItem(e2.nodeName);
    }, removeAttributeNS: function(e2, t2) {
      t2 = this.getAttributeNodeNS(e2, t2);
      t2 && this.removeAttributeNode(t2);
    }, hasAttributeNS: function(e2, t2) {
      return null != this.getAttributeNodeNS(e2, t2);
    }, getAttributeNS: function(e2, t2) {
      t2 = this.getAttributeNodeNS(e2, t2);
      return t2 && t2.value || "";
    }, setAttributeNS: function(e2, t2, i2) {
      t2 = this.ownerDocument.createAttributeNS(e2, t2);
      t2.value = t2.nodeValue = "" + i2, this.setAttributeNode(t2);
    }, getAttributeNodeNS: function(e2, t2) {
      return this.attributes.getNamedItemNS(e2, t2);
    }, getElementsByTagName: function(n2) {
      return new pa(this, function(t2) {
        var i2 = [];
        return wa(t2, function(e2) {
          e2 === t2 || e2.nodeType != $r || "*" !== n2 && e2.tagName != n2 || i2.push(e2);
        }), i2;
      });
    }, getElementsByTagNameNS: function(n2, r2) {
      return new pa(this, function(t2) {
        var i2 = [];
        return wa(t2, function(e2) {
          e2 === t2 || e2.nodeType !== $r || "*" !== n2 && e2.namespaceURI !== n2 || "*" !== r2 && e2.localName != r2 || i2.push(e2);
        }), i2;
      });
    } }).getElementsByTagName, Sa.prototype.getElementsByTagNameNS = Na.prototype.getElementsByTagNameNS, Yr(Na, ba), Ua.prototype.nodeType = Jr, Yr(Ua, ba), Ba.prototype = { data: "", substringData: function(e2, t2) {
      return this.data.substring(e2, e2 + t2);
    }, appendData: function(e2) {
      e2 = this.data + e2, this.nodeValue = this.data = e2, this.length = e2.length;
    }, insertData: function(e2, t2) {
      this.replaceData(e2, 0, t2);
    }, appendChild: function(e2) {
      throw new Error(oa[ua]);
    }, deleteData: function(e2, t2) {
      this.replaceData(e2, t2, "");
    }, replaceData: function(e2, t2, i2) {
      var n2 = this.data.substring(0, e2), t2 = this.data.substring(e2 + t2);
      this.nodeValue = this.data = i2 = n2 + i2 + t2, this.length = i2.length;
    } }, Yr(Ba, ba), Fa.prototype = { nodeName: "#text", nodeType: Zr, splitText: function(e2) {
      var t2 = (i2 = this.data).substring(e2), i2 = i2.substring(0, e2);
      this.data = this.nodeValue = i2, this.length = i2.length;
      t2 = this.ownerDocument.createTextNode(t2);
      return this.parentNode && this.parentNode.insertBefore(t2, this.nextSibling), t2;
    } }, Yr(Fa, Ba), ja.prototype = { nodeName: "#comment", nodeType: na }, Yr(ja, Ba), Ha.prototype = { nodeName: "#cdata-section", nodeType: ea }, Yr(Ha, Ba), Va.prototype.nodeType = aa, Yr(Va, ba), qa.prototype.nodeType = 12, Yr(qa, ba), Wa.prototype.nodeType = 6, Yr(Wa, ba), Ga.prototype.nodeType = ta, Yr(Ga, ba), za.prototype.nodeName = "#document-fragment", za.prototype.nodeType = sa, Yr(za, ba), Xa.prototype.nodeType = ia, Yr(Xa, ba), Ka.prototype.serializeToString = function(e2, t2, i2) {
      return Ya.call(e2, t2, i2);
    }, ba.prototype.toString = Ya;
    try {
      Object.defineProperty && (da = function e2(t2) {
        switch (t2.nodeType) {
          case $r:
          case sa:
            var i2 = [];
            for (t2 = t2.firstChild; t2; )
              7 !== t2.nodeType && 8 !== t2.nodeType && i2.push(e2(t2)), t2 = t2.nextSibling;
            return i2.join("");
          default:
            return t2.nodeValue;
        }
      }, Object.defineProperty(pa.prototype, "length", { get: function() {
        return fa(this), this.$$length;
      } }), Object.defineProperty(ba.prototype, "textContent", { get: function() {
        return da(this);
      }, set: function(e2) {
        switch (this.nodeType) {
          case $r:
          case sa:
            for (; this.firstChild; )
              this.removeChild(this.firstChild);
            (e2 || String(e2)) && this.appendChild(this.ownerDocument.createTextNode(e2));
            break;
          default:
            this.data = e2, this.value = e2, this.nodeValue = e2;
        }
      } }), Za = function(e2, t2, i2) {
        e2["$$" + t2] = i2;
      });
    } catch (e2) {
    }
    var x = { DocumentType: Va, DOMException: ca, DOMImplementation: _a, Element: Na, Node: ba, NodeList: ha, XMLSerializer: Ka }, es = m(function(e2, t2) {
      var i2 = Vr.freeze;
      t2.XML_ENTITIES = i2({ amp: "&", apos: "'", gt: ">", lt: "<", quot: '"' }), t2.HTML_ENTITIES = i2({ lt: "<", gt: ">", amp: "&", quot: '"', apos: "'", Agrave: "\xC0", Aacute: "\xC1", Acirc: "\xC2", Atilde: "\xC3", Auml: "\xC4", Aring: "\xC5", AElig: "\xC6", Ccedil: "\xC7", Egrave: "\xC8", Eacute: "\xC9", Ecirc: "\xCA", Euml: "\xCB", Igrave: "\xCC", Iacute: "\xCD", Icirc: "\xCE", Iuml: "\xCF", ETH: "\xD0", Ntilde: "\xD1", Ograve: "\xD2", Oacute: "\xD3", Ocirc: "\xD4", Otilde: "\xD5", Ouml: "\xD6", Oslash: "\xD8", Ugrave: "\xD9", Uacute: "\xDA", Ucirc: "\xDB", Uuml: "\xDC", Yacute: "\xDD", THORN: "\xDE", szlig: "\xDF", agrave: "\xE0", aacute: "\xE1", acirc: "\xE2", atilde: "\xE3", auml: "\xE4", aring: "\xE5", aelig: "\xE6", ccedil: "\xE7", egrave: "\xE8", eacute: "\xE9", ecirc: "\xEA", euml: "\xEB", igrave: "\xEC", iacute: "\xED", icirc: "\xEE", iuml: "\xEF", eth: "\xF0", ntilde: "\xF1", ograve: "\xF2", oacute: "\xF3", ocirc: "\xF4", otilde: "\xF5", ouml: "\xF6", oslash: "\xF8", ugrave: "\xF9", uacute: "\xFA", ucirc: "\xFB", uuml: "\xFC", yacute: "\xFD", thorn: "\xFE", yuml: "\xFF", nbsp: "\xA0", iexcl: "\xA1", cent: "\xA2", pound: "\xA3", curren: "\xA4", yen: "\xA5", brvbar: "\xA6", sect: "\xA7", uml: "\xA8", copy: "\xA9", ordf: "\xAA", laquo: "\xAB", not: "\xAC", shy: "\xAD\xAD", reg: "\xAE", macr: "\xAF", deg: "\xB0", plusmn: "\xB1", sup2: "\xB2", sup3: "\xB3", acute: "\xB4", micro: "\xB5", para: "\xB6", middot: "\xB7", cedil: "\xB8", sup1: "\xB9", ordm: "\xBA", raquo: "\xBB", frac14: "\xBC", frac12: "\xBD", frac34: "\xBE", iquest: "\xBF", times: "\xD7", divide: "\xF7", forall: "\u2200", part: "\u2202", exist: "\u2203", empty: "\u2205", nabla: "\u2207", isin: "\u2208", notin: "\u2209", ni: "\u220B", prod: "\u220F", sum: "\u2211", minus: "\u2212", lowast: "\u2217", radic: "\u221A", prop: "\u221D", infin: "\u221E", ang: "\u2220", and: "\u2227", or: "\u2228", cap: "\u2229", cup: "\u222A", int: "\u222B", there4: "\u2234", sim: "\u223C", cong: "\u2245", asymp: "\u2248", ne: "\u2260", equiv: "\u2261", le: "\u2264", ge: "\u2265", sub: "\u2282", sup: "\u2283", nsub: "\u2284", sube: "\u2286", supe: "\u2287", oplus: "\u2295", otimes: "\u2297", perp: "\u22A5", sdot: "\u22C5", Alpha: "\u0391", Beta: "\u0392", Gamma: "\u0393", Delta: "\u0394", Epsilon: "\u0395", Zeta: "\u0396", Eta: "\u0397", Theta: "\u0398", Iota: "\u0399", Kappa: "\u039A", Lambda: "\u039B", Mu: "\u039C", Nu: "\u039D", Xi: "\u039E", Omicron: "\u039F", Pi: "\u03A0", Rho: "\u03A1", Sigma: "\u03A3", Tau: "\u03A4", Upsilon: "\u03A5", Phi: "\u03A6", Chi: "\u03A7", Psi: "\u03A8", Omega: "\u03A9", alpha: "\u03B1", beta: "\u03B2", gamma: "\u03B3", delta: "\u03B4", epsilon: "\u03B5", zeta: "\u03B6", eta: "\u03B7", theta: "\u03B8", iota: "\u03B9", kappa: "\u03BA", lambda: "\u03BB", mu: "\u03BC", nu: "\u03BD", xi: "\u03BE", omicron: "\u03BF", pi: "\u03C0", rho: "\u03C1", sigmaf: "\u03C2", sigma: "\u03C3", tau: "\u03C4", upsilon: "\u03C5", phi: "\u03C6", chi: "\u03C7", psi: "\u03C8", omega: "\u03C9", thetasym: "\u03D1", upsih: "\u03D2", piv: "\u03D6", OElig: "\u0152", oelig: "\u0153", Scaron: "\u0160", scaron: "\u0161", Yuml: "\u0178", fnof: "\u0192", circ: "\u02C6", tilde: "\u02DC", ensp: "\u2002", emsp: "\u2003", thinsp: "\u2009", zwnj: "\u200C", zwj: "\u200D", lrm: "\u200E", rlm: "\u200F", ndash: "\u2013", mdash: "\u2014", lsquo: "\u2018", rsquo: "\u2019", sbquo: "\u201A", ldquo: "\u201C", rdquo: "\u201D", bdquo: "\u201E", dagger: "\u2020", Dagger: "\u2021", bull: "\u2022", hellip: "\u2026", permil: "\u2030", prime: "\u2032", Prime: "\u2033", lsaquo: "\u2039", rsaquo: "\u203A", oline: "\u203E", euro: "\u20AC", trade: "\u2122", larr: "\u2190", uarr: "\u2191", rarr: "\u2192", darr: "\u2193", harr: "\u2194", crarr: "\u21B5", lceil: "\u2308", rceil: "\u2309", lfloor: "\u230A", rfloor: "\u230B", loz: "\u25CA", spades: "\u2660", clubs: "\u2663", hearts: "\u2665", diams: "\u2666" }), t2.entityMap = t2.HTML_ENTITIES;
    });
    es.XML_ENTITIES, es.HTML_ENTITIES, es.entityMap;
    var ts = Vr.NAMESPACE, U = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/, zt = new RegExp("[\\-\\.0-9" + U.source.slice(1, -1) + "\\u00B7\\u0300-\\u036F\\u203F-\\u2040]"), is = new RegExp("^" + U.source + zt.source + "*(?::" + U.source + zt.source + "*)?$"), ns = 0, rs = 1, as = 2, ss = 3, os = 4, us = 5, ls = 6, ds = 7;
    function cs(e2, t2) {
      this.message = e2, this.locator = t2, Error.captureStackTrace && Error.captureStackTrace(this, cs);
    }
    function hs() {
    }
    function ps(e2, t2) {
      return t2.lineNumber = e2.lineNumber, t2.columnNumber = e2.columnNumber, t2;
    }
    function fs(e2, t2, i2) {
      for (var n2 = e2.tagName, r2 = null, a2 = e2.length; a2--; ) {
        var s2 = e2[a2], o2 = s2.qName, u2 = s2.value, o2 = 0 < (d2 = o2.indexOf(":")) ? (l2 = s2.prefix = o2.slice(0, d2), c2 = o2.slice(d2 + 1), "xmlns" === l2 && c2) : (l2 = null, "xmlns" === (c2 = o2) && "");
        s2.localName = c2, false !== o2 && (null == r2 && (r2 = {}, ms(i2, i2 = {})), i2[o2] = r2[o2] = u2, s2.uri = ts.XMLNS, t2.startPrefixMapping(o2, u2));
      }
      for (var l2, a2 = e2.length; a2--; )
        (l2 = (s2 = e2[a2]).prefix) && ("xml" === l2 && (s2.uri = ts.XML), "xmlns" !== l2 && (s2.uri = i2[l2 || ""]));
      var d2, c2 = 0 < (d2 = n2.indexOf(":")) ? (l2 = e2.prefix = n2.slice(0, d2), e2.localName = n2.slice(d2 + 1)) : (l2 = null, e2.localName = n2), h2 = e2.uri = i2[l2 || ""];
      if (t2.startElement(h2, c2, n2, e2), !e2.closed)
        return e2.currentNSMap = i2, e2.localNSMap = r2, 1;
      if (t2.endElement(h2, c2, n2), r2)
        for (l2 in r2)
          Object.prototype.hasOwnProperty.call(r2, l2) && t2.endPrefixMapping(l2);
    }
    function ms(e2, t2) {
      for (var i2 in e2)
        Object.prototype.hasOwnProperty.call(e2, i2) && (t2[i2] = e2[i2]);
    }
    function gs() {
      this.attributeNames = {};
    }
    (cs.prototype = new Error()).name = cs.name, hs.prototype = { parse: function(e2, t2, i2) {
      var n2 = this.domBuilder;
      n2.startDocument(), ms(t2, t2 = {}), function(i3, e3, n3, r2, a2) {
        function s2(e4) {
          var t4 = e4.slice(1, -1);
          return Object.hasOwnProperty.call(n3, t4) ? n3[t4] : "#" === t4.charAt(0) ? 65535 < (t4 = parseInt(t4.substr(1).replace("x", "0x"))) ? (t4 -= 65536, String.fromCharCode(55296 + (t4 >> 10), 56320 + (1023 & t4))) : String.fromCharCode(t4) : (a2.error("entity not found:" + e4), e4);
        }
        function t3(e4) {
          var t4;
          f2 < e4 && (t4 = i3.substring(f2, e4).replace(/&#?\w+;/g, s2), c2 && o2(f2), r2.characters(t4, 0, e4 - f2), f2 = e4);
        }
        function o2(e4, t4) {
          for (; l2 <= e4 && (t4 = d2.exec(i3)); )
            u2 = t4.index, l2 = u2 + t4[0].length, c2.lineNumber++;
          c2.columnNumber = e4 - u2 + 1;
        }
        var u2 = 0, l2 = 0, d2 = /.*(?:\r\n?|\n)|.*$/g, c2 = r2.locator, h2 = [{ currentNSMap: e3 }], p2 = {}, f2 = 0;
        for (; ; ) {
          try {
            var m2, g2, y2 = i3.indexOf("<", f2);
            if (y2 < 0)
              return i3.substr(f2).match(/^\s*$/) || (m2 = r2.doc, g2 = m2.createTextNode(i3.substr(f2)), m2.appendChild(g2), r2.currentElement = g2);
            switch (f2 < y2 && t3(y2), i3.charAt(y2 + 1)) {
              case "/":
                var v2 = i3.indexOf(">", y2 + 3), _2 = i3.substring(y2 + 2, v2).replace(/[ \t\n\r]+$/g, ""), b2 = h2.pop();
                v2 < 0 ? (_2 = i3.substring(y2 + 2).replace(/[\s<].*/, ""), a2.error("end tag name: " + _2 + " is not complete:" + b2.tagName), v2 = y2 + 1 + _2.length) : _2.match(/\s</) && (_2 = _2.replace(/[\s<].*/, ""), a2.error("end tag name: " + _2 + " maybe not complete"), v2 = y2 + 1 + _2.length);
                var T2 = b2.localNSMap, w2 = b2.tagName == _2;
                if (w2 || b2.tagName && b2.tagName.toLowerCase() == _2.toLowerCase()) {
                  if (r2.endElement(b2.uri, b2.localName, _2), T2)
                    for (var S2 in T2)
                      Object.prototype.hasOwnProperty.call(T2, S2) && r2.endPrefixMapping(S2);
                  w2 || a2.fatalError("end tag name: " + _2 + " is not match the current start tagName:" + b2.tagName);
                } else
                  h2.push(b2);
                v2++;
                break;
              case "?":
                c2 && o2(y2), v2 = function(e4, t4, i4) {
                  var n4 = e4.indexOf("?>", t4);
                  if (n4) {
                    t4 = e4.substring(t4, n4).match(/^<\?(\S*)\s*([\s\S]*?)\s*$/);
                    return t4 ? (t4[0].length, i4.processingInstruction(t4[1], t4[2]), n4 + 2) : -1;
                  }
                  return -1;
                }(i3, y2, r2);
                break;
              case "!":
                c2 && o2(y2), v2 = function(e4, t4, i4, n4) {
                  {
                    if ("-" === e4.charAt(t4 + 2)) {
                      if ("-" !== e4.charAt(t4 + 3))
                        return -1;
                      var r3 = e4.indexOf("-->", t4 + 4);
                      return t4 < r3 ? (i4.comment(e4, t4 + 4, r3 - t4 - 4), r3 + 3) : (n4.error("Unclosed comment"), -1);
                    }
                    if ("CDATA[" == e4.substr(t4 + 3, 6)) {
                      r3 = e4.indexOf("]]>", t4 + 9);
                      return i4.startCDATA(), i4.characters(e4, t4 + 9, r3 - t4 - 9), i4.endCDATA(), r3 + 3;
                    }
                    var a3 = function(e5, t5) {
                      var i5, n5 = [], r4 = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;
                      r4.lastIndex = t5, r4.exec(e5);
                      for (; i5 = r4.exec(e5); )
                        if (n5.push(i5), i5[1])
                          return n5;
                    }(e4, t4), n4 = a3.length;
                    if (1 < n4 && /!doctype/i.test(a3[0][0])) {
                      r3 = a3[1][0], e4 = false, t4 = false;
                      3 < n4 && (/^public$/i.test(a3[2][0]) ? (e4 = a3[3][0], t4 = 4 < n4 && a3[4][0]) : /^system$/i.test(a3[2][0]) && (t4 = a3[3][0]));
                      n4 = a3[n4 - 1];
                      return i4.startDTD(r3, e4, t4), i4.endDTD(), n4.index + n4[0].length;
                    }
                  }
                  return -1;
                }(i3, y2, r2, a2);
                break;
              default:
                c2 && o2(y2);
                var E2 = new gs(), k2 = h2[h2.length - 1].currentNSMap, v2 = function(e4, t4, n4, i4, r3, a3) {
                  function s3(e5, t5, i5) {
                    n4.attributeNames.hasOwnProperty(e5) && a3.fatalError("Attribute " + e5 + " redefined"), n4.addValue(e5, t5.replace(/[\t\n\r]/g, " ").replace(/&#?\w+;/g, r3), i5);
                  }
                  var o3, u3 = ++t4, l3 = ns;
                  for (; ; ) {
                    var d3 = e4.charAt(u3);
                    switch (d3) {
                      case "=":
                        if (l3 === rs)
                          o3 = e4.slice(t4, u3), l3 = ss;
                        else {
                          if (l3 !== as)
                            throw new Error("attribute equal must after attrName");
                          l3 = ss;
                        }
                        break;
                      case "'":
                      case '"':
                        if (l3 === ss || l3 === rs) {
                          if (l3 === rs && (a3.warning('attribute value must after "="'), o3 = e4.slice(t4, u3)), t4 = u3 + 1, !(0 < (u3 = e4.indexOf(d3, t4))))
                            throw new Error("attribute value no end '" + d3 + "' match");
                          c3 = e4.slice(t4, u3), s3(o3, c3, t4 - 1), l3 = us;
                        } else {
                          if (l3 != os)
                            throw new Error('attribute value must after "="');
                          c3 = e4.slice(t4, u3), s3(o3, c3, t4), a3.warning('attribute "' + o3 + '" missed start quot(' + d3 + ")!!"), t4 = u3 + 1, l3 = us;
                        }
                        break;
                      case "/":
                        switch (l3) {
                          case ns:
                            n4.setTagName(e4.slice(t4, u3));
                          case us:
                          case ls:
                          case ds:
                            l3 = ds, n4.closed = true;
                          case os:
                          case rs:
                          case as:
                            break;
                          default:
                            throw new Error("attribute invalid close char('/')");
                        }
                        break;
                      case "":
                        return a3.error("unexpected end of input"), l3 == ns && n4.setTagName(e4.slice(t4, u3)), u3;
                      case ">":
                        switch (l3) {
                          case ns:
                            n4.setTagName(e4.slice(t4, u3));
                          case us:
                          case ls:
                          case ds:
                            break;
                          case os:
                          case rs:
                            "/" === (c3 = e4.slice(t4, u3)).slice(-1) && (n4.closed = true, c3 = c3.slice(0, -1));
                          case as:
                            l3 === as && (c3 = o3), l3 == os ? (a3.warning('attribute "' + c3 + '" missed quot(")!'), s3(o3, c3, t4)) : (ts.isHTML(i4[""]) && c3.match(/^(?:disabled|checked|selected)$/i) || a3.warning('attribute "' + c3 + '" missed value!! "' + c3 + '" instead!!'), s3(c3, c3, t4));
                            break;
                          case ss:
                            throw new Error("attribute value missed!!");
                        }
                        return u3;
                      case "\x80":
                        d3 = " ";
                      default:
                        if (d3 <= " ")
                          switch (l3) {
                            case ns:
                              n4.setTagName(e4.slice(t4, u3)), l3 = ls;
                              break;
                            case rs:
                              o3 = e4.slice(t4, u3), l3 = as;
                              break;
                            case os:
                              var c3 = e4.slice(t4, u3);
                              a3.warning('attribute "' + c3 + '" missed quot(")!!'), s3(o3, c3, t4);
                            case us:
                              l3 = ls;
                          }
                        else
                          switch (l3) {
                            case as:
                              n4.tagName, ts.isHTML(i4[""]) && o3.match(/^(?:disabled|checked|selected)$/i) || a3.warning('attribute "' + o3 + '" missed value!! "' + o3 + '" instead2!!'), s3(o3, o3, t4), t4 = u3, l3 = rs;
                              break;
                            case us:
                              a3.warning('attribute space is required"' + o3 + '"!!');
                            case ls:
                              l3 = rs, t4 = u3;
                              break;
                            case ss:
                              l3 = os, t4 = u3;
                              break;
                            case ds:
                              throw new Error("elements closed character '/' and '>' must be connected to");
                          }
                    }
                    u3++;
                  }
                }(i3, y2, E2, k2, s2, a2), C2 = E2.length;
                if (!E2.closed && function(e4, t4, i4, n4) {
                  var r3 = n4[i4];
                  null == r3 && ((r3 = e4.lastIndexOf("</" + i4 + ">")) < t4 && (r3 = e4.lastIndexOf("</" + i4)), n4[i4] = r3);
                  return r3 < t4;
                }(i3, v2, E2.tagName, p2) && (E2.closed = true, n3.nbsp || a2.warning("unclosed xml attribute")), c2 && C2) {
                  for (var I2 = ps(c2, {}), x2 = 0; x2 < C2; x2++) {
                    var A2 = E2[x2];
                    o2(A2.offset), A2.locator = ps(c2, {});
                  }
                  r2.locator = I2, fs(E2, r2, k2) && h2.push(E2), r2.locator = c2;
                } else
                  fs(E2, r2, k2) && h2.push(E2);
                ts.isHTML(E2.uri) && !E2.closed ? v2 = function(e4, t4, i4, n4, r3) {
                  if (/^(?:script|textarea)$/i.test(i4)) {
                    var a3 = e4.indexOf("</" + i4 + ">", t4), e4 = e4.substring(t4 + 1, a3);
                    if (/[&<]/.test(e4))
                      return /^script$/i.test(i4) || (e4 = e4.replace(/&#?\w+;/g, n4)), r3.characters(e4, 0, e4.length), a3;
                  }
                  return t4 + 1;
                }(i3, v2, E2.tagName, s2, r2) : v2++;
            }
          } catch (e4) {
            if (e4 instanceof cs)
              throw e4;
            a2.error("element parse error: " + e4), v2 = -1;
          }
          f2 < v2 ? f2 = v2 : t3(Math.max(y2, f2) + 1);
        }
      }(e2, t2, i2, n2, this.errorHandler), n2.endDocument();
    } }, gs.prototype = { setTagName: function(e2) {
      if (!is.test(e2))
        throw new Error("invalid tagName:" + e2);
      this.tagName = e2;
    }, addValue: function(e2, t2, i2) {
      if (!is.test(e2))
        throw new Error("invalid attribute:" + e2);
      this.attributeNames[e2] = this.length, this[this.length++] = { qName: e2, value: t2, offset: i2 };
    }, length: 0, getLocalName: function(e2) {
      return this[e2].localName;
    }, getLocator: function(e2) {
      return this[e2].locator;
    }, getQName: function(e2) {
      return this[e2].qName;
    }, getURI: function(e2) {
      return this[e2].uri;
    }, getValue: function(e2) {
      return this[e2].value;
    } };
    var ar = { XMLReader: hs, ParseError: cs }, ys = x.DOMImplementation, vs = Vr.NAMESPACE, _s = ar.ParseError, bs = ar.XMLReader;
    function Ts(e2) {
      return e2.replace(/\r[\n\u0085]/g, "\n").replace(/[\r\u0085\u2028]/g, "\n");
    }
    function ws(e2) {
      this.options = e2 || { locator: {} };
    }
    function Ss() {
      this.cdata = false;
    }
    function Es(e2, t2) {
      t2.lineNumber = e2.lineNumber, t2.columnNumber = e2.columnNumber;
    }
    function ks(e2) {
      if (e2)
        return "\n@" + (e2.systemId || "") + "#[line:" + e2.lineNumber + ",col:" + e2.columnNumber + "]";
    }
    function Cs(e2, t2, i2) {
      return "string" == typeof e2 ? e2.substr(t2, i2) : e2.length >= t2 + i2 || t2 ? new java.lang.String(e2, t2, i2) + "" : e2;
    }
    function Is(e2, t2) {
      (e2.currentElement || e2.doc).appendChild(t2);
    }
    ws.prototype.parseFromString = function(e2, t2) {
      var i2 = this.options, n2 = new bs(), r2 = i2.domBuilder || new Ss(), a2 = i2.errorHandler, s2 = i2.locator, o2 = i2.xmlns || {}, u2 = /\/x?html?$/.test(t2), t2 = u2 ? es.HTML_ENTITIES : es.XML_ENTITIES;
      s2 && r2.setDocumentLocator(s2), n2.errorHandler = function(n3, e3, r3) {
        if (!n3) {
          if (e3 instanceof Ss)
            return e3;
          n3 = e3;
        }
        var a3 = {}, s3 = n3 instanceof Function;
        function t3(t4) {
          var i3 = n3[t4];
          !i3 && s3 && (i3 = 2 == n3.length ? function(e4) {
            n3(t4, e4);
          } : n3), a3[t4] = i3 ? function(e4) {
            i3("[xmldom " + t4 + "]	" + e4 + ks(r3));
          } : function() {
          };
        }
        return r3 = r3 || {}, t3("warning"), t3("error"), t3("fatalError"), a3;
      }(a2, r2, s2), n2.domBuilder = i2.domBuilder || r2, u2 && (o2[""] = vs.HTML), o2.xml = o2.xml || vs.XML;
      i2 = i2.normalizeLineEndings || Ts;
      return e2 && "string" == typeof e2 ? n2.parse(i2(e2), o2, t2) : n2.errorHandler.error("invalid doc source"), r2.doc;
    }, Ss.prototype = { startDocument: function() {
      this.doc = new ys().createDocument(null, null, null), this.locator && (this.doc.documentURI = this.locator.systemId);
    }, startElement: function(e2, t2, i2, n2) {
      var r2 = this.doc, a2 = r2.createElementNS(e2, i2 || t2), s2 = n2.length;
      Is(this, a2), this.currentElement = a2, this.locator && Es(this.locator, a2);
      for (var o2 = 0; o2 < s2; o2++) {
        var e2 = n2.getURI(o2), u2 = n2.getValue(o2), i2 = n2.getQName(o2), l2 = r2.createAttributeNS(e2, i2);
        this.locator && Es(n2.getLocator(o2), l2), l2.value = l2.nodeValue = u2, a2.setAttributeNode(l2);
      }
    }, endElement: function(e2, t2, i2) {
      var n2 = this.currentElement;
      n2.tagName, this.currentElement = n2.parentNode;
    }, startPrefixMapping: function(e2, t2) {
    }, endPrefixMapping: function(e2) {
    }, processingInstruction: function(e2, t2) {
      t2 = this.doc.createProcessingInstruction(e2, t2);
      this.locator && Es(this.locator, t2), Is(this, t2);
    }, ignorableWhitespace: function(e2, t2, i2) {
    }, characters: function(e2, t2, i2) {
      var n2;
      (e2 = Cs.apply(this, arguments)) && (n2 = this.cdata ? this.doc.createCDATASection(e2) : this.doc.createTextNode(e2), this.currentElement ? this.currentElement.appendChild(n2) : /^\s*$/.test(e2) && this.doc.appendChild(n2), this.locator && Es(this.locator, n2));
    }, skippedEntity: function(e2) {
    }, endDocument: function() {
      this.doc.normalize();
    }, setDocumentLocator: function(e2) {
      (this.locator = e2) && (e2.lineNumber = 0);
    }, comment: function(e2, t2, i2) {
      e2 = Cs.apply(this, arguments);
      e2 = this.doc.createComment(e2);
      this.locator && Es(this.locator, e2), Is(this, e2);
    }, startCDATA: function() {
      this.cdata = true;
    }, endCDATA: function() {
      this.cdata = false;
    }, startDTD: function(e2, t2, i2) {
      var n2 = this.doc.implementation;
      n2 && n2.createDocumentType && (i2 = n2.createDocumentType(e2, t2, i2), this.locator && Es(this.locator, i2), Is(this, i2), this.doc.doctype = i2);
    }, warning: function(e2) {
    }, error: function(e2) {
    }, fatalError: function(e2) {
      throw new _s(e2, this.locator);
    } }, "endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl".replace(/\w+/g, function(e2) {
      Ss.prototype[e2] = function() {
        return null;
      };
    });
    function xs(e2) {
      return !!e2 && "object" == typeof e2;
    }
    function As() {
      for (var e2 = arguments.length, t2 = new Array(e2), i2 = 0; i2 < e2; i2++)
        t2[i2] = arguments[i2];
      return t2.reduce(function(t3, i3) {
        return "object" != typeof i3 || Object.keys(i3).forEach(function(e3) {
          Array.isArray(t3[e3]) && Array.isArray(i3[e3]) ? t3[e3] = t3[e3].concat(i3[e3]) : xs(t3[e3]) && xs(i3[e3]) ? t3[e3] = As(t3[e3], i3[e3]) : t3[e3] = i3[e3];
        }), t3;
      }, {});
    }
    function Ps(t2) {
      return Object.keys(t2).map(function(e2) {
        return t2[e2];
      });
    }
    function Ls(e2) {
      return e2.reduce(function(e3, t2) {
        return e3.concat(t2);
      }, []);
    }
    function Os(e2) {
      if (!e2.length)
        return [];
      for (var t2 = [], i2 = 0; i2 < e2.length; i2++)
        t2.push(e2[i2]);
      return t2;
    }
    function Ds(e2, t2) {
      for (var i2 = 0; i2 < e2.length; i2++)
        if (t2(e2[i2]))
          return i2;
      return -1;
    }
    function Rs(e2) {
      var t2 = e2.baseUrl, i2 = void 0 === (n2 = e2.source) ? "" : n2, n2 = void 0 === (n2 = e2.range) ? "" : n2, e2 = void 0 === (e2 = e2.indexRange) ? "" : e2, i2 = { uri: i2, resolvedUri: Sr((void 0 === t2 ? "" : t2) || "", i2) };
      return (n2 || e2) && (n2 = (n2 || e2).split("-"), e2 = window.BigInt ? window.BigInt(n2[0]) : parseInt(n2[0], 10), n2 = window.BigInt ? window.BigInt(n2[1]) : parseInt(n2[1], 10), e2 < Number.MAX_SAFE_INTEGER && "bigint" == typeof e2 && (e2 = Number(e2)), "bigint" == typeof (n2 = "bigint" == typeof (n2 = n2 < Number.MAX_SAFE_INTEGER && "bigint" == typeof n2 ? Number(n2) : n2) || "bigint" == typeof e2 ? window.BigInt(n2) - window.BigInt(e2) + window.BigInt(1) : n2 - e2 + 1) && n2 < Number.MAX_SAFE_INTEGER && (n2 = Number(n2)), i2.byterange = { length: n2, offset: e2 }), i2;
    }
    function Ms(e2) {
      return e2 && "number" != typeof e2 && (e2 = parseInt(e2, 10)), isNaN(e2) ? null : e2;
    }
    function Ns(e2) {
      var a2, t2 = e2.type, i2 = e2.duration, n2 = e2.timescale, r2 = void 0 === n2 ? 1 : n2, s2 = e2.periodDuration, o2 = e2.sourceDuration, e2 = function(e3, t3) {
        for (var i3 = [], n3 = e3; n3 < t3; n3++)
          i3.push(n3);
        return i3;
      }((n2 = Lo[t2](e2)).start, n2.end).map((a2 = e2, function(e3) {
        var t3 = a2.duration, i3 = a2.timescale, n3 = a2.periodStart, r3 = a2.startNumber;
        return { number: (void 0 === r3 ? 1 : r3) + e3, duration: t3 / (void 0 === i3 ? 1 : i3), timeline: n3, time: e3 * t3 };
      }));
      return "static" === t2 && (e2[t2 = e2.length - 1].duration = ("number" == typeof s2 ? s2 : o2) - i2 / r2 * t2), e2;
    }
    function Us(e2) {
      var t2 = e2.baseUrl, i2 = void 0 === (u2 = e2.initialization) ? {} : u2, n2 = e2.sourceDuration, r2 = void 0 === (o2 = e2.indexRange) ? "" : o2, a2 = e2.periodStart, s2 = e2.presentationTime, o2 = void 0 === (u2 = e2.number) ? 0 : u2, u2 = e2.duration;
      if (!t2)
        throw new Error(xo);
      return i2 = Rs({ baseUrl: t2, source: i2.sourceURL, range: i2.range }), (r2 = Rs({ baseUrl: t2, source: t2, indexRange: r2 })).map = i2, u2 ? (e2 = Ns(e2)).length && (r2.duration = e2[0].duration, r2.timeline = e2[0].timeline) : n2 && (r2.duration = n2, r2.timeline = a2), r2.presentationTime = s2 || a2, r2.number = o2, [r2];
    }
    function Bs(e2, t2, i2) {
      for (var n2 = e2.sidx.map || null, r2 = e2.sidx.duration, a2 = e2.timeline || 0, s2 = (s2 = e2.sidx.byterange).offset + s2.length, o2 = t2.timescale, u2 = t2.references.filter(function(e3) {
        return 1 !== e3.referenceType;
      }), l2 = [], d2 = e2.endList ? "static" : "dynamic", c2 = e2.sidx.timeline, h2 = c2, p2 = e2.mediaSequence || 0, f2 = "bigint" == typeof t2.firstOffset ? window.BigInt(s2) + t2.firstOffset : s2 + t2.firstOffset, m2 = 0; m2 < u2.length; m2++) {
        var g2 = t2.references[m2], y2 = g2.referencedSize, v2 = g2.subsegmentDuration, g2 = void 0, g2 = "bigint" == typeof f2 ? f2 + window.BigInt(y2) - window.BigInt(1) : f2 + y2 - 1, g2 = Us({ baseUrl: i2, timescale: o2, timeline: a2, periodStart: c2, presentationTime: h2, number: p2, duration: v2, sourceDuration: r2, indexRange: f2 + "-" + g2, type: d2 })[0];
        n2 && (g2.map = n2), l2.push(g2), f2 += "bigint" == typeof f2 ? window.BigInt(y2) : y2, h2 += v2 / o2, p2++;
      }
      return e2.segments = l2, e2;
    }
    function Fs(e2) {
      return i2 = function(e3) {
        return e3.timeline;
      }, Ps(e2.reduce(function(t2, e3) {
        return e3.forEach(function(e4) {
          t2[i2(e4)] = e4;
        }), t2;
      }, {})).sort(function(e3, t2) {
        return e3.timeline > t2.timeline ? 1 : -1;
      });
      var i2;
    }
    function js(e2) {
      var r2, a2, s2 = [];
      return r2 = e2, a2 = function(e3, t2, i2, n2) {
        s2 = s2.concat(e3.playlists || []);
      }, Oo.forEach(function(e3) {
        for (var t2 in r2.mediaGroups[e3])
          for (var i2 in r2.mediaGroups[e3][t2]) {
            var n2 = r2.mediaGroups[e3][t2][i2];
            a2(n2, e3, t2, i2);
          }
      }), s2;
    }
    function Hs(e2) {
      var i2 = e2.playlist, e2 = e2.mediaSequence;
      i2.mediaSequence = e2, i2.segments.forEach(function(e3, t2) {
        e3.number = i2.mediaSequence + t2;
      });
    }
    function Vs(e2) {
      var r2, a2, t2 = e2.oldManifest, i2 = e2.newManifest, n2 = t2.playlists.concat(js(t2)), e2 = i2.playlists.concat(js(i2));
      return i2.timelineStarts = Fs([t2.timelineStarts, i2.timelineStarts]), n2 = { oldPlaylists: n2, newPlaylists: e2, timelineStarts: i2.timelineStarts }, r2 = n2.oldPlaylists, e2 = n2.newPlaylists, a2 = n2.timelineStarts, e2.forEach(function(t3) {
        t3.discontinuitySequence = Ds(a2, function(e4) {
          return e4.timeline === t3.timeline;
        });
        var e3 = function(e4, t4) {
          for (var i4 = 0; i4 < e4.length; i4++)
            if (e4[i4].attributes.NAME === t4)
              return e4[i4];
          return null;
        }(r2, t3.attributes.NAME);
        if (e3 && !t3.sidx) {
          var i3 = t3.segments[0], n3 = Ds(e3.segments, function(e4) {
            return Math.abs(e4.presentationTime - i3.presentationTime) < 1 / 60;
          });
          if (-1 === n3)
            return Hs({ playlist: t3, mediaSequence: e3.mediaSequence + e3.segments.length }), t3.segments[0].discontinuity = true, t3.discontinuityStarts.unshift(0), void ((!e3.segments.length && t3.timeline > e3.timeline || e3.segments.length && t3.timeline > e3.segments[e3.segments.length - 1].timeline) && t3.discontinuitySequence--);
          e3.segments[n3].discontinuity && !i3.discontinuity && (i3.discontinuity = true, t3.discontinuityStarts.unshift(0), t3.discontinuitySequence--), Hs({ playlist: t3, mediaSequence: e3.segments[n3].number });
        }
      }), i2;
    }
    function qs(e2) {
      return e2 && e2.uri + "-" + (t2 = e2.byterange, e2 = "bigint" == typeof t2.offset || "bigint" == typeof t2.length ? window.BigInt(t2.offset) + window.BigInt(t2.length) - window.BigInt(1) : t2.offset + t2.length - 1, t2.offset + "-" + e2);
      var t2;
    }
    function Ws(e2) {
      return Ps(e2.reduce(function(e3, t2) {
        var i2, n2 = t2.attributes.id + (t2.attributes.lang || "");
        return e3[n2] ? (t2.segments && (t2.segments[0] && (t2.segments[0].discontinuity = true), (i2 = e3[n2].segments).push.apply(i2, t2.segments)), t2.attributes.contentProtection && (e3[n2].attributes.contentProtection = t2.attributes.contentProtection)) : (e3[n2] = t2, e3[n2].attributes.timelineStarts = []), e3[n2].attributes.timelineStarts.push({ start: t2.attributes.periodStart, timeline: t2.attributes.periodStart }), e3;
      }, {})).map(function(e3) {
        var t2, n2;
        return e3.discontinuityStarts = (t2 = e3.segments || [], n2 = "discontinuity", t2.reduce(function(e4, t3, i2) {
          return t3[n2] && e4.push(i2), e4;
        }, [])), e3;
      });
    }
    function Gs(e2, t2) {
      var i2 = qs(e2.sidx);
      return (i2 = i2 && t2[i2] && t2[i2].sidx) && Bs(e2, i2, e2.sidx.resolvedUri), e2;
    }
    function zs(e2, h2, p2) {
      var f2;
      return void 0 === h2 && (h2 = {}), void 0 === p2 && (p2 = false), e2 = e2.reduce(function(e3, t2) {
        var i2 = t2.attributes.role && t2.attributes.role.value || "", n2 = t2.attributes.lang || "", r2 = t2.attributes.label || "main";
        e3[r2 = n2 && !t2.attributes.label ? t2.attributes.lang + (i2 ? " (" + i2 + ")" : "") : r2] || (e3[r2] = { language: n2, autoselect: true, default: "main" === i2, playlists: [], uri: "" });
        var a2, s2, o2, u2, l2, d2, c2, u2 = Gs((s2 = p2, o2 = (a2 = t2).attributes, u2 = a2.segments, l2 = a2.sidx, d2 = a2.mediaSequence, c2 = a2.discontinuitySequence, n2 = a2.discontinuityStarts, u2 = { attributes: ((a2 = { NAME: o2.id, BANDWIDTH: o2.bandwidth, CODECS: o2.codecs })["PROGRAM-ID"] = 1, a2), uri: "", endList: "static" === o2.type, timeline: o2.periodStart, resolvedUri: "", targetDuration: o2.duration, discontinuitySequence: c2, discontinuityStarts: n2, timelineStarts: o2.timelineStarts, mediaSequence: d2, segments: u2 }, o2.contentProtection && (u2.contentProtection = o2.contentProtection), l2 && (u2.sidx = l2), s2 && (u2.attributes.AUDIO = "audio", u2.attributes.SUBTITLES = "subs"), u2), h2);
        return e3[r2].playlists.push(u2), "undefined" == typeof f2 && "main" === i2 && ((f2 = t2).default = true), e3;
      }, {}), f2 || (e2[Object.keys(e2)[0]].default = true), e2;
    }
    function Xs(e2) {
      var t2 = e2.attributes, i2 = e2.segments, n2 = e2.sidx, r2 = e2.discontinuityStarts, i2 = { attributes: ((e2 = { NAME: t2.id, AUDIO: "audio", SUBTITLES: "subs", RESOLUTION: { width: t2.width, height: t2.height }, CODECS: t2.codecs, BANDWIDTH: t2.bandwidth })["PROGRAM-ID"] = 1, e2), uri: "", endList: "static" === t2.type, timeline: t2.periodStart, resolvedUri: "", targetDuration: t2.duration, discontinuityStarts: r2, timelineStarts: t2.timelineStarts, segments: i2 };
      return t2.frameRate && (i2.attributes["FRAME-RATE"] = t2.frameRate), t2.contentProtection && (i2.contentProtection = t2.contentProtection), n2 && (i2.sidx = n2), i2;
    }
    function Ks(e2) {
      return "video/mp4" === (e2 = e2.attributes).mimeType || "video/webm" === e2.mimeType || "video" === e2.contentType;
    }
    function Ys(e2) {
      return "audio/mp4" === (e2 = e2.attributes).mimeType || "audio/webm" === e2.mimeType || "audio" === e2.contentType;
    }
    function Qs(e2) {
      return "text/vtt" === (e2 = e2.attributes).mimeType || "text" === e2.contentType;
    }
    function $s(i2) {
      return i2 ? Object.keys(i2).reduce(function(e2, t2) {
        t2 = i2[t2];
        return e2.concat(t2.playlists);
      }, []) : [];
    }
    function Js(e2) {
      var t2 = e2.dashPlaylists, i2 = e2.locations, n2 = void 0 === (d2 = e2.sidxMapping) ? {} : d2, r2 = e2.previousManifest;
      if (!t2.length)
        return {};
      var a2 = (c2 = t2[0].attributes).sourceDuration, s2 = c2.type, o2 = c2.suggestedPresentationDelay, u2 = c2.minimumUpdatePeriod, l2 = Ws(t2.filter(Ks)).map(Xs), d2 = Ws(t2.filter(Ys)), e2 = Ws(t2.filter(Qs)), c2 = t2.map(function(e3) {
        return e3.attributes.captionServices;
      }).filter(Boolean), a2 = { allowCache: true, discontinuityStarts: [], segments: [], endList: true, mediaGroups: ((t2 = { AUDIO: {}, VIDEO: {} })["CLOSED-CAPTIONS"] = {}, t2.SUBTITLES = {}, t2), uri: "", duration: a2, playlists: function(e3, t3) {
        if (void 0 === t3 && (t3 = {}), !Object.keys(t3).length)
          return e3;
        for (var i3 in e3)
          e3[i3] = Gs(e3[i3], t3);
        return e3;
      }(l2, n2) };
      0 <= u2 && (a2.minimumUpdatePeriod = 1e3 * u2), i2 && (a2.locations = i2), "dynamic" === s2 && (a2.suggestedPresentationDelay = o2);
      var h2, p2, o2 = 0 === a2.playlists.length, o2 = d2.length ? zs(d2, n2, o2) : null, n2 = e2.length ? (void 0 === (h2 = n2) && (h2 = {}), e2.reduce(function(e3, t3) {
        var i3 = t3.attributes.lang || "text";
        return e3[i3] || (e3[i3] = { language: i3, default: false, autoselect: false, playlists: [], uri: "" }), e3[i3].playlists.push(Gs(function(e4) {
          var t4 = e4.attributes, i4 = e4.segments, n3 = e4.mediaSequence, r3 = e4.discontinuityStarts, a3 = e4.discontinuitySequence;
          "undefined" == typeof i4 && (i4 = [{ uri: t4.baseUrl, timeline: t4.periodStart, resolvedUri: t4.baseUrl || "", duration: t4.sourceDuration, number: 0 }], t4.duration = t4.sourceDuration);
          (e4 = { NAME: t4.id, BANDWIDTH: t4.bandwidth })["PROGRAM-ID"] = 1;
          return t4.codecs && (e4.CODECS = t4.codecs), { attributes: e4, uri: "", endList: "static" === t4.type, timeline: t4.periodStart, resolvedUri: t4.baseUrl || "", targetDuration: t4.duration, timelineStarts: t4.timelineStarts, discontinuityStarts: r3, discontinuitySequence: a3, mediaSequence: n3, segments: i4 };
        }(t3), h2)), e3;
      }, {})) : null, l2 = (e2 = l2.concat($s(o2), $s(n2))).map(function(e3) {
        return e3.timelineStarts;
      });
      return a2.timelineStarts = Fs(l2), e2 = e2, p2 = a2.timelineStarts, e2.forEach(function(t3) {
        t3.mediaSequence = 0, t3.discontinuitySequence = Ds(p2, function(e3) {
          return e3.timeline === t3.timeline;
        }), t3.segments && t3.segments.forEach(function(e3, t4) {
          e3.number = t4;
        });
      }), o2 && (a2.mediaGroups.AUDIO.audio = o2), n2 && (a2.mediaGroups.SUBTITLES.subs = n2), c2.length && (a2.mediaGroups["CLOSED-CAPTIONS"].cc = c2.reduce(function(n3, e3) {
        return e3 && e3.forEach(function(e4) {
          var t3 = e4.channel, i3 = e4.language;
          n3[i3] = { autoselect: false, default: false, instreamId: t3, language: i3 }, e4.hasOwnProperty("aspectRatio") && (n3[i3].aspectRatio = e4.aspectRatio), e4.hasOwnProperty("easyReader") && (n3[i3].easyReader = e4.easyReader), e4.hasOwnProperty("3D") && (n3[i3]["3D"] = e4["3D"]);
        }), n3;
      }, {})), r2 ? Vs({ oldManifest: r2, newManifest: a2 }) : a2;
    }
    function Zs(e2, t2) {
      for (var i2, n2, r2, a2, s2, o2, u2 = e2.type, l2 = e2.minimumUpdatePeriod, d2 = void 0 === l2 ? 0 : l2, c2 = void 0 === (l2 = e2.media) ? "" : l2, h2 = e2.sourceDuration, p2 = void 0 === (l2 = e2.timescale) ? 1 : l2, f2 = void 0 === (l2 = e2.startNumber) ? 1 : l2, m2 = e2.periodStart, g2 = [], y2 = -1, v2 = 0; v2 < t2.length; v2++) {
        var _2 = t2[v2], b2 = _2.d, T2 = _2.r || 0, w2 = _2.t || 0;
        y2 < 0 && (y2 = w2), w2 && y2 < w2 && (y2 = w2);
        var S2, E2 = void 0;
        E2 = T2 < 0 ? (S2 = v2 + 1) === t2.length ? "dynamic" === u2 && 0 < d2 && 0 < c2.indexOf("$Number$") ? (i2 = y2, n2 = b2, _2 = o2 = s2 = a2 = r2 = void 0, r2 = (w2 = e2).NOW, a2 = w2.clientOffset, s2 = w2.availabilityStartTime, o2 = w2.timescale, _2 = w2.periodStart, w2 = w2.minimumUpdatePeriod, Math.ceil((((r2 + a2) / 1e3 + (void 0 === w2 ? 0 : w2) - (s2 + (void 0 === _2 ? 0 : _2))) * (void 0 === o2 ? 1 : o2) - i2) / n2)) : (h2 * p2 - y2) / b2 : (t2[S2].t - y2) / b2 : T2 + 1;
        for (var k2 = f2 + g2.length + E2, C2 = f2 + g2.length; C2 < k2; )
          g2.push({ number: C2, duration: b2 / p2, time: y2, timeline: m2 }), y2 += b2, C2++;
      }
      return g2;
    }
    function eo(e2, t2) {
      return e2.replace(Do, (r2 = t2, function(e3, t3, i2, n2) {
        if ("$$" === e3)
          return "$";
        if ("undefined" == typeof r2[t3])
          return e3;
        e3 = "" + r2[t3];
        return "RepresentationID" === t3 || (n2 = i2 ? parseInt(n2, 10) : 1) <= e3.length ? e3 : new Array(n2 - e3.length + 1).join("0") + e3;
      }));
      var r2;
    }
    function to(r2, e2) {
      var a2 = { RepresentationID: r2.id, Bandwidth: r2.bandwidth || 0 }, t2 = void 0 === (t2 = r2.initialization) ? { sourceURL: "", range: "" } : t2, s2 = Rs({ baseUrl: r2.baseUrl, source: eo(t2.sourceURL, a2), range: t2.range });
      return (t2 = e2, (e2 = r2).duration || t2 ? e2.duration ? Ns(e2) : Zs(e2, t2) : [{ number: e2.startNumber || 1, duration: e2.sourceDuration, time: 0, timeline: e2.periodStart }]).map(function(e3) {
        a2.Number = e3.number, a2.Time = e3.time;
        var t3 = eo(r2.media || "", a2), i2 = r2.timescale || 1, n2 = r2.presentationTimeOffset || 0, i2 = r2.periodStart + (e3.time - n2) / i2;
        return { uri: t3, timeline: e3.timeline, duration: e3.duration, resolvedUri: Sr(r2.baseUrl || "", t3), map: s2, number: e3.number, presentationTime: i2 };
      });
    }
    function io(r2, e2) {
      var t2 = r2.duration, i2 = void 0 === (i2 = r2.segmentUrls) ? [] : i2, a2 = r2.periodStart;
      if (!t2 && !e2 || t2 && e2)
        throw new Error(Ao);
      var n2, s2 = i2.map(function(e3) {
        return i3 = e3, e3 = (t3 = r2).baseUrl, t3 = t3.initialization, t3 = Rs({ baseUrl: e3, source: (t3 = void 0 === t3 ? {} : t3).sourceURL, range: t3.range }), (i3 = Rs({ baseUrl: e3, source: i3.media, range: i3.mediaRange })).map = t3, i3;
        var t3, i3;
      });
      return t2 && (n2 = Ns(r2)), (n2 = e2 ? Zs(r2, e2) : n2).map(function(e3, t3) {
        if (s2[t3]) {
          var i3 = s2[t3], n3 = r2.timescale || 1, t3 = r2.presentationTimeOffset || 0;
          return i3.timeline = e3.timeline, i3.duration = e3.duration, i3.number = e3.number, i3.presentationTime = a2 + (e3.time - t3) / n3, i3;
        }
      }).filter(function(e3) {
        return e3;
      });
    }
    function no(e2) {
      var t2, i2 = e2.attributes, n2 = e2.segmentInfo;
      n2.template ? (a2 = to, t2 = As(i2, n2.template)) : n2.base ? (a2 = Us, t2 = As(i2, n2.base)) : n2.list && (a2 = io, t2 = As(i2, n2.list));
      var r2 = { attributes: i2 };
      if (!a2)
        return r2;
      var a2, e2 = a2(t2, n2.segmentTimeline);
      return t2.duration ? (i2 = t2.duration, a2 = t2.timescale, t2.duration = i2 / (void 0 === a2 ? 1 : a2)) : e2.length ? t2.duration = e2.reduce(function(e3, t3) {
        return Math.max(e3, Math.ceil(t3.duration));
      }, 0) : t2.duration = 0, r2.attributes = t2, r2.segments = e2, n2.base && t2.indexRange && (r2.sidx = e2[0], r2.segments = []), r2;
    }
    function ro(e2, t2) {
      return Os(e2.childNodes).filter(function(e3) {
        return e3.tagName === t2;
      });
    }
    function ao(e2) {
      return e2.textContent.trim();
    }
    function so(e2) {
      if (!(r2 = /P(?:(\d*)Y)?(?:(\d*)M)?(?:(\d*)D)?(?:T(?:(\d*)H)?(?:(\d*)M)?(?:([\d.]*)S)?)?/.exec(e2)))
        return 0;
      var t2 = (a2 = r2.slice(1))[0], i2 = a2[1], n2 = a2[2], e2 = a2[3], r2 = a2[4], a2 = a2[5];
      return 31536e3 * parseFloat(t2 || 0) + 2592e3 * parseFloat(i2 || 0) + 86400 * parseFloat(n2 || 0) + 3600 * parseFloat(e2 || 0) + 60 * parseFloat(r2 || 0) + parseFloat(a2 || 0);
    }
    function oo(e2) {
      return e2 && e2.attributes ? Os(e2.attributes).reduce(function(e3, t2) {
        var i2 = Ro[t2.name] || Ro.DEFAULT;
        return e3[t2.name] = i2(t2.value), e3;
      }, {}) : {};
    }
    function uo(e2, i2) {
      return i2.length ? Ls(e2.map(function(t2) {
        return i2.map(function(e3) {
          return Sr(t2, ao(e3));
        });
      })) : e2;
    }
    function lo(e2) {
      var t2 = ro(e2, "SegmentTemplate")[0], i2 = ro(e2, "SegmentList")[0], n2 = i2 && ro(i2, "SegmentURL").map(function(e3) {
        return As({ tag: "SegmentURL" }, oo(e3));
      }), r2 = ro(e2, "SegmentBase")[0], e2 = (a2 = i2 || t2) && ro(a2, "SegmentTimeline")[0], a2 = (a2 = i2 || r2 || t2) && ro(a2, "Initialization")[0];
      (t2 = t2 && oo(t2)) && a2 ? t2.initialization = a2 && oo(a2) : t2 && t2.initialization && (t2.initialization = { sourceURL: t2.initialization });
      var s2 = { template: t2, segmentTimeline: e2 && ro(e2, "S").map(oo), list: i2 && As(oo(i2), { segmentUrls: n2, initialization: oo(a2) }), base: r2 && As(oo(r2), { initialization: oo(a2) }) };
      return Object.keys(s2).forEach(function(e3) {
        s2[e3] || delete s2[e3];
      }), s2;
    }
    function co(u2, l2, d2) {
      return function(e2) {
        var t2 = oo(e2), i2 = uo(l2, ro(e2, "BaseURL")), n2 = ro(e2, "Role")[0], n2 = { role: oo(n2) }, t2 = As(u2, t2, n2), n2 = ro(e2, "Accessibility")[0], n2 = "urn:scte:dash:cc:cea-608:2015" === (n2 = oo(n2)).schemeIdUri ? ("string" != typeof n2.value ? [] : n2.value.split(";")).map(function(e3) {
          var t3, i3, n3;
          return /^CC\d=/.test(n3 = e3) ? (i3 = (t3 = e3.split("="))[0], n3 = t3[1]) : /^CC\d$/.test(e3) && (i3 = e3), { channel: i3, language: n3 };
        }) : "urn:scte:dash:cc:cea-708:2015" === n2.schemeIdUri ? ("string" != typeof n2.value ? [] : n2.value.split(";")).map(function(e3) {
          var t3, i3, n3 = { channel: void 0, language: void 0, aspectRatio: 1, easyReader: 0, "3D": 0 };
          return /=/.test(e3) ? (t3 = (i3 = e3.split("="))[0], i3 = void 0 === (i3 = i3[1]) ? "" : i3, n3.channel = t3, n3.language = e3, i3.split(",").forEach(function(e4) {
            var t4 = e4.split(":"), e4 = t4[0], t4 = t4[1];
            "lang" === e4 ? n3.language = t4 : "er" === e4 ? n3.easyReader = Number(t4) : "war" === e4 ? n3.aspectRatio = Number(t4) : "3D" === e4 && (n3["3D"] = Number(t4));
          })) : n3.language = e3, n3.channel && (n3.channel = "SERVICE" + n3.channel), n3;
        }) : void 0;
        n2 && (t2 = As(t2, { captionServices: n2 }));
        n2 = ro(e2, "Label")[0];
        n2 && n2.childNodes.length && (r2 = n2.childNodes[0].nodeValue.trim(), t2 = As(t2, { label: r2 }));
        var r2 = ro(e2, "ContentProtection").reduce(function(e3, t3) {
          var i3 = oo(t3);
          i3.schemeIdUri && (i3.schemeIdUri = i3.schemeIdUri.toLowerCase());
          var n3 = Mo[i3.schemeIdUri];
          return n3 && (e3[n3] = { attributes: i3 }, (t3 = ro(t3, "cenc:pssh")[0]) && (t3 = ao(t3), e3[n3].pssh = t3 && Br(t3))), e3;
        }, {});
        Object.keys(r2).length && (t2 = As(t2, { contentProtection: r2 }));
        var a2, s2, o2, r2 = lo(e2), e2 = ro(e2, "Representation"), r2 = As(d2, r2);
        return Ls(e2.map((a2 = t2, s2 = i2, o2 = r2, function(e3) {
          var t3 = ro(e3, "BaseURL"), t3 = uo(s2, t3), i3 = As(a2, oo(e3)), n3 = lo(e3);
          return t3.map(function(e4) {
            return { segmentInfo: As(o2, n3), attributes: As(i3, { baseUrl: e4 }) };
          });
        })));
      };
    }
    function ho(e2, t2) {
      var i2 = t2 = void 0 === t2 ? {} : t2, n2 = void 0 === (a2 = i2.manifestUri) ? "" : a2, t2 = void 0 === (r2 = i2.NOW) ? Date.now() : r2, r2 = void 0 === (a2 = i2.clientOffset) ? 0 : a2;
      if (!(i2 = ro(e2, "Period")).length)
        throw new Error(ko);
      var a2 = ro(e2, "Location"), s2 = oo(e2), e2 = uo([n2], ro(e2, "BaseURL"));
      s2.type = s2.type || "static", s2.sourceDuration = s2.mediaPresentationDuration || 0, s2.NOW = t2, s2.clientOffset = r2, a2.length && (s2.locations = a2.map(ao));
      var o2, u2, l2 = [];
      return i2.forEach(function(e3, t3) {
        var i3, n3 = oo(e3), r3 = l2[t3 - 1];
        n3.start = (i3 = { attributes: n3, priorPeriodAttributes: r3 ? r3.attributes : null, mpdType: s2.type }, t3 = i3.attributes, r3 = i3.priorPeriodAttributes, i3 = i3.mpdType, "number" == typeof t3.start ? t3.start : r3 && "number" == typeof r3.start && "number" == typeof r3.duration ? r3.start + r3.duration : r3 || "static" !== i3 ? null : 0), l2.push({ node: e3, attributes: n3 });
      }), { locations: s2.locations, representationInfo: Ls(l2.map((o2 = s2, u2 = e2, function(e3, t3) {
        var i3 = uo(u2, ro(e3.node, "BaseURL")), n3 = As(o2, { periodStart: e3.attributes.start });
        "number" == typeof e3.attributes.duration && (n3.periodDuration = e3.attributes.duration);
        var r3 = ro(e3.node, "AdaptationSet"), e3 = lo(e3.node);
        return Ls(r3.map(co(n3, i3, e3)));
      }))) };
    }
    function po(e2) {
      if ("" === e2)
        throw new Error(Co);
      var t2, i2, n2 = new Eo();
      try {
        i2 = (t2 = n2.parseFromString(e2, "application/xml")) && "MPD" === t2.documentElement.tagName ? t2.documentElement : null;
      } catch (e3) {
      }
      if (!i2 || i2 && 0 < i2.getElementsByTagName("parsererror").length)
        throw new Error(Io);
      return i2;
    }
    function fo(e2, t2) {
      void 0 === t2 && (t2 = {});
      var i2 = ho(po(e2), t2), e2 = i2.representationInfo.map(no);
      return Js({ dashPlaylists: e2, locations: i2.locations, sidxMapping: t2.sidxMapping, previousManifest: t2.previousManifest });
    }
    function mo(e2) {
      return function(e3) {
        e3 = ro(e3, "UTCTiming")[0];
        if (!e3)
          return null;
        var t2 = oo(e3);
        switch (t2.schemeIdUri) {
          case "urn:mpeg:dash:utc:http-head:2014":
          case "urn:mpeg:dash:utc:http-head:2012":
            t2.method = "HEAD";
            break;
          case "urn:mpeg:dash:utc:http-xsdate:2014":
          case "urn:mpeg:dash:utc:http-iso:2014":
          case "urn:mpeg:dash:utc:http-xsdate:2012":
          case "urn:mpeg:dash:utc:http-iso:2012":
            t2.method = "GET";
            break;
          case "urn:mpeg:dash:utc:direct:2014":
          case "urn:mpeg:dash:utc:direct:2012":
            t2.method = "DIRECT", t2.value = Date.parse(t2.value);
            break;
          case "urn:mpeg:dash:utc:http-ntp:2014":
          case "urn:mpeg:dash:utc:ntp:2014":
          case "urn:mpeg:dash:utc:sntp:2014":
          default:
            throw new Error(Po);
        }
        return t2;
      }(po(e2));
    }
    function go(e2, t2) {
      return void 0 === t2 && (t2 = 0), (e2 = _r(e2)).length - t2 < 10 || !wr(e2, Fo, { offset: t2 }) ? t2 : go(e2, t2 += function(e3, t3) {
        void 0 === t3 && (t3 = 0);
        var i2 = (e3 = _r(e3))[t3 + 5], t3 = e3[t3 + 6] << 21 | e3[t3 + 7] << 14 | e3[t3 + 8] << 7 | e3[t3 + 9];
        return (16 & i2) >> 4 ? 20 + t3 : 10 + t3;
      }(e2, t2));
    }
    function yo(e2) {
      return "string" == typeof e2 ? Tr(e2) : e2;
    }
    function vo(e2, t2, i2) {
      var n2;
      void 0 === i2 && (i2 = false), n2 = t2, t2 = Array.isArray(n2) ? n2.map(yo) : [yo(n2)], e2 = _r(e2);
      var r2 = [];
      if (!t2.length)
        return r2;
      for (var a2 = 0; a2 < e2.length; ) {
        var s2 = (e2[a2] << 24 | e2[a2 + 1] << 16 | e2[a2 + 2] << 8 | e2[a2 + 3]) >>> 0, o2 = e2.subarray(a2 + 4, a2 + 8);
        if (0 == s2)
          break;
        var u2 = a2 + s2;
        if (u2 > e2.length) {
          if (i2)
            break;
          u2 = e2.length;
        }
        s2 = e2.subarray(a2 + 8, u2);
        wr(o2, t2[0]) && (1 === t2.length ? r2.push(s2) : r2.push.apply(r2, vo(s2, t2.slice(1), i2))), a2 = u2;
      }
      return r2;
    }
    function _o(e2, t2, i2, n2) {
      void 0 === i2 && (i2 = true), void 0 === n2 && (n2 = false);
      var r2 = function(e3) {
        for (var t3 = 1, i3 = 0; i3 < Ho.length && !(e3 & Ho[i3]); i3++)
          t3++;
        return t3;
      }(e2[t2]), a2 = e2.subarray(t2, t2 + r2);
      return i2 && ((a2 = Array.prototype.slice.call(e2, t2, t2 + r2))[0] ^= Ho[r2 - 1]), { length: r2, value: function(n3, e3) {
        var t3 = void 0 === e3 ? {} : e3, e3 = t3.signed, e3 = void 0 !== e3 && e3, t3 = t3.le, r3 = void 0 !== t3 && t3;
        n3 = _r(n3);
        t3 = r3 ? "reduce" : "reduceRight", t3 = (n3[t3] || Array.prototype[t3]).call(n3, function(e4, t4, i3) {
          i3 = r3 ? i3 : Math.abs(i3 + 1 - n3.length);
          return e4 + Mr(t4) * Nr[i3];
        }, Mr(0));
        return !e3 || (e3 = Nr[n3.length] / Mr(2) - Mr(1)) < (t3 = Mr(t3)) && (t3 -= e3, t3 -= e3, t3 -= Mr(2)), Number(t3);
      }(a2, { signed: n2 }), bytes: a2 };
    }
    function bo(e2) {
      return "string" == typeof e2 ? e2.match(/.{1,2}/g).map(bo) : "number" == typeof e2 ? br(e2) : e2;
    }
    function To(e2, t2, i2) {
      if (i2 >= t2.length)
        return t2.length;
      var n2 = _o(t2, i2, false);
      if (wr(e2.bytes, n2.bytes))
        return i2;
      var r2 = _o(t2, i2 + n2.length);
      return To(e2, t2, i2 + r2.length + r2.value + n2.length);
    }
    function wo(e2, t2) {
      var i2;
      i2 = t2, t2 = Array.isArray(i2) ? i2.map(bo) : [bo(i2)], e2 = _r(e2);
      var n2 = [];
      if (!t2.length)
        return n2;
      for (var r2 = 0; r2 < e2.length; ) {
        var a2 = _o(e2, r2, false), s2 = _o(e2, r2 + a2.length), o2 = r2 + a2.length + s2.length;
        127 === s2.value && (s2.value = To(a2, e2, o2), s2.value !== e2.length && (s2.value -= o2));
        var u2 = o2 + s2.value > e2.length ? e2.length : o2 + s2.value, u2 = e2.subarray(o2, u2);
        wr(t2[0], a2.bytes) && (1 === t2.length ? n2.push(u2) : n2 = n2.concat(wo(u2, t2.slice(1)))), r2 += a2.length + s2.length + u2.length;
      }
      return n2;
    }
    function So(e2, t2, i2, n2) {
      void 0 === n2 && (n2 = 1 / 0), e2 = _r(e2), i2 = [].concat(i2);
      for (var r2, a2 = 0, s2 = 0; a2 < e2.length && (s2 < n2 || r2); ) {
        var o2 = void 0;
        if (wr(e2.subarray(a2), Vo) ? o2 = 4 : wr(e2.subarray(a2), qo) && (o2 = 3), o2) {
          if (s2++, r2)
            return function(e3) {
              for (var t3 = [], i3 = 1; i3 < e3.length - 2; )
                wr(e3.subarray(i3, i3 + 3), Wo) && (t3.push(i3 + 2), i3++), i3++;
              if (0 === t3.length)
                return e3;
              for (var n3 = e3.length - t3.length, r3 = new Uint8Array(n3), a3 = 0, i3 = 0; i3 < n3; a3++, i3++)
                a3 === t3[0] && (a3++, t3.shift()), r3[i3] = e3[a3];
              return r3;
            }(e2.subarray(r2, a2));
          var u2 = void 0;
          "h264" === t2 ? u2 = 31 & e2[a2 + o2] : "h265" === t2 && (u2 = e2[a2 + o2] >> 1 & 63), -1 !== i2.indexOf(u2) && (r2 = a2 + o2), a2 += o2 + ("h264" === t2 ? 1 : 2);
        } else
          a2++;
      }
      return e2.subarray(0, 0);
    }
    var Eo = { __DOMHandler: Ss, normalizeLineEndings: Ts, DOMParser: ws }.DOMParser, ko = "INVALID_NUMBER_OF_PERIOD", Co = "DASH_EMPTY_MANIFEST", Io = "DASH_INVALID_XML", xo = "NO_BASE_URL", Ao = "SEGMENT_TIME_UNSPECIFIED", Po = "UNSUPPORTED_UTC_TIMING_SCHEME", Lo = { static: function(e2) {
      var t2 = e2.duration, i2 = e2.timescale, n2 = void 0 === i2 ? 1 : i2, r2 = e2.sourceDuration, i2 = e2.periodDuration, e2 = Ms(e2.endNumber), n2 = t2 / n2;
      return "number" == typeof e2 ? { start: 0, end: e2 } : "number" == typeof i2 ? { start: 0, end: i2 / n2 } : { start: 0, end: r2 / n2 };
    }, dynamic: function(e2) {
      var t2 = e2.NOW, i2 = e2.clientOffset, n2 = e2.availabilityStartTime, r2 = e2.timescale, a2 = void 0 === r2 ? 1 : r2, s2 = e2.duration, o2 = e2.periodStart, u2 = void 0 === o2 ? 0 : o2, r2 = e2.minimumUpdatePeriod, o2 = void 0 === r2 ? 0 : r2, r2 = e2.timeShiftBufferDepth, r2 = void 0 === r2 ? 1 / 0 : r2, e2 = Ms(e2.endNumber), i2 = (t2 + i2) / 1e3, u2 = n2 + u2, o2 = Math.ceil((i2 + o2 - u2) * a2 / s2), r2 = Math.floor((i2 - u2 - r2) * a2 / s2), s2 = Math.floor((i2 - u2) * a2 / s2);
      return { start: Math.max(0, r2), end: "number" == typeof e2 ? e2 : Math.min(o2, s2) };
    } }, Oo = ["AUDIO", "SUBTITLES"], Do = /\$([A-z]*)(?:(%0)([0-9]+)d)?\$/g, Ro = { mediaPresentationDuration: so, availabilityStartTime: function(e2) {
      return /^\d+-\d+-\d+T\d+:\d+:\d+(\.\d+)?$/.test(e2 = e2) && (e2 += "Z"), Date.parse(e2) / 1e3;
    }, minimumUpdatePeriod: so, suggestedPresentationDelay: so, type: function(e2) {
      return e2;
    }, timeShiftBufferDepth: so, start: so, width: function(e2) {
      return parseInt(e2, 10);
    }, height: function(e2) {
      return parseInt(e2, 10);
    }, bandwidth: function(e2) {
      return parseInt(e2, 10);
    }, frameRate: function(e2) {
      return parseFloat(e2.split("/").reduce(function(e3, t2) {
        return e3 / t2;
      }));
    }, startNumber: function(e2) {
      return parseInt(e2, 10);
    }, timescale: function(e2) {
      return parseInt(e2, 10);
    }, presentationTimeOffset: function(e2) {
      return parseInt(e2, 10);
    }, duration: function(e2) {
      var t2 = parseInt(e2, 10);
      return isNaN(t2) ? so(e2) : t2;
    }, d: function(e2) {
      return parseInt(e2, 10);
    }, t: function(e2) {
      return parseInt(e2, 10);
    }, r: function(e2) {
      return parseInt(e2, 10);
    }, DEFAULT: function(e2) {
      return e2;
    } }, Mo = { "urn:uuid:1077efec-c0b2-4d02-ace3-3c1e52e2fb4b": "org.w3.clearkey", "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed": "com.widevine.alpha", "urn:uuid:9a04f079-9840-4286-ab92-e65be0885f95": "com.microsoft.playready", "urn:uuid:f239e769-efa3-4850-9c16-a903c6932efb": "com.adobe.primetime" }, No = Math.pow(2, 32), Uo = function(e2) {
      var t2 = new DataView(e2.buffer, e2.byteOffset, e2.byteLength);
      return t2.getBigUint64 ? (e2 = t2.getBigUint64(0)) < Number.MAX_SAFE_INTEGER ? Number(e2) : e2 : t2.getUint32(0) * No + t2.getUint32(4);
    }, Bo = function(e2) {
      var t2 = new DataView(e2.buffer, e2.byteOffset, e2.byteLength), i2 = { version: e2[0], flags: new Uint8Array(e2.subarray(1, 4)), references: [], referenceId: t2.getUint32(4), timescale: t2.getUint32(8) }, n2 = 12;
      0 === i2.version ? (i2.earliestPresentationTime = t2.getUint32(n2), i2.firstOffset = t2.getUint32(n2 + 4), n2 += 8) : (i2.earliestPresentationTime = Uo(e2.subarray(n2)), i2.firstOffset = Uo(e2.subarray(n2 + 8)), n2 += 16);
      var r2 = t2.getUint16(n2 += 2);
      for (n2 += 2; 0 < r2; n2 += 12, r2--)
        i2.references.push({ referenceType: (128 & e2[n2]) >>> 7, referencedSize: 2147483647 & t2.getUint32(n2), subsegmentDuration: t2.getUint32(n2 + 4), startsWithSap: !!(128 & e2[n2 + 8]), sapType: (112 & e2[n2 + 8]) >>> 4, sapDeltaTime: 268435455 & t2.getUint32(n2 + 8) });
      return i2;
    }, Fo = _r([73, 68, 51]), jo = { EBML: _r([26, 69, 223, 163]), DocType: _r([66, 130]), Segment: _r([24, 83, 128, 103]), SegmentInfo: _r([21, 73, 169, 102]), Tracks: _r([22, 84, 174, 107]), Track: _r([174]), TrackNumber: _r([215]), DefaultDuration: _r([35, 227, 131]), TrackEntry: _r([174]), TrackType: _r([131]), FlagDefault: _r([136]), CodecID: _r([134]), CodecPrivate: _r([99, 162]), VideoTrack: _r([224]), AudioTrack: _r([225]), Cluster: _r([31, 67, 182, 117]), Timestamp: _r([231]), TimestampScale: _r([42, 215, 177]), BlockGroup: _r([160]), BlockDuration: _r([155]), Block: _r([161]), SimpleBlock: _r([163]) }, Ho = [128, 64, 32, 16, 8, 4, 2, 1], Vo = _r([0, 0, 0, 1]), qo = _r([0, 0, 1]), Wo = _r([0, 0, 3]), Go = { webm: _r([119, 101, 98, 109]), matroska: _r([109, 97, 116, 114, 111, 115, 107, 97]), flac: _r([102, 76, 97, 67]), ogg: _r([79, 103, 103, 83]), ac3: _r([11, 119]), riff: _r([82, 73, 70, 70]), avi: _r([65, 86, 73]), wav: _r([87, 65, 86, 69]), "3gp": _r([102, 116, 121, 112, 51, 103]), mp4: _r([102, 116, 121, 112]), fmp4: _r([115, 116, 121, 112]), mov: _r([102, 116, 121, 112, 113, 116]), moov: _r([109, 111, 111, 118]), moof: _r([109, 111, 111, 102]) }, zo = { aac: function(e2) {
      var t2 = go(e2);
      return wr(e2, [255, 16], { offset: t2, mask: [255, 22] });
    }, mp3: function(e2) {
      var t2 = go(e2);
      return wr(e2, [255, 2], { offset: t2, mask: [255, 6] });
    }, webm: function(e2) {
      e2 = wo(e2, [jo.EBML, jo.DocType])[0];
      return wr(e2, Go.webm);
    }, mkv: function(e2) {
      e2 = wo(e2, [jo.EBML, jo.DocType])[0];
      return wr(e2, Go.matroska);
    }, mp4: function(e2) {
      return !zo["3gp"](e2) && !zo.mov(e2) && (!(!wr(e2, Go.mp4, { offset: 4 }) && !wr(e2, Go.fmp4, { offset: 4 })) || (!(!wr(e2, Go.moof, { offset: 4 }) && !wr(e2, Go.moov, { offset: 4 })) || void 0));
    }, mov: function(e2) {
      return wr(e2, Go.mov, { offset: 4 });
    }, "3gp": function(e2) {
      return wr(e2, Go["3gp"], { offset: 4 });
    }, ac3: function(e2) {
      var t2 = go(e2);
      return wr(e2, Go.ac3, { offset: t2 });
    }, ts: function(e2) {
      if (e2.length < 189 && 1 <= e2.length)
        return 71 === e2[0];
      for (var t2 = 0; t2 + 188 < e2.length && t2 < 188; ) {
        if (71 === e2[t2] && 71 === e2[t2 + 188])
          return true;
        t2 += 1;
      }
      return false;
    }, flac: function(e2) {
      var t2 = go(e2);
      return wr(e2, Go.flac, { offset: t2 });
    }, ogg: function(e2) {
      return wr(e2, Go.ogg);
    }, avi: function(e2) {
      return wr(e2, Go.riff) && wr(e2, Go.avi, { offset: 8 });
    }, wav: function(e2) {
      return wr(e2, Go.riff) && wr(e2, Go.wav, { offset: 8 });
    }, h264: function(e2) {
      return So(e2, "h264", 7, 3).length;
    }, h265: function(e2) {
      return So(e2, "h265", [32, 33], 3).length;
    } }, Xo = Object.keys(zo).filter(function(e2) {
      return "ts" !== e2 && "h264" !== e2 && "h265" !== e2;
    }).concat(["ts", "h264", "h265"]);
    Xo.forEach(function(e2) {
      var t2 = zo[e2];
      zo[e2] = function(e3) {
        return t2(_r(e3));
      };
    });
    function Ko(e2) {
      e2 = _r(e2);
      for (var t2 = 0; t2 < Xo.length; t2++) {
        var i2 = Xo[t2];
        if (Yo[i2](e2))
          return i2;
      }
      return "";
    }
    var Yo = zo, Qo = 9e4, $o = m(function(t2) {
      function i2(e2) {
        return t2.exports = i2 = Object.setPrototypeOf ? Object.getPrototypeOf : function(e3) {
          return e3.__proto__ || Object.getPrototypeOf(e3);
        }, i2(e2);
      }
      t2.exports = i2;
    });
    function Jo(e2, t2, i2) {
      return e2 && i2 && i2.responseURL && t2 !== i2.responseURL ? i2.responseURL : t2;
    }
    function Zo(e2) {
      return ir.log.debug ? ir.log.debug.bind(ir, "VHS:", e2 + " >") : function() {
      };
    }
    function eu(e2, t2) {
      var i2, n2 = [];
      if (e2 && e2.length)
        for (i2 = 0; i2 < e2.length; i2++)
          t2(e2.start(i2), e2.end(i2)) && n2.push([e2.start(i2), e2.end(i2)]);
      return ir.createTimeRanges(n2);
    }
    function tu(e2, i2) {
      return eu(e2, function(e3, t2) {
        return e3 - 0.1 <= i2 && i2 <= t2 + 0.1;
      });
    }
    function iu(e2, t2) {
      return eu(e2, function(e3) {
        return t2 <= e3 - Rl;
      });
    }
    function nu(e2) {
      var t2 = [];
      if (!e2 || !e2.length)
        return "";
      for (var i2 = 0; i2 < e2.length; i2++)
        t2.push(e2.start(i2) + " => " + e2.end(i2));
      return t2.join(", ");
    }
    function ru(e2) {
      for (var t2 = [], i2 = 0; i2 < e2.length; i2++)
        t2.push({ start: e2.start(i2), end: e2.end(i2) });
      return t2;
    }
    function au(e2) {
      if (e2 && e2.length && e2.end)
        return e2.end(e2.length - 1);
    }
    function su(e2, t2) {
      var i2 = 0;
      if (!e2 || !e2.length)
        return i2;
      for (var n2 = 0; n2 < e2.length; n2++) {
        var r2 = e2.start(n2), a2 = e2.end(n2);
        a2 < t2 || (i2 += r2 < t2 && t2 <= a2 ? a2 - t2 : a2 - r2);
      }
      return i2;
    }
    function ou(t2, e2) {
      if (!e2.preload)
        return e2.duration;
      var i2 = 0;
      return (e2.parts || []).forEach(function(e3) {
        i2 += e3.duration;
      }), (e2.preloadHints || []).forEach(function(e3) {
        "PART" === e3.type && (i2 += t2.partTargetDuration);
      }), i2;
    }
    function uu(e2) {
      return (e2.segments || []).reduce(function(i2, n2, r2) {
        return n2.parts ? n2.parts.forEach(function(e3, t2) {
          i2.push({ duration: e3.duration, segmentIndex: r2, partIndex: t2, part: e3, segment: n2 });
        }) : i2.push({ duration: n2.duration, segmentIndex: r2, partIndex: null, segment: n2, part: null }), i2;
      }, []);
    }
    function lu(e2) {
      return (e2 = e2.segments && e2.segments.length && e2.segments[e2.segments.length - 1]) && e2.parts || [];
    }
    function du(e2) {
      var t2 = e2.preloadSegment;
      if (t2) {
        e2 = t2.parts, t2 = (t2.preloadHints || []).reduce(function(e3, t3) {
          return e3 + ("PART" === t3.type ? 1 : 0);
        }, 0);
        return t2 += e2 && e2.length ? e2.length : 0;
      }
    }
    function cu(e2, t2) {
      return t2.endList ? 0 : e2 && e2.suggestedPresentationDelay ? e2.suggestedPresentationDelay : (e2 = 0 < lu(t2).length) && t2.serverControl && t2.serverControl.partHoldBack ? t2.serverControl.partHoldBack : e2 && t2.partTargetDuration ? 3 * t2.partTargetDuration : t2.serverControl && t2.serverControl.holdBack ? t2.serverControl.holdBack : t2.targetDuration ? 3 * t2.targetDuration : 0;
    }
    function hu(e2, t2, i2) {
      if ((t2 = "undefined" == typeof t2 ? e2.mediaSequence + e2.segments.length : t2) < e2.mediaSequence)
        return 0;
      var n2 = function(e3, t3) {
        var i3 = 0, n3 = t3 - e3.mediaSequence, r2 = e3.segments[n3];
        if (r2) {
          if ("undefined" != typeof r2.start)
            return { result: r2.start, precise: true };
          if ("undefined" != typeof r2.end)
            return { result: r2.end - r2.duration, precise: true };
        }
        for (; n3--; ) {
          if ("undefined" != typeof (r2 = e3.segments[n3]).end)
            return { result: i3 + r2.end, precise: true };
          if (i3 += ou(e3, r2), "undefined" != typeof r2.start)
            return { result: i3 + r2.start, precise: true };
        }
        return { result: i3, precise: false };
      }(e2, t2);
      return n2.precise ? n2.result : (t2 = function(e3, t3) {
        for (var i3, n3 = 0, r2 = t3 - e3.mediaSequence; r2 < e3.segments.length; r2++) {
          if ("undefined" != typeof (i3 = e3.segments[r2]).start)
            return { result: i3.start - n3, precise: true };
          if (n3 += ou(e3, i3), "undefined" != typeof i3.end)
            return { result: i3.end - n3, precise: true };
        }
        return { result: -1, precise: false };
      }(e2, t2)).precise ? t2.result : n2.result + i2;
    }
    function pu(e2, t2, i2) {
      if (!e2)
        return 0;
      if ("number" != typeof i2 && (i2 = 0), "undefined" == typeof t2) {
        if (e2.totalDuration)
          return e2.totalDuration;
        if (!e2.endList)
          return window.Infinity;
      }
      return hu(e2, t2, i2);
    }
    function fu(e2) {
      var t2 = e2.defaultDuration, i2 = e2.durationList, n2 = e2.startIndex, r2 = e2.endIndex, a2 = 0;
      if (r2 < n2 && (n2 = (e2 = [r2, n2])[0], r2 = e2[1]), n2 < 0) {
        for (var s2 = n2; s2 < Math.min(0, r2); s2++)
          a2 += t2;
        n2 = 0;
      }
      for (var o2 = n2; o2 < r2; o2++)
        a2 += i2[o2].duration;
      return a2;
    }
    function mu(e2, t2, i2, n2) {
      return e2 && e2.segments ? e2.endList ? pu(e2) : null === t2 ? null : (t2 = hu(e2, e2.mediaSequence + e2.segments.length, t2 = t2 || 0), i2 && (t2 -= n2 = "number" == typeof n2 ? n2 : cu(null, e2)), Math.max(0, t2)) : null;
    }
    function gu(e2) {
      return e2.excludeUntil && e2.excludeUntil > Date.now();
    }
    function yu(e2) {
      return e2.excludeUntil && e2.excludeUntil === 1 / 0;
    }
    function vu(e2) {
      var t2 = gu(e2);
      return !e2.disabled && !t2;
    }
    function _u(e2, t2) {
      return t2.attributes && t2.attributes[e2];
    }
    function bu(e2, t2) {
      if (1 === e2.playlists.length)
        return true;
      var i2 = t2.attributes.BANDWIDTH || Number.MAX_VALUE;
      return 0 === e2.playlists.filter(function(e3) {
        return !!vu(e3) && (e3.attributes.BANDWIDTH || 0) < i2;
      }).length;
    }
    function Tu(e2, t2) {
      return !(!e2 && !t2 || !e2 && t2 || e2 && !t2) && (e2 === t2 || (!(!e2.id || !t2.id || e2.id !== t2.id) || (!(!e2.resolvedUri || !t2.resolvedUri || e2.resolvedUri !== t2.resolvedUri) || !(!e2.uri || !t2.uri || e2.uri !== t2.uri))));
    }
    function wu(e2, t2) {
      var i2, n2 = e2 && e2.mediaGroups && e2.mediaGroups.AUDIO || {}, r2 = false;
      for (i2 in n2) {
        for (var a2 in n2[i2])
          if (r2 = t2(n2[i2][a2]))
            break;
        if (r2)
          break;
      }
      return !!r2;
    }
    function Su(i2) {
      if (!i2 || !i2.playlists || !i2.playlists.length)
        return wu(i2, function(e3) {
          return e3.playlists && e3.playlists.length || e3.uri;
        });
      for (var e2 = 0; e2 < i2.playlists.length; e2++) {
        var t2 = function(e3) {
          var t3 = i2.playlists[e3], e3 = t3.attributes && t3.attributes.CODECS;
          return e3 && e3.split(",").every(pr) || wu(i2, function(e4) {
            return Tu(t3, e4);
          }) ? "continue" : { v: false };
        }(e2);
        if ("continue" !== t2 && "object" == typeof t2)
          return t2.v;
      }
      return true;
    }
    function Eu(e2, t2) {
      return e2 + "-" + t2;
    }
    function ku(e2, t2, i2) {
      return "placeholder-uri-" + e2 + "-" + t2 + "-" + i2;
    }
    function Cu(r2, a2) {
      r2.mediaGroups && ["AUDIO", "SUBTITLES"].forEach(function(e2) {
        if (r2.mediaGroups[e2])
          for (var t2 in r2.mediaGroups[e2])
            for (var i2 in r2.mediaGroups[e2][t2]) {
              var n2 = r2.mediaGroups[e2][t2][i2];
              a2(n2, e2, t2, i2);
            }
      });
    }
    function Iu(e2) {
      var t2 = e2.playlist, i2 = e2.uri, e2 = e2.id;
      t2.id = e2, t2.playlistErrors_ = 0, i2 && (t2.uri = i2), t2.attributes = t2.attributes || {};
    }
    function xu(o2, e2, u2) {
      void 0 === u2 && (u2 = ku), o2.uri = e2;
      for (var t2 = 0; t2 < o2.playlists.length; t2++)
        o2.playlists[t2].uri || (o2.playlists[t2].uri = "placeholder-uri-" + t2);
      var i2, n2 = Su(o2);
      Cu(o2, function(e3, r2, a2, s2) {
        if (!e3.playlists || !e3.playlists.length) {
          if (n2 && "AUDIO" === r2 && !e3.uri)
            for (var t3 = 0; t3 < o2.playlists.length; t3++) {
              var i3 = o2.playlists[t3];
              if (i3.attributes && i3.attributes.AUDIO && i3.attributes.AUDIO === a2)
                return;
            }
          e3.playlists = [g({}, e3)];
        }
        e3.playlists.forEach(function(e4, t4) {
          var i4 = u2(r2, a2, s2, e4), n3 = Eu(t4, i4);
          e4.uri ? e4.resolvedUri = e4.resolvedUri || Dl(o2.uri, e4.uri) : (e4.uri = 0 === t4 ? i4 : n3, e4.resolvedUri = e4.uri), e4.id = e4.id || n3, e4.attributes = e4.attributes || {}, o2.playlists[e4.id] = e4, o2.playlists[e4.uri] = e4;
        });
      }), function(e3) {
        for (var t3 = e3.playlists.length; t3--; ) {
          var i3 = e3.playlists[t3];
          Iu({ playlist: i3, id: Eu(t3, i3.uri) }), i3.resolvedUri = Dl(e3.uri, i3.uri), e3.playlists[i3.id] = i3, (e3.playlists[i3.uri] = i3).attributes.BANDWIDTH || Ul.warn("Invalid playlist STREAM-INF detected. Missing BANDWIDTH attribute.");
        }
      }(o2), Cu(i2 = o2, function(e3) {
        e3.uri && (e3.resolvedUri = Dl(i2.uri, e3.uri));
      });
    }
    function Au(e2, t2, i2) {
      var n2 = e2.slice(), r2 = t2.slice();
      i2 = i2 || 0;
      for (var a2, s2 = [], o2 = 0; o2 < r2.length; o2++) {
        var u2 = n2[o2 + i2], l2 = r2[o2];
        u2 ? (a2 = u2.map || a2, s2.push(function(e3, t3) {
          if (!e3)
            return t3;
          var i3 = Bl(e3, t3);
          if (e3.preloadHints && !t3.preloadHints && delete i3.preloadHints, e3.parts && !t3.parts)
            delete i3.parts;
          else if (e3.parts && t3.parts)
            for (var n3 = 0; n3 < t3.parts.length; n3++)
              e3.parts && e3.parts[n3] && (i3.parts[n3] = Bl(e3.parts[n3], t3.parts[n3]));
          return !e3.skipped && t3.skipped && (i3.skipped = false), e3.preload && !t3.preload && (i3.preload = false), i3;
        }(u2, l2))) : (a2 && !l2.map && (l2.map = a2), s2.push(l2));
      }
      return s2;
    }
    function Pu(e2, t2) {
      !e2.resolvedUri && e2.uri && (e2.resolvedUri = Dl(t2, e2.uri)), e2.key && !e2.key.resolvedUri && (e2.key.resolvedUri = Dl(t2, e2.key.uri)), e2.map && !e2.map.resolvedUri && (e2.map.resolvedUri = Dl(t2, e2.map.uri)), e2.map && e2.map.key && !e2.map.key.resolvedUri && (e2.map.key.resolvedUri = Dl(t2, e2.map.key.uri)), e2.parts && e2.parts.length && e2.parts.forEach(function(e3) {
        e3.resolvedUri || (e3.resolvedUri = Dl(t2, e3.uri));
      }), e2.preloadHints && e2.preloadHints.length && e2.preloadHints.forEach(function(e3) {
        e3.resolvedUri || (e3.resolvedUri = Dl(t2, e3.uri));
      });
    }
    function Lu(e2) {
      var t2 = e2.segments || [], i2 = e2.preloadSegment;
      if (i2 && i2.parts && i2.parts.length) {
        if (i2.preloadHints) {
          for (var n2 = 0; n2 < i2.preloadHints.length; n2++)
            if ("MAP" === i2.preloadHints[n2].type)
              return t2;
        }
        i2.duration = e2.targetDuration, i2.preload = true, t2.push(i2);
      }
      return t2;
    }
    function Ou(e2, t2) {
      return e2 === t2 || e2.segments && t2.segments && e2.segments.length === t2.segments.length && e2.endList === t2.endList && e2.mediaSequence === t2.mediaSequence && e2.preloadSegment === t2.preloadSegment;
    }
    function Du(e2, a2, t2) {
      void 0 === t2 && (t2 = Ou);
      var i2 = Bl(e2, {}), n2 = i2.playlists[a2.id];
      if (!n2)
        return null;
      if (t2(n2, a2))
        return null;
      a2.segments = Lu(a2);
      var s2 = Bl(n2, a2);
      if (s2.preloadSegment && !a2.preloadSegment && delete s2.preloadSegment, n2.segments) {
        if (a2.skip) {
          a2.segments = a2.segments || [];
          for (var r2 = 0; r2 < a2.skip.skippedSegments; r2++)
            a2.segments.unshift({ skipped: true });
        }
        s2.segments = Au(n2.segments, a2.segments, a2.mediaSequence - n2.mediaSequence);
      }
      s2.segments.forEach(function(e3) {
        Pu(e3, s2.resolvedUri);
      });
      for (var o2 = 0; o2 < i2.playlists.length; o2++)
        i2.playlists[o2].id === a2.id && (i2.playlists[o2] = s2);
      return i2.playlists[a2.id] = s2, i2.playlists[a2.uri] = s2, Cu(e2, function(e3, t3, i3, n3) {
        if (e3.playlists)
          for (var r3 = 0; r3 < e3.playlists.length; r3++)
            a2.id === e3.playlists[r3].id && (e3.playlists[r3] = s2);
      }), i2;
    }
    function Ru(e2, t2) {
      var i2 = e2.segments || [], n2 = i2[i2.length - 1], n2 = (i2 = n2 && n2.parts && n2.parts[n2.parts.length - 1]) && i2.duration || n2 && n2.duration;
      return t2 && n2 ? 1e3 * n2 : 500 * (e2.partTargetDuration || e2.targetDuration || 10);
    }
    function Mu(e2, t2, i2, n2) {
      var r2 = "arraybuffer" === e2.responseType ? e2.response : e2.responseText;
      !t2 && r2 && (e2.responseTime = Date.now(), e2.roundTripTime = e2.responseTime - e2.requestTime, e2.bytesReceived = r2.byteLength || r2.length, e2.bandwidth || (e2.bandwidth = Math.floor(e2.bytesReceived / e2.roundTripTime * 8 * 1e3))), i2.headers && (e2.responseHeaders = i2.headers), t2 && "ETIMEDOUT" === t2.code && (e2.timedout = true), n2(t2 = !t2 && !e2.aborted && 200 !== i2.statusCode && 206 !== i2.statusCode && 0 !== i2.statusCode ? new Error("XHR Failed with a response of: " + (e2 && (r2 || e2.responseText))) : t2, e2);
    }
    function Nu() {
      function a2(e2, i2) {
        e2 = Hl({ timeout: 45e3 }, e2);
        var t2 = a2.beforeRequest || ir.Vhs.xhr.beforeRequest;
        !t2 || "function" != typeof t2 || (t2 = t2(e2)) && (e2 = t2);
        var n2 = (true === ir.Vhs.xhr.original ? jl : ir.Vhs.xhr)(e2, function(e3, t3) {
          return Mu(n2, e3, t3, i2);
        }), r2 = n2.abort;
        return n2.abort = function() {
          return n2.aborted = true, r2.apply(n2, arguments);
        }, n2.uri = e2.uri, n2.requestTime = Date.now(), n2;
      }
      return a2.original = true, a2;
    }
    function Uu(e2) {
      var t2, i2 = {};
      return e2.byterange && (i2.Range = (t2 = e2.byterange, e2 = t2.offset, t2 = "bigint" == typeof t2.offset || "bigint" == typeof t2.length ? window.BigInt(t2.offset) + window.BigInt(t2.length) - window.BigInt(1) : t2.offset + t2.length - 1, "bytes=" + e2 + "-" + t2)), i2;
    }
    function Bu(e2, t2) {
      return e2 = e2.toString(16), "00".substring(0, 2 - e2.length) + e2 + (t2 % 2 ? " " : "");
    }
    function Fu(e2) {
      return 32 <= e2 && e2 < 126 ? String.fromCharCode(e2) : ".";
    }
    function ju(i2) {
      var n2 = {};
      return Object.keys(i2).forEach(function(e2) {
        var t2 = i2[e2];
        vr(t2) ? n2[e2] = { bytes: t2.buffer, byteOffset: t2.byteOffset, byteLength: t2.byteLength } : n2[e2] = t2;
      }), n2;
    }
    function Hu(e2) {
      var t2 = e2.byterange || { length: 1 / 0, offset: 0 };
      return [t2.length, t2.offset, e2.resolvedUri].join(",");
    }
    function Vu(e2) {
      return e2.resolvedUri;
    }
    function qu(e2) {
      for (var t2 = Array.prototype.slice.call(e2), i2 = "", n2 = 0; n2 < t2.length / 16; n2++)
        i2 += t2.slice(16 * n2, 16 * n2 + 16).map(Bu).join("") + " " + t2.slice(16 * n2, 16 * n2 + 16).map(Fu).join("") + "\n";
      return i2;
    }
    function Wu(e2) {
      var t2 = e2.playlist, i2 = e2.time, n2 = void 0 === i2 ? void 0 : i2;
      if (!(i2 = e2.callback))
        throw new Error("getProgramTime: callback must be provided");
      return t2 && void 0 !== n2 ? (e2 = function(e3, t3) {
        if (!t3 || !t3.segments || 0 === t3.segments.length)
          return null;
        for (var i3, n3 = 0, r2 = 0; r2 < t3.segments.length && !(e3 <= (n3 = (i3 = t3.segments[r2]).videoTimingInfo ? i3.videoTimingInfo.transmuxedPresentationEnd : n3 + i3.duration)); r2++)
          ;
        var a2 = t3.segments[t3.segments.length - 1];
        if (a2.videoTimingInfo && a2.videoTimingInfo.transmuxedPresentationEnd < e3)
          return null;
        if (n3 < e3) {
          if (e3 > n3 + 0.25 * a2.duration)
            return null;
          i3 = a2;
        }
        return { segment: i3, estimatedStart: i3.videoTimingInfo ? i3.videoTimingInfo.transmuxedPresentationStart : n3 - i3.duration, type: i3.videoTimingInfo ? "accurate" : "estimate" };
      }(n2, t2)) ? "estimate" === e2.type ? i2({ message: "Accurate programTime could not be determined. Please seek to e.seekTime and try again", seekTime: e2.estimatedStart }) : (t2 = { mediaSeconds: n2 }, (e2 = function(e3, t3) {
        if (!t3.dateTimeObject)
          return null;
        var i3 = t3.videoTimingInfo.transmuxerPrependedSeconds, i3 = e3 - (t3.videoTimingInfo.transmuxedPresentationStart + i3);
        return new Date(t3.dateTimeObject.getTime() + 1e3 * i3);
      }(n2, e2.segment)) && (t2.programDateTime = e2.toISOString()), i2(null, t2)) : i2({ message: "valid programTime was not found" }) : i2({ message: "getProgramTime: playlist and time must be provided" });
    }
    function Gu(e2) {
      var t2 = e2.programTime, i2 = e2.playlist, n2 = e2.retryCount, r2 = void 0 === n2 ? 2 : n2, a2 = e2.seekTo, s2 = e2.pauseAfterSeek, o2 = void 0 === s2 || s2, u2 = e2.tech, l2 = e2.callback;
      if (!l2)
        throw new Error("seekToProgramTime: callback must be provided");
      return "undefined" != typeof t2 && i2 && a2 ? i2.endList || u2.hasStarted_ ? function(e3) {
        if (!e3.segments || 0 === e3.segments.length)
          return false;
        for (var t3 = 0; t3 < e3.segments.length; t3++)
          if (!e3.segments[t3].dateTimeObject)
            return false;
        return true;
      }(i2) ? (n2 = function(e3, t3) {
        var i3;
        try {
          i3 = new Date(e3);
        } catch (e4) {
          return null;
        }
        if (!t3 || !t3.segments || 0 === t3.segments.length)
          return null;
        if (i3 < (r3 = t3.segments[0]).dateTimeObject)
          return null;
        for (var n3 = 0; n3 < t3.segments.length - 1; n3++) {
          var r3 = t3.segments[n3];
          if (i3 < t3.segments[n3 + 1].dateTimeObject)
            break;
        }
        var a3, s3 = t3.segments[t3.segments.length - 1], e3 = s3.dateTimeObject, a3 = s3.videoTimingInfo ? (a3 = s3.videoTimingInfo).transmuxedPresentationEnd - a3.transmuxedPresentationStart - a3.transmuxerPrependedSeconds : s3.duration + 0.25 * s3.duration;
        return new Date(e3.getTime() + 1e3 * a3) < i3 ? null : { segment: r3 = e3 < i3 ? s3 : r3, estimatedStart: r3.videoTimingInfo ? r3.videoTimingInfo.transmuxedPresentationStart : Nl.duration(t3, t3.mediaSequence + t3.segments.indexOf(r3)), type: r3.videoTimingInfo ? "accurate" : "estimate" };
      }(t2, i2)) ? (s2 = n2.segment, e2 = function(e3, t3) {
        var i3;
        try {
          n3 = new Date(e3), i3 = new Date(t3);
        } catch (e4) {
        }
        var n3 = n3.getTime();
        return (i3.getTime() - n3) / 1e3;
      }(s2.dateTimeObject, t2), "estimate" === n2.type ? 0 === r2 ? l2({ message: t2 + " is not buffered yet. Try again" }) : (a2(n2.estimatedStart + e2), void u2.one("seeked", function() {
        Gu({ programTime: t2, playlist: i2, retryCount: r2 - 1, seekTo: a2, pauseAfterSeek: o2, tech: u2, callback: l2 });
      })) : (e2 = s2.start + e2, u2.one("seeked", function() {
        return l2(null, u2.currentTime());
      }), o2 && u2.pause(), void a2(e2))) : l2({ message: t2 + " was not found in the stream" }) : l2({ message: "programDateTime tags must be provided in the manifest " + i2.resolvedUri }) : l2({ message: "player must be playing a live stream to start buffering" }) : l2({ message: "seekToProgramTime: programTime, seekTo and playlist must be provided" });
    }
    function zu(e2, t2) {
      if (4 === e2.readyState)
        return t2();
    }
    function Xu(e2, t2, r2) {
      function n2(e3, t3, i3, n3) {
        return t3.abort(), o2 = true, r2(e3, t3, i3, n3);
      }
      function i2(e3, t3) {
        if (!o2) {
          if (e3)
            return n2(e3, t3, "", s2);
          var i3 = t3.responseText.substring(s2 && s2.byteLength || 0, t3.responseText.length);
          if (s2 = function() {
            for (var e4 = arguments.length, t4 = new Array(e4), i4 = 0; i4 < e4; i4++)
              t4[i4] = arguments[i4];
            if ((t4 = t4.filter(function(e5) {
              return e5 && (e5.byteLength || e5.length) && "string" != typeof e5;
            })).length <= 1)
              return _r(t4[0]);
            var n3 = t4.reduce(function(e5, t5, i5) {
              return e5 + (t5.byteLength || t5.length);
            }, 0), r3 = new Uint8Array(n3), a3 = 0;
            return t4.forEach(function(e5) {
              e5 = _r(e5), r3.set(e5, a3), a3 += e5.byteLength;
            }), r3;
          }(s2, Tr(i3, true)), a2 = a2 || go(s2), s2.length < 10 || a2 && s2.length < a2 + 2)
            return zu(t3, function() {
              return n2(e3, t3, "", s2);
            });
          i3 = Ko(s2);
          return "ts" === i3 && s2.length < 188 || !i3 && s2.length < 376 ? zu(t3, function() {
            return n2(e3, t3, "", s2);
          }) : n2(null, t3, i3, s2);
        }
      }
      var a2, s2 = [], o2 = false, u2 = t2({ uri: e2, beforeSend: function(t3) {
        t3.overrideMimeType("text/plain; charset=x-user-defined"), t3.addEventListener("progress", function(e3) {
          return e3.total, e3.loaded, Mu(t3, null, { statusCode: t3.status }, i2);
        });
      } }, function(e3, t3) {
        return Mu(u2, e3, t3, i2);
      });
      return u2;
    }
    function Ku(e2, t2) {
      if (!Ou(e2, t2))
        return false;
      if (e2.sidx && t2.sidx && (e2.sidx.offset !== t2.sidx.offset || e2.sidx.length !== t2.sidx.length))
        return false;
      if (!e2.sidx && t2.sidx || e2.sidx && !t2.sidx)
        return false;
      if (e2.segments && !t2.segments || !e2.segments && t2.segments)
        return false;
      if (!e2.segments && !t2.segments)
        return true;
      for (var i2 = 0; i2 < e2.segments.length; i2++) {
        var n2 = e2.segments[i2], r2 = t2.segments[i2];
        if (n2.uri !== r2.uri)
          return false;
        if (n2.byterange || r2.byterange) {
          n2 = n2.byterange, r2 = r2.byterange;
          if (n2 && !r2 || !n2 && r2)
            return false;
          if (n2.offset !== r2.offset || n2.length !== r2.length)
            return false;
        }
      }
      return true;
    }
    function Yu(e2, t2, i2, n2) {
      return "placeholder-uri-" + e2 + "-" + t2 + "-" + (n2.attributes.NAME || i2);
    }
    function Qu(e2, t2, i2) {
      for (var r2, a2, s2 = true, o2 = Vl(e2, { duration: t2.duration, minimumUpdatePeriod: t2.minimumUpdatePeriod, timelineStarts: t2.timelineStarts }), n2 = 0; n2 < t2.playlists.length; n2++) {
        var u2, l2 = t2.playlists[n2];
        l2.sidx && (u2 = qs(l2.sidx), i2 && i2[u2] && i2[u2].sidx && Bs(l2, i2[u2].sidx, l2.sidx.resolvedUri));
        l2 = Du(o2, l2, Ku);
        l2 && (o2 = l2, s2 = false);
      }
      return Cu(t2, function(e3, t3, i3, n3) {
        var r3, a3;
        e3.playlists && e3.playlists.length && (r3 = e3.playlists[0].id, (a3 = Du(o2, e3.playlists[0], Ku)) && (n3 in (o2 = a3).mediaGroups[t3][i3] || (o2.mediaGroups[t3][i3][n3] = e3), o2.mediaGroups[t3][i3][n3].playlists[0] = o2.playlists[r3], s2 = false));
      }), a2 = t2, Cu(r2 = o2, function(e3, t3, i3, n3) {
        n3 in a2.mediaGroups[t3][i3] || delete r2.mediaGroups[t3][i3][n3];
      }), (s2 = t2.minimumUpdatePeriod === e2.minimumUpdatePeriod && s2) ? null : o2;
    }
    function $u(e2, t2) {
      var i2, n2 = {};
      for (i2 in e2) {
        var r2 = e2[i2].sidx;
        if (r2) {
          var a2 = qs(r2);
          if (!t2[a2])
            break;
          var s2 = t2[a2].sidxInfo;
          s2 = s2, r2 = r2, (Boolean(!s2.map && !r2.map) || Boolean(s2.map && r2.map && s2.map.byterange.offset === r2.map.byterange.offset && s2.map.byterange.length === r2.map.byterange.length)) && s2.uri === r2.uri && s2.byterange.offset === r2.byterange.offset && s2.byterange.length === r2.byterange.length && (n2[a2] = t2[a2]);
        }
      }
      return n2;
    }
    function Ju(e2) {
      return e2.on = e2.addEventListener, e2.off = e2.removeEventListener, e2;
    }
    function Zu(i2) {
      var n2 = i2.transmuxer, e2 = i2.bytes, t2 = i2.audioAppendStart, r2 = i2.gopsToAlignWith, a2 = i2.remux, s2 = i2.onData, o2 = i2.onTrackInfo, u2 = i2.onAudioTimingInfo, l2 = i2.onVideoTimingInfo, d2 = i2.onVideoSegmentTimingInfo, c2 = i2.onAudioSegmentTimingInfo, h2 = i2.onId3, p2 = i2.onCaptions, f2 = i2.onDone, m2 = i2.onEndedTimeline, g2 = i2.onTransmuxerLog, y2 = i2.isEndOfTimeline, v2 = { buffer: [] }, _2 = y2;
      n2.onmessage = function(e3) {
        var t3;
        n2.currentTransmux === i2 && ("data" === e3.data.action && function(e4, t4, i3) {
          var n3 = e4.data.segment, r3 = n3.type, a3 = n3.initSegment, s3 = n3.captions, o3 = n3.captionStreams, u3 = n3.metadata, l3 = n3.videoFrameDtsTime, n3 = n3.videoFramePtsTime;
          t4.buffer.push({ captions: s3, captionStreams: o3, metadata: u3 });
          e4 = e4.data.segment.boxes || { data: e4.data.segment.data }, a3 = { type: r3, data: new Uint8Array(e4.data, e4.data.byteOffset, e4.data.byteLength), initSegment: new Uint8Array(a3.data, a3.byteOffset, a3.byteLength) };
          "undefined" != typeof l3 && (a3.videoFrameDtsTime = l3), "undefined" != typeof n3 && (a3.videoFramePtsTime = n3), i3(a3);
        }(e3, v2, s2), "trackinfo" === e3.data.action && o2(e3.data.trackInfo), "gopInfo" === e3.data.action && (v2.gopInfo = e3.data.gopInfo), "audioTimingInfo" === e3.data.action && u2(e3.data.audioTimingInfo), "videoTimingInfo" === e3.data.action && l2(e3.data.videoTimingInfo), "videoSegmentTimingInfo" === e3.data.action && d2(e3.data.videoSegmentTimingInfo), "audioSegmentTimingInfo" === e3.data.action && c2(e3.data.audioSegmentTimingInfo), "id3Frame" === e3.data.action && h2([e3.data.id3Frame], e3.data.id3Frame.dispatchType), "caption" === e3.data.action && p2(e3.data.caption), "endedtimeline" === e3.data.action && (_2 = false, m2()), "log" === e3.data.action && g2(e3.data.log), "transmuxed" === e3.data.type && (_2 || (n2.onmessage = null, e3 = (t3 = { transmuxedData: v2, callback: f2 }).transmuxedData, t3 = t3.callback, e3.buffer = [], t3(e3), zl(n2))));
      }, t2 && n2.postMessage({ action: "setAudioAppendStart", appendStart: t2 }), Array.isArray(r2) && n2.postMessage({ action: "alignGopsWith", gopsToAlignWith: r2 }), "undefined" != typeof a2 && n2.postMessage({ action: "setRemux", remux: a2 }), e2.byteLength && (r2 = e2 instanceof ArrayBuffer ? e2 : e2.buffer, a2 = e2 instanceof ArrayBuffer ? 0 : e2.byteOffset, n2.postMessage({ action: "push", data: r2, byteOffset: a2, byteLength: e2.byteLength }, [r2])), y2 && n2.postMessage({ action: "endTimeline" }), n2.postMessage({ action: "flush" });
    }
    function el(e2, t2) {
      e2.postMessage({ action: t2 }), zl(e2);
    }
    function tl(e2, t2) {
      if (!t2.currentTransmux)
        return t2.currentTransmux = e2, el(t2, e2), 0;
      t2.transmuxQueue.push(el.bind(null, t2, e2));
    }
    function il(e2) {
      if (!e2.transmuxer.currentTransmux)
        return e2.transmuxer.currentTransmux = e2, void Zu(e2);
      e2.transmuxer.transmuxQueue.push(e2);
    }
    function nl(i2) {
      var n2 = i2.transmuxer, r2 = i2.endAction || i2.action, a2 = i2.callback, e2 = g({}, i2, { endAction: null, transmuxer: null, callback: null }), t2 = function e3(t3) {
        t3.data.action === r2 && (n2.removeEventListener("message", e3), t3.data.data && (t3.data.data = new Uint8Array(t3.data.data, i2.byteOffset || 0, i2.byteLength || t3.data.data.byteLength), i2.data && (i2.data = t3.data.data)), a2(t3.data));
      };
      n2.addEventListener("message", t2), i2.data ? (t2 = i2.data instanceof ArrayBuffer, e2.byteOffset = t2 ? 0 : i2.data.byteOffset, e2.byteLength = i2.data.byteLength, t2 = [t2 ? i2.data : i2.data.buffer], n2.postMessage(e2, t2)) : n2.postMessage(e2);
    }
    function rl(e2) {
      e2.forEach(function(e3) {
        e3.abort();
      });
    }
    function al(e2, t2) {
      return t2.timedout ? { status: t2.status, message: "HLS request timed-out at URL: " + t2.uri, code: Ql, xhr: t2 } : t2.aborted ? { status: t2.status, message: "HLS request aborted at URL: " + t2.uri, code: $l, xhr: t2 } : e2 ? { status: t2.status, message: "HLS request errored at URL: " + t2.uri, code: Yl, xhr: t2 } : "arraybuffer" === t2.responseType && 0 === t2.response.byteLength ? { status: t2.status, message: "Empty HLS response at URL: " + t2.uri, code: Yl, xhr: t2 } : null;
    }
    function sl(a2, s2, o2) {
      return function(e2, t2) {
        var i2 = t2.response, e2 = al(e2, t2);
        if (e2)
          return o2(e2, a2);
        if (16 !== i2.byteLength)
          return o2({ status: t2.status, message: "Invalid HLS key at URL: " + t2.uri, code: Yl, xhr: t2 }, a2);
        for (var i2 = new DataView(i2), n2 = new Uint32Array([i2.getUint32(0), i2.getUint32(4), i2.getUint32(8), i2.getUint32(12)]), r2 = 0; r2 < s2.length; r2++)
          s2[r2].bytes = n2;
        return o2(null, a2);
      };
    }
    function ol(i2, n2) {
      var e2 = Ko(i2.map.bytes);
      if ("mp4" !== e2) {
        var t2 = i2.map.resolvedUri || i2.map.uri;
        return n2({ internal: true, message: "Found unsupported " + (e2 || "unknown") + " container for initialization segment at URL: " + t2, code: Yl });
      }
      nl({ action: "probeMp4Tracks", data: i2.map.bytes, transmuxer: i2.transmuxer, callback: function(e3) {
        var t3 = e3.tracks, e3 = e3.data;
        return i2.map.bytes = e3, t3.forEach(function(e4) {
          i2.map.tracks = i2.map.tracks || {}, i2.map.tracks[e4.type] || "number" == typeof (i2.map.tracks[e4.type] = e4).id && e4.timescale && (i2.map.timescales = i2.map.timescales || {}, i2.map.timescales[e4.id] = e4.timescale);
        }), n2(null);
      } });
    }
    function ul(e2) {
      var i2 = e2.segment, n2 = e2.finishProcessingFn, r2 = e2.responseType;
      return function(e3, t2) {
        e3 = al(e3, t2);
        if (e3)
          return n2(e3, i2);
        e3 = "arraybuffer" !== r2 && t2.responseText ? function(e4) {
          for (var t3 = new Uint8Array(new ArrayBuffer(e4.length)), i3 = 0; i3 < e4.length; i3++)
            t3[i3] = e4.charCodeAt(i3);
          return t3.buffer;
        }(t2.responseText.substring(i2.lastReachedChar || 0)) : t2.response;
        return i2.stats = { bandwidth: (t2 = t2).bandwidth, bytesReceived: t2.bytesReceived || 0, roundTripTime: t2.roundTripTime || 0 }, i2.key ? i2.encryptedBytes = new Uint8Array(e3) : i2.bytes = new Uint8Array(e3), n2(null, i2);
      };
    }
    function ll(e2) {
      var i2 = e2.segment, t2 = e2.bytes, n2 = e2.trackInfoFn, r2 = e2.timingInfoFn, a2 = e2.videoSegmentTimingInfoFn, s2 = e2.audioSegmentTimingInfoFn, o2 = e2.id3Fn, u2 = e2.captionsFn, l2 = e2.isEndOfTimeline, d2 = e2.endedTimelineFn, c2 = e2.dataFn, h2 = e2.doneFn, p2 = e2.onTransmuxerLog, e2 = i2.map && i2.map.tracks || {}, f2 = Boolean(e2.audio && e2.video), m2 = r2.bind(null, i2, "audio", "start"), g2 = r2.bind(null, i2, "audio", "end"), y2 = r2.bind(null, i2, "video", "start"), v2 = r2.bind(null, i2, "video", "end");
      nl({ action: "probeTs", transmuxer: i2.transmuxer, data: t2, baseStartTime: i2.baseStartTime, callback: function(e3) {
        i2.bytes = t2 = e3.data;
        e3 = e3.result;
        e3 && (n2(i2, { hasAudio: e3.hasAudio, hasVideo: e3.hasVideo, isMuxed: f2 }), n2 = null, e3.hasAudio && !f2 && m2(e3.audioStart), e3.hasVideo && y2(e3.videoStart), y2 = m2 = null), il({ bytes: t2, transmuxer: i2.transmuxer, audioAppendStart: i2.audioAppendStart, gopsToAlignWith: i2.gopsToAlignWith, remux: f2, onData: function(e4) {
          e4.type = "combined" === e4.type ? "video" : e4.type, c2(i2, e4);
        }, onTrackInfo: function(e4) {
          n2 && (f2 && (e4.isMuxed = true), n2(i2, e4));
        }, onAudioTimingInfo: function(e4) {
          m2 && "undefined" != typeof e4.start && (m2(e4.start), m2 = null), g2 && "undefined" != typeof e4.end && g2(e4.end);
        }, onVideoTimingInfo: function(e4) {
          y2 && "undefined" != typeof e4.start && (y2(e4.start), y2 = null), v2 && "undefined" != typeof e4.end && v2(e4.end);
        }, onVideoSegmentTimingInfo: function(e4) {
          a2(e4);
        }, onAudioSegmentTimingInfo: function(e4) {
          s2(e4);
        }, onId3: function(e4, t3) {
          o2(i2, e4, t3);
        }, onCaptions: function(e4) {
          u2(i2, [e4]);
        }, isEndOfTimeline: l2, onEndedTimeline: function() {
          d2();
        }, onTransmuxerLog: p2, onDone: function(e4) {
          h2 && (e4.type = "combined" === e4.type ? "video" : e4.type, h2(null, i2, e4));
        } });
      } });
    }
    function dl(e2) {
      var i2 = e2.segment, n2 = e2.bytes, t2 = e2.trackInfoFn, r2 = e2.timingInfoFn, a2 = e2.videoSegmentTimingInfoFn, s2 = e2.audioSegmentTimingInfoFn, o2 = e2.id3Fn, u2 = e2.captionsFn, l2 = e2.isEndOfTimeline, d2 = e2.endedTimelineFn, c2 = e2.dataFn, h2 = e2.doneFn, p2 = e2.onTransmuxerLog, f2 = new Uint8Array(n2);
      if (0 < vo(f2, ["moof"]).length) {
        i2.isFmp4 = true;
        var m2 = i2.map.tracks, g2 = { isFmp4: true, hasVideo: !!m2.video, hasAudio: !!m2.audio };
        m2.audio && m2.audio.codec && "enca" !== m2.audio.codec && (g2.audioCodec = m2.audio.codec), m2.video && m2.video.codec && "encv" !== m2.video.codec && (g2.videoCodec = m2.video.codec), m2.video && m2.audio && (g2.isMuxed = true), t2(i2, g2);
        var y2 = function(e3) {
          c2(i2, { data: f2, type: g2.hasAudio && !g2.isMuxed ? "audio" : "video" }), e3 && e3.length && u2(i2, e3), h2(null, i2, {});
        };
        nl({ action: "probeMp4StartTime", timescales: i2.map.timescales, data: f2, transmuxer: i2.transmuxer, callback: function(e3) {
          var t3 = e3.data, e3 = e3.startTime;
          n2 = t3.buffer, i2.bytes = f2 = t3, g2.hasAudio && !g2.isMuxed && r2(i2, "audio", "start", e3), g2.hasVideo && r2(i2, "video", "start", e3), m2.video && t3.byteLength && i2.transmuxer ? nl({ action: "pushMp4Captions", endAction: "mp4Captions", transmuxer: i2.transmuxer, data: f2, timescales: i2.map.timescales, trackIds: [m2.video.id], callback: function(e4) {
            n2 = e4.data.buffer, i2.bytes = f2 = e4.data, e4.logs.forEach(function(e5) {
              p2(ir.mergeOptions(e5, { stream: "mp4CaptionParser" }));
            }), y2(e4.captions);
          } }) : y2();
        } });
      } else if (i2.transmuxer) {
        if ("undefined" == typeof i2.container && (i2.container = Ko(f2)), "ts" !== i2.container && "aac" !== i2.container)
          return t2(i2, { hasAudio: false, hasVideo: false }), h2(null, i2, {}), 0;
        ll({ segment: i2, bytes: n2, trackInfoFn: t2, timingInfoFn: r2, videoSegmentTimingInfoFn: a2, audioSegmentTimingInfoFn: s2, id3Fn: o2, captionsFn: u2, isEndOfTimeline: l2, endedTimelineFn: d2, dataFn: c2, doneFn: h2, onTransmuxerLog: p2 });
      } else
        h2(null, i2, {});
    }
    function cl(e2, i2) {
      var n2 = e2.id, t2 = e2.key, r2 = e2.encryptedBytes, a2 = e2.decryptionWorker, e2 = function e3(t3) {
        t3.data.source === n2 && (a2.removeEventListener("message", e3), t3 = t3.data.decrypted, i2(new Uint8Array(t3.bytes, t3.byteOffset, t3.byteLength)));
      };
      a2.addEventListener("message", e2), e2 = t2.bytes.slice ? t2.bytes.slice() : new Uint32Array(Array.prototype.slice.call(t2.bytes)), a2.postMessage(ju({ source: n2, encrypted: r2, key: e2, iv: t2.iv }), [r2.buffer, e2.buffer]);
    }
    function hl(e2) {
      var i2 = e2.activeXhrs, m2 = e2.decryptionWorker, g2 = e2.trackInfoFn, y2 = e2.timingInfoFn, v2 = e2.videoSegmentTimingInfoFn, _2 = e2.audioSegmentTimingInfoFn, b2 = e2.id3Fn, T2 = e2.captionsFn, w2 = e2.isEndOfTimeline, S2 = e2.endedTimelineFn, E2 = e2.dataFn, k2 = e2.doneFn, C2 = e2.onTransmuxerLog, n2 = 0, r2 = false;
      return function(e3, f2) {
        if (!r2) {
          if (e3)
            return r2 = true, rl(i2), k2(e3, f2);
          if ((n2 += 1) === i2.length) {
            var t2 = function() {
              if (f2.encryptedBytes)
                return t3 = (e4 = { decryptionWorker: m2, segment: f2, trackInfoFn: g2, timingInfoFn: y2, videoSegmentTimingInfoFn: v2, audioSegmentTimingInfoFn: _2, id3Fn: b2, captionsFn: T2, isEndOfTimeline: w2, endedTimelineFn: S2, dataFn: E2, doneFn: k2, onTransmuxerLog: C2 }).decryptionWorker, i3 = e4.segment, n3 = e4.trackInfoFn, r3 = e4.timingInfoFn, a2 = e4.videoSegmentTimingInfoFn, s2 = e4.audioSegmentTimingInfoFn, o2 = e4.id3Fn, u2 = e4.captionsFn, l2 = e4.isEndOfTimeline, d2 = e4.endedTimelineFn, c2 = e4.dataFn, h2 = e4.doneFn, p2 = e4.onTransmuxerLog, void cl({ id: i3.requestId, key: i3.key, encryptedBytes: i3.encryptedBytes, decryptionWorker: t3 }, function(e5) {
                  i3.bytes = e5, dl({ segment: i3, bytes: i3.bytes, trackInfoFn: n3, timingInfoFn: r3, videoSegmentTimingInfoFn: a2, audioSegmentTimingInfoFn: s2, id3Fn: o2, captionsFn: u2, isEndOfTimeline: l2, endedTimelineFn: d2, dataFn: c2, doneFn: h2, onTransmuxerLog: p2 });
                });
              var e4, t3, i3, n3, r3, a2, s2, o2, u2, l2, d2, c2, h2, p2;
              dl({ segment: f2, bytes: f2.bytes, trackInfoFn: g2, timingInfoFn: y2, videoSegmentTimingInfoFn: v2, audioSegmentTimingInfoFn: _2, id3Fn: b2, captionsFn: T2, isEndOfTimeline: w2, endedTimelineFn: S2, dataFn: E2, doneFn: k2, onTransmuxerLog: C2 });
            };
            if (f2.endOfAllRequests = Date.now(), f2.map && f2.map.encryptedBytes && !f2.map.bytes)
              return cl({ decryptionWorker: m2, id: f2.requestId + "-init", encryptedBytes: f2.map.encryptedBytes, key: f2.map.key }, function(e4) {
                f2.map.bytes = e4, ol(f2, function(e5) {
                  return e5 ? (rl(i2), k2(e5, f2)) : void t2();
                });
              });
            t2();
          }
        }
      };
    }
    function pl(e2) {
      var n2 = e2.segment, r2 = e2.progressFn;
      return e2.trackInfoFn, e2.timingInfoFn, e2.videoSegmentTimingInfoFn, e2.audioSegmentTimingInfoFn, e2.id3Fn, e2.captionsFn, e2.isEndOfTimeline, e2.endedTimelineFn, e2.dataFn, function(e3) {
        var t2, i2 = e3.target;
        if (!i2.aborted)
          return n2.stats = ir.mergeOptions(n2.stats, (i2 = (t2 = e3).target, (i2 = { bandwidth: 1 / 0, bytesReceived: 0, roundTripTime: Date.now() - i2.requestTime || 0 }).bytesReceived = t2.loaded, i2.bandwidth = Math.floor(i2.bytesReceived / i2.roundTripTime * 8 * 1e3), i2)), !n2.stats.firstBytesReceivedAt && n2.stats.bytesReceived && (n2.stats.firstBytesReceivedAt = Date.now()), r2(e3, n2);
      };
    }
    function fl(e2) {
      var t2, i2, n2, r2 = e2.xhr, a2 = e2.xhrOptions, s2 = e2.decryptionWorker, o2 = e2.segment, u2 = e2.abortFn, l2 = e2.progressFn, d2 = e2.trackInfoFn, c2 = e2.timingInfoFn, h2 = e2.videoSegmentTimingInfoFn, p2 = e2.audioSegmentTimingInfoFn, f2 = e2.id3Fn, m2 = e2.captionsFn, g2 = e2.isEndOfTimeline, y2 = e2.endedTimelineFn, v2 = e2.dataFn, _2 = e2.doneFn, e2 = e2.onTransmuxerLog, b2 = [], _2 = hl({ activeXhrs: b2, decryptionWorker: s2, trackInfoFn: d2, timingInfoFn: c2, videoSegmentTimingInfoFn: h2, audioSegmentTimingInfoFn: p2, id3Fn: f2, captionsFn: m2, isEndOfTimeline: g2, endedTimelineFn: y2, dataFn: v2, doneFn: _2, onTransmuxerLog: e2 });
      o2.key && !o2.key.bytes && (e2 = [o2.key], o2.map && !o2.map.bytes && o2.map.key && o2.map.key.resolvedUri === o2.key.resolvedUri && e2.push(o2.map.key), e2 = r2(ir.mergeOptions(a2, { uri: o2.key.resolvedUri, responseType: "arraybuffer" }), sl(o2, e2, _2)), b2.push(e2)), o2.map && !o2.map.bytes && (!o2.map.key || o2.key && o2.key.resolvedUri === o2.map.key.resolvedUri || (t2 = r2(ir.mergeOptions(a2, { uri: o2.map.key.resolvedUri, responseType: "arraybuffer" }), sl(o2, [o2.map.key], _2)), b2.push(t2)), t2 = r2(ir.mergeOptions(a2, { uri: o2.map.resolvedUri, responseType: "arraybuffer", headers: Uu(o2.map) }), (i2 = (t2 = { segment: o2, finishProcessingFn: _2 }).segment, n2 = t2.finishProcessingFn, function(e3, t3) {
        e3 = al(e3, t3);
        if (e3)
          return n2(e3, i2);
        e3 = new Uint8Array(t3.response);
        if (i2.map.key)
          return i2.map.encryptedBytes = e3, n2(null, i2);
        i2.map.bytes = e3, ol(i2, function(e4) {
          return e4 ? (e4.xhr = t3, e4.status = t3.status, n2(e4, i2)) : void n2(null, i2);
        });
      })), b2.push(t2)), a2 = ir.mergeOptions(a2, { uri: o2.part && o2.part.resolvedUri || o2.resolvedUri, responseType: "arraybuffer", headers: Uu(o2) }), (a2 = r2(a2, ul({ segment: o2, finishProcessingFn: _2, responseType: a2.responseType }))).addEventListener("progress", pl({ segment: o2, progressFn: l2, trackInfoFn: d2, timingInfoFn: c2, videoSegmentTimingInfoFn: h2, audioSegmentTimingInfoFn: p2, id3Fn: f2, captionsFn: m2, isEndOfTimeline: g2, endedTimelineFn: y2, dataFn: v2 })), b2.push(a2);
      var T2 = {};
      return b2.forEach(function(e3) {
        var t3, i3;
        e3.addEventListener("loadend", (t3 = (e3 = { loadendState: T2, abortFn: u2 }).loadendState, i3 = e3.abortFn, function(e4) {
          e4.target.aborted && i3 && !t3.calledAbortFn && (i3(), t3.calledAbortFn = true);
        }));
      }), function() {
        return rl(b2);
      };
    }
    function ml(e2, t2) {
      return t2 = t2.attributes || {}, e2 && e2.mediaGroups && e2.mediaGroups.AUDIO && t2.AUDIO && e2.mediaGroups.AUDIO[t2.AUDIO];
    }
    function gl(e2) {
      var n2 = {};
      return e2.forEach(function(e3) {
        var t2 = e3.mediaType, i2 = e3.type, e3 = e3.details;
        n2[t2] = n2[t2] || [], n2[t2].push(cr("" + i2 + e3));
      }), Object.keys(n2).forEach(function(e3) {
        return 1 < n2[e3].length ? (Jl("multiple " + e3 + " codecs found as attributes: " + n2[e3].join(", ") + ". Setting playlist codecs to null so that we wait for mux.js to probe segments for real codecs."), void (n2[e3] = null)) : void (n2[e3] = n2[e3][0]);
      }), n2;
    }
    function yl(e2) {
      var t2 = 0;
      return e2.audio && t2++, e2.video && t2++, t2;
    }
    function vl(e2, t2) {
      var i2, n2 = t2.attributes || {}, r2 = gl(function(e3) {
        e3 = e3.attributes || {};
        if (e3.CODECS)
          return hr(e3.CODECS);
      }(t2) || []);
      return ml(e2, t2) && !r2.audio && !function(e3, t3) {
        if (!ml(e3, t3))
          return true;
        var i3, t3 = t3.attributes || {}, n3 = e3.mediaGroups.AUDIO[t3.AUDIO];
        for (i3 in n3)
          if (!n3[i3].uri && !n3[i3].playlists)
            return true;
        return false;
      }(e2, t2) && (i2 = gl(function(e3, t3) {
        if (!e3.mediaGroups.AUDIO || !t3)
          return null;
        var i3, n3 = e3.mediaGroups.AUDIO[t3];
        if (!n3)
          return null;
        for (i3 in n3) {
          var r3 = n3[i3];
          if (r3.default && r3.playlists)
            return hr(r3.playlists[0].attributes.CODECS);
        }
        return null;
      }(e2, n2.AUDIO) || [])).audio && (r2.audio = i2.audio), r2;
    }
    function _l(e2) {
      if (e2 && e2.playlist) {
        var t2 = e2.playlist;
        return JSON.stringify({ id: t2.id, bandwidth: e2.bandwidth, width: e2.width, height: e2.height, codecs: t2.attributes && t2.attributes.CODECS || "" });
      }
    }
    function bl(e2, t2) {
      return (e2 = e2 && window.getComputedStyle(e2)) ? e2[t2] : "";
    }
    function Tl(e2, n2) {
      var r2 = e2.slice();
      e2.sort(function(e3, t2) {
        var i2 = n2(e3, t2);
        return 0 === i2 ? r2.indexOf(e3) - r2.indexOf(t2) : i2;
      });
    }
    function wl(e2, t2) {
      var i2, n2;
      return (i2 = (i2 = e2.attributes.BANDWIDTH ? e2.attributes.BANDWIDTH : i2) || window.Number.MAX_VALUE) - (n2 = (n2 = t2.attributes.BANDWIDTH ? t2.attributes.BANDWIDTH : n2) || window.Number.MAX_VALUE);
    }
    function Sl(e2, t2, i2, n2, r2, a2) {
      if (e2) {
        var s2 = { bandwidth: t2, width: i2, height: n2, limitRenditionByPlayerDimensions: r2 }, o2 = e2.playlists;
        Nl.isAudioOnly(e2) && (o2 = a2.getAudioTrackPlaylists_(), s2.audioOnly = true);
        var u2 = o2.map(function(e3) {
          var t3 = e3.attributes && e3.attributes.RESOLUTION && e3.attributes.RESOLUTION.width, i3 = e3.attributes && e3.attributes.RESOLUTION && e3.attributes.RESOLUTION.height, n3 = e3.attributes && e3.attributes.BANDWIDTH;
          return { bandwidth: n3 || window.Number.MAX_VALUE, width: t3, height: i3, playlist: e3 };
        });
        Tl(u2, function(e3, t3) {
          return e3.bandwidth - t3.bandwidth;
        });
        var l2 = (u2 = u2.filter(function(e3) {
          return !Nl.isIncompatible(e3.playlist);
        })).filter(function(e3) {
          return Nl.isEnabled(e3.playlist);
        }), e2 = (l2 = !l2.length ? u2.filter(function(e3) {
          return !Nl.isDisabled(e3.playlist);
        }) : l2).filter(function(e3) {
          return e3.bandwidth * Wl.BANDWIDTH_VARIANCE < t2;
        }), d2 = e2[e2.length - 1], o2 = e2.filter(function(e3) {
          return e3.bandwidth === d2.bandwidth;
        })[0];
        if (false === r2) {
          var c2 = o2 || l2[0] || u2[0];
          if (c2 && c2.playlist) {
            r2 = o2 ? "bandwidthBestRep" : "sortedPlaylistReps";
            return l2[0] && (r2 = "enabledPlaylistReps"), Zl("choosing " + _l(c2) + " using " + r2 + " with options", s2), c2.playlist;
          }
          return Zl("could not choose a playlist with options", s2), null;
        }
        c2 = e2.filter(function(e3) {
          return e3.width && e3.height;
        });
        Tl(c2, function(e3, t3) {
          return e3.width - t3.width;
        });
        var h2, p2, f2, e2 = c2.filter(function(e3) {
          return e3.width === i2 && e3.height === n2;
        }), d2 = e2[e2.length - 1], e2 = e2.filter(function(e3) {
          return e3.bandwidth === d2.bandwidth;
        })[0];
        e2 || (p2 = (h2 = c2.filter(function(e3) {
          return e3.width > i2 || e3.height > n2;
        })).filter(function(e3) {
          return e3.width === h2[0].width && e3.height === h2[0].height;
        }), d2 = p2[p2.length - 1], p2 = p2.filter(function(e3) {
          return e3.bandwidth === d2.bandwidth;
        })[0]), a2.experimentalLeastPixelDiffSelector && (m2 = c2.map(function(e3) {
          return e3.pixelDiff = Math.abs(e3.width - i2) + Math.abs(e3.height - n2), e3;
        }), Tl(m2, function(e3, t3) {
          return e3.pixelDiff === t3.pixelDiff ? t3.bandwidth - e3.bandwidth : e3.pixelDiff - t3.pixelDiff;
        }), f2 = m2[0]);
        var m2 = f2 || p2 || e2 || o2 || l2[0] || u2[0];
        if (m2 && m2.playlist) {
          u2 = "sortedPlaylistReps";
          return f2 ? u2 = "leastPixelDiffRep" : p2 ? u2 = "resolutionPlusOneRep" : e2 ? u2 = "resolutionBestRep" : o2 ? u2 = "bandwidthBestRep" : l2[0] && (u2 = "enabledPlaylistReps"), Zl("choosing " + _l(m2) + " using " + u2 + " with options", s2), m2.playlist;
        }
        return Zl("could not choose a playlist with options", s2), null;
      }
    }
    function El(e2) {
      var t2 = e2.inbandTextTracks, i2 = e2.metadataArray, r2 = e2.timestampOffset, n2 = e2.videoDuration;
      if (i2) {
        var a2 = window.WebKitDataCue || window.VTTCue, s2 = t2.metadataTrack_;
        if (s2 && (i2.forEach(function(e3) {
          var n3 = e3.cueTime + r2;
          !("number" != typeof n3 || window.isNaN(n3) || n3 < 0) && n3 < 1 / 0 && e3.frames.forEach(function(e4) {
            var t3, i3 = new a2(n3, n3, e4.value || e4.url || e4.data || "");
            i3.frame = e4, i3.value = e4, t3 = i3, Object.defineProperties(t3.frame, { id: { get: function() {
              return ir.log.warn("cue.frame.id is deprecated. Use cue.value.key instead."), t3.value.key;
            } }, value: { get: function() {
              return ir.log.warn("cue.frame.value is deprecated. Use cue.value.data instead."), t3.value.data;
            } }, privateData: { get: function() {
              return ir.log.warn("cue.frame.privateData is deprecated. Use cue.value.data instead."), t3.value.data;
            } } }), s2.addCue(i3);
          });
        }), s2.cues && s2.cues.length)) {
          for (var o2 = s2.cues, u2 = [], l2 = 0; l2 < o2.length; l2++)
            o2[l2] && u2.push(o2[l2]);
          var d2 = u2.reduce(function(e3, t3) {
            var i3 = e3[t3.startTime] || [];
            return i3.push(t3), e3[t3.startTime] = i3, e3;
          }, {}), c2 = Object.keys(d2).sort(function(e3, t3) {
            return Number(e3) - Number(t3);
          });
          c2.forEach(function(e3, t3) {
            var e3 = d2[e3], i3 = Number(c2[t3 + 1]) || n2;
            e3.forEach(function(e4) {
              e4.endTime = i3;
            });
          });
        }
      }
    }
    function kl(e2, t2, i2) {
      var n2, r2;
      if (i2 && i2.cues)
        for (n2 = i2.cues.length; n2--; )
          (r2 = i2.cues[n2]).startTime >= e2 && r2.endTime <= t2 && i2.removeCue(r2);
    }
    function Cl(e2) {
      return "number" == typeof e2 && isFinite(e2);
    }
    function Il(e2) {
      var t2 = e2.startOfSegment, i2 = e2.duration, n2 = e2.segment, r2 = e2.part, a2 = e2.playlist, s2 = a2.mediaSequence, o2 = a2.id, u2 = a2.segments, l2 = e2.mediaIndex, d2 = e2.partIndex, c2 = e2.timeline, h2 = (void 0 === u2 ? [] : u2).length - 1, p2 = "mediaIndex/partIndex increment";
      return e2.getMediaInfoForTime ? p2 = "getMediaInfoForTime (" + e2.getMediaInfoForTime + ")" : e2.isSyncRequest && (p2 = "getSyncSegmentCandidate (isSyncRequest)"), e2.independent && (p2 += " with independent " + e2.independent), a2 = "number" == typeof d2, u2 = e2.segment.uri ? "segment" : "pre-segment", e2 = a2 ? du({ preloadSegment: n2 }) - 1 : 0, u2 + " [" + (s2 + l2) + "/" + (s2 + h2) + "]" + (a2 ? " part [" + d2 + "/" + e2 + "]" : "") + " segment start/end [" + n2.start + " => " + n2.end + "]" + (a2 ? " part start/end [" + r2.start + " => " + r2.end + "]" : "") + " startOfSegment [" + t2 + "] duration [" + i2 + "] timeline [" + c2 + "] selected by [" + p2 + "] playlist [" + o2 + "]";
    }
    function xl(e2) {
      return e2 + "TimingInfo";
    }
    function Al(e2) {
      var t2 = e2.timelineChangeController, i2 = e2.currentTimeline, n2 = e2.segmentTimeline, r2 = e2.loaderType, e2 = e2.audioDisabled;
      if (i2 !== n2) {
        if ("audio" === r2) {
          i2 = t2.lastTimelineChange({ type: "main" });
          return !i2 || i2.to !== n2;
        }
        if ("main" === r2 && e2) {
          t2 = t2.pendingTimelineChange({ type: "audio" });
          return t2 && t2.to === n2 ? false : true;
        }
      }
    }
    function Pl(e2) {
      var t2 = e2.segmentDuration, e2 = e2.maxDuration;
      return !!t2 && Math.round(t2) > e2 + Rl;
    }
    function Ll(e2, t2) {
      if ("hls" !== t2)
        return null;
      var n2, r2, i2 = (n2 = { audioTimingInfo: e2.audioTimingInfo, videoTimingInfo: e2.videoTimingInfo }, r2 = 0, ["video", "audio"].forEach(function(e3) {
        var t3, i3 = n2[e3 + "TimingInfo"];
        i3 && (e3 = i3.start, i3 = i3.end, "bigint" == typeof e3 || "bigint" == typeof i3 ? t3 = window.BigInt(i3) - window.BigInt(e3) : "number" == typeof e3 && "number" == typeof i3 && (t3 = i3 - e3), "undefined" != typeof t3 && r2 < t3 && (r2 = t3));
      }), r2 = "bigint" == typeof r2 && r2 < Number.MAX_SAFE_INTEGER ? Number(r2) : r2);
      if (!i2)
        return null;
      var a2 = e2.playlist.targetDuration, s2 = Pl({ segmentDuration: i2, maxDuration: 2 * a2 }), t2 = Pl({ segmentDuration: i2, maxDuration: a2 }), a2 = "Segment with index " + e2.mediaIndex + " from playlist " + e2.playlist.id + " has a duration of " + i2 + " when the reported duration is " + e2.duration + " and the target duration is " + a2 + ". For HLS content, a duration in excess of the target duration may result in playback issues. See the HLS specification section on EXT-X-TARGETDURATION for more details: https://tools.ietf.org/html/draft-pantos-http-live-streaming-23#section-4.3.3.1";
      return s2 || t2 ? { severity: s2 ? "warn" : "info", message: a2 } : null;
    }
    var Ol = function(e2) {
      return -1 !== Function.toString.call(e2).indexOf("[native code]");
    }, W = m(function(t2) {
      function n2(e2) {
        var i2 = "function" == typeof Map ? /* @__PURE__ */ new Map() : void 0;
        return t2.exports = n2 = function(e3) {
          if (null === e3 || !Ol(e3))
            return e3;
          if ("function" != typeof e3)
            throw new TypeError("Super expression must either be null or a function");
          if ("undefined" != typeof i2) {
            if (i2.has(e3))
              return i2.get(e3);
            i2.set(e3, t3);
          }
          function t3() {
            return Xn(e3, arguments, $o(this).constructor);
          }
          return t3.prototype = Object.create(e3.prototype, { constructor: { value: t3, enumerable: false, writable: true, configurable: true } }), jn(t3, e3);
        }, n2(e2);
      }
      t2.exports = n2;
    }), Dl = function(e2, t2) {
      if (/^[a-z]+:/i.test(t2))
        return t2;
      /^data:/.test(e2) && (e2 = window.location && window.location.href || "");
      var i2 = "function" == typeof window.URL, n2 = /^\/\//.test(e2), r2 = !window.location && !/\/\//i.test(e2);
      if (i2 ? e2 = new window.URL(e2, window.location || rr) : /\/\//i.test(e2) || (e2 = nr.buildAbsoluteURL(window.location && window.location.href || "", e2)), i2) {
        i2 = new URL(t2, e2);
        return r2 ? i2.href.slice(rr.length) : n2 ? i2.href.slice(i2.protocol.length) : i2.href;
      }
      return nr.buildAbsoluteURL(e2, t2);
    }, Rl = 1 / 30, Ml = ir.createTimeRange, Nl = { liveEdgeDelay: cu, duration: pu, seekable: function(e2, t2, i2) {
      var n2 = t2 || 0, i2 = mu(e2, t2, true, i2);
      return null === i2 ? Ml() : Ml(n2, i2);
    }, getMediaInfoForTime: function(e2) {
      for (var t2 = e2.playlist, i2 = e2.currentTime, n2 = e2.startingSegmentIndex, r2 = e2.startingPartIndex, a2 = e2.startTime, s2 = e2.experimentalExactManifestTimings, o2 = i2 - a2, u2 = uu(t2), l2 = 0, d2 = 0; d2 < u2.length; d2++) {
        var c2 = u2[d2];
        if (n2 === c2.segmentIndex && ("number" != typeof r2 || "number" != typeof c2.partIndex || r2 === c2.partIndex)) {
          l2 = d2;
          break;
        }
      }
      if (o2 < 0) {
        if (0 < l2)
          for (var h2 = l2 - 1; 0 <= h2; h2--) {
            var p2 = u2[h2];
            if (o2 += p2.duration, s2) {
              if (o2 < 0)
                continue;
            } else if (o2 + Rl <= 0)
              continue;
            return { partIndex: p2.partIndex, segmentIndex: p2.segmentIndex, startTime: a2 - fu({ defaultDuration: t2.targetDuration, durationList: u2, startIndex: l2, endIndex: h2 }) };
          }
        return { partIndex: u2[0] && u2[0].partIndex || null, segmentIndex: u2[0] && u2[0].segmentIndex || 0, startTime: i2 };
      }
      if (l2 < 0) {
        for (var f2 = l2; f2 < 0; f2++)
          if ((o2 -= t2.targetDuration) < 0)
            return { partIndex: u2[0] && u2[0].partIndex || null, segmentIndex: u2[0] && u2[0].segmentIndex || 0, startTime: i2 };
        l2 = 0;
      }
      for (var m2 = l2; m2 < u2.length; m2++) {
        var g2 = u2[m2];
        if (o2 -= g2.duration, s2) {
          if (0 < o2)
            continue;
        } else if (0 <= o2 - Rl)
          continue;
        return { partIndex: g2.partIndex, segmentIndex: g2.segmentIndex, startTime: a2 + fu({ defaultDuration: t2.targetDuration, durationList: u2, startIndex: l2, endIndex: m2 }) };
      }
      return { segmentIndex: u2[u2.length - 1].segmentIndex, partIndex: u2[u2.length - 1].partIndex, startTime: i2 };
    }, isEnabled: vu, isDisabled: function(e2) {
      return e2.disabled;
    }, isBlacklisted: gu, isIncompatible: yu, playlistEnd: mu, isAes: function(e2) {
      for (var t2 = 0; t2 < e2.segments.length; t2++)
        if (e2.segments[t2].key)
          return true;
      return false;
    }, hasAttribute: _u, estimateSegmentRequestTime: function(e2, t2, i2, n2) {
      return _u("BANDWIDTH", i2) ? (e2 * i2.attributes.BANDWIDTH - 8 * (n2 = void 0 === n2 ? 0 : n2)) / t2 : NaN;
    }, isLowestEnabledRendition: bu, isAudioOnly: Su, playlistMatch: Tu, segmentDurationWithParts: ou }, Ul = ir.log, Bl = ir.mergeOptions, Qr = ir.EventTarget, Fl = function(a2) {
      function e2(e3, t3, i2) {
        var n2;
        if (void 0 === i2 && (i2 = {}), n2 = a2.call(this) || this, !e3)
          throw new Error("A non-empty playlist URL or object is required");
        n2.logger_ = Zo("PlaylistLoader");
        var r2 = i2.withCredentials, r2 = void 0 !== r2 && r2, i2 = i2.handleManifestRedirects, i2 = void 0 !== i2 && i2;
        n2.src = e3, n2.vhs_ = t3, n2.withCredentials = r2, n2.handleManifestRedirects = i2;
        t3 = t3.options_;
        return n2.customTagParsers = t3 && t3.customTagParsers || [], n2.customTagMappers = t3 && t3.customTagMappers || [], n2.experimentalLLHLS = t3 && t3.experimentalLLHLS || false, ir.browser.IE_VERSION && (n2.experimentalLLHLS = false), n2.state = "HAVE_NOTHING", n2.handleMediaupdatetimeout_ = n2.handleMediaupdatetimeout_.bind(ft(n2)), n2.on("mediaupdatetimeout", n2.handleMediaupdatetimeout_), n2;
      }
      mt(e2, a2);
      var t2 = e2.prototype;
      return t2.handleMediaupdatetimeout_ = function() {
        var e3, t3, i2 = this;
        "HAVE_METADATA" === this.state && (e3 = this.media(), t3 = Dl(this.master.uri, e3.uri), this.experimentalLLHLS && (t3 = function(e4, t4) {
          if (t4.endList || !t4.serverControl)
            return e4;
          var i3, n2, r2, a3, s2 = {};
          return t4.serverControl.canBlockReload && (r2 = t4.preloadSegment, i3 = t4.mediaSequence + t4.segments.length, r2 && (n2 = r2.parts || [], -1 < (r2 = du(t4) - 1) && r2 != n2.length - 1 && (s2._HLS_part = r2), (-1 < r2 || n2.length) && i3--), s2._HLS_msn = i3), t4.serverControl && t4.serverControl.canSkipUntil && (s2._HLS_skip = t4.serverControl.canSkipDateranges ? "v2" : "YES"), Object.keys(s2).length && (a3 = new window.URL(e4), ["_HLS_skip", "_HLS_msn", "_HLS_part"].forEach(function(e5) {
            s2.hasOwnProperty(e5) && a3.searchParams.set(e5, s2[e5]);
          }), e4 = a3.toString()), e4;
        }(t3, e3)), this.state = "HAVE_CURRENT_METADATA", this.request = this.vhs_.xhr({ uri: t3, withCredentials: this.withCredentials }, function(e4, t4) {
          if (i2.request)
            return e4 ? i2.playlistRequestError(i2.request, i2.media(), "HAVE_METADATA") : void i2.haveMetadata({ playlistString: i2.request.responseText, url: i2.media().uri, id: i2.media().id });
        }));
      }, t2.playlistRequestError = function(e3, t3, i2) {
        var n2 = t3.uri, t3 = t3.id;
        this.request = null, i2 && (this.state = i2), this.error = { playlist: this.master.playlists[t3], status: e3.status, message: "HLS playlist request error at URL: " + n2 + ".", responseText: e3.responseText, code: 500 <= e3.status ? 4 : 2 }, this.trigger("error");
      }, t2.parseManifest_ = function(e3) {
        var t3 = this, i2 = e3.url;
        return function(e4) {
          var t4 = e4.onwarn, i3 = e4.oninfo, n2 = e4.manifestString, r2 = e4.customTagParsers, a3 = void 0 === r2 ? [] : r2, r2 = e4.customTagMappers, r2 = void 0 === r2 ? [] : r2, e4 = e4.experimentalLLHLS, s2 = new Ir();
          t4 && s2.on("warn", t4), i3 && s2.on("info", i3), a3.forEach(function(e5) {
            return s2.addParser(e5);
          }), r2.forEach(function(e5) {
            return s2.addTagMapper(e5);
          }), s2.push(n2), s2.end();
          var o2 = s2.manifest;
          e4 || (["preloadSegment", "skip", "serverControl", "renditionReports", "partInf", "partTargetDuration"].forEach(function(e5) {
            o2.hasOwnProperty(e5) && delete o2[e5];
          }), o2.segments && o2.segments.forEach(function(t5) {
            ["parts", "preloadHints"].forEach(function(e5) {
              t5.hasOwnProperty(e5) && delete t5[e5];
            });
          })), o2.targetDuration || (u2 = 10, o2.segments && o2.segments.length && (u2 = o2.segments.reduce(function(e5, t5) {
            return Math.max(e5, t5.duration);
          }, 0)), t4 && t4("manifest has no targetDuration defaulting to " + u2), o2.targetDuration = u2);
          var u2 = lu(o2);
          return u2.length && !o2.partTargetDuration && (u2 = u2.reduce(function(e5, t5) {
            return Math.max(e5, t5.duration);
          }, 0), t4 && (t4("manifest has no partTargetDuration defaulting to " + u2), Ul.error("LL-HLS manifest has parts but lacks required #EXT-X-PART-INF:PART-TARGET value. See https://datatracker.ietf.org/doc/html/draft-pantos-hls-rfc8216bis-09#section-4.4.3.7. Playback is not guaranteed.")), o2.partTargetDuration = u2), o2;
        }({ onwarn: function(e4) {
          e4 = e4.message;
          return t3.logger_("m3u8-parser warn for " + i2 + ": " + e4);
        }, oninfo: function(e4) {
          e4 = e4.message;
          return t3.logger_("m3u8-parser info for " + i2 + ": " + e4);
        }, manifestString: e3.manifestString, customTagParsers: this.customTagParsers, customTagMappers: this.customTagMappers, experimentalLLHLS: this.experimentalLLHLS });
      }, t2.haveMetadata = function(e3) {
        var t3 = e3.playlistString, i2 = e3.playlistObject, n2 = e3.url, e3 = e3.id;
        this.request = null, this.state = "HAVE_METADATA";
        t3 = i2 || this.parseManifest_({ url: n2, manifestString: t3 });
        t3.lastRequest = Date.now(), Iu({ playlist: t3, uri: n2, id: e3 });
        n2 = Du(this.master, t3);
        this.targetDuration = t3.partTargetDuration || t3.targetDuration, this.pendingMedia_ = null, n2 ? (this.master = n2, this.media_ = this.master.playlists[e3]) : this.trigger("playlistunchanged"), this.updateMediaUpdateTimeout_(Ru(this.media(), !!n2)), this.trigger("loadedplaylist");
      }, t2.dispose = function() {
        this.trigger("dispose"), this.stopRequest(), window.clearTimeout(this.mediaUpdateTimeout), window.clearTimeout(this.finalRenditionTimeout), this.off();
      }, t2.stopRequest = function() {
        var e3;
        this.request && (e3 = this.request, this.request = null, e3.onreadystatechange = null, e3.abort());
      }, t2.media = function(i2, e3) {
        var n2 = this;
        if (!i2)
          return this.media_;
        if ("HAVE_NOTHING" === this.state)
          throw new Error("Cannot switch media playlist from " + this.state);
        if ("string" == typeof i2) {
          if (!this.master.playlists[i2])
            throw new Error("Unknown playlist URI: " + i2);
          i2 = this.master.playlists[i2];
        }
        if (window.clearTimeout(this.finalRenditionTimeout), e3) {
          var t3 = (i2.partTargetDuration || i2.targetDuration) / 2 * 1e3 || 5e3;
          this.finalRenditionTimeout = window.setTimeout(this.media.bind(this, i2, false), t3);
        } else {
          var r2 = this.state, e3 = !this.media_ || i2.id !== this.media_.id, t3 = this.master.playlists[i2.id];
          if (t3 && t3.endList || i2.endList && i2.segments.length)
            return this.request && (this.request.onreadystatechange = null, this.request.abort(), this.request = null), this.state = "HAVE_METADATA", this.media_ = i2, void (e3 && (this.trigger("mediachanging"), "HAVE_MASTER" === r2 ? this.trigger("loadedmetadata") : this.trigger("mediachange")));
          if (this.updateMediaUpdateTimeout_(Ru(i2, true)), e3) {
            if (this.state = "SWITCHING_MEDIA", this.request) {
              if (i2.resolvedUri === this.request.url)
                return;
              this.request.onreadystatechange = null, this.request.abort(), this.request = null;
            }
            this.media_ && this.trigger("mediachanging"), this.pendingMedia_ = i2, this.request = this.vhs_.xhr({ uri: i2.resolvedUri, withCredentials: this.withCredentials }, function(e4, t4) {
              if (n2.request) {
                if (i2.lastRequest = Date.now(), i2.resolvedUri = Jo(n2.handleManifestRedirects, i2.resolvedUri, t4), e4)
                  return n2.playlistRequestError(n2.request, i2, r2);
                n2.haveMetadata({ playlistString: t4.responseText, url: i2.uri, id: i2.id }), "HAVE_MASTER" === r2 ? n2.trigger("loadedmetadata") : n2.trigger("mediachange");
              }
            });
          }
        }
      }, t2.pause = function() {
        this.mediaUpdateTimeout && (window.clearTimeout(this.mediaUpdateTimeout), this.mediaUpdateTimeout = null), this.stopRequest(), "HAVE_NOTHING" === this.state && (this.started = false), "SWITCHING_MEDIA" === this.state ? this.media_ ? this.state = "HAVE_METADATA" : this.state = "HAVE_MASTER" : "HAVE_CURRENT_METADATA" === this.state && (this.state = "HAVE_METADATA");
      }, t2.load = function(e3) {
        var t3 = this;
        this.mediaUpdateTimeout && (window.clearTimeout(this.mediaUpdateTimeout), this.mediaUpdateTimeout = null);
        var i2 = this.media();
        e3 ? (e3 = i2 ? (i2.partTargetDuration || i2.targetDuration) / 2 * 1e3 : 5e3, this.mediaUpdateTimeout = window.setTimeout(function() {
          t3.mediaUpdateTimeout = null, t3.load();
        }, e3)) : this.started ? i2 && !i2.endList ? this.trigger("mediaupdatetimeout") : this.trigger("loadedplaylist") : this.start();
      }, t2.updateMediaUpdateTimeout_ = function(e3) {
        var t3 = this;
        this.mediaUpdateTimeout && (window.clearTimeout(this.mediaUpdateTimeout), this.mediaUpdateTimeout = null), this.media() && !this.media().endList && (this.mediaUpdateTimeout = window.setTimeout(function() {
          t3.mediaUpdateTimeout = null, t3.trigger("mediaupdatetimeout"), t3.updateMediaUpdateTimeout_(e3);
        }, e3));
      }, t2.start = function() {
        var i2 = this;
        if (this.started = true, "object" == typeof this.src)
          return this.src.uri || (this.src.uri = window.location.href), this.src.resolvedUri = this.src.uri, void setTimeout(function() {
            i2.setupInitialPlaylist(i2.src);
          }, 0);
        this.request = this.vhs_.xhr({ uri: this.src, withCredentials: this.withCredentials }, function(e3, t3) {
          if (i2.request) {
            if (i2.request = null, e3)
              return i2.error = { status: t3.status, message: "HLS playlist request error at URL: " + i2.src + ".", responseText: t3.responseText, code: 2 }, "HAVE_NOTHING" === i2.state && (i2.started = false), i2.trigger("error");
            i2.src = Jo(i2.handleManifestRedirects, i2.src, t3);
            t3 = i2.parseManifest_({ manifestString: t3.responseText, url: i2.src });
            i2.setupInitialPlaylist(t3);
          }
        });
      }, t2.srcUri = function() {
        return "string" == typeof this.src ? this.src : this.src.uri;
      }, t2.setupInitialPlaylist = function(e3) {
        if (this.state = "HAVE_MASTER", e3.playlists)
          return this.master = e3, xu(this.master, this.srcUri()), e3.playlists.forEach(function(t4) {
            t4.segments = Lu(t4), t4.segments.forEach(function(e4) {
              Pu(e4, t4.resolvedUri);
            });
          }), this.trigger("loadedplaylist"), void (this.request || this.media(this.master.playlists[0]));
        var t3, i2, n2, r2 = this.srcUri() || window.location.href;
        this.master = (i2 = Eu(0, t3 = r2), (n2 = { mediaGroups: { AUDIO: {}, VIDEO: {}, "CLOSED-CAPTIONS": {}, SUBTITLES: {} }, uri: window.location.href, resolvedUri: window.location.href, playlists: [{ uri: t3, id: i2, resolvedUri: t3, attributes: {} }] }).playlists[i2] = n2.playlists[0], n2.playlists[t3] = n2.playlists[0], n2), this.haveMetadata({ playlistObject: e3, url: r2, id: this.master.playlists[0].id }), this.trigger("loadedmetadata");
      }, e2;
    }(Qr), jl = ir.xhr, Hl = ir.mergeOptions, U = Object.freeze({ __proto__: null, createTransferableMessage: ju, initSegmentId: Hu, segmentKeyId: Vu, hexDump: qu, tagDump: function(e2) {
      e2 = e2.bytes;
      return qu(e2);
    }, textRanges: function(e2) {
      for (var t2, i2, n2 = "", r2 = 0; r2 < e2.length; r2++)
        n2 += (i2 = r2, (t2 = e2).start(i2) + "-" + t2.end(i2) + " ");
      return n2;
    } }), zt = ir.EventTarget, Vl = ir.mergeOptions, ql = function(a2) {
      function e2(e3, t3, i2, n2) {
        var r2;
        void 0 === i2 && (i2 = {}), (r2 = a2.call(this) || this).masterPlaylistLoader_ = n2 || ft(r2), n2 || (r2.isMaster_ = true);
        n2 = i2.withCredentials, n2 = void 0 !== n2 && n2, i2 = i2.handleManifestRedirects, i2 = void 0 !== i2 && i2;
        if (r2.vhs_ = t3, r2.withCredentials = n2, r2.handleManifestRedirects = i2, !e3)
          throw new Error("A non-empty playlist URL or object is required");
        return r2.on("minimumUpdatePeriod", function() {
          r2.refreshXml_();
        }), r2.on("mediaupdatetimeout", function() {
          r2.refreshMedia_(r2.media().id);
        }), r2.state = "HAVE_NOTHING", r2.loadedPlaylists_ = {}, r2.logger_ = Zo("DashPlaylistLoader"), r2.isMaster_ ? (r2.masterPlaylistLoader_.srcUrl = e3, r2.masterPlaylistLoader_.sidxMapping_ = {}) : r2.childPlaylist_ = e3, r2;
      }
      mt(e2, a2);
      var t2 = e2.prototype;
      return t2.requestErrored_ = function(e3, t3, i2) {
        return !this.request || (this.request = null, e3 ? (this.error = "object" != typeof e3 || e3 instanceof Error ? { status: t3.status, message: "DASH request error at URL: " + t3.uri, response: t3.response, code: 2 } : e3, i2 && (this.state = i2), this.trigger("error"), true) : void 0);
      }, t2.addSidxSegments_ = function(a3, n2, r2) {
        var s2, o2, u2 = this, l2 = a3.sidx && qs(a3.sidx);
        a3.sidx && l2 && !this.masterPlaylistLoader_.sidxMapping_[l2] ? (s2 = Jo(this.handleManifestRedirects, a3.sidx.resolvedUri), o2 = function(e3, t3) {
          if (!u2.requestErrored_(e3, t3, n2)) {
            var i2, e3 = u2.masterPlaylistLoader_.sidxMapping_;
            try {
              i2 = Bo(_r(t3.response).subarray(8));
            } catch (e4) {
              return void u2.requestErrored_(e4, t3, n2);
            }
            return e3[l2] = { sidxInfo: a3.sidx, sidx: i2 }, Bs(a3, i2, a3.sidx.resolvedUri), r2(true);
          }
        }, this.request = Xu(s2, this.vhs_.xhr, function(e3, t3, i2, n3) {
          if (e3)
            return o2(e3, t3);
          if (!i2 || "mp4" !== i2)
            return o2({ status: t3.status, message: "Unsupported " + (i2 || "unknown") + " container type for sidx segment at URL: " + s2, response: "", playlist: a3, internal: true, blacklistDuration: 1 / 0, code: 2 }, t3);
          var r3 = a3.sidx.byterange, i2 = r3.offset, r3 = r3.length;
          if (n3.length >= r3 + i2)
            return o2(e3, { response: n3.subarray(i2, i2 + r3), status: t3.status, uri: t3.uri });
          u2.request = u2.vhs_.xhr({ uri: s2, responseType: "arraybuffer", headers: Uu({ byterange: a3.sidx.byterange }) }, o2);
        })) : this.mediaRequest_ = window.setTimeout(function() {
          return r2(false);
        }, 0);
      }, t2.dispose = function() {
        this.trigger("dispose"), this.stopRequest(), this.loadedPlaylists_ = {}, window.clearTimeout(this.minimumUpdatePeriodTimeout_), window.clearTimeout(this.mediaRequest_), window.clearTimeout(this.mediaUpdateTimeout), this.mediaUpdateTimeout = null, this.mediaRequest_ = null, this.minimumUpdatePeriodTimeout_ = null, this.masterPlaylistLoader_.createMupOnMedia_ && (this.off("loadedmetadata", this.masterPlaylistLoader_.createMupOnMedia_), this.masterPlaylistLoader_.createMupOnMedia_ = null), this.off();
      }, t2.hasPendingRequest = function() {
        return this.request || this.mediaRequest_;
      }, t2.stopRequest = function() {
        var e3;
        this.request && (e3 = this.request, this.request = null, e3.onreadystatechange = null, e3.abort());
      }, t2.media = function(t3) {
        var i2 = this;
        if (!t3)
          return this.media_;
        if ("HAVE_NOTHING" === this.state)
          throw new Error("Cannot switch media playlist from " + this.state);
        var n2 = this.state;
        if ("string" == typeof t3) {
          if (!this.masterPlaylistLoader_.master.playlists[t3])
            throw new Error("Unknown playlist URI: " + t3);
          t3 = this.masterPlaylistLoader_.master.playlists[t3];
        }
        var e3 = !this.media_ || t3.id !== this.media_.id;
        if (e3 && this.loadedPlaylists_[t3.id] && this.loadedPlaylists_[t3.id].endList)
          return this.state = "HAVE_METADATA", this.media_ = t3, void (e3 && (this.trigger("mediachanging"), this.trigger("mediachange")));
        e3 && (this.media_ && this.trigger("mediachanging"), this.addSidxSegments_(t3, n2, function(e4) {
          i2.haveMetadata({ startingState: n2, playlist: t3 });
        }));
      }, t2.haveMetadata = function(e3) {
        var t3 = e3.startingState, e3 = e3.playlist;
        this.state = "HAVE_METADATA", this.loadedPlaylists_[e3.id] = e3, this.mediaRequest_ = null, this.refreshMedia_(e3.id), "HAVE_MASTER" === t3 ? this.trigger("loadedmetadata") : this.trigger("mediachange");
      }, t2.pause = function() {
        this.masterPlaylistLoader_.createMupOnMedia_ && (this.off("loadedmetadata", this.masterPlaylistLoader_.createMupOnMedia_), this.masterPlaylistLoader_.createMupOnMedia_ = null), this.stopRequest(), window.clearTimeout(this.mediaUpdateTimeout), this.mediaUpdateTimeout = null, this.isMaster_ && (window.clearTimeout(this.masterPlaylistLoader_.minimumUpdatePeriodTimeout_), this.masterPlaylistLoader_.minimumUpdatePeriodTimeout_ = null), "HAVE_NOTHING" === this.state && (this.started = false);
      }, t2.load = function(e3) {
        var t3 = this;
        window.clearTimeout(this.mediaUpdateTimeout), this.mediaUpdateTimeout = null;
        var i2 = this.media();
        e3 ? (e3 = i2 ? i2.targetDuration / 2 * 1e3 : 5e3, this.mediaUpdateTimeout = window.setTimeout(function() {
          return t3.load();
        }, e3)) : this.started ? i2 && !i2.endList ? (this.isMaster_ && !this.minimumUpdatePeriodTimeout_ && (this.trigger("minimumUpdatePeriod"), this.updateMinimumUpdatePeriodTimeout_()), this.trigger("mediaupdatetimeout")) : this.trigger("loadedplaylist") : this.start();
      }, t2.start = function() {
        var i2 = this;
        this.started = true, this.isMaster_ ? this.requestMaster_(function(e3, t3) {
          i2.haveMaster_(), i2.hasPendingRequest() || i2.media_ || i2.media(i2.masterPlaylistLoader_.master.playlists[0]);
        }) : this.mediaRequest_ = window.setTimeout(function() {
          return i2.haveMaster_();
        }, 0);
      }, t2.requestMaster_ = function(n2) {
        var r2 = this;
        this.request = this.vhs_.xhr({ uri: this.masterPlaylistLoader_.srcUrl, withCredentials: this.withCredentials }, function(e3, t3) {
          if (!r2.requestErrored_(e3, t3)) {
            var i2 = t3.responseText !== r2.masterPlaylistLoader_.masterXml_;
            return r2.masterPlaylistLoader_.masterXml_ = t3.responseText, t3.responseHeaders && t3.responseHeaders.date ? r2.masterLoaded_ = Date.parse(t3.responseHeaders.date) : r2.masterLoaded_ = Date.now(), r2.masterPlaylistLoader_.srcUrl = Jo(r2.handleManifestRedirects, r2.masterPlaylistLoader_.srcUrl, t3), i2 ? (r2.handleMaster_(), void r2.syncClientServerClock_(function() {
              return n2(t3, i2);
            })) : n2(t3, i2);
          }
          "HAVE_NOTHING" === r2.state && (r2.started = false);
        });
      }, t2.syncClientServerClock_ = function(i2) {
        var n2 = this, r2 = mo(this.masterPlaylistLoader_.masterXml_);
        return null === r2 ? (this.masterPlaylistLoader_.clientOffset_ = this.masterLoaded_ - Date.now(), i2()) : "DIRECT" === r2.method ? (this.masterPlaylistLoader_.clientOffset_ = r2.value - Date.now(), i2()) : void (this.request = this.vhs_.xhr({ uri: Dl(this.masterPlaylistLoader_.srcUrl, r2.value), method: r2.method, withCredentials: this.withCredentials }, function(e3, t3) {
          if (n2.request) {
            if (e3)
              return n2.masterPlaylistLoader_.clientOffset_ = n2.masterLoaded_ - Date.now(), i2();
            t3 = "HEAD" === r2.method ? t3.responseHeaders && t3.responseHeaders.date ? Date.parse(t3.responseHeaders.date) : n2.masterLoaded_ : Date.parse(t3.responseText);
            n2.masterPlaylistLoader_.clientOffset_ = t3 - Date.now(), i2();
          }
        }));
      }, t2.haveMaster_ = function() {
        this.state = "HAVE_MASTER", this.isMaster_ ? this.trigger("loadedplaylist") : this.media_ || this.media(this.childPlaylist_);
      }, t2.handleMaster_ = function() {
        this.mediaRequest_ = null;
        var e3, t3, i2, n2, r2 = this.masterPlaylistLoader_.master, t3 = (a3 = { masterXml: this.masterPlaylistLoader_.masterXml_, srcUrl: this.masterPlaylistLoader_.srcUrl, clientOffset: this.masterPlaylistLoader_.clientOffset_, sidxMapping: this.masterPlaylistLoader_.sidxMapping_, previousManifest: r2 }, e3 = a3.masterXml, t3 = a3.srcUrl, i2 = a3.clientOffset, n2 = a3.sidxMapping, a3 = a3.previousManifest, a3 = fo(e3, { manifestUri: t3, clientOffset: i2, sidxMapping: n2, previousManifest: a3 }), xu(a3, t3, Yu), a3);
        r2 && (t3 = Qu(r2, t3, this.masterPlaylistLoader_.sidxMapping_)), this.masterPlaylistLoader_.master = t3 || r2;
        var a3 = this.masterPlaylistLoader_.master.locations && this.masterPlaylistLoader_.master.locations[0];
        return a3 && a3 !== this.masterPlaylistLoader_.srcUrl && (this.masterPlaylistLoader_.srcUrl = a3), (!r2 || t3 && t3.minimumUpdatePeriod !== r2.minimumUpdatePeriod) && this.updateMinimumUpdatePeriodTimeout_(), Boolean(t3);
      }, t2.updateMinimumUpdatePeriodTimeout_ = function() {
        var e3 = this.masterPlaylistLoader_;
        e3.createMupOnMedia_ && (e3.off("loadedmetadata", e3.createMupOnMedia_), e3.createMupOnMedia_ = null), e3.minimumUpdatePeriodTimeout_ && (window.clearTimeout(e3.minimumUpdatePeriodTimeout_), e3.minimumUpdatePeriodTimeout_ = null);
        var t3 = e3.master && e3.master.minimumUpdatePeriod;
        0 === t3 && (e3.media() ? t3 = 1e3 * e3.media().targetDuration : (e3.createMupOnMedia_ = e3.updateMinimumUpdatePeriodTimeout_, e3.one("loadedmetadata", e3.createMupOnMedia_))), "number" != typeof t3 || t3 <= 0 ? t3 < 0 && this.logger_("found invalid minimumUpdatePeriod of " + t3 + ", not setting a timeout") : this.createMUPTimeout_(t3);
      }, t2.createMUPTimeout_ = function(e3) {
        var t3 = this.masterPlaylistLoader_;
        t3.minimumUpdatePeriodTimeout_ = window.setTimeout(function() {
          t3.minimumUpdatePeriodTimeout_ = null, t3.trigger("minimumUpdatePeriod"), t3.createMUPTimeout_(e3);
        }, e3);
      }, t2.refreshXml_ = function() {
        var i2 = this;
        this.requestMaster_(function(e3, t3) {
          var r2, a3;
          t3 && (i2.media_ && (i2.media_ = i2.masterPlaylistLoader_.master.playlists[i2.media_.id]), i2.masterPlaylistLoader_.sidxMapping_ = (t3 = i2.masterPlaylistLoader_.master, r2 = i2.masterPlaylistLoader_.sidxMapping_, a3 = $u(t3.playlists, r2), Cu(t3, function(e4, t4, i3, n2) {
            e4.playlists && e4.playlists.length && (e4 = e4.playlists, a3 = Vl(a3, $u(e4, r2)));
          }), a3), i2.addSidxSegments_(i2.media(), i2.state, function(e4) {
            i2.refreshMedia_(i2.media().id);
          }));
        });
      }, t2.refreshMedia_ = function(e3) {
        var t3 = this;
        if (!e3)
          throw new Error("refreshMedia_ must take a media id");
        this.media_ && this.isMaster_ && this.handleMaster_();
        var i2 = this.masterPlaylistLoader_.master.playlists, n2 = !this.media_ || this.media_ !== i2[e3];
        n2 ? this.media_ = i2[e3] : this.trigger("playlistunchanged"), this.mediaUpdateTimeout || function e4() {
          t3.media().endList || (t3.mediaUpdateTimeout = window.setTimeout(function() {
            t3.trigger("mediaupdatetimeout"), e4();
          }, Ru(t3.media(), Boolean(n2))));
        }(), this.trigger("loadedplaylist");
      }, e2;
    }(zt), Wl = { GOAL_BUFFER_LENGTH: 30, MAX_GOAL_BUFFER_LENGTH: 60, BACK_BUFFER_LENGTH: 30, GOAL_BUFFER_LENGTH_RATE: 1, INITIAL_BANDWIDTH: 4194304, BANDWIDTH_VARIANCE: 1.2, BUFFER_LOW_WATER_LINE: 0, MAX_BUFFER_LOW_WATER_LINE: 30, EXPERIMENTAL_MAX_BUFFER_LOW_WATER_LINE: 16, BUFFER_LOW_WATER_LINE_RATE: 1, BUFFER_HIGH_WATER_LINE: 30 }, x = function(n2) {
      return function() {
        var e2 = function(t3) {
          try {
            return URL.createObjectURL(new Blob([t3], { type: "application/javascript" }));
          } catch (e3) {
            var i3 = new BlobBuilder();
            return i3.append(t3), URL.createObjectURL(i3.getBlob());
          }
        }(n2), t2 = Ju(new Worker(e2));
        t2.objURL = e2;
        var i2 = t2.terminate;
        return t2.on = t2.addEventListener, t2.off = t2.removeEventListener, t2.terminate = function() {
          return URL.revokeObjectURL(e2), i2.call(this);
        }, t2;
      };
    }, ar = function(e2) {
      return "var browserWorkerPolyFill = " + Ju.toString() + ";\nbrowserWorkerPolyFill(self);\n" + e2;
    }, Qr = function(e2) {
      return e2.toString().replace(/^function.+?{/, "").slice(0, -1);
    }, Gl = x(ar(Qr(function() {
      var e2 = function() {
        this.init = function() {
          var a3 = {};
          this.on = function(e3, t3) {
            a3[e3] || (a3[e3] = []), a3[e3] = a3[e3].concat(t3);
          }, this.off = function(e3, t3) {
            return !!a3[e3] && (t3 = a3[e3].indexOf(t3), a3[e3] = a3[e3].slice(), a3[e3].splice(t3, 1), -1 < t3);
          }, this.trigger = function(e3) {
            var t3, i3, n3, r3 = a3[e3];
            if (r3)
              if (2 === arguments.length)
                for (i3 = r3.length, t3 = 0; t3 < i3; ++t3)
                  r3[t3].call(this, arguments[1]);
              else {
                for (n3 = [], t3 = arguments.length, t3 = 1; t3 < arguments.length; ++t3)
                  n3.push(arguments[t3]);
                for (i3 = r3.length, t3 = 0; t3 < i3; ++t3)
                  r3[t3].apply(this, n3);
              }
          }, this.dispose = function() {
            a3 = {};
          };
        };
      };
      e2.prototype.pipe = function(t3) {
        return this.on("data", function(e3) {
          t3.push(e3);
        }), this.on("done", function(e3) {
          t3.flush(e3);
        }), this.on("partialdone", function(e3) {
          t3.partialFlush(e3);
        }), this.on("endedtimeline", function(e3) {
          t3.endTimeline(e3);
        }), this.on("reset", function(e3) {
          t3.reset(e3);
        }), t3;
      }, e2.prototype.push = function(e3) {
        this.trigger("data", e3);
      }, e2.prototype.flush = function(e3) {
        this.trigger("done", e3);
      }, e2.prototype.partialFlush = function(e3) {
        this.trigger("partialdone", e3);
      }, e2.prototype.endTimeline = function(e3) {
        this.trigger("endedtimeline", e3);
      }, e2.prototype.reset = function(e3) {
        this.trigger("reset", e3);
      };
      var u2, t2, i2, n2, r2, a2, s2, o2, l2, d2, c2, h2, p2, f2, m2, g2, y2, v2, _2, b2, T2, w2, S2, E2, k2, C2, I2, x2, A2, P2, L2, O2, D2, R2, M2, N2, U2, B2, F2, j2 = e2, H2 = Math.pow(2, 32), V2 = { getUint64: function(e3) {
        var t3 = new DataView(e3.buffer, e3.byteOffset, e3.byteLength);
        return t3.getBigUint64 ? (e3 = t3.getBigUint64(0)) < Number.MAX_SAFE_INTEGER ? Number(e3) : e3 : t3.getUint32(0) * H2 + t3.getUint32(4);
      }, MAX_UINT32: H2 }, q2 = V2.MAX_UINT32;
      !function() {
        if (T2 = { avc1: [], avcC: [], btrt: [], dinf: [], dref: [], esds: [], ftyp: [], hdlr: [], mdat: [], mdhd: [], mdia: [], mfhd: [], minf: [], moof: [], moov: [], mp4a: [], mvex: [], mvhd: [], pasp: [], sdtp: [], smhd: [], stbl: [], stco: [], stsc: [], stsd: [], stsz: [], stts: [], styp: [], tfdt: [], tfhd: [], traf: [], trak: [], trun: [], trex: [], tkhd: [], vmhd: [] }, "undefined" != typeof Uint8Array) {
          for (var e3 in T2)
            T2.hasOwnProperty(e3) && (T2[e3] = [e3.charCodeAt(0), e3.charCodeAt(1), e3.charCodeAt(2), e3.charCodeAt(3)]);
          w2 = new Uint8Array(["i".charCodeAt(0), "s".charCodeAt(0), "o".charCodeAt(0), "m".charCodeAt(0)]), E2 = new Uint8Array(["a".charCodeAt(0), "v".charCodeAt(0), "c".charCodeAt(0), "1".charCodeAt(0)]), S2 = new Uint8Array([0, 0, 0, 1]), k2 = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 118, 105, 100, 101, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 86, 105, 100, 101, 111, 72, 97, 110, 100, 108, 101, 114, 0]), C2 = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 115, 111, 117, 110, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 83, 111, 117, 110, 100, 72, 97, 110, 100, 108, 101, 114, 0]), I2 = { video: k2, audio: C2 }, P2 = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 12, 117, 114, 108, 32, 0, 0, 0, 1]), A2 = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0]), L2 = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0]), O2 = L2, D2 = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), R2 = L2, x2 = new Uint8Array([0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0]);
        }
      }(), u2 = function(e3) {
        for (var t3, i3 = [], n3 = 0, r3 = 1; r3 < arguments.length; r3++)
          i3.push(arguments[r3]);
        for (r3 = i3.length; r3--; )
          n3 += i3[r3].byteLength;
        for (t3 = new Uint8Array(n3 + 8), new DataView(t3.buffer, t3.byteOffset, t3.byteLength).setUint32(0, t3.byteLength), t3.set(e3, 4), r3 = 0, n3 = 8; r3 < i3.length; r3++)
          t3.set(i3[r3], n3), n3 += i3[r3].byteLength;
        return t3;
      }, t2 = function() {
        return u2(T2.dinf, u2(T2.dref, P2));
      }, i2 = function(e3) {
        return u2(T2.esds, new Uint8Array([0, 0, 0, 0, 3, 25, 0, 0, 0, 4, 17, 64, 21, 0, 6, 0, 0, 0, 218, 192, 0, 0, 218, 192, 5, 2, e3.audioobjecttype << 3 | e3.samplingfrequencyindex >>> 1, e3.samplingfrequencyindex << 7 | e3.channelcount << 3, 6, 1, 2]));
      }, f2 = function(e3) {
        return u2(T2.hdlr, I2[e3]);
      }, p2 = function(e3) {
        var t3 = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 3, 0, 1, 95, 144, e3.duration >>> 24 & 255, e3.duration >>> 16 & 255, e3.duration >>> 8 & 255, 255 & e3.duration, 85, 196, 0, 0]);
        return e3.samplerate && (t3[12] = e3.samplerate >>> 24 & 255, t3[13] = e3.samplerate >>> 16 & 255, t3[14] = e3.samplerate >>> 8 & 255, t3[15] = 255 & e3.samplerate), u2(T2.mdhd, t3);
      }, h2 = function(e3) {
        return u2(T2.mdia, p2(e3), f2(e3.type), a2(e3));
      }, r2 = function(e3) {
        return u2(T2.mfhd, new Uint8Array([0, 0, 0, 0, (4278190080 & e3) >> 24, (16711680 & e3) >> 16, (65280 & e3) >> 8, 255 & e3]));
      }, a2 = function(e3) {
        return u2(T2.minf, "video" === e3.type ? u2(T2.vmhd, x2) : u2(T2.smhd, A2), t2(), g2(e3));
      }, We2 = function(e3, t3) {
        for (var i3 = [], n3 = t3.length; n3--; )
          i3[n3] = v2(t3[n3]);
        return u2.apply(null, [T2.moof, r2(e3)].concat(i3));
      }, s2 = function(e3) {
        for (var t3 = e3.length, i3 = []; t3--; )
          i3[t3] = d2(e3[t3]);
        return u2.apply(null, [T2.moov, l2(4294967295)].concat(i3).concat(o2(e3)));
      }, o2 = function(e3) {
        for (var t3 = e3.length, i3 = []; t3--; )
          i3[t3] = _2(e3[t3]);
        return u2.apply(null, [T2.mvex].concat(i3));
      }, l2 = function(e3) {
        e3 = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 1, 95, 144, (4278190080 & e3) >> 24, (16711680 & e3) >> 16, (65280 & e3) >> 8, 255 & e3, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255]);
        return u2(T2.mvhd, e3);
      }, m2 = function(e3) {
        for (var t3, i3 = e3.samples || [], n3 = new Uint8Array(4 + i3.length), r3 = 0; r3 < i3.length; r3++)
          t3 = i3[r3].flags, n3[r3 + 4] = t3.dependsOn << 4 | t3.isDependedOn << 2 | t3.hasRedundancy;
        return u2(T2.sdtp, n3);
      }, g2 = function(e3) {
        return u2(T2.stbl, y2(e3), u2(T2.stts, R2), u2(T2.stsc, O2), u2(T2.stsz, D2), u2(T2.stco, L2));
      }, y2 = function(e3) {
        return u2(T2.stsd, new Uint8Array([0, 0, 0, 0, 0, 0, 0, 1]), ("video" === e3.type ? M2 : N2)(e3));
      }, M2 = function(e3) {
        for (var t3, i3, n3 = e3.sps || [], r3 = e3.pps || [], a3 = [], s3 = [], o3 = 0; o3 < n3.length; o3++)
          a3.push((65280 & n3[o3].byteLength) >>> 8), a3.push(255 & n3[o3].byteLength), a3 = a3.concat(Array.prototype.slice.call(n3[o3]));
        for (o3 = 0; o3 < r3.length; o3++)
          s3.push((65280 & r3[o3].byteLength) >>> 8), s3.push(255 & r3[o3].byteLength), s3 = s3.concat(Array.prototype.slice.call(r3[o3]));
        return t3 = [T2.avc1, new Uint8Array([0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (65280 & e3.width) >> 8, 255 & e3.width, (65280 & e3.height) >> 8, 255 & e3.height, 0, 72, 0, 0, 0, 72, 0, 0, 0, 0, 0, 0, 0, 1, 19, 118, 105, 100, 101, 111, 106, 115, 45, 99, 111, 110, 116, 114, 105, 98, 45, 104, 108, 115, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 17, 17]), u2(T2.avcC, new Uint8Array([1, e3.profileIdc, e3.profileCompatibility, e3.levelIdc, 255].concat([n3.length], a3, [r3.length], s3))), u2(T2.btrt, new Uint8Array([0, 28, 156, 128, 0, 45, 198, 192, 0, 45, 198, 192]))], e3.sarRatio && (i3 = e3.sarRatio[0], e3 = e3.sarRatio[1], t3.push(u2(T2.pasp, new Uint8Array([(4278190080 & i3) >> 24, (16711680 & i3) >> 16, (65280 & i3) >> 8, 255 & i3, (4278190080 & e3) >> 24, (16711680 & e3) >> 16, (65280 & e3) >> 8, 255 & e3])))), u2.apply(null, t3);
      }, N2 = function(e3) {
        return u2(T2.mp4a, new Uint8Array([0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, (65280 & e3.channelcount) >> 8, 255 & e3.channelcount, (65280 & e3.samplesize) >> 8, 255 & e3.samplesize, 0, 0, 0, 0, (65280 & e3.samplerate) >> 8, 255 & e3.samplerate, 0, 0]), i2(e3));
      }, c2 = function(e3) {
        e3 = new Uint8Array([0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, (4278190080 & e3.id) >> 24, (16711680 & e3.id) >> 16, (65280 & e3.id) >> 8, 255 & e3.id, 0, 0, 0, 0, (4278190080 & e3.duration) >> 24, (16711680 & e3.duration) >> 16, (65280 & e3.duration) >> 8, 255 & e3.duration, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 0, 0, 0, (65280 & e3.width) >> 8, 255 & e3.width, 0, 0, (65280 & e3.height) >> 8, 255 & e3.height, 0, 0]);
        return u2(T2.tkhd, e3);
      }, v2 = function(e3) {
        var t3, i3 = u2(T2.tfhd, new Uint8Array([0, 0, 0, 58, (4278190080 & e3.id) >> 24, (16711680 & e3.id) >> 16, (65280 & e3.id) >> 8, 255 & e3.id, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])), n3 = Math.floor(e3.baseMediaDecodeTime / q2), r3 = Math.floor(e3.baseMediaDecodeTime % q2), n3 = u2(T2.tfdt, new Uint8Array([1, 0, 0, 0, n3 >>> 24 & 255, n3 >>> 16 & 255, n3 >>> 8 & 255, 255 & n3, r3 >>> 24 & 255, r3 >>> 16 & 255, r3 >>> 8 & 255, 255 & r3]));
        return "audio" === e3.type ? (t3 = b2(e3, 92), u2(T2.traf, i3, n3, t3)) : (r3 = m2(e3), t3 = b2(e3, r3.length + 92), u2(T2.traf, i3, n3, t3, r3));
      }, d2 = function(e3) {
        return e3.duration = e3.duration || 4294967295, u2(T2.trak, c2(e3), h2(e3));
      }, _2 = function(e3) {
        var t3 = new Uint8Array([0, 0, 0, 0, (4278190080 & e3.id) >> 24, (16711680 & e3.id) >> 16, (65280 & e3.id) >> 8, 255 & e3.id, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1]);
        return "video" !== e3.type && (t3[t3.length - 1] = 0), u2(T2.trex, t3);
      }, U2 = function(e3, t3) {
        var i3 = 0, n3 = 0, r3 = 0, a3 = 0;
        return e3.length && (void 0 !== e3[0].duration && (i3 = 1), void 0 !== e3[0].size && (n3 = 2), void 0 !== e3[0].flags && (r3 = 4), void 0 !== e3[0].compositionTimeOffset && (a3 = 8)), [0, 0, i3 | n3 | r3 | a3, 1, (4278190080 & e3.length) >>> 24, (16711680 & e3.length) >>> 16, (65280 & e3.length) >>> 8, 255 & e3.length, (4278190080 & t3) >>> 24, (16711680 & t3) >>> 16, (65280 & t3) >>> 8, 255 & t3];
      }, B2 = function(e3, t3) {
        var i3, n3, r3, a3, s3 = e3.samples || [];
        for (t3 += 20 + 16 * s3.length, t3 = U2(s3, t3), (n3 = new Uint8Array(t3.length + 16 * s3.length)).set(t3), i3 = t3.length, a3 = 0; a3 < s3.length; a3++)
          r3 = s3[a3], n3[i3++] = (4278190080 & r3.duration) >>> 24, n3[i3++] = (16711680 & r3.duration) >>> 16, n3[i3++] = (65280 & r3.duration) >>> 8, n3[i3++] = 255 & r3.duration, n3[i3++] = (4278190080 & r3.size) >>> 24, n3[i3++] = (16711680 & r3.size) >>> 16, n3[i3++] = (65280 & r3.size) >>> 8, n3[i3++] = 255 & r3.size, n3[i3++] = r3.flags.isLeading << 2 | r3.flags.dependsOn, n3[i3++] = r3.flags.isDependedOn << 6 | r3.flags.hasRedundancy << 4 | r3.flags.paddingValue << 1 | r3.flags.isNonSyncSample, n3[i3++] = 61440 & r3.flags.degradationPriority, n3[i3++] = 15 & r3.flags.degradationPriority, n3[i3++] = (4278190080 & r3.compositionTimeOffset) >>> 24, n3[i3++] = (16711680 & r3.compositionTimeOffset) >>> 16, n3[i3++] = (65280 & r3.compositionTimeOffset) >>> 8, n3[i3++] = 255 & r3.compositionTimeOffset;
        return u2(T2.trun, n3);
      }, F2 = function(e3, t3) {
        var i3, n3, r3, a3, s3 = e3.samples || [];
        for (t3 += 20 + 8 * s3.length, t3 = U2(s3, t3), (i3 = new Uint8Array(t3.length + 8 * s3.length)).set(t3), n3 = t3.length, a3 = 0; a3 < s3.length; a3++)
          r3 = s3[a3], i3[n3++] = (4278190080 & r3.duration) >>> 24, i3[n3++] = (16711680 & r3.duration) >>> 16, i3[n3++] = (65280 & r3.duration) >>> 8, i3[n3++] = 255 & r3.duration, i3[n3++] = (4278190080 & r3.size) >>> 24, i3[n3++] = (16711680 & r3.size) >>> 16, i3[n3++] = (65280 & r3.size) >>> 8, i3[n3++] = 255 & r3.size;
        return u2(T2.trun, i3);
      }, b2 = function(e3, t3) {
        return ("audio" === e3.type ? F2 : B2)(e3, t3);
      };
      n2 = function() {
        return u2(T2.ftyp, w2, S2, w2, E2);
      };
      function W2(e3, t3) {
        var i3 = { size: 0, flags: { isLeading: 0, dependsOn: 1, isDependedOn: 0, hasRedundancy: 0, degradationPriority: 0, isNonSyncSample: 1 } };
        return i3.dataOffset = t3, i3.compositionTimeOffset = e3.pts - e3.dts, i3.duration = e3.duration, i3.size = 4 * e3.length, i3.size += e3.byteLength, e3.keyFrame && (i3.flags.dependsOn = 2, i3.flags.isNonSyncSample = 0), i3;
      }
      function G2(e3) {
        for (var t3 = []; e3--; )
          t3.push(0);
        return t3;
      }
      function z2() {
        var e3, i3;
        return X2 || (e3 = { 96e3: [ie2, [227, 64], G2(154), [56]], 88200: [ie2, [231], G2(170), [56]], 64e3: [ie2, [248, 192], G2(240), [56]], 48e3: [ie2, [255, 192], G2(268), [55, 148, 128], G2(54), [112]], 44100: [ie2, [255, 192], G2(268), [55, 163, 128], G2(84), [112]], 32e3: [ie2, [255, 192], G2(268), [55, 234], G2(226), [112]], 24e3: [ie2, [255, 192], G2(268), [55, 255, 128], G2(268), [111, 112], G2(126), [224]], 16e3: [ie2, [255, 192], G2(268), [55, 255, 128], G2(268), [111, 255], G2(269), [223, 108], G2(195), [1, 192]], 12e3: [ne2, G2(268), [3, 127, 248], G2(268), [6, 255, 240], G2(268), [13, 255, 224], G2(268), [27, 253, 128], G2(259), [56]], 11025: [ne2, G2(268), [3, 127, 248], G2(268), [6, 255, 240], G2(268), [13, 255, 224], G2(268), [27, 255, 192], G2(268), [55, 175, 128], G2(108), [112]], 8e3: [ne2, G2(268), [3, 121, 16], G2(47), [7]] }, i3 = e3, X2 = Object.keys(i3).reduce(function(e4, t3) {
          return e4[t3] = new Uint8Array(i3[t3].reduce(function(e5, t4) {
            return e5.concat(t4);
          }, [])), e4;
        }, {})), X2;
      }
      var X2, K2 = function(e3) {
        return u2(T2.mdat, e3);
      }, Y2 = We2, Q2 = function(e3) {
        var t3 = n2(), i3 = s2(e3), e3 = new Uint8Array(t3.byteLength + i3.byteLength);
        return e3.set(t3), e3.set(i3, t3.byteLength), e3;
      }, $2 = function(e3) {
        var t3, i3, n3 = [], r3 = [];
        for (r3.byteLength = 0, r3.nalCount = 0, r3.duration = 0, t3 = n3.byteLength = 0; t3 < e3.length; t3++)
          "access_unit_delimiter_rbsp" === (i3 = e3[t3]).nalUnitType ? (n3.length && (n3.duration = i3.dts - n3.dts, r3.byteLength += n3.byteLength, r3.nalCount += n3.length, r3.duration += n3.duration, r3.push(n3)), (n3 = [i3]).byteLength = i3.data.byteLength, n3.pts = i3.pts, n3.dts = i3.dts) : ("slice_layer_without_partitioning_rbsp_idr" === i3.nalUnitType && (n3.keyFrame = true), n3.duration = i3.dts - n3.dts, n3.byteLength += i3.data.byteLength, n3.push(i3));
        return r3.length && (!n3.duration || n3.duration <= 0) && (n3.duration = r3[r3.length - 1].duration), r3.byteLength += n3.byteLength, r3.nalCount += n3.length, r3.duration += n3.duration, r3.push(n3), r3;
      }, J2 = function(e3) {
        var t3, i3, n3 = [], r3 = [];
        for (n3.byteLength = 0, n3.nalCount = 0, n3.duration = 0, n3.pts = e3[0].pts, n3.dts = e3[0].dts, r3.byteLength = 0, r3.nalCount = 0, r3.duration = 0, r3.pts = e3[0].pts, r3.dts = e3[0].dts, t3 = 0; t3 < e3.length; t3++)
          (i3 = e3[t3]).keyFrame ? (n3.length && (r3.push(n3), r3.byteLength += n3.byteLength, r3.nalCount += n3.nalCount, r3.duration += n3.duration), (n3 = [i3]).nalCount = i3.length, n3.byteLength = i3.byteLength, n3.pts = i3.pts, n3.dts = i3.dts, n3.duration = i3.duration) : (n3.duration += i3.duration, n3.nalCount += i3.length, n3.byteLength += i3.byteLength, n3.push(i3));
        return r3.length && n3.duration <= 0 && (n3.duration = r3[r3.length - 1].duration), r3.byteLength += n3.byteLength, r3.nalCount += n3.nalCount, r3.duration += n3.duration, r3.push(n3), r3;
      }, Z2 = function(e3) {
        var t3;
        return !e3[0][0].keyFrame && 1 < e3.length && (t3 = e3.shift(), e3.byteLength -= t3.byteLength, e3.nalCount -= t3.nalCount, e3[0][0].dts = t3.dts, e3[0][0].pts = t3.pts, e3[0][0].duration += t3.duration), e3;
      }, ee2 = function(e3, t3) {
        for (var i3, n3, r3, a3 = t3 || 0, s3 = [], o3 = 0; o3 < e3.length; o3++)
          for (n3 = e3[o3], i3 = 0; i3 < n3.length; i3++)
            r3 = n3[i3], a3 += (r3 = W2(r3, a3)).size, s3.push(r3);
        return s3;
      }, te2 = function(e3) {
        for (var t3, i3, n3, r3, a3, s3 = 0, o3 = e3.byteLength, u3 = e3.nalCount, l3 = new Uint8Array(o3 + 4 * u3), d3 = new DataView(l3.buffer), c3 = 0; c3 < e3.length; c3++)
          for (n3 = e3[c3], t3 = 0; t3 < n3.length; t3++)
            for (r3 = n3[t3], i3 = 0; i3 < r3.length; i3++)
              a3 = r3[i3], d3.setUint32(s3, a3.data.byteLength), l3.set(a3.data, s3 += 4), s3 += a3.data.byteLength;
        return l3;
      }, ie2 = [33, 16, 5, 32, 164, 27], ne2 = [33, 65, 108, 84, 1, 2, 4, 8, 168, 2, 4, 8, 17, 191, 252], re2 = function(e3) {
        return 9e4 * e3;
      }, ae2 = function(e3, t3) {
        return e3 * t3;
      }, se2 = function(e3) {
        return e3 / 9e4;
      }, oe2 = function(e3, t3) {
        return e3 / t3;
      }, ue2 = 9e4, le2 = re2, de2 = se2, ce2 = function(e3, t3) {
        return re2(oe2(e3, t3));
      }, he2 = function(e3, t3) {
        return ae2(se2(e3), t3);
      }, pe2 = function(e3, t3, i3) {
        return se2(i3 ? e3 : e3 - t3);
      }, fe2 = function(e3, t3, i3, n3) {
        var r3, a3, s3, o3, u3, l3, d3 = 0, c3 = 0;
        if (t3.length && (r3 = ce2(e3.baseMediaDecodeTime, e3.samplerate), a3 = Math.ceil(ue2 / (e3.samplerate / 1024)), i3 && n3 && (s3 = r3 - Math.max(i3, n3), c3 = (d3 = Math.floor(s3 / a3)) * a3), !(d3 < 1 || ue2 / 2 < c3))) {
          for (o3 = (o3 = z2()[e3.samplerate]) || t3[0].data, u3 = 0; u3 < d3; u3++)
            l3 = t3[0], t3.splice(0, 0, { data: o3, dts: l3.dts - a3, pts: l3.pts - a3 });
          return e3.baseMediaDecodeTime -= Math.floor(he2(c3, e3.samplerate)), c3;
        }
      }, me2 = function(e3, t3, i3) {
        return t3.minSegmentDts >= i3 ? e3 : (t3.minSegmentDts = 1 / 0, e3.filter(function(e4) {
          return e4.dts >= i3 && (t3.minSegmentDts = Math.min(t3.minSegmentDts, e4.dts), t3.minSegmentPts = t3.minSegmentDts, true);
        }));
      }, ge2 = function(e3) {
        for (var t3, i3 = [], n3 = 0; n3 < e3.length; n3++)
          t3 = e3[n3], i3.push({ size: t3.data.byteLength, duration: 1024 });
        return i3;
      }, ye2 = function(e3) {
        for (var t3, i3 = 0, n3 = new Uint8Array(function(e4) {
          for (var t4 = 0, i4 = 0; i4 < e4.length; i4++)
            t4 += e4[i4].data.byteLength;
          return t4;
        }(e3)), r3 = 0; r3 < e3.length; r3++)
          t3 = e3[r3], n3.set(t3.data, i3), i3 += t3.data.byteLength;
        return n3;
      }, ve2 = ue2, _e2 = function(e3) {
        delete e3.minSegmentDts, delete e3.maxSegmentDts, delete e3.minSegmentPts, delete e3.maxSegmentPts;
      }, be2 = function(e3, t3) {
        var i3 = e3.minSegmentDts;
        return t3 || (i3 -= e3.timelineStartInfo.dts), t3 = e3.timelineStartInfo.baseMediaDecodeTime, t3 += i3, t3 = Math.max(0, t3), "audio" === e3.type && (t3 *= e3.samplerate / ve2, t3 = Math.floor(t3)), t3;
      }, Te2 = function(e3, t3) {
        "number" == typeof t3.pts && (void 0 === e3.timelineStartInfo.pts && (e3.timelineStartInfo.pts = t3.pts), void 0 === e3.minSegmentPts ? e3.minSegmentPts = t3.pts : e3.minSegmentPts = Math.min(e3.minSegmentPts, t3.pts), void 0 === e3.maxSegmentPts ? e3.maxSegmentPts = t3.pts : e3.maxSegmentPts = Math.max(e3.maxSegmentPts, t3.pts)), "number" == typeof t3.dts && (void 0 === e3.timelineStartInfo.dts && (e3.timelineStartInfo.dts = t3.dts), void 0 === e3.minSegmentDts ? e3.minSegmentDts = t3.dts : e3.minSegmentDts = Math.min(e3.minSegmentDts, t3.dts), void 0 === e3.maxSegmentDts ? e3.maxSegmentDts = t3.dts : e3.maxSegmentDts = Math.max(e3.maxSegmentDts, t3.dts));
      }, we2 = function(e3) {
        for (var t3 = 0, i3 = { payloadType: -1, payloadSize: 0 }, n3 = 0, r3 = 0; t3 < e3.byteLength && 128 !== e3[t3]; ) {
          for (; 255 === e3[t3]; )
            n3 += 255, t3++;
          for (n3 += e3[t3++]; 255 === e3[t3]; )
            r3 += 255, t3++;
          if (r3 += e3[t3++], !i3.payload && 4 === n3) {
            if ("GA94" === String.fromCharCode(e3[t3 + 3], e3[t3 + 4], e3[t3 + 5], e3[t3 + 6])) {
              i3.payloadType = n3, i3.payloadSize = r3, i3.payload = e3.subarray(t3, t3 + r3);
              break;
            }
            i3.payload = void 0;
          }
          t3 += r3, r3 = n3 = 0;
        }
        return i3;
      }, Se2 = function(e3) {
        return 181 !== e3.payload[0] || 49 != (e3.payload[1] << 8 | e3.payload[2]) || "GA94" !== String.fromCharCode(e3.payload[3], e3.payload[4], e3.payload[5], e3.payload[6]) || 3 !== e3.payload[7] ? null : e3.payload.subarray(8, e3.payload.length - 1);
      }, Ee2 = function(e3, t3) {
        var i3, n3, r3, a3, s3 = [];
        if (!(64 & t3[0]))
          return s3;
        for (n3 = 31 & t3[0], i3 = 0; i3 < n3; i3++)
          a3 = { type: 3 & t3[2 + (r3 = 3 * i3)], pts: e3 }, 4 & t3[2 + r3] && (a3.ccData = t3[3 + r3] << 8 | t3[4 + r3], s3.push(a3));
        return s3;
      }, ke2 = function(e3) {
        for (var t3 = e3.byteLength, i3 = [], n3 = 1; n3 < t3 - 2; )
          0 === e3[n3] && 0 === e3[n3 + 1] && 3 === e3[n3 + 2] ? (i3.push(n3 + 2), n3 += 2) : n3++;
        if (0 === i3.length)
          return e3;
        for (var r3 = t3 - i3.length, a3 = new Uint8Array(r3), s3 = 0, n3 = 0; n3 < r3; s3++, n3++)
          s3 === i3[0] && (s3++, i3.shift()), a3[n3] = e3[s3];
        return a3;
      }, Ce2 = 4, Ie2 = function e3(t3) {
        t3 = t3 || {}, e3.prototype.init.call(this), this.parse708captions_ = "boolean" != typeof t3.parse708captions || t3.parse708captions, this.captionPackets_ = [], this.ccStreams_ = [new Ue2(0, 0), new Ue2(0, 1), new Ue2(1, 0), new Ue2(1, 1)], this.parse708captions_ && (this.cc708Stream_ = new Oe2({ captionServices: t3.captionServices })), this.reset(), this.ccStreams_.forEach(function(e4) {
          e4.on("data", this.trigger.bind(this, "data")), e4.on("partialdone", this.trigger.bind(this, "partialdone")), e4.on("done", this.trigger.bind(this, "done"));
        }, this), this.parse708captions_ && (this.cc708Stream_.on("data", this.trigger.bind(this, "data")), this.cc708Stream_.on("partialdone", this.trigger.bind(this, "partialdone")), this.cc708Stream_.on("done", this.trigger.bind(this, "done")));
      };
      (Ie2.prototype = new j2()).push = function(e3) {
        var t3, i3;
        if ("sei_rbsp" === e3.nalUnitType && (t3 = we2(e3.escapedRBSP)).payload && t3.payloadType === Ce2 && (i3 = Se2(t3)))
          if (e3.dts < this.latestDts_)
            this.ignoreNextEqualDts_ = true;
          else {
            if (e3.dts === this.latestDts_ && this.ignoreNextEqualDts_)
              return this.numSameDts_--, void (this.numSameDts_ || (this.ignoreNextEqualDts_ = false));
            i3 = Ee2(e3.pts, i3), this.captionPackets_ = this.captionPackets_.concat(i3), this.latestDts_ !== e3.dts && (this.numSameDts_ = 0), this.numSameDts_++, this.latestDts_ = e3.dts;
          }
      }, Ie2.prototype.flushCCStreams = function(t3) {
        this.ccStreams_.forEach(function(e3) {
          return "flush" === t3 ? e3.flush() : e3.partialFlush();
        }, this);
      }, Ie2.prototype.flushStream = function(e3) {
        this.captionPackets_.length && (this.captionPackets_.forEach(function(e4, t3) {
          e4.presortIndex = t3;
        }), this.captionPackets_.sort(function(e4, t3) {
          return e4.pts === t3.pts ? e4.presortIndex - t3.presortIndex : e4.pts - t3.pts;
        }), this.captionPackets_.forEach(function(e4) {
          e4.type < 2 ? this.dispatchCea608Packet(e4) : this.dispatchCea708Packet(e4);
        }, this), this.captionPackets_.length = 0), this.flushCCStreams(e3);
      }, Ie2.prototype.flush = function() {
        return this.flushStream("flush");
      }, Ie2.prototype.partialFlush = function() {
        return this.flushStream("partialFlush");
      }, Ie2.prototype.reset = function() {
        this.latestDts_ = null, this.ignoreNextEqualDts_ = false, this.numSameDts_ = 0, this.activeCea608Channel_ = [null, null], this.ccStreams_.forEach(function(e3) {
          e3.reset();
        });
      }, Ie2.prototype.dispatchCea608Packet = function(e3) {
        this.setsTextOrXDSActive(e3) ? this.activeCea608Channel_[e3.type] = null : this.setsChannel1Active(e3) ? this.activeCea608Channel_[e3.type] = 0 : this.setsChannel2Active(e3) && (this.activeCea608Channel_[e3.type] = 1), null !== this.activeCea608Channel_[e3.type] && this.ccStreams_[(e3.type << 1) + this.activeCea608Channel_[e3.type]].push(e3);
      }, Ie2.prototype.setsChannel1Active = function(e3) {
        return 4096 == (30720 & e3.ccData);
      }, Ie2.prototype.setsChannel2Active = function(e3) {
        return 6144 == (30720 & e3.ccData);
      }, Ie2.prototype.setsTextOrXDSActive = function(e3) {
        return 256 == (28928 & e3.ccData) || 4138 == (30974 & e3.ccData) || 6186 == (30974 & e3.ccData);
      }, Ie2.prototype.dispatchCea708Packet = function(e3) {
        this.parse708captions_ && this.cc708Stream_.push(e3);
      };
      function xe2(e3) {
        return 32 <= e3 && e3 <= 127 || 160 <= e3 && e3 <= 255;
      }
      function Ae2(e3) {
        this.windowNum = e3, this.reset();
      }
      var Pe2 = { 127: 9834, 4128: 32, 4129: 160, 4133: 8230, 4138: 352, 4140: 338, 4144: 9608, 4145: 8216, 4146: 8217, 4147: 8220, 4148: 8221, 4149: 8226, 4153: 8482, 4154: 353, 4156: 339, 4157: 8480, 4159: 376, 4214: 8539, 4215: 8540, 4216: 8541, 4217: 8542, 4218: 9168, 4219: 9124, 4220: 9123, 4221: 9135, 4222: 9126, 4223: 9121, 4256: 12600 };
      Ae2.prototype.reset = function() {
        this.clearText(), this.pendingNewLine = false, this.winAttr = {}, this.penAttr = {}, this.penLoc = {}, this.penColor = {}, this.visible = 0, this.rowLock = 0, this.columnLock = 0, this.priority = 0, this.relativePositioning = 0, this.anchorVertical = 0, this.anchorHorizontal = 0, this.anchorPoint = 0, this.rowCount = 1, this.virtualRowCount = this.rowCount + 1, this.columnCount = 41, this.windowStyle = 0, this.penStyle = 0;
      }, Ae2.prototype.getText = function() {
        return this.rows.join("\n");
      }, Ae2.prototype.clearText = function() {
        this.rows = [""], this.rowIdx = 0;
      }, Ae2.prototype.newLine = function(e3) {
        for (this.rows.length >= this.virtualRowCount && "function" == typeof this.beforeRowOverflow && this.beforeRowOverflow(e3), 0 < this.rows.length && (this.rows.push(""), this.rowIdx++); this.rows.length > this.virtualRowCount; )
          this.rows.shift(), this.rowIdx--;
      }, Ae2.prototype.isEmpty = function() {
        return 0 === this.rows.length || 1 === this.rows.length && "" === this.rows[0];
      }, Ae2.prototype.addText = function(e3) {
        this.rows[this.rowIdx] += e3;
      }, Ae2.prototype.backspace = function() {
        var e3;
        this.isEmpty() || (e3 = this.rows[this.rowIdx], this.rows[this.rowIdx] = e3.substr(0, e3.length - 1));
      };
      function Le2(e3, t3, i3) {
        this.serviceNum = e3, this.text = "", this.currentWindow = new Ae2(-1), this.windows = [], this.stream = i3, "string" == typeof t3 && this.createTextDecoder(t3);
      }
      Le2.prototype.init = function(e3, t3) {
        this.startPts = e3;
        for (var i3 = 0; i3 < 8; i3++)
          this.windows[i3] = new Ae2(i3), "function" == typeof t3 && (this.windows[i3].beforeRowOverflow = t3);
      }, Le2.prototype.setCurrentWindow = function(e3) {
        this.currentWindow = this.windows[e3];
      }, Le2.prototype.createTextDecoder = function(t3) {
        if ("undefined" == typeof TextDecoder)
          this.stream.trigger("log", { level: "warn", message: "The `encoding` option is unsupported without TextDecoder support" });
        else
          try {
            this.textDecoder_ = new TextDecoder(t3);
          } catch (e3) {
            this.stream.trigger("log", { level: "warn", message: "TextDecoder could not be created with " + t3 + " encoding. " + e3 });
          }
      };
      var Oe2 = function e3(t3) {
        t3 = t3 || {}, e3.prototype.init.call(this);
        var i3, n3 = this, r3 = t3.captionServices || {}, a3 = {};
        Object.keys(r3).forEach(function(e4) {
          i3 = r3[e4], /^SERVICE/.test(e4) && (a3[e4] = i3.encoding);
        }), this.serviceEncodings = a3, this.current708Packet = null, this.services = {}, this.push = function(e4) {
          (3 === e4.type || null === n3.current708Packet) && n3.new708Packet(), n3.add708Bytes(e4);
        };
      };
      Oe2.prototype = new j2(), Oe2.prototype.new708Packet = function() {
        null !== this.current708Packet && this.push708Packet(), this.current708Packet = { data: [], ptsVals: [] };
      }, Oe2.prototype.add708Bytes = function(e3) {
        var t3 = e3.ccData, i3 = t3 >>> 8, t3 = 255 & t3;
        this.current708Packet.ptsVals.push(e3.pts), this.current708Packet.data.push(i3), this.current708Packet.data.push(t3);
      }, Oe2.prototype.push708Packet = function() {
        var e3, t3 = this.current708Packet, i3 = t3.data, n3 = null, r3 = 0, a3 = i3[r3++];
        for (t3.seq = a3 >> 6, t3.sizeCode = 63 & a3; r3 < i3.length; r3++)
          e3 = 31 & (a3 = i3[r3++]), 7 === (n3 = a3 >> 5) && 0 < e3 && (n3 = i3[r3++]), this.pushServiceBlock(n3, r3, e3), 0 < e3 && (r3 += e3 - 1);
      }, Oe2.prototype.pushServiceBlock = function(e3, t3, i3) {
        for (var n3, r3 = t3, a3 = this.current708Packet.data, s3 = (s3 = this.services[e3]) || this.initService(e3, r3); r3 < t3 + i3 && r3 < a3.length; r3++)
          n3 = a3[r3], xe2(n3) ? r3 = this.handleText(r3, s3) : 24 === n3 ? r3 = this.multiByteCharacter(r3, s3) : 16 === n3 ? r3 = this.extendedCommands(r3, s3) : 128 <= n3 && n3 <= 135 ? r3 = this.setCurrentWindow(r3, s3) : 152 <= n3 && n3 <= 159 ? r3 = this.defineWindow(r3, s3) : 136 === n3 ? r3 = this.clearWindows(r3, s3) : 140 === n3 ? r3 = this.deleteWindows(r3, s3) : 137 === n3 ? r3 = this.displayWindows(r3, s3) : 138 === n3 ? r3 = this.hideWindows(r3, s3) : 139 === n3 ? r3 = this.toggleWindows(r3, s3) : 151 === n3 ? r3 = this.setWindowAttributes(r3, s3) : 144 === n3 ? r3 = this.setPenAttributes(r3, s3) : 145 === n3 ? r3 = this.setPenColor(r3, s3) : 146 === n3 ? r3 = this.setPenLocation(r3, s3) : 143 === n3 ? s3 = this.reset(r3, s3) : 8 === n3 ? s3.currentWindow.backspace() : 12 === n3 ? s3.currentWindow.clearText() : 13 === n3 ? s3.currentWindow.pendingNewLine = true : 14 === n3 ? s3.currentWindow.clearText() : 141 === n3 && r3++;
      }, Oe2.prototype.extendedCommands = function(e3, t3) {
        var i3 = this.current708Packet.data[++e3];
        return e3 = xe2(i3) ? this.handleText(e3, t3, { isExtended: true }) : e3;
      }, Oe2.prototype.getPts = function(e3) {
        return this.current708Packet.ptsVals[Math.floor(e3 / 2)];
      }, Oe2.prototype.initService = function(t3, e3) {
        var i3, n3 = "SERVICE" + t3, r3 = this;
        return n3 in this.serviceEncodings && (i3 = this.serviceEncodings[n3]), this.services[t3] = new Le2(t3, i3, r3), this.services[t3].init(this.getPts(e3), function(e4) {
          r3.flushDisplayed(e4, r3.services[t3]);
        }), this.services[t3];
      }, Oe2.prototype.handleText = function(e3, t3, i3) {
        var n3, r3 = i3 && i3.isExtended, a3 = i3 && i3.isMultiByte, s3 = this.current708Packet.data, o3 = r3 ? 4096 : 0, u3 = s3[e3], i3 = s3[e3 + 1], s3 = t3.currentWindow, l3 = t3.textDecoder_ && !r3 ? (a3 ? (n3 = [u3, i3], e3++) : n3 = [u3], t3.textDecoder_.decode(new Uint8Array(n3))) : (l3 = Pe2[u3 = o3 | u3] || u3, 4096 & u3 && u3 === l3 ? "" : String.fromCharCode(l3));
        return s3.pendingNewLine && !s3.isEmpty() && s3.newLine(this.getPts(e3)), s3.pendingNewLine = false, s3.addText(l3), e3;
      }, Oe2.prototype.multiByteCharacter = function(e3, t3) {
        var i3 = this.current708Packet.data, n3 = i3[e3 + 1], i3 = i3[e3 + 2];
        return e3 = xe2(n3) && xe2(i3) ? this.handleText(++e3, t3, { isMultiByte: true }) : e3;
      }, Oe2.prototype.setCurrentWindow = function(e3, t3) {
        var i3 = this.current708Packet.data[e3];
        return t3.setCurrentWindow(7 & i3), e3;
      }, Oe2.prototype.defineWindow = function(e3, t3) {
        var i3 = this.current708Packet.data, n3 = i3[e3];
        t3.setCurrentWindow(7 & n3);
        t3 = t3.currentWindow, n3 = i3[++e3];
        return t3.visible = (32 & n3) >> 5, t3.rowLock = (16 & n3) >> 4, t3.columnLock = (8 & n3) >> 3, t3.priority = 7 & n3, n3 = i3[++e3], t3.relativePositioning = (128 & n3) >> 7, t3.anchorVertical = 127 & n3, n3 = i3[++e3], t3.anchorHorizontal = n3, n3 = i3[++e3], t3.anchorPoint = (240 & n3) >> 4, t3.rowCount = 15 & n3, n3 = i3[++e3], t3.columnCount = 63 & n3, n3 = i3[++e3], t3.windowStyle = (56 & n3) >> 3, t3.penStyle = 7 & n3, t3.virtualRowCount = t3.rowCount + 1, e3;
      }, Oe2.prototype.setWindowAttributes = function(e3, t3) {
        var i3 = this.current708Packet.data, n3 = i3[e3], t3 = t3.currentWindow.winAttr, n3 = i3[++e3];
        return t3.fillOpacity = (192 & n3) >> 6, t3.fillRed = (48 & n3) >> 4, t3.fillGreen = (12 & n3) >> 2, t3.fillBlue = 3 & n3, n3 = i3[++e3], t3.borderType = (192 & n3) >> 6, t3.borderRed = (48 & n3) >> 4, t3.borderGreen = (12 & n3) >> 2, t3.borderBlue = 3 & n3, n3 = i3[++e3], t3.borderType += (128 & n3) >> 5, t3.wordWrap = (64 & n3) >> 6, t3.printDirection = (48 & n3) >> 4, t3.scrollDirection = (12 & n3) >> 2, t3.justify = 3 & n3, n3 = i3[++e3], t3.effectSpeed = (240 & n3) >> 4, t3.effectDirection = (12 & n3) >> 2, t3.displayEffect = 3 & n3, e3;
      }, Oe2.prototype.flushDisplayed = function(e3, t3) {
        for (var i3 = [], n3 = 0; n3 < 8; n3++)
          t3.windows[n3].visible && !t3.windows[n3].isEmpty() && i3.push(t3.windows[n3].getText());
        t3.endPts = e3, t3.text = i3.join("\n\n"), this.pushCaption(t3), t3.startPts = e3;
      }, Oe2.prototype.pushCaption = function(e3) {
        "" !== e3.text && (this.trigger("data", { startPts: e3.startPts, endPts: e3.endPts, text: e3.text, stream: "cc708_" + e3.serviceNum }), e3.text = "", e3.startPts = e3.endPts);
      }, Oe2.prototype.displayWindows = function(e3, t3) {
        var i3 = this.current708Packet.data[++e3], n3 = this.getPts(e3);
        this.flushDisplayed(n3, t3);
        for (var r3 = 0; r3 < 8; r3++)
          i3 & 1 << r3 && (t3.windows[r3].visible = 1);
        return e3;
      }, Oe2.prototype.hideWindows = function(e3, t3) {
        var i3 = this.current708Packet.data[++e3], n3 = this.getPts(e3);
        this.flushDisplayed(n3, t3);
        for (var r3 = 0; r3 < 8; r3++)
          i3 & 1 << r3 && (t3.windows[r3].visible = 0);
        return e3;
      }, Oe2.prototype.toggleWindows = function(e3, t3) {
        var i3 = this.current708Packet.data[++e3], n3 = this.getPts(e3);
        this.flushDisplayed(n3, t3);
        for (var r3 = 0; r3 < 8; r3++)
          i3 & 1 << r3 && (t3.windows[r3].visible ^= 1);
        return e3;
      }, Oe2.prototype.clearWindows = function(e3, t3) {
        var i3 = this.current708Packet.data[++e3], n3 = this.getPts(e3);
        this.flushDisplayed(n3, t3);
        for (var r3 = 0; r3 < 8; r3++)
          i3 & 1 << r3 && t3.windows[r3].clearText();
        return e3;
      }, Oe2.prototype.deleteWindows = function(e3, t3) {
        var i3 = this.current708Packet.data[++e3], n3 = this.getPts(e3);
        this.flushDisplayed(n3, t3);
        for (var r3 = 0; r3 < 8; r3++)
          i3 & 1 << r3 && t3.windows[r3].reset();
        return e3;
      }, Oe2.prototype.setPenAttributes = function(e3, t3) {
        var i3 = this.current708Packet.data, n3 = i3[e3], t3 = t3.currentWindow.penAttr, n3 = i3[++e3];
        return t3.textTag = (240 & n3) >> 4, t3.offset = (12 & n3) >> 2, t3.penSize = 3 & n3, n3 = i3[++e3], t3.italics = (128 & n3) >> 7, t3.underline = (64 & n3) >> 6, t3.edgeType = (56 & n3) >> 3, t3.fontStyle = 7 & n3, e3;
      }, Oe2.prototype.setPenColor = function(e3, t3) {
        var i3 = this.current708Packet.data, n3 = i3[e3], t3 = t3.currentWindow.penColor, n3 = i3[++e3];
        return t3.fgOpacity = (192 & n3) >> 6, t3.fgRed = (48 & n3) >> 4, t3.fgGreen = (12 & n3) >> 2, t3.fgBlue = 3 & n3, n3 = i3[++e3], t3.bgOpacity = (192 & n3) >> 6, t3.bgRed = (48 & n3) >> 4, t3.bgGreen = (12 & n3) >> 2, t3.bgBlue = 3 & n3, n3 = i3[++e3], t3.edgeRed = (48 & n3) >> 4, t3.edgeGreen = (12 & n3) >> 2, t3.edgeBlue = 3 & n3, e3;
      }, Oe2.prototype.setPenLocation = function(e3, t3) {
        var i3 = this.current708Packet.data, n3 = i3[e3], r3 = t3.currentWindow.penLoc;
        return t3.currentWindow.pendingNewLine = true, n3 = i3[++e3], r3.row = 15 & n3, n3 = i3[++e3], r3.column = 63 & n3, e3;
      }, Oe2.prototype.reset = function(e3, t3) {
        var i3 = this.getPts(e3);
        return this.flushDisplayed(i3, t3), this.initService(t3.serviceNum, e3);
      };
      function De2(e3) {
        return null === e3 ? "" : (e3 = Me2[e3] || e3, String.fromCharCode(e3));
      }
      function Re2() {
        for (var e3 = [], t3 = 15; t3--; )
          e3.push("");
        return e3;
      }
      var Me2 = { 42: 225, 92: 233, 94: 237, 95: 243, 96: 250, 123: 231, 124: 247, 125: 209, 126: 241, 127: 9608, 304: 174, 305: 176, 306: 189, 307: 191, 308: 8482, 309: 162, 310: 163, 311: 9834, 312: 224, 313: 160, 314: 232, 315: 226, 316: 234, 317: 238, 318: 244, 319: 251, 544: 193, 545: 201, 546: 211, 547: 218, 548: 220, 549: 252, 550: 8216, 551: 161, 552: 42, 553: 39, 554: 8212, 555: 169, 556: 8480, 557: 8226, 558: 8220, 559: 8221, 560: 192, 561: 194, 562: 199, 563: 200, 564: 202, 565: 203, 566: 235, 567: 206, 568: 207, 569: 239, 570: 212, 571: 217, 572: 249, 573: 219, 574: 171, 575: 187, 800: 195, 801: 227, 802: 205, 803: 204, 804: 236, 805: 210, 806: 242, 807: 213, 808: 245, 809: 123, 810: 125, 811: 92, 812: 94, 813: 95, 814: 124, 815: 126, 816: 196, 817: 228, 818: 214, 819: 246, 820: 223, 821: 165, 822: 164, 823: 9474, 824: 197, 825: 229, 826: 216, 827: 248, 828: 9484, 829: 9488, 830: 9492, 831: 9496 }, Ne2 = [4352, 4384, 4608, 4640, 5376, 5408, 5632, 5664, 5888, 5920, 4096, 4864, 4896, 5120, 5152], Ue2 = function e3(t3, i3) {
        e3.prototype.init.call(this), this.field_ = t3 || 0, this.dataChannel_ = i3 || 0, this.name_ = "CC" + (1 + (this.field_ << 1 | this.dataChannel_)), this.setConstants(), this.reset(), this.push = function(e4) {
          var t4, i4, n3, r3, a3 = 32639 & e4.ccData;
          a3 !== this.lastControlCode_ ? (4096 == (61440 & a3) ? this.lastControlCode_ = a3 : a3 !== this.PADDING_ && (this.lastControlCode_ = null), t4 = a3 >>> 8, i4 = 255 & a3, a3 === this.PADDING_ || (a3 === this.RESUME_CAPTION_LOADING_ ? this.mode_ = "popOn" : a3 === this.END_OF_CAPTION_ ? (this.mode_ = "popOn", this.clearFormatting(e4.pts), this.flushDisplayed(e4.pts), r3 = this.displayed_, this.displayed_ = this.nonDisplayed_, this.nonDisplayed_ = r3, this.startPts_ = e4.pts) : a3 === this.ROLL_UP_2_ROWS_ ? (this.rollUpRows_ = 2, this.setRollUp(e4.pts)) : a3 === this.ROLL_UP_3_ROWS_ ? (this.rollUpRows_ = 3, this.setRollUp(e4.pts)) : a3 === this.ROLL_UP_4_ROWS_ ? (this.rollUpRows_ = 4, this.setRollUp(e4.pts)) : a3 === this.CARRIAGE_RETURN_ ? (this.clearFormatting(e4.pts), this.flushDisplayed(e4.pts), this.shiftRowsUp_(), this.startPts_ = e4.pts) : a3 === this.BACKSPACE_ ? "popOn" === this.mode_ ? this.nonDisplayed_[this.row_] = this.nonDisplayed_[this.row_].slice(0, -1) : this.displayed_[this.row_] = this.displayed_[this.row_].slice(0, -1) : a3 === this.ERASE_DISPLAYED_MEMORY_ ? (this.flushDisplayed(e4.pts), this.displayed_ = Re2()) : a3 === this.ERASE_NON_DISPLAYED_MEMORY_ ? this.nonDisplayed_ = Re2() : a3 === this.RESUME_DIRECT_CAPTIONING_ ? ("paintOn" !== this.mode_ && (this.flushDisplayed(e4.pts), this.displayed_ = Re2()), this.mode_ = "paintOn", this.startPts_ = e4.pts) : this.isSpecialCharacter(t4, i4) ? (n3 = De2((t4 = (3 & t4) << 8) | i4), this[this.mode_](e4.pts, n3), this.column_++) : this.isExtCharacter(t4, i4) ? ("popOn" === this.mode_ ? this.nonDisplayed_[this.row_] = this.nonDisplayed_[this.row_].slice(0, -1) : this.displayed_[this.row_] = this.displayed_[this.row_].slice(0, -1), n3 = De2((t4 = (3 & t4) << 8) | i4), this[this.mode_](e4.pts, n3), this.column_++) : this.isMidRowCode(t4, i4) ? (this.clearFormatting(e4.pts), this[this.mode_](e4.pts, " "), this.column_++, 14 == (14 & i4) && this.addFormatting(e4.pts, ["i"]), 1 == (1 & i4) && this.addFormatting(e4.pts, ["u"])) : this.isOffsetControlCode(t4, i4) ? this.column_ += 3 & i4 : this.isPAC(t4, i4) ? (r3 = Ne2.indexOf(7968 & a3), "rollUp" === this.mode_ && (r3 - this.rollUpRows_ + 1 < 0 && (r3 = this.rollUpRows_ - 1), this.setRollUp(e4.pts, r3)), r3 !== this.row_ && (this.clearFormatting(e4.pts), this.row_ = r3), 1 & i4 && -1 === this.formatting_.indexOf("u") && this.addFormatting(e4.pts, ["u"]), 16 == (16 & a3) && (this.column_ = 4 * ((14 & a3) >> 1)), this.isColorPAC(i4) && 14 == (14 & i4) && this.addFormatting(e4.pts, ["i"])) : this.isNormalChar(t4) && (0 === i4 && (i4 = null), n3 = De2(t4), n3 += De2(i4), this[this.mode_](e4.pts, n3), this.column_ += n3.length))) : this.lastControlCode_ = null;
        };
      };
      Ue2.prototype = new j2(), Ue2.prototype.flushDisplayed = function(e3) {
        var t3 = this.displayed_.map(function(e4, t4) {
          try {
            return e4.trim();
          } catch (e5) {
            return this.trigger("log", { level: "warn", message: "Skipping a malformed 608 caption at index " + t4 + "." }), "";
          }
        }, this).join("\n").replace(/^\n+|\n+$/g, "");
        t3.length && this.trigger("data", { startPts: this.startPts_, endPts: e3, text: t3, stream: this.name_ });
      }, Ue2.prototype.reset = function() {
        this.mode_ = "popOn", this.topRow_ = 0, this.startPts_ = 0, this.displayed_ = Re2(), this.nonDisplayed_ = Re2(), this.lastControlCode_ = null, this.column_ = 0, this.row_ = 14, this.rollUpRows_ = 2, this.formatting_ = [];
      }, Ue2.prototype.setConstants = function() {
        0 === this.dataChannel_ ? (this.BASE_ = 16, this.EXT_ = 17, this.CONTROL_ = (20 | this.field_) << 8, this.OFFSET_ = 23) : 1 === this.dataChannel_ && (this.BASE_ = 24, this.EXT_ = 25, this.CONTROL_ = (28 | this.field_) << 8, this.OFFSET_ = 31), this.PADDING_ = 0, this.RESUME_CAPTION_LOADING_ = 32 | this.CONTROL_, this.END_OF_CAPTION_ = 47 | this.CONTROL_, this.ROLL_UP_2_ROWS_ = 37 | this.CONTROL_, this.ROLL_UP_3_ROWS_ = 38 | this.CONTROL_, this.ROLL_UP_4_ROWS_ = 39 | this.CONTROL_, this.CARRIAGE_RETURN_ = 45 | this.CONTROL_, this.RESUME_DIRECT_CAPTIONING_ = 41 | this.CONTROL_, this.BACKSPACE_ = 33 | this.CONTROL_, this.ERASE_DISPLAYED_MEMORY_ = 44 | this.CONTROL_, this.ERASE_NON_DISPLAYED_MEMORY_ = 46 | this.CONTROL_;
      }, Ue2.prototype.isSpecialCharacter = function(e3, t3) {
        return e3 === this.EXT_ && 48 <= t3 && t3 <= 63;
      }, Ue2.prototype.isExtCharacter = function(e3, t3) {
        return (e3 === this.EXT_ + 1 || e3 === this.EXT_ + 2) && 32 <= t3 && t3 <= 63;
      }, Ue2.prototype.isMidRowCode = function(e3, t3) {
        return e3 === this.EXT_ && 32 <= t3 && t3 <= 47;
      }, Ue2.prototype.isOffsetControlCode = function(e3, t3) {
        return e3 === this.OFFSET_ && 33 <= t3 && t3 <= 35;
      }, Ue2.prototype.isPAC = function(e3, t3) {
        return e3 >= this.BASE_ && e3 < this.BASE_ + 8 && 64 <= t3 && t3 <= 127;
      }, Ue2.prototype.isColorPAC = function(e3) {
        return 64 <= e3 && e3 <= 79 || 96 <= e3 && e3 <= 127;
      }, Ue2.prototype.isNormalChar = function(e3) {
        return 32 <= e3 && e3 <= 127;
      }, Ue2.prototype.setRollUp = function(e3, t3) {
        if ("rollUp" !== this.mode_ && (this.row_ = 14, this.mode_ = "rollUp", this.flushDisplayed(e3), this.nonDisplayed_ = Re2(), this.displayed_ = Re2()), void 0 !== t3 && t3 !== this.row_)
          for (var i3 = 0; i3 < this.rollUpRows_; i3++)
            this.displayed_[t3 - i3] = this.displayed_[this.row_ - i3], this.displayed_[this.row_ - i3] = "";
        void 0 === t3 && (t3 = this.row_), this.topRow_ = t3 - this.rollUpRows_ + 1;
      }, Ue2.prototype.addFormatting = function(e3, t3) {
        this.formatting_ = this.formatting_.concat(t3);
        t3 = t3.reduce(function(e4, t4) {
          return e4 + "<" + t4 + ">";
        }, "");
        this[this.mode_](e3, t3);
      }, Ue2.prototype.clearFormatting = function(e3) {
        var t3;
        this.formatting_.length && (t3 = this.formatting_.reverse().reduce(function(e4, t4) {
          return e4 + "</" + t4 + ">";
        }, ""), this.formatting_ = [], this[this.mode_](e3, t3));
      }, Ue2.prototype.popOn = function(e3, t3) {
        var i3 = this.nonDisplayed_[this.row_];
        this.nonDisplayed_[this.row_] = i3 += t3;
      }, Ue2.prototype.rollUp = function(e3, t3) {
        var i3 = this.displayed_[this.row_];
        this.displayed_[this.row_] = i3 += t3;
      }, Ue2.prototype.shiftRowsUp_ = function() {
        for (var e3 = 0; e3 < this.topRow_; e3++)
          this.displayed_[e3] = "";
        for (e3 = this.row_ + 1; e3 < 15; e3++)
          this.displayed_[e3] = "";
        for (e3 = this.topRow_; e3 < this.row_; e3++)
          this.displayed_[e3] = this.displayed_[e3 + 1];
        this.displayed_[this.row_] = "";
      }, Ue2.prototype.paintOn = function(e3, t3) {
        var i3 = this.displayed_[this.row_];
        this.displayed_[this.row_] = i3 += t3;
      };
      function Be2(e3, t3) {
        var i3 = 1;
        for (t3 < e3 && (i3 = -1); 4294967296 < Math.abs(t3 - e3); )
          e3 += 8589934592 * i3;
        return e3;
      }
      var Fe2 = { CaptionStream: Ie2, Cea608Stream: Ue2, Cea708Stream: Oe2 }, je2 = { H264_STREAM_TYPE: 27, ADTS_STREAM_TYPE: 15, METADATA_STREAM_TYPE: 21 }, e2 = function e3(t3) {
        var i3, n3;
        e3.prototype.init.call(this), this.type_ = t3 || "shared", this.push = function(e4) {
          "shared" !== this.type_ && e4.type !== this.type_ || (void 0 === n3 && (n3 = e4.dts), e4.dts = Be2(e4.dts, n3), e4.pts = Be2(e4.pts, n3), i3 = e4.dts, this.trigger("data", e4));
        }, this.flush = function() {
          n3 = i3, this.trigger("done");
        }, this.endTimeline = function() {
          this.flush(), this.trigger("endedtimeline");
        }, this.discontinuity = function() {
          i3 = n3 = void 0;
        }, this.reset = function() {
          this.discontinuity(), this.trigger("reset");
        };
      };
      e2.prototype = new j2();
      function He2(e3, t3, i3) {
        for (var n3 = "", r3 = t3; r3 < i3; r3++)
          n3 += "%" + ("00" + e3[r3].toString(16)).slice(-2);
        return n3;
      }
      function Ve2(e3, t3, i3) {
        return decodeURIComponent(He2(e3, t3, i3));
      }
      function qe2(e3) {
        return e3[0] << 21 | e3[1] << 14 | e3[2] << 7 | e3[3];
      }
      var We2 = e2, Ie2 = Be2, Ge2 = { TXXX: function(e3) {
        var t3;
        if (3 === e3.data[0]) {
          for (t3 = 1; t3 < e3.data.length; t3++)
            if (0 === e3.data[t3]) {
              e3.description = Ve2(e3.data, 1, t3), e3.value = Ve2(e3.data, t3 + 1, e3.data.length).replace(/\0*$/, "");
              break;
            }
          e3.data = e3.value;
        }
      }, WXXX: function(e3) {
        var t3;
        if (3 === e3.data[0]) {
          for (t3 = 1; t3 < e3.data.length; t3++)
            if (0 === e3.data[t3]) {
              e3.description = Ve2(e3.data, 1, t3), e3.url = Ve2(e3.data, t3 + 1, e3.data.length);
              break;
            }
        }
      }, PRIV: function(e3) {
        for (var t3, i3 = 0; i3 < e3.data.length; i3++)
          if (0 === e3.data[i3]) {
            e3.owner = (t3 = e3.data, unescape(He2(t3, 0, i3)));
            break;
          }
        e3.privateData = e3.data.subarray(i3 + 1), e3.data = e3.privateData;
      } }, ze2 = function(e3) {
        var t3, i3 = { descriptor: e3 && e3.descriptor }, u3 = 0, l3 = [], d3 = 0;
        if (ze2.prototype.init.call(this), this.dispatchType = je2.METADATA_STREAM_TYPE.toString(16), i3.descriptor)
          for (t3 = 0; t3 < i3.descriptor.length; t3++)
            this.dispatchType += ("00" + i3.descriptor[t3].toString(16)).slice(-2);
        this.push = function(e4) {
          var t4, i4, n3, r3, a3, s3, o3;
          if ("timed-metadata" === e4.type) {
            if (e4.dataAlignmentIndicator && (d3 = 0, l3.length = 0), 0 === l3.length && (e4.data.length < 10 || e4.data[0] !== "I".charCodeAt(0) || e4.data[1] !== "D".charCodeAt(0) || e4.data[2] !== "3".charCodeAt(0)))
              this.trigger("log", { level: "warn", message: "Skipping unrecognized metadata packet" });
            else if (l3.push(e4), d3 += e4.data.byteLength, 1 === l3.length && (u3 = qe2(e4.data.subarray(6, 10)), u3 += 10), !(d3 < u3)) {
              for (t4 = { data: new Uint8Array(u3), frames: [], pts: l3[0].pts, dts: l3[0].dts }, r3 = 0; r3 < u3; )
                t4.data.set(l3[0].data.subarray(0, u3 - r3), r3), r3 += l3[0].data.byteLength, d3 -= l3[0].data.byteLength, l3.shift();
              i4 = 10, 64 & t4.data[5] && (i4 += 4, i4 += qe2(t4.data.subarray(10, 14)), u3 -= qe2(t4.data.subarray(16, 20)));
              do {
                if ((n3 = qe2(t4.data.subarray(i4 + 4, i4 + 8))) < 1)
                  return void this.trigger("log", { level: "warn", message: "Malformed ID3 frame encountered. Skipping metadata parsing." });
              } while ((o3 = { id: String.fromCharCode(t4.data[i4], t4.data[i4 + 1], t4.data[i4 + 2], t4.data[i4 + 3]), data: t4.data.subarray(i4 + 10, i4 + n3 + 10) }).key = o3.id, Ge2[o3.id] && (Ge2[o3.id](o3), "com.apple.streaming.transportStreamTimestamp" === o3.owner && (s3 = (1 & (a3 = o3.data)[3]) << 30 | a3[4] << 22 | a3[5] << 14 | a3[6] << 6 | a3[7] >>> 2, s3 *= 4, s3 += 3 & a3[7], o3.timeStamp = s3, void 0 === t4.pts && void 0 === t4.dts && (t4.pts = o3.timeStamp, t4.dts = o3.timeStamp), this.trigger("timestamp", o3))), t4.frames.push(o3), i4 += 10, (i4 += n3) < u3);
              this.trigger("data", t4);
            }
          }
        };
      };
      ze2.prototype = new j2();
      var Xe2, Ke2, e2 = ze2, We2 = We2, Ye2 = function() {
        var r3 = new Uint8Array(188), a3 = 0;
        Ye2.prototype.init.call(this), this.push = function(e3) {
          var t3, i3 = 0, n3 = 188;
          for (a3 ? ((t3 = new Uint8Array(e3.byteLength + a3)).set(r3.subarray(0, a3)), t3.set(e3, a3), a3 = 0) : t3 = e3; n3 < t3.byteLength; )
            71 !== t3[i3] || 71 !== t3[n3] ? (i3++, n3++) : (this.trigger("data", t3.subarray(i3, n3)), i3 += 188, n3 += 188);
          i3 < t3.byteLength && (r3.set(t3.subarray(i3), 0), a3 = t3.byteLength - i3);
        }, this.flush = function() {
          188 === a3 && 71 === r3[0] && (this.trigger("data", r3), a3 = 0), this.trigger("done");
        }, this.endTimeline = function() {
          this.flush(), this.trigger("endedtimeline");
        }, this.reset = function() {
          a3 = 0, this.trigger("reset");
        };
      };
      Ye2.prototype = new j2(), (Xe2 = function() {
        var n3, r3, a3, s3;
        Xe2.prototype.init.call(this), (s3 = this).packetsWaitingForPmt = [], this.programMapTable = void 0, n3 = function(e3, t3) {
          var i3 = 0;
          t3.payloadUnitStartIndicator && (i3 += e3[i3] + 1), ("pat" === t3.type ? r3 : a3)(e3.subarray(i3), t3);
        }, r3 = function(e3, t3) {
          t3.section_number = e3[7], t3.last_section_number = e3[8], s3.pmtPid = (31 & e3[10]) << 8 | e3[11], t3.pmtPid = s3.pmtPid;
        }, a3 = function(e3, t3) {
          var i3, n4;
          if (1 & e3[5]) {
            for (s3.programMapTable = { video: null, audio: null, "timed-metadata": {} }, i3 = 3 + ((15 & e3[1]) << 8 | e3[2]) - 4, n4 = 12 + ((15 & e3[10]) << 8 | e3[11]); n4 < i3; ) {
              var r4 = e3[n4], a4 = (31 & e3[n4 + 1]) << 8 | e3[n4 + 2];
              r4 === je2.H264_STREAM_TYPE && null === s3.programMapTable.video ? s3.programMapTable.video = a4 : r4 === je2.ADTS_STREAM_TYPE && null === s3.programMapTable.audio ? s3.programMapTable.audio = a4 : r4 === je2.METADATA_STREAM_TYPE && (s3.programMapTable["timed-metadata"][a4] = r4), n4 += 5 + ((15 & e3[n4 + 3]) << 8 | e3[n4 + 4]);
            }
            t3.programMapTable = s3.programMapTable;
          }
        }, this.push = function(e3) {
          var t3 = {}, i3 = 4;
          if (t3.payloadUnitStartIndicator = !!(64 & e3[1]), t3.pid = 31 & e3[1], t3.pid <<= 8, t3.pid |= e3[2], 1 < (48 & e3[3]) >>> 4 && (i3 += e3[i3] + 1), 0 === t3.pid)
            t3.type = "pat", n3(e3.subarray(i3), t3), this.trigger("data", t3);
          else if (t3.pid === this.pmtPid)
            for (t3.type = "pmt", n3(e3.subarray(i3), t3), this.trigger("data", t3); this.packetsWaitingForPmt.length; )
              this.processPes_.apply(this, this.packetsWaitingForPmt.shift());
          else
            void 0 === this.programMapTable ? this.packetsWaitingForPmt.push([e3, i3, t3]) : this.processPes_(e3, i3, t3);
        }, this.processPes_ = function(e3, t3, i3) {
          i3.pid === this.programMapTable.video ? i3.streamType = je2.H264_STREAM_TYPE : i3.pid === this.programMapTable.audio ? i3.streamType = je2.ADTS_STREAM_TYPE : i3.streamType = this.programMapTable["timed-metadata"][i3.pid], i3.type = "pes", i3.data = e3.subarray(t3), this.trigger("data", i3);
        };
      }).prototype = new j2(), Xe2.STREAM_TYPES = { h264: 27, adts: 15 }, (Ke2 = function() {
        function n3(e3, t4, i3) {
          var n4, r4, a4, s4, o4 = new Uint8Array(e3.size), u3 = { type: t4 }, l3 = 0, d3 = 0;
          if (e3.data.length && !(e3.size < 9)) {
            for (u3.trackId = e3.data[0].pid, l3 = 0; l3 < e3.data.length; l3++)
              n4 = e3.data[l3], o4.set(n4.data, d3), d3 += n4.data.byteLength;
            a4 = u3, s4 = (r4 = o4)[0] << 16 | r4[1] << 8 | r4[2], a4.data = new Uint8Array(), 1 == s4 && (a4.packetLength = 6 + (r4[4] << 8 | r4[5]), a4.dataAlignmentIndicator = 0 != (4 & r4[6]), 192 & (s4 = r4[7]) && (a4.pts = (14 & r4[9]) << 27 | (255 & r4[10]) << 20 | (254 & r4[11]) << 12 | (255 & r4[12]) << 5 | (254 & r4[13]) >>> 3, a4.pts *= 4, a4.pts += (6 & r4[13]) >>> 1, a4.dts = a4.pts, 64 & s4 && (a4.dts = (14 & r4[14]) << 27 | (255 & r4[15]) << 20 | (254 & r4[16]) << 12 | (255 & r4[17]) << 5 | (254 & r4[18]) >>> 3, a4.dts *= 4, a4.dts += (6 & r4[18]) >>> 1)), a4.data = r4.subarray(9 + r4[8])), t4 = "video" === t4 || u3.packetLength <= e3.size, (i3 || t4) && (e3.size = 0, e3.data.length = 0), t4 && c3.trigger("data", u3);
          }
        }
        var t3, c3 = this, r3 = false, a3 = { data: [], size: 0 }, s3 = { data: [], size: 0 }, o3 = { data: [], size: 0 };
        Ke2.prototype.init.call(this), this.push = function(i3) {
          ({ pat: function() {
          }, pes: function() {
            var e3, t4;
            switch (i3.streamType) {
              case je2.H264_STREAM_TYPE:
                e3 = a3, t4 = "video";
                break;
              case je2.ADTS_STREAM_TYPE:
                e3 = s3, t4 = "audio";
                break;
              case je2.METADATA_STREAM_TYPE:
                e3 = o3, t4 = "timed-metadata";
                break;
              default:
                return;
            }
            i3.payloadUnitStartIndicator && n3(e3, t4, true), e3.data.push(i3), e3.size += i3.data.byteLength;
          }, pmt: function() {
            var e3 = { type: "metadata", tracks: [] };
            null !== (t3 = i3.programMapTable).video && e3.tracks.push({ timelineStartInfo: { baseMediaDecodeTime: 0 }, id: +t3.video, codec: "avc", type: "video" }), null !== t3.audio && e3.tracks.push({ timelineStartInfo: { baseMediaDecodeTime: 0 }, id: +t3.audio, codec: "adts", type: "audio" }), r3 = true, c3.trigger("data", e3);
          } })[i3.type]();
        }, this.reset = function() {
          a3.size = 0, a3.data.length = 0, s3.size = 0, s3.data.length = 0, this.trigger("reset");
        }, this.flushStreams_ = function() {
          n3(a3, "video"), n3(s3, "audio"), n3(o3, "timed-metadata");
        }, this.flush = function() {
          var e3;
          !r3 && t3 && (e3 = { type: "metadata", tracks: [] }, null !== t3.video && e3.tracks.push({ timelineStartInfo: { baseMediaDecodeTime: 0 }, id: +t3.video, codec: "avc", type: "video" }), null !== t3.audio && e3.tracks.push({ timelineStartInfo: { baseMediaDecodeTime: 0 }, id: +t3.audio, codec: "adts", type: "audio" }), c3.trigger("data", e3)), r3 = false, this.flushStreams_(), this.trigger("done");
        };
      }).prototype = new j2();
      var Qe2, $e2 = { PAT_PID: 0, MP2T_PACKET_LENGTH: 188, TransportPacketStream: Ye2, TransportParseStream: Xe2, ElementaryStream: Ke2, TimestampRolloverStream: We2, CaptionStream: Fe2.CaptionStream, Cea608Stream: Fe2.Cea608Stream, Cea708Stream: Fe2.Cea708Stream, MetadataStream: e2 };
      for (Qe2 in je2)
        je2.hasOwnProperty(Qe2) && ($e2[Qe2] = je2[Qe2]);
      var Je2 = $e2, Ze2 = ue2, et2 = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3, 7350], tt2 = function(u3) {
        var l3, d3 = 0;
        tt2.prototype.init.call(this), this.skipWarn_ = function(e3, t3) {
          this.trigger("log", { level: "warn", message: "adts skiping bytes " + e3 + " to " + t3 + " in frame " + d3 + " outside syncword" });
        }, this.push = function(e3) {
          var t3, i3, n3, r3, a3, s3, o3 = 0;
          if (u3 || (d3 = 0), "audio" === e3.type) {
            for (l3 && l3.length ? (n3 = l3, (l3 = new Uint8Array(n3.byteLength + e3.data.byteLength)).set(n3), l3.set(e3.data, n3.byteLength)) : l3 = e3.data; o3 + 7 < l3.length; )
              if (255 === l3[o3] && 240 == (246 & l3[o3 + 1])) {
                if ("number" == typeof s3 && (this.skipWarn_(s3, o3), s3 = null), i3 = 2 * (1 & ~l3[o3 + 1]), t3 = (3 & l3[o3 + 3]) << 11 | l3[o3 + 4] << 3 | (224 & l3[o3 + 5]) >> 5, a3 = (r3 = 1024 * (1 + (3 & l3[o3 + 6]))) * Ze2 / et2[(60 & l3[o3 + 2]) >>> 2], l3.byteLength - o3 < t3)
                  break;
                this.trigger("data", { pts: e3.pts + d3 * a3, dts: e3.dts + d3 * a3, sampleCount: r3, audioobjecttype: 1 + (l3[o3 + 2] >>> 6 & 3), channelcount: (1 & l3[o3 + 2]) << 2 | (192 & l3[o3 + 3]) >>> 6, samplerate: et2[(60 & l3[o3 + 2]) >>> 2], samplingfrequencyindex: (60 & l3[o3 + 2]) >>> 2, samplesize: 16, data: l3.subarray(o3 + 7 + i3, o3 + t3) }), d3++, o3 += t3;
              } else
                "number" != typeof s3 && (s3 = o3), o3++;
            "number" == typeof s3 && (this.skipWarn_(s3, o3), s3 = null), l3 = l3.subarray(o3);
          }
        }, this.flush = function() {
          d3 = 0, this.trigger("done");
        }, this.reset = function() {
          l3 = void 0, this.trigger("reset");
        }, this.endTimeline = function() {
          l3 = void 0, this.trigger("endedtimeline");
        };
      };
      tt2.prototype = new j2();
      var it2, nt2, rt2 = tt2, at2 = function(n3) {
        var r3 = n3.byteLength, a3 = 0, s3 = 0;
        this.length = function() {
          return 8 * r3;
        }, this.bitsAvailable = function() {
          return 8 * r3 + s3;
        }, this.loadWord = function() {
          var e3 = n3.byteLength - r3, t3 = new Uint8Array(4), i3 = Math.min(4, r3);
          if (0 === i3)
            throw new Error("no bytes available");
          t3.set(n3.subarray(e3, e3 + i3)), a3 = new DataView(t3.buffer).getUint32(0), s3 = 8 * i3, r3 -= i3;
        }, this.skipBits = function(e3) {
          var t3;
          e3 < s3 || (e3 -= s3, e3 -= 8 * (t3 = Math.floor(e3 / 8)), r3 -= t3, this.loadWord()), a3 <<= e3, s3 -= e3;
        }, this.readBits = function(e3) {
          var t3 = Math.min(s3, e3), i3 = a3 >>> 32 - t3;
          return 0 < (s3 -= t3) ? a3 <<= t3 : 0 < r3 && this.loadWord(), 0 < (t3 = e3 - t3) ? i3 << t3 | this.readBits(t3) : i3;
        }, this.skipLeadingZeros = function() {
          for (var e3 = 0; e3 < s3; ++e3)
            if (0 != (a3 & 2147483648 >>> e3))
              return a3 <<= e3, s3 -= e3, e3;
          return this.loadWord(), e3 + this.skipLeadingZeros();
        }, this.skipUnsignedExpGolomb = function() {
          this.skipBits(1 + this.skipLeadingZeros());
        }, this.skipExpGolomb = function() {
          this.skipBits(1 + this.skipLeadingZeros());
        }, this.readUnsignedExpGolomb = function() {
          var e3 = this.skipLeadingZeros();
          return this.readBits(e3 + 1) - 1;
        }, this.readExpGolomb = function() {
          var e3 = this.readUnsignedExpGolomb();
          return 1 & e3 ? 1 + e3 >>> 1 : -1 * (e3 >>> 1);
        }, this.readBoolean = function() {
          return 1 === this.readBits(1);
        }, this.readUnsignedByte = function() {
          return this.readBits(8);
        }, this.loadWord();
      }, st2 = function() {
        var n3, r3, a3 = 0;
        st2.prototype.init.call(this), this.push = function(e3) {
          for (var t3, i3 = (r3 = r3 ? ((t3 = new Uint8Array(r3.byteLength + e3.data.byteLength)).set(r3), t3.set(e3.data, r3.byteLength), t3) : e3.data).byteLength; a3 < i3 - 3; a3++)
            if (1 === r3[a3 + 2]) {
              n3 = a3 + 5;
              break;
            }
          for (; n3 < i3; )
            switch (r3[n3]) {
              case 0:
                if (0 !== r3[n3 - 1]) {
                  n3 += 2;
                  break;
                }
                if (0 !== r3[n3 - 2]) {
                  n3++;
                  break;
                }
                for (a3 + 3 !== n3 - 2 && this.trigger("data", r3.subarray(a3 + 3, n3 - 2)); 1 !== r3[++n3] && n3 < i3; )
                  ;
                a3 = n3 - 2, n3 += 3;
                break;
              case 1:
                if (0 !== r3[n3 - 1] || 0 !== r3[n3 - 2]) {
                  n3 += 3;
                  break;
                }
                this.trigger("data", r3.subarray(a3 + 3, n3 - 2)), a3 = n3 - 2, n3 += 3;
                break;
              default:
                n3 += 3;
            }
          r3 = r3.subarray(a3), n3 -= a3, a3 = 0;
        }, this.reset = function() {
          r3 = null, a3 = 0, this.trigger("reset");
        }, this.flush = function() {
          r3 && 3 < r3.byteLength && this.trigger("data", r3.subarray(a3 + 3)), r3 = null, a3 = 0, this.trigger("done");
        }, this.endTimeline = function() {
          this.flush(), this.trigger("endedtimeline");
        };
      };
      st2.prototype = new j2(), nt2 = { 100: true, 110: true, 122: true, 244: true, 44: true, 83: true, 86: true, 118: true, 128: true, 138: true, 139: true, 134: true }, (it2 = function() {
        var i3, n3, r3, a3, s3, o3, m3, t3 = new st2();
        it2.prototype.init.call(this), (i3 = this).push = function(e3) {
          "video" === e3.type && (n3 = e3.trackId, r3 = e3.pts, a3 = e3.dts, t3.push(e3));
        }, t3.on("data", function(e3) {
          var t4 = { trackId: n3, pts: r3, dts: a3, data: e3, nalUnitTypeCode: 31 & e3[0] };
          switch (t4.nalUnitTypeCode) {
            case 5:
              t4.nalUnitType = "slice_layer_without_partitioning_rbsp_idr";
              break;
            case 6:
              t4.nalUnitType = "sei_rbsp", t4.escapedRBSP = s3(e3.subarray(1));
              break;
            case 7:
              t4.nalUnitType = "seq_parameter_set_rbsp", t4.escapedRBSP = s3(e3.subarray(1)), t4.config = o3(t4.escapedRBSP);
              break;
            case 8:
              t4.nalUnitType = "pic_parameter_set_rbsp";
              break;
            case 9:
              t4.nalUnitType = "access_unit_delimiter_rbsp";
          }
          i3.trigger("data", t4);
        }), t3.on("done", function() {
          i3.trigger("done");
        }), t3.on("partialdone", function() {
          i3.trigger("partialdone");
        }), t3.on("reset", function() {
          i3.trigger("reset");
        }), t3.on("endedtimeline", function() {
          i3.trigger("endedtimeline");
        }), this.flush = function() {
          t3.flush();
        }, this.partialFlush = function() {
          t3.partialFlush();
        }, this.reset = function() {
          t3.reset();
        }, this.endTimeline = function() {
          t3.endTimeline();
        }, m3 = function(e3, t4) {
          for (var i4 = 8, n4 = 8, r4 = 0; r4 < e3; r4++)
            i4 = 0 === (n4 = 0 !== n4 ? (i4 + t4.readExpGolomb() + 256) % 256 : n4) ? i4 : n4;
        }, s3 = function(e3) {
          for (var t4 = e3.byteLength, i4 = [], n4 = 1; n4 < t4 - 2; )
            0 === e3[n4] && 0 === e3[n4 + 1] && 3 === e3[n4 + 2] ? (i4.push(n4 + 2), n4 += 2) : n4++;
          if (0 === i4.length)
            return e3;
          for (var r4 = t4 - i4.length, a4 = new Uint8Array(r4), s4 = 0, n4 = 0; n4 < r4; s4++, n4++)
            s4 === i4[0] && (s4++, i4.shift()), a4[n4] = e3[s4];
          return a4;
        }, o3 = function(e3) {
          var t4, i4, n4, r4, a4, s4 = 0, o4 = 0, u3 = 0, l3 = 0, d3 = [1, 1], c3 = new at2(e3), h3 = c3.readUnsignedByte(), p3 = c3.readUnsignedByte(), f3 = c3.readUnsignedByte();
          if (c3.skipUnsignedExpGolomb(), nt2[h3] && (3 === (i4 = c3.readUnsignedExpGolomb()) && c3.skipBits(1), c3.skipUnsignedExpGolomb(), c3.skipUnsignedExpGolomb(), c3.skipBits(1), c3.readBoolean()))
            for (r4 = 3 !== i4 ? 8 : 12, a4 = 0; a4 < r4; a4++)
              c3.readBoolean() && m3(a4 < 6 ? 16 : 64, c3);
          if (c3.skipUnsignedExpGolomb(), 0 === (n4 = c3.readUnsignedExpGolomb()))
            c3.readUnsignedExpGolomb();
          else if (1 === n4)
            for (c3.skipBits(1), c3.skipExpGolomb(), c3.skipExpGolomb(), t4 = c3.readUnsignedExpGolomb(), a4 = 0; a4 < t4; a4++)
              c3.skipExpGolomb();
          if (c3.skipUnsignedExpGolomb(), c3.skipBits(1), e3 = c3.readUnsignedExpGolomb(), i4 = c3.readUnsignedExpGolomb(), 0 === (n4 = c3.readBits(1)) && c3.skipBits(1), c3.skipBits(1), c3.readBoolean() && (s4 = c3.readUnsignedExpGolomb(), o4 = c3.readUnsignedExpGolomb(), u3 = c3.readUnsignedExpGolomb(), l3 = c3.readUnsignedExpGolomb()), c3.readBoolean() && c3.readBoolean()) {
            switch (c3.readUnsignedByte()) {
              case 1:
                d3 = [1, 1];
                break;
              case 2:
                d3 = [12, 11];
                break;
              case 3:
                d3 = [10, 11];
                break;
              case 4:
                d3 = [16, 11];
                break;
              case 5:
                d3 = [40, 33];
                break;
              case 6:
                d3 = [24, 11];
                break;
              case 7:
                d3 = [20, 11];
                break;
              case 8:
                d3 = [32, 11];
                break;
              case 9:
                d3 = [80, 33];
                break;
              case 10:
                d3 = [18, 11];
                break;
              case 11:
                d3 = [15, 11];
                break;
              case 12:
                d3 = [64, 33];
                break;
              case 13:
                d3 = [160, 99];
                break;
              case 14:
                d3 = [4, 3];
                break;
              case 15:
                d3 = [3, 2];
                break;
              case 16:
                d3 = [2, 1];
                break;
              case 255:
                d3 = [c3.readUnsignedByte() << 8 | c3.readUnsignedByte(), c3.readUnsignedByte() << 8 | c3.readUnsignedByte()];
            }
            d3 && (d3[0], d3[1]);
          }
          return { profileIdc: h3, levelIdc: f3, profileCompatibility: p3, width: 16 * (e3 + 1) - 2 * s4 - 2 * o4, height: (2 - n4) * (i4 + 1) * 16 - 2 * u3 - 2 * l3, sarRatio: d3 };
        };
      }).prototype = new j2();
      function ot2(e3, t3) {
        var i3 = 0 <= (i3 = e3[t3 + 6] << 21 | e3[t3 + 7] << 14 | e3[t3 + 8] << 7 | e3[t3 + 9]) ? i3 : 0;
        return (16 & e3[t3 + 5]) >> 4 ? i3 + 20 : i3 + 10;
      }
      function ut2(e3, t3) {
        return e3.length - t3 < 10 || e3[t3] !== "I".charCodeAt(0) || e3[t3 + 1] !== "D".charCodeAt(0) || e3[t3 + 2] !== "3".charCodeAt(0) ? t3 : ut2(e3, t3 += ot2(e3, t3));
      }
      function lt2(e3) {
        return e3[0] << 21 | e3[1] << 14 | e3[2] << 7 | e3[3];
      }
      var e2 = { H264Stream: it2, NalByteStream: st2 }, dt2 = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3, 7350], ct2 = { isLikelyAacData: function(e3) {
        var t3 = ut2(e3, 0);
        return e3.length >= t3 + 2 && 255 == (255 & e3[t3]) && 240 == (240 & e3[t3 + 1]) && 16 == (22 & e3[t3 + 1]);
      }, parseId3TagSize: ot2, parseAdtsSize: function(e3, t3) {
        var i3 = (224 & e3[t3 + 5]) >> 5, n3 = e3[t3 + 4] << 3;
        return 6144 & e3[t3 + 3] | n3 | i3;
      }, parseType: function(e3, t3) {
        return e3[t3] === "I".charCodeAt(0) && e3[t3 + 1] === "D".charCodeAt(0) && e3[t3 + 2] === "3".charCodeAt(0) ? "timed-metadata" : true & e3[t3] && 240 == (240 & e3[t3 + 1]) ? "audio" : null;
      }, parseSampleRate: function(e3) {
        for (var t3 = 0; t3 + 5 < e3.length; ) {
          if (255 === e3[t3] && 240 == (246 & e3[t3 + 1]))
            return dt2[(60 & e3[t3 + 2]) >>> 2];
          t3++;
        }
        return null;
      }, parseAacTimestamp: function(e3) {
        var t3, i3 = 10;
        64 & e3[5] && (i3 += 4, i3 += lt2(e3.subarray(10, 14)));
        do {
          if ((t3 = lt2(e3.subarray(i3 + 4, i3 + 8))) < 1)
            return null;
          if ("PRIV" === String.fromCharCode(e3[i3], e3[i3 + 1], e3[i3 + 2], e3[i3 + 3])) {
            for (var n3 = e3.subarray(i3 + 10, i3 + t3 + 10), r3 = 0; r3 < n3.byteLength; r3++)
              if (0 === n3[r3]) {
                if ("com.apple.streaming.transportStreamTimestamp" !== unescape(function(e4, t4, i4) {
                  for (var n4 = "", r4 = t4; r4 < i4; r4++)
                    n4 += "%" + ("00" + e4[r4].toString(16)).slice(-2);
                  return n4;
                }(n3, 0, r3)))
                  break;
                var a3 = n3.subarray(r3 + 1), s3 = (1 & a3[3]) << 30 | a3[4] << 22 | a3[5] << 14 | a3[6] << 6 | a3[7] >>> 2;
                return s3 *= 4, s3 += 3 & a3[7];
              }
          }
        } while (i3 += 10, (i3 += t3) < e3.byteLength);
        return null;
      } }, ht2 = function() {
        var a3 = new Uint8Array(), s3 = 0;
        ht2.prototype.init.call(this), this.setTimestamp = function(e3) {
          s3 = e3;
        }, this.push = function(e3) {
          var t3, i3, n3 = 0, r3 = 0;
          for (a3.length ? (i3 = a3.length, (a3 = new Uint8Array(e3.byteLength + i3)).set(a3.subarray(0, i3)), a3.set(e3, i3)) : a3 = e3; 3 <= a3.length - r3; )
            if (a3[r3] !== "I".charCodeAt(0) || a3[r3 + 1] !== "D".charCodeAt(0) || a3[r3 + 2] !== "3".charCodeAt(0))
              if (255 != (255 & a3[r3]) || 240 != (240 & a3[r3 + 1]))
                r3++;
              else {
                if (a3.length - r3 < 7)
                  break;
                if (r3 + (n3 = ct2.parseAdtsSize(a3, r3)) > a3.length)
                  break;
                t3 = { type: "audio", data: a3.subarray(r3, r3 + n3), pts: s3, dts: s3 }, this.trigger("data", t3), r3 += n3;
              }
            else {
              if (a3.length - r3 < 10)
                break;
              if (r3 + (n3 = ct2.parseId3TagSize(a3, r3)) > a3.length)
                break;
              t3 = { type: "timed-metadata", data: a3.subarray(r3, r3 + n3) }, this.trigger("data", t3), r3 += n3;
            }
          e3 = a3.length - r3, a3 = 0 < e3 ? a3.subarray(r3) : new Uint8Array();
        }, this.reset = function() {
          a3 = new Uint8Array(), this.trigger("reset");
        }, this.endTimeline = function() {
          a3 = new Uint8Array(), this.trigger("endedtimeline");
        };
      };
      ht2.prototype = new j2();
      function pt2(e3, t3) {
        t3.stream = e3, this.trigger("log", t3);
      }
      function ft2(e3, t3) {
        for (var i3 = Object.keys(t3), n3 = 0; n3 < i3.length; n3++) {
          var r3 = i3[n3];
          "headOfPipeline" !== r3 && t3[r3].on && t3[r3].on("log", pt2.bind(e3, r3));
        }
      }
      function mt2(e3, t3) {
        var i3;
        if (e3.length === t3.length) {
          for (i3 = 0; i3 < e3.length; i3++)
            if (e3[i3] !== t3[i3])
              return;
          return 1;
        }
      }
      function gt2(e3, t3, i3, n3, r3, a3) {
        return { start: { dts: e3, pts: e3 + (i3 - t3) }, end: { dts: e3 + (n3 - t3), pts: e3 + (r3 - i3) }, prependedContentDuration: a3, baseMediaDecodeTime: e3 };
      }
      var yt2, vt2, _t2, bt2 = ht2, Tt2 = ["audioobjecttype", "channelcount", "samplerate", "samplingfrequencyindex", "samplesize"], wt2 = ["width", "height", "profileIdc", "levelIdc", "profileCompatibility", "sarRatio"], St2 = e2.H264Stream, Et2 = ct2.isLikelyAacData, kt2 = ue2, Ct2 = function(a3, s3) {
        var o3 = [], u3 = 0, l3 = 0, d3 = 1 / 0, c3 = (s3 = s3 || {}).firstSequenceNumber || 0;
        Ct2.prototype.init.call(this), this.push = function(t3) {
          Te2(a3, t3), a3 && Tt2.forEach(function(e3) {
            a3[e3] = t3[e3];
          }), o3.push(t3);
        }, this.setEarliestDts = function(e3) {
          u3 = e3;
        }, this.setVideoBaseMediaDecodeTime = function(e3) {
          d3 = e3;
        }, this.setAudioAppendStart = function(e3) {
          l3 = e3;
        }, this.flush = function() {
          var e3, t3, i3, n3, r3;
          0 !== o3.length && (e3 = me2(o3, a3, u3), a3.baseMediaDecodeTime = be2(a3, s3.keepOriginalTimestamps), r3 = fe2(a3, e3, l3, d3), a3.samples = ge2(e3), t3 = K2(ye2(e3)), o3 = [], n3 = Y2(c3, [a3]), i3 = new Uint8Array(n3.byteLength + t3.byteLength), c3++, i3.set(n3), i3.set(t3, n3.byteLength), _e2(a3), n3 = Math.ceil(1024 * kt2 / a3.samplerate), e3.length && (n3 = e3.length * n3, this.trigger("segmentTimingInfo", gt2(ce2(a3.baseMediaDecodeTime, a3.samplerate), e3[0].dts, e3[0].pts, e3[0].dts + n3, e3[0].pts + n3, r3 || 0)), this.trigger("timingInfo", { start: e3[0].pts, end: e3[0].pts + n3 })), this.trigger("data", { track: a3, boxes: i3 })), this.trigger("done", "AudioSegmentStream");
        }, this.reset = function() {
          _e2(a3), o3 = [], this.trigger("reset");
        };
      };
      Ct2.prototype = new j2(), (yt2 = function(s3, a3) {
        var t3, i3, o3 = [], l3 = [], u3 = (a3 = a3 || {}).firstSequenceNumber || 0;
        yt2.prototype.init.call(this), delete s3.minPTS, this.gopCache_ = [], this.push = function(e3) {
          Te2(s3, e3), "seq_parameter_set_rbsp" !== e3.nalUnitType || t3 || (t3 = e3.config, s3.sps = [e3.data], wt2.forEach(function(e4) {
            s3[e4] = t3[e4];
          }, this)), "pic_parameter_set_rbsp" !== e3.nalUnitType || i3 || (i3 = e3.data, s3.pps = [e3.data]), o3.push(e3);
        }, this.flush = function() {
          for (var e3, t4, i4, n3 = 0; o3.length && "access_unit_delimiter_rbsp" !== o3[0].nalUnitType; )
            o3.shift();
          if (0 === o3.length)
            return this.resetStream_(), void this.trigger("done", "VideoSegmentStream");
          if (e3 = $2(o3), (t4 = J2(e3))[0][0].keyFrame || ((i4 = this.getGopForFusion_(o3[0], s3)) ? (n3 = i4.duration, t4.unshift(i4), t4.byteLength += i4.byteLength, t4.nalCount += i4.nalCount, t4.pts = i4.pts, t4.dts = i4.dts, t4.duration += i4.duration) : t4 = Z2(t4)), l3.length) {
            var r3 = a3.alignGopsAtEnd ? this.alignGopsAtEnd_(t4) : this.alignGopsAtStart_(t4);
            if (!r3)
              return this.gopCache_.unshift({ gop: t4.pop(), pps: s3.pps, sps: s3.sps }), this.gopCache_.length = Math.min(6, this.gopCache_.length), o3 = [], this.resetStream_(), void this.trigger("done", "VideoSegmentStream");
            _e2(s3), t4 = r3;
          }
          Te2(s3, t4), s3.samples = ee2(t4), e3 = K2(te2(t4)), s3.baseMediaDecodeTime = be2(s3, a3.keepOriginalTimestamps), this.trigger("processedGopsInfo", t4.map(function(e4) {
            return { pts: e4.pts, dts: e4.dts, byteLength: e4.byteLength };
          })), i4 = t4[0], r3 = t4[t4.length - 1], this.trigger("segmentTimingInfo", gt2(s3.baseMediaDecodeTime, i4.dts, i4.pts, r3.dts + r3.duration, r3.pts + r3.duration, n3)), this.trigger("timingInfo", { start: t4[0].pts, end: t4[t4.length - 1].pts + t4[t4.length - 1].duration }), this.gopCache_.unshift({ gop: t4.pop(), pps: s3.pps, sps: s3.sps }), this.gopCache_.length = Math.min(6, this.gopCache_.length), o3 = [], this.trigger("baseMediaDecodeTime", s3.baseMediaDecodeTime), this.trigger("timelineStartInfo", s3.timelineStartInfo), n3 = Y2(u3, [s3]), t4 = new Uint8Array(n3.byteLength + e3.byteLength), u3++, t4.set(n3), t4.set(e3, n3.byteLength), this.trigger("data", { track: s3, boxes: t4 }), this.resetStream_(), this.trigger("done", "VideoSegmentStream");
        }, this.reset = function() {
          this.resetStream_(), o3 = [], this.gopCache_.length = 0, l3.length = 0, this.trigger("reset");
        }, this.resetStream_ = function() {
          _e2(s3), i3 = t3 = void 0;
        }, this.getGopForFusion_ = function(e3) {
          for (var t4, i4, n3, r3 = 1 / 0, a4 = 0; a4 < this.gopCache_.length; a4++)
            i4 = (n3 = this.gopCache_[a4]).gop, s3.pps && mt2(s3.pps[0], n3.pps[0]) && s3.sps && mt2(s3.sps[0], n3.sps[0]) && (i4.dts < s3.timelineStartInfo.dts || -1e4 <= (i4 = e3.dts - i4.dts - i4.duration) && i4 <= 45e3 && (!t4 || i4 < r3) && (t4 = n3, r3 = i4));
          return t4 ? t4.gop : null;
        }, this.alignGopsAtStart_ = function(e3) {
          for (var t4, i4, n3, r3, a4 = e3.byteLength, s4 = e3.nalCount, o4 = e3.duration, u4 = t4 = 0; u4 < l3.length && t4 < e3.length && (i4 = l3[u4], n3 = e3[t4], i4.pts !== n3.pts); )
            n3.pts > i4.pts ? u4++ : (t4++, a4 -= n3.byteLength, s4 -= n3.nalCount, o4 -= n3.duration);
          return 0 === t4 ? e3 : t4 === e3.length ? null : ((r3 = e3.slice(t4)).byteLength = a4, r3.duration = o4, r3.nalCount = s4, r3.pts = r3[0].pts, r3.dts = r3[0].dts, r3);
        }, this.alignGopsAtEnd_ = function(e3) {
          for (var t4, i4, n3 = l3.length - 1, r3 = e3.length - 1, a4 = null, s4 = false; 0 <= n3 && 0 <= r3; ) {
            if (t4 = l3[n3], i4 = e3[r3], t4.pts === i4.pts) {
              s4 = true;
              break;
            }
            t4.pts > i4.pts ? n3-- : (n3 === l3.length - 1 && (a4 = r3), r3--);
          }
          if (!s4 && null === a4)
            return null;
          if (0 === (u4 = s4 ? r3 : a4))
            return e3;
          var o4 = e3.slice(u4), u4 = o4.reduce(function(e4, t5) {
            return e4.byteLength += t5.byteLength, e4.duration += t5.duration, e4.nalCount += t5.nalCount, e4;
          }, { byteLength: 0, duration: 0, nalCount: 0 });
          return o4.byteLength = u4.byteLength, o4.duration = u4.duration, o4.nalCount = u4.nalCount, o4.pts = o4[0].pts, o4.dts = o4[0].dts, o4;
        }, this.alignGopsWith = function(e3) {
          l3 = e3;
        };
      }).prototype = new j2(), (_t2 = function(e3, t3) {
        this.numberOfTracks = 0, this.metadataStream = t3, "undefined" != typeof (e3 = e3 || {}).remux ? this.remuxTracks = !!e3.remux : this.remuxTracks = true, "boolean" == typeof e3.keepOriginalTimestamps ? this.keepOriginalTimestamps = e3.keepOriginalTimestamps : this.keepOriginalTimestamps = false, this.pendingTracks = [], this.videoTrack = null, this.pendingBoxes = [], this.pendingCaptions = [], this.pendingMetadata = [], this.pendingBytes = 0, this.emittedTracks = 0, _t2.prototype.init.call(this), this.push = function(e4) {
          return e4.text ? this.pendingCaptions.push(e4) : e4.frames ? this.pendingMetadata.push(e4) : (this.pendingTracks.push(e4.track), this.pendingBytes += e4.boxes.byteLength, "video" === e4.track.type && (this.videoTrack = e4.track, this.pendingBoxes.push(e4.boxes)), void ("audio" === e4.track.type && (this.audioTrack = e4.track, this.pendingBoxes.unshift(e4.boxes))));
        };
      }).prototype = new j2(), _t2.prototype.flush = function(e3) {
        var t3, i3, n3, r3 = 0, a3 = { captions: [], captionStreams: {}, metadata: [], info: {} }, s3 = 0;
        if (this.pendingTracks.length < this.numberOfTracks) {
          if ("VideoSegmentStream" !== e3 && "AudioSegmentStream" !== e3)
            return;
          if (this.remuxTracks)
            return;
          if (0 === this.pendingTracks.length)
            return this.emittedTracks++, void (this.emittedTracks >= this.numberOfTracks && (this.trigger("done"), this.emittedTracks = 0));
        }
        if (this.videoTrack ? (s3 = this.videoTrack.timelineStartInfo.pts, wt2.forEach(function(e4) {
          a3.info[e4] = this.videoTrack[e4];
        }, this)) : this.audioTrack && (s3 = this.audioTrack.timelineStartInfo.pts, Tt2.forEach(function(e4) {
          a3.info[e4] = this.audioTrack[e4];
        }, this)), this.videoTrack || this.audioTrack) {
          for (1 === this.pendingTracks.length ? a3.type = this.pendingTracks[0].type : a3.type = "combined", this.emittedTracks += this.pendingTracks.length, e3 = Q2(this.pendingTracks), a3.initSegment = new Uint8Array(e3.byteLength), a3.initSegment.set(e3), a3.data = new Uint8Array(this.pendingBytes), n3 = 0; n3 < this.pendingBoxes.length; n3++)
            a3.data.set(this.pendingBoxes[n3], r3), r3 += this.pendingBoxes[n3].byteLength;
          for (n3 = 0; n3 < this.pendingCaptions.length; n3++)
            (t3 = this.pendingCaptions[n3]).startTime = pe2(t3.startPts, s3, this.keepOriginalTimestamps), t3.endTime = pe2(t3.endPts, s3, this.keepOriginalTimestamps), a3.captionStreams[t3.stream] = true, a3.captions.push(t3);
          for (n3 = 0; n3 < this.pendingMetadata.length; n3++)
            (i3 = this.pendingMetadata[n3]).cueTime = pe2(i3.pts, s3, this.keepOriginalTimestamps), a3.metadata.push(i3);
          for (a3.metadata.dispatchType = this.metadataStream.dispatchType, this.pendingTracks.length = 0, this.videoTrack = null, this.pendingBoxes.length = 0, this.pendingCaptions.length = 0, this.pendingBytes = 0, this.pendingMetadata.length = 0, this.trigger("data", a3), n3 = 0; n3 < a3.captions.length; n3++)
            t3 = a3.captions[n3], this.trigger("caption", t3);
          for (n3 = 0; n3 < a3.metadata.length; n3++)
            i3 = a3.metadata[n3], this.trigger("id3Frame", i3);
        }
        this.emittedTracks >= this.numberOfTracks && (this.trigger("done"), this.emittedTracks = 0);
      }, _t2.prototype.setRemux = function(e3) {
        this.remuxTracks = e3;
      }, (vt2 = function(n3) {
        var r3, a3, s3 = this, i3 = true;
        vt2.prototype.init.call(this), this.baseMediaDecodeTime = (n3 = n3 || {}).baseMediaDecodeTime || 0, this.transmuxPipeline_ = {}, this.setupAacPipeline = function() {
          var t3 = {};
          (this.transmuxPipeline_ = t3).type = "aac", t3.metadataStream = new Je2.MetadataStream(), t3.aacStream = new bt2(), t3.audioTimestampRolloverStream = new Je2.TimestampRolloverStream("audio"), t3.timedMetadataTimestampRolloverStream = new Je2.TimestampRolloverStream("timed-metadata"), t3.adtsStream = new rt2(), t3.coalesceStream = new _t2(n3, t3.metadataStream), t3.headOfPipeline = t3.aacStream, t3.aacStream.pipe(t3.audioTimestampRolloverStream).pipe(t3.adtsStream), t3.aacStream.pipe(t3.timedMetadataTimestampRolloverStream).pipe(t3.metadataStream).pipe(t3.coalesceStream), t3.metadataStream.on("timestamp", function(e3) {
            t3.aacStream.setTimestamp(e3.timeStamp);
          }), t3.aacStream.on("data", function(e3) {
            "timed-metadata" !== e3.type && "audio" !== e3.type || t3.audioSegmentStream || (a3 = a3 || { timelineStartInfo: { baseMediaDecodeTime: s3.baseMediaDecodeTime }, codec: "adts", type: "audio" }, t3.coalesceStream.numberOfTracks++, t3.audioSegmentStream = new Ct2(a3, n3), t3.audioSegmentStream.on("log", s3.getLogTrigger_("audioSegmentStream")), t3.audioSegmentStream.on("timingInfo", s3.trigger.bind(s3, "audioTimingInfo")), t3.adtsStream.pipe(t3.audioSegmentStream).pipe(t3.coalesceStream), s3.trigger("trackinfo", { hasAudio: !!a3, hasVideo: !!r3 }));
          }), t3.coalesceStream.on("data", this.trigger.bind(this, "data")), t3.coalesceStream.on("done", this.trigger.bind(this, "done")), ft2(this, t3);
        }, this.setupTsPipeline = function() {
          var i4 = {};
          (this.transmuxPipeline_ = i4).type = "ts", i4.metadataStream = new Je2.MetadataStream(), i4.packetStream = new Je2.TransportPacketStream(), i4.parseStream = new Je2.TransportParseStream(), i4.elementaryStream = new Je2.ElementaryStream(), i4.timestampRolloverStream = new Je2.TimestampRolloverStream(), i4.adtsStream = new rt2(), i4.h264Stream = new St2(), i4.captionStream = new Je2.CaptionStream(n3), i4.coalesceStream = new _t2(n3, i4.metadataStream), i4.headOfPipeline = i4.packetStream, i4.packetStream.pipe(i4.parseStream).pipe(i4.elementaryStream).pipe(i4.timestampRolloverStream), i4.timestampRolloverStream.pipe(i4.h264Stream), i4.timestampRolloverStream.pipe(i4.adtsStream), i4.timestampRolloverStream.pipe(i4.metadataStream).pipe(i4.coalesceStream), i4.h264Stream.pipe(i4.captionStream).pipe(i4.coalesceStream), i4.elementaryStream.on("data", function(e3) {
            var t3;
            if ("metadata" === e3.type) {
              for (t3 = e3.tracks.length; t3--; )
                r3 || "video" !== e3.tracks[t3].type ? a3 || "audio" !== e3.tracks[t3].type || ((a3 = e3.tracks[t3]).timelineStartInfo.baseMediaDecodeTime = s3.baseMediaDecodeTime) : (r3 = e3.tracks[t3]).timelineStartInfo.baseMediaDecodeTime = s3.baseMediaDecodeTime;
              r3 && !i4.videoSegmentStream && (i4.coalesceStream.numberOfTracks++, i4.videoSegmentStream = new yt2(r3, n3), i4.videoSegmentStream.on("log", s3.getLogTrigger_("videoSegmentStream")), i4.videoSegmentStream.on("timelineStartInfo", function(e4) {
                a3 && !n3.keepOriginalTimestamps && (a3.timelineStartInfo = e4, i4.audioSegmentStream.setEarliestDts(e4.dts - s3.baseMediaDecodeTime));
              }), i4.videoSegmentStream.on("processedGopsInfo", s3.trigger.bind(s3, "gopInfo")), i4.videoSegmentStream.on("segmentTimingInfo", s3.trigger.bind(s3, "videoSegmentTimingInfo")), i4.videoSegmentStream.on("baseMediaDecodeTime", function(e4) {
                a3 && i4.audioSegmentStream.setVideoBaseMediaDecodeTime(e4);
              }), i4.videoSegmentStream.on("timingInfo", s3.trigger.bind(s3, "videoTimingInfo")), i4.h264Stream.pipe(i4.videoSegmentStream).pipe(i4.coalesceStream)), a3 && !i4.audioSegmentStream && (i4.coalesceStream.numberOfTracks++, i4.audioSegmentStream = new Ct2(a3, n3), i4.audioSegmentStream.on("log", s3.getLogTrigger_("audioSegmentStream")), i4.audioSegmentStream.on("timingInfo", s3.trigger.bind(s3, "audioTimingInfo")), i4.audioSegmentStream.on("segmentTimingInfo", s3.trigger.bind(s3, "audioSegmentTimingInfo")), i4.adtsStream.pipe(i4.audioSegmentStream).pipe(i4.coalesceStream)), s3.trigger("trackinfo", { hasAudio: !!a3, hasVideo: !!r3 });
            }
          }), i4.coalesceStream.on("data", this.trigger.bind(this, "data")), i4.coalesceStream.on("id3Frame", function(e3) {
            e3.dispatchType = i4.metadataStream.dispatchType, s3.trigger("id3Frame", e3);
          }), i4.coalesceStream.on("caption", this.trigger.bind(this, "caption")), i4.coalesceStream.on("done", this.trigger.bind(this, "done")), ft2(this, i4);
        }, this.setBaseMediaDecodeTime = function(e3) {
          var t3 = this.transmuxPipeline_;
          n3.keepOriginalTimestamps || (this.baseMediaDecodeTime = e3), a3 && (a3.timelineStartInfo.dts = void 0, a3.timelineStartInfo.pts = void 0, _e2(a3), t3.audioTimestampRolloverStream && t3.audioTimestampRolloverStream.discontinuity()), r3 && (t3.videoSegmentStream && (t3.videoSegmentStream.gopCache_ = []), r3.timelineStartInfo.dts = void 0, r3.timelineStartInfo.pts = void 0, _e2(r3), t3.captionStream.reset()), t3.timestampRolloverStream && t3.timestampRolloverStream.discontinuity();
        }, this.setAudioAppendStart = function(e3) {
          a3 && this.transmuxPipeline_.audioSegmentStream.setAudioAppendStart(e3);
        }, this.setRemux = function(e3) {
          var t3 = this.transmuxPipeline_;
          n3.remux = e3, t3 && t3.coalesceStream && t3.coalesceStream.setRemux(e3);
        }, this.alignGopsWith = function(e3) {
          r3 && this.transmuxPipeline_.videoSegmentStream && this.transmuxPipeline_.videoSegmentStream.alignGopsWith(e3);
        }, this.getLogTrigger_ = function(t3) {
          var i4 = this;
          return function(e3) {
            e3.stream = t3, i4.trigger("log", e3);
          };
        }, this.push = function(e3) {
          var t3;
          i3 && ((t3 = Et2(e3)) && "aac" !== this.transmuxPipeline_.type ? this.setupAacPipeline() : t3 || "ts" === this.transmuxPipeline_.type || this.setupTsPipeline(), i3 = false), this.transmuxPipeline_.headOfPipeline.push(e3);
        }, this.flush = function() {
          i3 = true, this.transmuxPipeline_.headOfPipeline.flush();
        }, this.endTimeline = function() {
          this.transmuxPipeline_.headOfPipeline.endTimeline();
        }, this.reset = function() {
          this.transmuxPipeline_.headOfPipeline && this.transmuxPipeline_.headOfPipeline.reset();
        }, this.resetCaptions = function() {
          this.transmuxPipeline_.captionStream && this.transmuxPipeline_.captionStream.reset();
        };
      }).prototype = new j2();
      function It2(e3, d3) {
        var i3 = Mt2(e3, ["moof", "traf"]), e3 = Mt2(e3, ["mdat"]), c3 = {}, n3 = [];
        return e3.forEach(function(e4, t3) {
          t3 = i3[t3];
          n3.push({ mdat: e4, traf: t3 });
        }), n3.forEach(function(e4) {
          var t3, i4, n4, r3, a3, s3 = e4.mdat, o3 = e4.traf, u3 = Mt2(o3, ["tfhd"]), l3 = Ht2(u3[0]), e4 = l3.trackId, u3 = Mt2(o3, ["tfdt"]), u3 = 0 < u3.length ? Bt2(u3[0]).baseMediaDecodeTime : 0, o3 = Mt2(o3, ["trun"]);
          d3 === e4 && 0 < o3.length && (o3 = o3, t3 = u3, i4 = (l3 = l3).defaultSampleDuration || 0, n4 = l3.defaultSampleSize || 0, r3 = l3.trackId, a3 = [], o3.forEach(function(e5) {
            e5 = jt2(e5).samples;
            e5.forEach(function(e6) {
              void 0 === e6.duration && (e6.duration = i4), void 0 === e6.size && (e6.size = n4), e6.trackId = r3, e6.dts = t3, void 0 === e6.compositionTimeOffset && (e6.compositionTimeOffset = 0), "bigint" == typeof t3 ? (e6.pts = t3 + Vt2.BigInt(e6.compositionTimeOffset), t3 += Vt2.BigInt(e6.duration)) : (e6.pts = t3 + e6.compositionTimeOffset, t3 += e6.duration);
            }), a3 = a3.concat(e5);
          }), s3 = function(e5, t4, i5) {
            for (var n5, r4, a4 = new DataView(e5.buffer, e5.byteOffset, e5.byteLength), s4 = { logs: [], seiNals: [] }, o4 = 0; o4 + 4 < e5.length; o4 += n5)
              if (n5 = a4.getUint32(o4), o4 += 4, !(n5 <= 0))
                switch (31 & e5[o4]) {
                  case 6:
                    var u4 = e5.subarray(o4 + 1, o4 + 1 + n5), l4 = function(e6, t5) {
                      for (var i6 = e6, n6 = 0; n6 < t5.length; n6++) {
                        var r5 = t5[n6];
                        if (i6 < r5.size)
                          return r5;
                        i6 -= r5.size;
                      }
                      return null;
                    }(o4, t4), u4 = { nalUnitType: "sei_rbsp", size: n5, data: u4, escapedRBSP: qt2(u4), trackId: i5 };
                    if (l4)
                      u4.pts = l4.pts, u4.dts = l4.dts, r4 = l4;
                    else {
                      if (!r4) {
                        s4.logs.push({ level: "warn", message: "We've encountered a nal unit without data at " + o4 + " for trackId " + i5 + ". See mux.js#223." });
                        break;
                      }
                      u4.pts = r4.pts, u4.dts = r4.dts;
                    }
                    s4.seiNals.push(u4);
                }
            return s4;
          }(s3, a3, e4), c3[e4] || (c3[e4] = { seiNals: [], logs: [] }), c3[e4].seiNals = c3[e4].seiNals.concat(s3.seiNals), c3[e4].logs = c3[e4].logs.concat(s3.logs));
        }), c3;
      }
      function xt2(e3) {
        var t3 = 31 & e3[1];
        return t3 <<= 8, t3 |= e3[2];
      }
      function At2(e3) {
        return !!(64 & e3[1]);
      }
      function Pt2(e3) {
        var t3 = 0;
        return 1 < (48 & e3[3]) >>> 4 && (t3 += e3[4] + 1), t3;
      }
      function Lt2(e3) {
        switch (e3) {
          case 5:
            return "slice_layer_without_partitioning_rbsp_idr";
          case 6:
            return "sei_rbsp";
          case 7:
            return "seq_parameter_set_rbsp";
          case 8:
            return "pic_parameter_set_rbsp";
          case 9:
            return "access_unit_delimiter_rbsp";
          default:
            return null;
        }
      }
      var Ot2 = { Transmuxer: vt2, VideoSegmentStream: yt2, AudioSegmentStream: Ct2, AUDIO_PROPERTIES: Tt2, VIDEO_PROPERTIES: wt2, generateSegmentTimingInfo: gt2 }, e2 = function(e3) {
        return e3 >>> 0;
      }, Dt2 = function(e3) {
        var t3 = "";
        return t3 += String.fromCharCode(e3[0]), t3 += String.fromCharCode(e3[1]), t3 += String.fromCharCode(e3[2]), t3 += String.fromCharCode(e3[3]);
      }, Rt2 = e2, Mt2 = function e3(t3, i3) {
        var n3, r3, a3, s3 = [];
        if (!i3.length)
          return null;
        for (n3 = 0; n3 < t3.byteLength; )
          r3 = Rt2(t3[n3] << 24 | t3[n3 + 1] << 16 | t3[n3 + 2] << 8 | t3[n3 + 3]), a3 = Dt2(t3.subarray(n3 + 4, n3 + 8)), r3 = 1 < r3 ? n3 + r3 : t3.byteLength, a3 === i3[0] && (1 === i3.length ? s3.push(t3.subarray(n3 + 8, r3)) : (a3 = e3(t3.subarray(n3 + 8, r3), i3.slice(1))).length && (s3 = s3.concat(a3))), n3 = r3;
        return s3;
      }, Nt2 = e2, Ut2 = V2.getUint64, Bt2 = function(e3) {
        var t3 = { version: e3[0], flags: new Uint8Array(e3.subarray(1, 4)) };
        return 1 === t3.version ? t3.baseMediaDecodeTime = Ut2(e3.subarray(4)) : t3.baseMediaDecodeTime = Nt2(e3[4] << 24 | e3[5] << 16 | e3[6] << 8 | e3[7]), t3;
      }, Ft2 = function(e3) {
        return { isLeading: (12 & e3[0]) >>> 2, dependsOn: 3 & e3[0], isDependedOn: (192 & e3[1]) >>> 6, hasRedundancy: (48 & e3[1]) >>> 4, paddingValue: (14 & e3[1]) >>> 1, isNonSyncSample: 1 & e3[1], degradationPriority: e3[2] << 8 | e3[3] };
      }, jt2 = function(e3) {
        var t3, i3 = { version: e3[0], flags: new Uint8Array(e3.subarray(1, 4)), samples: [] }, n3 = new DataView(e3.buffer, e3.byteOffset, e3.byteLength), r3 = 1 & i3.flags[2], a3 = 4 & i3.flags[2], s3 = 1 & i3.flags[1], o3 = 2 & i3.flags[1], u3 = 4 & i3.flags[1], l3 = 8 & i3.flags[1], d3 = n3.getUint32(4), c3 = 8;
        for (r3 && (i3.dataOffset = n3.getInt32(c3), c3 += 4), a3 && d3 && (t3 = { flags: Ft2(e3.subarray(c3, c3 + 4)) }, c3 += 4, s3 && (t3.duration = n3.getUint32(c3), c3 += 4), o3 && (t3.size = n3.getUint32(c3), c3 += 4), l3 && (1 === i3.version ? t3.compositionTimeOffset = n3.getInt32(c3) : t3.compositionTimeOffset = n3.getUint32(c3), c3 += 4), i3.samples.push(t3), d3--); d3--; )
          t3 = {}, s3 && (t3.duration = n3.getUint32(c3), c3 += 4), o3 && (t3.size = n3.getUint32(c3), c3 += 4), u3 && (t3.flags = Ft2(e3.subarray(c3, c3 + 4)), c3 += 4), l3 && (1 === i3.version ? t3.compositionTimeOffset = n3.getInt32(c3) : t3.compositionTimeOffset = n3.getUint32(c3), c3 += 4), i3.samples.push(t3);
        return i3;
      }, Ht2 = function(e3) {
        var t3 = new DataView(e3.buffer, e3.byteOffset, e3.byteLength), i3 = { version: e3[0], flags: new Uint8Array(e3.subarray(1, 4)), trackId: t3.getUint32(4) }, n3 = 1 & i3.flags[2], r3 = 2 & i3.flags[2], a3 = 8 & i3.flags[2], s3 = 16 & i3.flags[2], o3 = 32 & i3.flags[2], u3 = 65536 & i3.flags[0], l3 = 131072 & i3.flags[0], e3 = 8;
        return n3 && (e3 += 4, i3.baseDataOffset = t3.getUint32(12), e3 += 4), r3 && (i3.sampleDescriptionIndex = t3.getUint32(e3), e3 += 4), a3 && (i3.defaultSampleDuration = t3.getUint32(e3), e3 += 4), s3 && (i3.defaultSampleSize = t3.getUint32(e3), e3 += 4), o3 && (i3.defaultSampleFlags = t3.getUint32(e3)), u3 && (i3.durationIsEmpty = true), !n3 && l3 && (i3.baseDataOffsetIsMoof = true), i3;
      }, j2 = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof commonjsGlobal ? commonjsGlobal : "undefined" != typeof self ? self : {}, j2 = "undefined" != typeof window ? window : "undefined" != typeof j2 ? j2 : "undefined" != typeof self ? self : {}, Vt2 = j2, qt2 = ke2, Wt2 = Fe2.CaptionStream, Gt2 = function() {
        var t3, r3, a3, s3, o3, i3, n3 = false;
        this.isInitialized = function() {
          return n3;
        }, this.init = function(e3) {
          t3 = new Wt2(), n3 = true, i3 = !!e3 && e3.isPartial, t3.on("data", function(e4) {
            e4.startTime = e4.startPts / s3, e4.endTime = e4.endPts / s3, o3.captions.push(e4), o3.captionStreams[e4.stream] = true;
          }), t3.on("log", function(e4) {
            o3.logs.push(e4);
          });
        }, this.isNewInit = function(e3, t4) {
          return !(e3 && 0 === e3.length || t4 && "object" == typeof t4 && 0 === Object.keys(t4).length) && (a3 !== e3[0] || s3 !== t4[a3]);
        }, this.parse = function(e3, t4, i4) {
          if (!this.isInitialized())
            return null;
          if (!t4 || !i4)
            return null;
          if (this.isNewInit(t4, i4))
            a3 = t4[0], s3 = i4[a3];
          else if (null === a3 || !s3)
            return r3.push(e3), null;
          for (; 0 < r3.length; ) {
            var n4 = r3.shift();
            this.parse(n4, t4, i4);
          }
          return (e3 = function(e4, t5, i5) {
            if (null === t5)
              return null;
            t5 = It2(e4, t5)[t5] || {};
            return { seiNals: t5.seiNals, logs: t5.logs, timescale: i5 };
          }(e3, a3, s3)) && e3.logs && (o3.logs = o3.logs.concat(e3.logs)), null !== e3 && e3.seiNals ? (this.pushNals(e3.seiNals), this.flushStream(), o3) : o3.logs.length ? { logs: o3.logs, captions: [], captionStreams: [] } : null;
        }, this.pushNals = function(e3) {
          if (!this.isInitialized() || !e3 || 0 === e3.length)
            return null;
          e3.forEach(function(e4) {
            t3.push(e4);
          });
        }, this.flushStream = function() {
          if (!this.isInitialized())
            return null;
          i3 ? t3.partialFlush() : t3.flush();
        }, this.clearParsedCaptions = function() {
          o3.captions = [], o3.captionStreams = {}, o3.logs = [];
        }, this.resetCaptionStream = function() {
          if (!this.isInitialized())
            return null;
          t3.reset();
        }, this.clearAllCaptions = function() {
          this.clearParsedCaptions(), this.resetCaptionStream();
        }, this.reset = function() {
          r3 = [], s3 = a3 = null, o3 ? this.clearParsedCaptions() : o3 = { captions: [], captionStreams: {}, logs: [] }, this.resetCaptionStream();
        }, this.reset();
      }, zt2 = e2, Xt2 = function(e3) {
        return ("00" + e3.toString(16)).slice(-2);
      }, Kt2 = V2.getUint64, j2 = function(e3) {
        return Mt2(e3, ["moov", "trak"]).reduce(function(e4, t3) {
          var i3, n3, r3 = Mt2(t3, ["tkhd"])[0];
          return r3 ? (i3 = r3[0], r3 = zt2(r3[n3 = 0 === i3 ? 12 : 20] << 24 | r3[1 + n3] << 16 | r3[2 + n3] << 8 | r3[3 + n3]), (t3 = Mt2(t3, ["mdia", "mdhd"])[0]) ? (i3 = t3[0], e4[r3] = zt2(t3[n3 = 0 === i3 ? 12 : 20] << 24 | t3[1 + n3] << 16 | t3[2 + n3] << 8 | t3[3 + n3]), e4) : null) : null;
        }, {});
      }, ke2 = function(a3, e3) {
        e3 = Mt2(e3, ["moof", "traf"]).reduce(function(e4, t3) {
          var i3, n3 = Mt2(t3, ["tfhd"])[0], r3 = zt2(n3[4] << 24 | n3[5] << 16 | n3[6] << 8 | n3[7]), n3 = a3[r3] || 9e4, r3 = Mt2(t3, ["tfdt"])[0], t3 = new DataView(r3.buffer, r3.byteOffset, r3.byteLength), t3 = 1 === r3[0] ? Kt2(r3.subarray(4, 12)) : t3.getUint32(4);
          return "bigint" == typeof t3 ? i3 = t3 / Vt2.BigInt(n3) : "number" != typeof t3 || isNaN(t3) || (i3 = t3 / n3), e4 = (i3 = i3 < Number.MAX_SAFE_INTEGER ? Number(i3) : i3) < e4 ? i3 : e4;
        }, 1 / 0);
        return "bigint" == typeof e3 || isFinite(e3) ? e3 : 0;
      }, e2 = function(e3) {
        var e3 = Mt2(e3, ["moov", "trak"]), n3 = [];
        return e3.forEach(function(e4) {
          var t3 = Mt2(e4, ["mdia", "hdlr"]), i3 = Mt2(e4, ["tkhd"]);
          t3.forEach(function(e5, t4) {
            e5 = Dt2(e5.subarray(8, 12)), t4 = i3[t4];
            "vide" === e5 && (t4 = 0 === (t4 = new DataView(t4.buffer, t4.byteOffset, t4.byteLength)).getUint8(0) ? t4.getUint32(12) : t4.getUint32(20), n3.push(t4));
          });
        }), n3;
      }, Yt2 = function(e3) {
        var t3 = 0 === e3[0] ? 12 : 20;
        return zt2(e3[t3] << 24 | e3[1 + t3] << 16 | e3[2 + t3] << 8 | e3[3 + t3]);
      }, V2 = function(e3) {
        var e3 = Mt2(e3, ["moov", "trak"]), s3 = [];
        return e3.forEach(function(e4) {
          var t3 = {}, i3 = Mt2(e4, ["tkhd"])[0];
          i3 && (i3 = (n3 = new DataView(i3.buffer, i3.byteOffset, i3.byteLength)).getUint8(0), t3.id = 0 === i3 ? n3.getUint32(12) : n3.getUint32(20));
          var n3 = Mt2(e4, ["mdia", "hdlr"])[0];
          n3 && (a3 = Dt2(n3.subarray(8, 12)), t3.type = "vide" === a3 ? "video" : "soun" === a3 ? "audio" : a3);
          var r3, a3 = Mt2(e4, ["mdia", "minf", "stbl", "stsd"])[0];
          a3 && (a3 = a3.subarray(8), t3.codec = Dt2(a3.subarray(4, 8)), (a3 = Mt2(a3, [t3.codec])[0]) && (/^[asm]vc[1-9]$/i.test(t3.codec) ? (r3 = a3.subarray(78), "avcC" === Dt2(r3.subarray(4, 8)) && 11 < r3.length ? (t3.codec += ".", t3.codec += Xt2(r3[9]), t3.codec += Xt2(r3[10]), t3.codec += Xt2(r3[11])) : t3.codec = "avc1.4d400d") : /^mp4[a,v]$/i.test(t3.codec) ? (r3 = a3.subarray(28), "esds" === Dt2(r3.subarray(4, 8)) && 20 < r3.length && 0 !== r3[19] ? (t3.codec += "." + Xt2(r3[19]), t3.codec += "." + Xt2(r3[20] >>> 2 & 63).replace(/^0/, "")) : t3.codec = "mp4a.40.2") : t3.codec = t3.codec.toLowerCase()));
          e4 = Mt2(e4, ["mdia", "mdhd"])[0];
          e4 && (t3.timescale = Yt2(e4)), s3.push(t3);
        }), s3;
      }, Qt2 = ke2, $t2 = V2, Jt2 = Ie2, Zt2 = {};
      Zt2.ts = { parseType: function(e3, t3) {
        e3 = xt2(e3);
        return 0 === e3 ? "pat" : e3 === t3 ? "pmt" : t3 ? "pes" : null;
      }, parsePat: function(e3) {
        var t3 = At2(e3), i3 = 4 + Pt2(e3);
        return t3 && (i3 += e3[i3] + 1), (31 & e3[i3 + 10]) << 8 | e3[i3 + 11];
      }, parsePmt: function(e3) {
        var t3 = {}, i3 = At2(e3), n3 = 4 + Pt2(e3);
        if (i3 && (n3 += e3[n3] + 1), 1 & e3[n3 + 5]) {
          for (var r3 = 3 + ((15 & e3[n3 + 1]) << 8 | e3[n3 + 2]) - 4, a3 = 12 + ((15 & e3[n3 + 10]) << 8 | e3[n3 + 11]); a3 < r3; ) {
            var s3 = n3 + a3;
            t3[(31 & e3[s3 + 1]) << 8 | e3[s3 + 2]] = e3[s3], a3 += 5 + ((15 & e3[s3 + 3]) << 8 | e3[s3 + 4]);
          }
          return t3;
        }
      }, parsePayloadUnitStartIndicator: At2, parsePesType: function(e3, t3) {
        switch (t3[xt2(e3)]) {
          case je2.H264_STREAM_TYPE:
            return "video";
          case je2.ADTS_STREAM_TYPE:
            return "audio";
          case je2.METADATA_STREAM_TYPE:
            return "timed-metadata";
          default:
            return null;
        }
      }, parsePesTime: function(e3) {
        if (!At2(e3))
          return null;
        var t3 = 4 + Pt2(e3);
        if (t3 >= e3.byteLength)
          return null;
        var i3 = null, n3 = e3[t3 + 7];
        return 192 & n3 && ((i3 = {}).pts = (14 & e3[t3 + 9]) << 27 | (255 & e3[t3 + 10]) << 20 | (254 & e3[t3 + 11]) << 12 | (255 & e3[t3 + 12]) << 5 | (254 & e3[t3 + 13]) >>> 3, i3.pts *= 4, i3.pts += (6 & e3[t3 + 13]) >>> 1, i3.dts = i3.pts, 64 & n3 && (i3.dts = (14 & e3[t3 + 14]) << 27 | (255 & e3[t3 + 15]) << 20 | (254 & e3[t3 + 16]) << 12 | (255 & e3[t3 + 17]) << 5 | (254 & e3[t3 + 18]) >>> 3, i3.dts *= 4, i3.dts += (6 & e3[t3 + 18]) >>> 1)), i3;
      }, videoPacketContainsKeyFrame: function(e3) {
        for (var t3 = 4 + Pt2(e3), i3 = e3.subarray(t3), n3 = 0, r3 = 0, a3 = false; r3 < i3.byteLength - 3; r3++)
          if (1 === i3[r3 + 2]) {
            n3 = r3 + 5;
            break;
          }
        for (; n3 < i3.byteLength; )
          switch (i3[n3]) {
            case 0:
              if (0 !== i3[n3 - 1]) {
                n3 += 2;
                break;
              }
              if (0 !== i3[n3 - 2]) {
                n3++;
                break;
              }
              for (r3 + 3 !== n3 - 2 && "slice_layer_without_partitioning_rbsp_idr" === Lt2(31 & i3[r3 + 3]) && (a3 = true); 1 !== i3[++n3] && n3 < i3.length; )
                ;
              r3 = n3 - 2, n3 += 3;
              break;
            case 1:
              if (0 !== i3[n3 - 1] || 0 !== i3[n3 - 2]) {
                n3 += 3;
                break;
              }
              "slice_layer_without_partitioning_rbsp_idr" === Lt2(31 & i3[r3 + 3]) && (a3 = true), r3 = n3 - 2, n3 += 3;
              break;
            default:
              n3 += 3;
          }
        return i3 = i3.subarray(r3), n3 -= r3, r3 = 0, a3 = i3 && 3 < i3.byteLength && "slice_layer_without_partitioning_rbsp_idr" === Lt2(31 & i3[r3 + 3]) ? true : a3;
      } }, Zt2.aac = ct2;
      function ei2(e3, t3, i3) {
        for (var n3, r3, a3, s3, o3 = 0, u3 = 188, l3 = false; u3 <= e3.byteLength; )
          if (71 !== e3[o3] || 71 !== e3[u3] && u3 !== e3.byteLength)
            o3++, u3++;
          else {
            if (n3 = e3.subarray(o3, u3), "pes" === Zt2.ts.parseType(n3, t3.pid) && (r3 = Zt2.ts.parsePesType(n3, t3.table), a3 = Zt2.ts.parsePayloadUnitStartIndicator(n3), "audio" === r3 && a3 && (s3 = Zt2.ts.parsePesTime(n3)) && (s3.type = "audio", i3.audio.push(s3), l3 = true)), l3)
              break;
            o3 += 188, u3 += 188;
          }
        for (o3 = (u3 = e3.byteLength) - 188, l3 = false; 0 <= o3; )
          if (71 !== e3[o3] || 71 !== e3[u3] && u3 !== e3.byteLength)
            o3--, u3--;
          else {
            if (n3 = e3.subarray(o3, u3), "pes" === Zt2.ts.parseType(n3, t3.pid) && (r3 = Zt2.ts.parsePesType(n3, t3.table), a3 = Zt2.ts.parsePayloadUnitStartIndicator(n3), "audio" === r3 && a3 && (s3 = Zt2.ts.parsePesTime(n3)) && (s3.type = "audio", i3.audio.push(s3), l3 = true)), l3)
              break;
            o3 -= 188, u3 -= 188;
          }
      }
      function ti2(e3) {
        var t3, i3 = { pid: null, table: null }, n3 = {};
        for (t3 in !function(e4, t4) {
          for (var i4, n4 = 0, r3 = 188; r3 < e4.byteLength; )
            if (71 !== e4[n4] || 71 !== e4[r3])
              n4++, r3++;
            else {
              switch (i4 = e4.subarray(n4, r3), Zt2.ts.parseType(i4, t4.pid)) {
                case "pat":
                  t4.pid = Zt2.ts.parsePat(i4);
                  break;
                case "pmt":
                  var a3 = Zt2.ts.parsePmt(i4);
                  t4.table = t4.table || {}, Object.keys(a3).forEach(function(e5) {
                    t4.table[e5] = a3[e5];
                  });
              }
              n4 += 188, r3 += 188;
            }
        }(e3, i3), i3.table)
          if (i3.table.hasOwnProperty(t3))
            switch (i3.table[t3]) {
              case je2.H264_STREAM_TYPE:
                n3.video = [], function(e4, t4, i4) {
                  for (var n4, r3, a3, s3, o3, u3, l3, d3, c3 = 0, h3 = 188, p3 = false, f3 = { data: [], size: 0 }; h3 < e4.byteLength; )
                    if (71 !== e4[c3] || 71 !== e4[h3])
                      c3++, h3++;
                    else {
                      if (n4 = e4.subarray(c3, h3), "pes" === Zt2.ts.parseType(n4, t4.pid)) {
                        if (r3 = Zt2.ts.parsePesType(n4, t4.table), a3 = Zt2.ts.parsePayloadUnitStartIndicator(n4), "video" === r3 && (a3 && !p3 && (s3 = Zt2.ts.parsePesTime(n4)) && (s3.type = "video", i4.video.push(s3), p3 = true), !i4.firstKeyFrame)) {
                          if (a3 && 0 !== f3.size) {
                            for (o3 = new Uint8Array(f3.size), u3 = 0; f3.data.length; )
                              l3 = f3.data.shift(), o3.set(l3, u3), u3 += l3.byteLength;
                            !Zt2.ts.videoPacketContainsKeyFrame(o3) || (d3 = Zt2.ts.parsePesTime(o3)) && (i4.firstKeyFrame = d3, i4.firstKeyFrame.type = "video"), f3.size = 0;
                          }
                          f3.data.push(n4), f3.size += n4.byteLength;
                        }
                      }
                      if (p3 && i4.firstKeyFrame)
                        break;
                      c3 += 188, h3 += 188;
                    }
                  for (c3 = (h3 = e4.byteLength) - 188, p3 = false; 0 <= c3; )
                    if (71 !== e4[c3] || 71 !== e4[h3])
                      c3--, h3--;
                    else {
                      if (n4 = e4.subarray(c3, h3), "pes" === Zt2.ts.parseType(n4, t4.pid) && (r3 = Zt2.ts.parsePesType(n4, t4.table), a3 = Zt2.ts.parsePayloadUnitStartIndicator(n4), "video" === r3 && a3 && (s3 = Zt2.ts.parsePesTime(n4)) && (s3.type = "video", i4.video.push(s3), p3 = true)), p3)
                        break;
                      c3 -= 188, h3 -= 188;
                    }
                }(e3, i3, n3), 0 === n3.video.length && delete n3.video;
                break;
              case je2.ADTS_STREAM_TYPE:
                n3.audio = [], ei2(e3, i3, n3), 0 === n3.audio.length && delete n3.audio;
            }
        return n3;
      }
      var ii2 = ue2, ni2 = function(e3, t3) {
        var i3, n3, r3 = (Zt2.aac.isLikelyAacData(e3) ? function(e4) {
          for (var t4, i4 = false, n4 = 0, r4 = null, a3 = null, s3 = 0, o3 = 0; 3 <= e4.length - o3; ) {
            switch (Zt2.aac.parseType(e4, o3)) {
              case "timed-metadata":
                if (e4.length - o3 < 10) {
                  i4 = true;
                  break;
                }
                if ((s3 = Zt2.aac.parseId3TagSize(e4, o3)) > e4.length) {
                  i4 = true;
                  break;
                }
                null === a3 && (t4 = e4.subarray(o3, o3 + s3), a3 = Zt2.aac.parseAacTimestamp(t4)), o3 += s3;
                break;
              case "audio":
                if (e4.length - o3 < 7) {
                  i4 = true;
                  break;
                }
                if ((s3 = Zt2.aac.parseAdtsSize(e4, o3)) > e4.length) {
                  i4 = true;
                  break;
                }
                null === r4 && (t4 = e4.subarray(o3, o3 + s3), r4 = Zt2.aac.parseSampleRate(t4)), n4++, o3 += s3;
                break;
              default:
                o3++;
            }
            if (i4)
              return null;
          }
          if (null === r4 || null === a3)
            return null;
          var u3 = ii2 / r4;
          return { audio: [{ type: "audio", dts: a3, pts: a3 }, { type: "audio", dts: a3 + 1024 * n4 * u3, pts: a3 + 1024 * n4 * u3 }] };
        } : ti2)(e3);
        return r3 && (r3.audio || r3.video) ? (e3 = t3, (t3 = r3).audio && t3.audio.length && ("undefined" != typeof (i3 = e3) && !isNaN(i3) || (i3 = t3.audio[0].dts), t3.audio.forEach(function(e4) {
          e4.dts = Jt2(e4.dts, i3), e4.pts = Jt2(e4.pts, i3), e4.dtsTime = e4.dts / ii2, e4.ptsTime = e4.pts / ii2;
        })), t3.video && t3.video.length && ("undefined" != typeof (n3 = e3) && !isNaN(n3) || (n3 = t3.video[0].dts), t3.video.forEach(function(e4) {
          e4.dts = Jt2(e4.dts, n3), e4.pts = Jt2(e4.pts, n3), e4.dtsTime = e4.dts / ii2, e4.ptsTime = e4.pts / ii2;
        }), t3.firstKeyFrame && ((t3 = t3.firstKeyFrame).dts = Jt2(t3.dts, n3), t3.pts = Jt2(t3.pts, n3), t3.dtsTime = t3.dts / ii2, t3.ptsTime = t3.pts / ii2)), r3) : null;
      }, ri2 = function() {
        function e3(e4, t4) {
          this.options = t4 || {}, this.self = e4, this.init();
        }
        var t3 = e3.prototype;
        return t3.init = function() {
          var i3, e4;
          this.transmuxer && this.transmuxer.dispose(), this.transmuxer = new Ot2.Transmuxer(this.options), i3 = this.self, (e4 = this.transmuxer).on("data", function(e5) {
            var t4 = e5.initSegment;
            e5.initSegment = { data: t4.buffer, byteOffset: t4.byteOffset, byteLength: t4.byteLength };
            t4 = e5.data;
            e5.data = t4.buffer, i3.postMessage({ action: "data", segment: e5, byteOffset: t4.byteOffset, byteLength: t4.byteLength }, [e5.data]);
          }), e4.on("done", function(e5) {
            i3.postMessage({ action: "done" });
          }), e4.on("gopInfo", function(e5) {
            i3.postMessage({ action: "gopInfo", gopInfo: e5 });
          }), e4.on("videoSegmentTimingInfo", function(e5) {
            var t4 = { start: { decode: de2(e5.start.dts), presentation: de2(e5.start.pts) }, end: { decode: de2(e5.end.dts), presentation: de2(e5.end.pts) }, baseMediaDecodeTime: de2(e5.baseMediaDecodeTime) };
            e5.prependedContentDuration && (t4.prependedContentDuration = de2(e5.prependedContentDuration)), i3.postMessage({ action: "videoSegmentTimingInfo", videoSegmentTimingInfo: t4 });
          }), e4.on("audioSegmentTimingInfo", function(e5) {
            var t4 = { start: { decode: de2(e5.start.dts), presentation: de2(e5.start.pts) }, end: { decode: de2(e5.end.dts), presentation: de2(e5.end.pts) }, baseMediaDecodeTime: de2(e5.baseMediaDecodeTime) };
            e5.prependedContentDuration && (t4.prependedContentDuration = de2(e5.prependedContentDuration)), i3.postMessage({ action: "audioSegmentTimingInfo", audioSegmentTimingInfo: t4 });
          }), e4.on("id3Frame", function(e5) {
            i3.postMessage({ action: "id3Frame", id3Frame: e5 });
          }), e4.on("caption", function(e5) {
            i3.postMessage({ action: "caption", caption: e5 });
          }), e4.on("trackinfo", function(e5) {
            i3.postMessage({ action: "trackinfo", trackInfo: e5 });
          }), e4.on("audioTimingInfo", function(e5) {
            i3.postMessage({ action: "audioTimingInfo", audioTimingInfo: { start: de2(e5.start), end: de2(e5.end) } });
          }), e4.on("videoTimingInfo", function(e5) {
            i3.postMessage({ action: "videoTimingInfo", videoTimingInfo: { start: de2(e5.start), end: de2(e5.end) } });
          }), e4.on("log", function(e5) {
            i3.postMessage({ action: "log", log: e5 });
          });
        }, t3.pushMp4Captions = function(e4) {
          this.captionParser || (this.captionParser = new Gt2(), this.captionParser.init());
          var t4 = new Uint8Array(e4.data, e4.byteOffset, e4.byteLength), e4 = this.captionParser.parse(t4, e4.trackIds, e4.timescales);
          this.self.postMessage({ action: "mp4Captions", captions: e4 && e4.captions || [], logs: e4 && e4.logs || [], data: t4.buffer }, [t4.buffer]);
        }, t3.probeMp4StartTime = function(e4) {
          var t4 = e4.timescales, e4 = e4.data, t4 = Qt2(t4, e4);
          this.self.postMessage({ action: "probeMp4StartTime", startTime: t4, data: e4 }, [e4.buffer]);
        }, t3.probeMp4Tracks = function(e4) {
          var t4 = e4.data, e4 = $t2(t4);
          this.self.postMessage({ action: "probeMp4Tracks", tracks: e4, data: t4 }, [t4.buffer]);
        }, t3.probeTs = function(e4) {
          var t4 = e4.data, i3 = e4.baseStartTime, e4 = "number" != typeof i3 || isNaN(i3) ? void 0 : i3 * ue2, i3 = ni2(t4, e4), e4 = null;
          i3 && ((e4 = { hasVideo: i3.video && 2 === i3.video.length || false, hasAudio: i3.audio && 2 === i3.audio.length || false }).hasVideo && (e4.videoStart = i3.video[0].ptsTime), e4.hasAudio && (e4.audioStart = i3.audio[0].ptsTime)), this.self.postMessage({ action: "probeTs", result: e4, data: t4 }, [t4.buffer]);
        }, t3.clearAllMp4Captions = function() {
          this.captionParser && this.captionParser.clearAllCaptions();
        }, t3.clearParsedMp4Captions = function() {
          this.captionParser && this.captionParser.clearParsedCaptions();
        }, t3.push = function(e4) {
          e4 = new Uint8Array(e4.data, e4.byteOffset, e4.byteLength);
          this.transmuxer.push(e4);
        }, t3.reset = function() {
          this.transmuxer.reset();
        }, t3.setTimestampOffset = function(e4) {
          e4 = e4.timestampOffset || 0;
          this.transmuxer.setBaseMediaDecodeTime(Math.round(le2(e4)));
        }, t3.setAudioAppendStart = function(e4) {
          this.transmuxer.setAudioAppendStart(Math.ceil(le2(e4.appendStart)));
        }, t3.setRemux = function(e4) {
          this.transmuxer.setRemux(e4.remux);
        }, t3.flush = function(e4) {
          this.transmuxer.flush(), self.postMessage({ action: "done", type: "transmuxed" });
        }, t3.endTimeline = function() {
          this.transmuxer.endTimeline(), self.postMessage({ action: "endedtimeline", type: "transmuxed" });
        }, t3.alignGopsWith = function(e4) {
          this.transmuxer.alignGopsWith(e4.gopsToAlignWith.slice());
        }, e3;
      }();
      self.onmessage = function(e3) {
        "init" === e3.data.action && e3.data.options ? this.messageHandlers = new ri2(self, e3.data.options) : (this.messageHandlers || (this.messageHandlers = new ri2(self)), e3.data && e3.data.action && "init" !== e3.data.action && this.messageHandlers[e3.data.action] && this.messageHandlers[e3.data.action](e3.data));
      };
    }))), zl = function(e2) {
      e2.currentTransmux = null, e2.transmuxQueue.length && (e2.currentTransmux = e2.transmuxQueue.shift(), "function" == typeof e2.currentTransmux ? e2.currentTransmux() : Zu(e2.currentTransmux));
    }, Xl = function(e2) {
      tl("reset", e2);
    }, Kl = function(e2) {
      var t2 = new Gl();
      t2.currentTransmux = null, t2.transmuxQueue = [];
      var i2 = t2.terminate;
      return t2.terminate = function() {
        return t2.currentTransmux = null, t2.transmuxQueue.length = 0, i2.call(t2);
      }, t2.postMessage({ action: "init", options: e2 }), t2;
    }, Yl = 2, Ql = -101, $l = -102, Jl = Zo("CodecUtils"), Zl = Zo("PlaylistSelector"), zt = function() {
      var e2 = this.useDevicePixelRatio && window.devicePixelRatio || 1;
      return Sl(this.playlists.master, this.systemBandwidth, parseInt(bl(this.tech_.el(), "width"), 10) * e2, parseInt(bl(this.tech_.el(), "height"), 10) * e2, this.limitRenditionByPlayerDimensions, this.masterPlaylistController_);
    }, ed = function(n2) {
      function e2(e3, t3) {
        var i2 = n2.call(this) || this;
        if (!e3)
          throw new TypeError("Initialization settings are required");
        if ("function" != typeof e3.currentTime)
          throw new TypeError("No currentTime getter specified");
        if (!e3.mediaSource)
          throw new TypeError("No MediaSource specified");
        return i2.bandwidth = e3.bandwidth, i2.throughput = { rate: 0, count: 0 }, i2.roundTrip = NaN, i2.resetStats_(), i2.mediaIndex = null, i2.partIndex = null, i2.hasPlayed_ = e3.hasPlayed, i2.currentTime_ = e3.currentTime, i2.seekable_ = e3.seekable, i2.seeking_ = e3.seeking, i2.duration_ = e3.duration, i2.mediaSource_ = e3.mediaSource, i2.vhs_ = e3.vhs, i2.loaderType_ = e3.loaderType, i2.currentMediaInfo_ = void 0, i2.startingMediaInfo_ = void 0, i2.segmentMetadataTrack_ = e3.segmentMetadataTrack, i2.goalBufferLength_ = e3.goalBufferLength, i2.sourceType_ = e3.sourceType, i2.sourceUpdater_ = e3.sourceUpdater, i2.inbandTextTracks_ = e3.inbandTextTracks, i2.state_ = "INIT", i2.timelineChangeController_ = e3.timelineChangeController, i2.shouldSaveSegmentTimingInfo_ = true, i2.parse708captions_ = e3.parse708captions, i2.useDtsForTimestampOffset_ = e3.useDtsForTimestampOffset, i2.captionServices_ = e3.captionServices, i2.experimentalExactManifestTimings = e3.experimentalExactManifestTimings, i2.checkBufferTimeout_ = null, i2.error_ = void 0, i2.currentTimeline_ = -1, i2.pendingSegment_ = null, i2.xhrOptions_ = null, i2.pendingSegments_ = [], i2.audioDisabled_ = false, i2.isPendingTimestampOffset_ = false, i2.gopBuffer_ = [], i2.timeMapping_ = 0, i2.safeAppend_ = 11 <= ir.browser.IE_VERSION, i2.appendInitSegment_ = { audio: true, video: true }, i2.playlistOfLastInitSegment_ = { audio: null, video: null }, i2.callQueue_ = [], i2.loadQueue_ = [], i2.metadataQueue_ = { id3: [], caption: [] }, i2.waitingOnRemove_ = false, i2.quotaExceededErrorRetryTimeout_ = null, i2.activeInitSegmentId_ = null, i2.initSegments_ = {}, i2.cacheEncryptionKeys_ = e3.cacheEncryptionKeys, i2.keyCache_ = {}, i2.decrypter_ = e3.decrypter, i2.syncController_ = e3.syncController, i2.syncPoint_ = { segmentIndex: 0, time: 0 }, i2.transmuxer_ = i2.createTransmuxer_(), i2.triggerSyncInfoUpdate_ = function() {
          return i2.trigger("syncinfoupdate");
        }, i2.syncController_.on("syncinfoupdate", i2.triggerSyncInfoUpdate_), i2.mediaSource_.addEventListener("sourceopen", function() {
          i2.isEndOfStream_() || (i2.ended_ = false);
        }), i2.fetchAtBuffer_ = false, i2.logger_ = Zo("SegmentLoader[" + i2.loaderType_ + "]"), Object.defineProperty(ft(i2), "state", { get: function() {
          return this.state_;
        }, set: function(e4) {
          e4 !== this.state_ && (this.logger_(this.state_ + " -> " + e4), this.state_ = e4, this.trigger("statechange"));
        } }), i2.sourceUpdater_.on("ready", function() {
          i2.hasEnoughInfoToAppend_() && i2.processCallQueue_();
        }), "main" === i2.loaderType_ && i2.timelineChangeController_.on("pendingtimelinechange", function() {
          i2.hasEnoughInfoToAppend_() && i2.processCallQueue_();
        }), "audio" === i2.loaderType_ && i2.timelineChangeController_.on("timelinechange", function() {
          i2.hasEnoughInfoToLoad_() && i2.processLoadQueue_(), i2.hasEnoughInfoToAppend_() && i2.processCallQueue_();
        }), i2;
      }
      mt(e2, n2);
      var t2 = e2.prototype;
      return t2.createTransmuxer_ = function() {
        return Kl({ remux: false, alignGopsAtEnd: this.safeAppend_, keepOriginalTimestamps: true, parse708captions: this.parse708captions_, captionServices: this.captionServices_ });
      }, t2.resetStats_ = function() {
        this.mediaBytesTransferred = 0, this.mediaRequests = 0, this.mediaRequestsAborted = 0, this.mediaRequestsTimedout = 0, this.mediaRequestsErrored = 0, this.mediaTransferDuration = 0, this.mediaSecondsLoaded = 0, this.mediaAppends = 0;
      }, t2.dispose = function() {
        this.trigger("dispose"), this.state = "DISPOSED", this.pause(), this.abort_(), this.transmuxer_ && this.transmuxer_.terminate(), this.resetStats_(), this.checkBufferTimeout_ && window.clearTimeout(this.checkBufferTimeout_), this.syncController_ && this.triggerSyncInfoUpdate_ && this.syncController_.off("syncinfoupdate", this.triggerSyncInfoUpdate_), this.off();
      }, t2.setAudio = function(e3) {
        this.audioDisabled_ = !e3, e3 ? this.appendInitSegment_.audio = true : this.sourceUpdater_.removeAudio(0, this.duration_());
      }, t2.abort = function() {
        "WAITING" === this.state ? (this.abort_(), this.state = "READY", this.paused() || this.monitorBuffer_()) : this.pendingSegment_ && (this.pendingSegment_ = null);
      }, t2.abort_ = function() {
        this.pendingSegment_ && this.pendingSegment_.abortRequests && this.pendingSegment_.abortRequests(), this.pendingSegment_ = null, this.callQueue_ = [], this.loadQueue_ = [], this.metadataQueue_.id3 = [], this.metadataQueue_.caption = [], this.timelineChangeController_.clearPendingTimelineChange(this.loaderType_), this.waitingOnRemove_ = false, window.clearTimeout(this.quotaExceededErrorRetryTimeout_), this.quotaExceededErrorRetryTimeout_ = null;
      }, t2.checkForAbort_ = function(e3) {
        return "APPENDING" !== this.state || this.pendingSegment_ ? !this.pendingSegment_ || this.pendingSegment_.requestId !== e3 : (this.state = "READY", true);
      }, t2.error = function(e3) {
        return "undefined" != typeof e3 && (this.logger_("error occurred:", e3), this.error_ = e3), this.pendingSegment_ = null, this.error_;
      }, t2.endOfStream = function() {
        this.ended_ = true, this.transmuxer_ && Xl(this.transmuxer_), this.gopBuffer_.length = 0, this.pause(), this.trigger("ended");
      }, t2.buffered_ = function() {
        var e3 = this.getMediaInfo_();
        if (!this.sourceUpdater_ || !e3)
          return ir.createTimeRanges();
        if ("main" === this.loaderType_) {
          var t3 = e3.hasAudio, i2 = e3.hasVideo, e3 = e3.isMuxed;
          if (i2 && t3 && !this.audioDisabled_ && !e3)
            return this.sourceUpdater_.buffered();
          if (i2)
            return this.sourceUpdater_.videoBuffered();
        }
        return this.sourceUpdater_.audioBuffered();
      }, t2.initSegmentForMap = function(e3, t3) {
        if (void 0 === t3 && (t3 = false), !e3)
          return null;
        var i2 = Hu(e3), n3 = this.initSegments_[i2];
        return t3 && !n3 && e3.bytes && (this.initSegments_[i2] = n3 = { resolvedUri: e3.resolvedUri, byterange: e3.byterange, bytes: e3.bytes, tracks: e3.tracks, timescales: e3.timescales }), n3 || e3;
      }, t2.segmentKey = function(e3, t3) {
        if (void 0 === t3 && (t3 = false), !e3)
          return null;
        var i2 = Vu(e3), n3 = this.keyCache_[i2];
        this.cacheEncryptionKeys_ && t3 && !n3 && e3.bytes && (this.keyCache_[i2] = n3 = { resolvedUri: e3.resolvedUri, bytes: e3.bytes });
        e3 = { resolvedUri: (n3 || e3).resolvedUri };
        return n3 && (e3.bytes = n3.bytes), e3;
      }, t2.couldBeginLoading_ = function() {
        return this.playlist_ && !this.paused();
      }, t2.load = function() {
        if (this.monitorBuffer_(), this.playlist_)
          return "INIT" === this.state && this.couldBeginLoading_() ? this.init_() : void (!this.couldBeginLoading_() || "READY" !== this.state && "INIT" !== this.state || (this.state = "READY"));
      }, t2.init_ = function() {
        return this.state = "READY", this.resetEverything(), this.monitorBuffer_();
      }, t2.playlist = function(e3, t3) {
        if (void 0 === t3 && (t3 = {}), e3) {
          var i2 = this.playlist_, n3 = this.pendingSegment_;
          this.playlist_ = e3, this.xhrOptions_ = t3, "INIT" === this.state && (e3.syncInfo = { mediaSequence: e3.mediaSequence, time: 0 }, "main" === this.loaderType_ && this.syncController_.setDateTimeMappingForStart(e3));
          var r2 = null;
          if (i2 && (i2.id ? r2 = i2.id : i2.uri && (r2 = i2.uri)), this.logger_("playlist update [" + r2 + " => " + (e3.id || e3.uri) + "]"), this.trigger("syncinfoupdate"), "INIT" === this.state && this.couldBeginLoading_())
            return this.init_();
          if (!i2 || i2.uri !== e3.uri)
            return null !== this.mediaIndex && (e3.endList ? this.resyncLoader() : this.resetLoader()), this.currentMediaInfo_ = void 0, void this.trigger("playlistupdate");
          t3 = e3.mediaSequence - i2.mediaSequence;
          this.logger_("live window shift [" + t3 + "]"), null !== this.mediaIndex && (this.mediaIndex -= t3, this.mediaIndex < 0 ? (this.mediaIndex = null, this.partIndex = null) : (r2 = this.playlist_.segments[this.mediaIndex], !this.partIndex || r2.parts && r2.parts.length && r2.parts[this.partIndex] || (r2 = this.mediaIndex, this.logger_("currently processing part (index " + this.partIndex + ") no longer exists."), this.resetLoader(), this.mediaIndex = r2))), n3 && (n3.mediaIndex -= t3, n3.mediaIndex < 0 ? (n3.mediaIndex = null, n3.partIndex = null) : (0 <= n3.mediaIndex && (n3.segment = e3.segments[n3.mediaIndex]), 0 <= n3.partIndex && n3.segment.parts && (n3.part = n3.segment.parts[n3.partIndex]))), this.syncController_.saveExpiredSegmentInfo(i2, e3);
        }
      }, t2.pause = function() {
        this.checkBufferTimeout_ && (window.clearTimeout(this.checkBufferTimeout_), this.checkBufferTimeout_ = null);
      }, t2.paused = function() {
        return null === this.checkBufferTimeout_;
      }, t2.resetEverything = function(e3) {
        this.ended_ = false, this.activeInitSegmentId_ = null, this.appendInitSegment_ = { audio: true, video: true }, this.resetLoader(), this.remove(0, 1 / 0, e3), this.transmuxer_ && (this.transmuxer_.postMessage({ action: "clearAllMp4Captions" }), this.transmuxer_.postMessage({ action: "reset" }));
      }, t2.resetLoader = function() {
        this.fetchAtBuffer_ = false, this.resyncLoader();
      }, t2.resyncLoader = function() {
        this.transmuxer_ && Xl(this.transmuxer_), this.mediaIndex = null, this.partIndex = null, this.syncPoint_ = null, this.isPendingTimestampOffset_ = false, this.callQueue_ = [], this.loadQueue_ = [], this.metadataQueue_.id3 = [], this.metadataQueue_.caption = [], this.abort(), this.transmuxer_ && this.transmuxer_.postMessage({ action: "clearParsedMp4Captions" });
      }, t2.remove = function(e3, t3, i2, n3) {
        if (void 0 === i2 && (i2 = function() {
        }), void 0 === n3 && (n3 = false), (t3 = t3 === 1 / 0 ? this.duration_() : t3) <= e3)
          this.logger_("skipping remove because end ${end} is <= start ${start}");
        else if (this.sourceUpdater_ && this.getMediaInfo_()) {
          var r2, a2 = 1, s2 = function() {
            0 === --a2 && i2();
          };
          for (r2 in !n3 && this.audioDisabled_ || (a2++, this.sourceUpdater_.removeAudio(e3, t3, s2)), !n3 && "main" !== this.loaderType_ || (this.gopBuffer_ = function(e4, t4, i3, n4) {
            for (var r3 = Math.ceil((t4 - n4) * Qo), a3 = Math.ceil((i3 - n4) * Qo), n4 = e4.slice(), s3 = e4.length; s3-- && !(e4[s3].pts <= a3); )
              ;
            if (-1 === s3)
              return n4;
            for (var o2 = s3 + 1; o2-- && !(e4[o2].pts <= r3); )
              ;
            return o2 = Math.max(o2, 0), n4.splice(o2, s3 - o2 + 1), n4;
          }(this.gopBuffer_, e3, t3, this.timeMapping_), a2++, this.sourceUpdater_.removeVideo(e3, t3, s2)), this.inbandTextTracks_)
            kl(e3, t3, this.inbandTextTracks_[r2]);
          kl(e3, t3, this.segmentMetadataTrack_), s2();
        } else
          this.logger_("skipping remove because no source updater or starting media info");
      }, t2.monitorBuffer_ = function() {
        this.checkBufferTimeout_ && window.clearTimeout(this.checkBufferTimeout_), this.checkBufferTimeout_ = window.setTimeout(this.monitorBufferTick_.bind(this), 1);
      }, t2.monitorBufferTick_ = function() {
        "READY" === this.state && this.fillBuffer_(), this.checkBufferTimeout_ && window.clearTimeout(this.checkBufferTimeout_), this.checkBufferTimeout_ = window.setTimeout(this.monitorBufferTick_.bind(this), 500);
      }, t2.fillBuffer_ = function() {
        var e3;
        this.sourceUpdater_.updating() || (e3 = this.chooseNextRequest_()) && ("number" == typeof e3.timestampOffset && (this.isPendingTimestampOffset_ = false, this.timelineChangeController_.pendingTimelineChange({ type: this.loaderType_, from: this.currentTimeline_, to: e3.timeline })), this.loadSegment_(e3));
      }, t2.isEndOfStream_ = function(e3, t3, i2) {
        if (void 0 === e3 && (e3 = this.mediaIndex), void 0 === t3 && (t3 = this.playlist_), void 0 === i2 && (i2 = this.partIndex), !t3 || !this.mediaSource_)
          return false;
        var n3 = "number" == typeof e3 && t3.segments[e3], e3 = e3 + 1 === t3.segments.length, n3 = !n3 || !n3.parts || i2 + 1 === n3.parts.length;
        return t3.endList && "open" === this.mediaSource_.readyState && e3 && n3;
      }, t2.chooseNextRequest_ = function() {
        var e3 = this.buffered_(), t3 = au(e3) || 0, i2 = su(e3, this.currentTime_()), n3 = !this.hasPlayed_() && 1 <= i2, r2 = i2 >= this.goalBufferLength_(), e3 = this.playlist_.segments;
        if (!e3.length || n3 || r2)
          return null;
        this.syncPoint_ = this.syncPoint_ || this.syncController_.getSyncPoint(this.playlist_, this.duration_(), this.currentTimeline_, this.currentTime_());
        var a2, n3 = { partIndex: null, mediaIndex: null, startOfSegment: null, playlist: this.playlist_, isSyncRequest: Boolean(!this.syncPoint_) };
        n3.isSyncRequest ? n3.mediaIndex = function(e4, t4, i3) {
          t4 = t4 || [];
          for (var n4 = [], r3 = 0, a3 = 0; a3 < t4.length; a3++) {
            var s3 = t4[a3];
            if (e4 === s3.timeline && (n4.push(a3), i3 < (r3 += s3.duration)))
              return a3;
          }
          return 0 === n4.length ? 0 : n4[n4.length - 1];
        }(this.currentTimeline_, e3, t3) : null !== this.mediaIndex ? (r2 = e3[this.mediaIndex], a2 = "number" == typeof this.partIndex ? this.partIndex : -1, n3.startOfSegment = r2.end || t3, r2.parts && r2.parts[a2 + 1] ? (n3.mediaIndex = this.mediaIndex, n3.partIndex = a2 + 1) : n3.mediaIndex = this.mediaIndex + 1) : (a2 = (o2 = Nl.getMediaInfoForTime({ experimentalExactManifestTimings: this.experimentalExactManifestTimings, playlist: this.playlist_, currentTime: this.fetchAtBuffer_ ? t3 : this.currentTime_(), startingPartIndex: this.syncPoint_.partIndex, startingSegmentIndex: this.syncPoint_.segmentIndex, startTime: this.syncPoint_.time })).segmentIndex, s2 = o2.startTime, o2 = o2.partIndex, n3.getMediaInfoForTime = this.fetchAtBuffer_ ? "bufferedEnd " + t3 : "currentTime " + this.currentTime_(), n3.mediaIndex = a2, n3.startOfSegment = s2, n3.partIndex = o2);
        var s2 = e3[n3.mediaIndex], o2 = s2 && "number" == typeof n3.partIndex && s2.parts && s2.parts[n3.partIndex];
        if (!s2 || "number" == typeof n3.partIndex && !o2)
          return null;
        "number" != typeof n3.partIndex && s2.parts && (n3.partIndex = 0, o2 = s2.parts[0]), i2 || !o2 || o2.independent || (0 === n3.partIndex ? (o2 = (i2 = e3[n3.mediaIndex - 1]).parts && i2.parts.length && i2.parts[i2.parts.length - 1]) && o2.independent && (--n3.mediaIndex, n3.partIndex = i2.parts.length - 1, n3.independent = "previous segment") : s2.parts[n3.partIndex - 1].independent && (--n3.partIndex, n3.independent = "previous part"));
        s2 = this.mediaSource_ && "ended" === this.mediaSource_.readyState;
        return n3.mediaIndex >= e3.length - 1 && s2 && !this.seeking_() ? null : this.generateSegmentInfo_(n3);
      }, t2.generateSegmentInfo_ = function(e3) {
        var t3 = e3.independent, i2 = e3.playlist, n3 = e3.mediaIndex, r2 = e3.startOfSegment, a2 = e3.isSyncRequest, s2 = e3.partIndex, o2 = e3.forceTimestampOffset, u2 = e3.getMediaInfoForTime, l2 = i2.segments[n3], e3 = "number" == typeof s2 && l2.parts[s2], t3 = { requestId: "segment-loader-" + Math.random(), uri: e3 && e3.resolvedUri || l2.resolvedUri, mediaIndex: n3, partIndex: e3 ? s2 : null, isSyncRequest: a2, startOfSegment: r2, playlist: i2, bytes: null, encryptedBytes: null, timestampOffset: null, timeline: l2.timeline, duration: e3 && e3.duration || l2.duration, segment: l2, part: e3, byteLength: 0, transmuxer: this.transmuxer_, getMediaInfoForTime: u2, independent: t3 }, o2 = "undefined" != typeof o2 ? o2 : this.isPendingTimestampOffset_;
        t3.timestampOffset = this.timestampOffsetForSegment_({ segmentTimeline: l2.timeline, currentTimeline: this.currentTimeline_, startOfSegment: r2, buffered: this.buffered_(), overrideCheck: o2 });
        o2 = au(this.sourceUpdater_.audioBuffered());
        return "number" == typeof o2 && (t3.audioAppendStart = o2 - this.sourceUpdater_.audioTimestampOffset()), this.sourceUpdater_.videoBuffered().length && (t3.gopsToAlignWith = function(e4, t4, i3) {
          if ("undefined" == typeof t4 || null === t4 || !e4.length)
            return [];
          for (var n4 = Math.ceil((t4 - i3 + 3) * Qo), r3 = 0; r3 < e4.length && !(e4[r3].pts > n4); r3++)
            ;
          return e4.slice(r3);
        }(this.gopBuffer_, this.currentTime_() - this.sourceUpdater_.videoTimestampOffset(), this.timeMapping_)), t3;
      }, t2.timestampOffsetForSegment_ = function(e3) {
        return i2 = (t3 = e3).segmentTimeline, n3 = t3.currentTimeline, r2 = t3.startOfSegment, e3 = t3.buffered, t3.overrideCheck || i2 !== n3 ? !(i2 < n3) && e3.length ? e3.end(e3.length - 1) : r2 : null;
        var t3, i2, n3, r2;
      }, t2.earlyAbortWhenNeeded_ = function(e3) {
        var t3, i2, n3, r2, a2, s2, o2, u2, l2, d2, c2, h2, p2;
        !this.vhs_.tech_.paused() && this.xhrOptions_.timeout && this.playlist_.attributes.BANDWIDTH && (Date.now() - (e3.firstBytesReceivedAt || Date.now()) < 1e3 || (t3 = this.currentTime_(), r2 = e3.bandwidth, a2 = this.pendingSegment_.duration, p2 = Nl.estimateSegmentRequestTime(a2, r2, this.playlist_, e3.bytesReceived), i2 = this.buffered_(), n3 = t3, void 0 === (e3 = this.vhs_.tech_.playbackRate()) && (e3 = 1), p2 <= (e3 = ((i2.length ? i2.end(i2.length - 1) : 0) - n3) / e3 - 1) || (r2 = { master: this.vhs_.playlists.master, currentTime: t3, bandwidth: r2, duration: this.duration_(), segmentDuration: a2, timeUntilRebuffer: e3, currentTimeline: this.currentTimeline_, syncController: this.syncController_ }, a2 = r2.master, s2 = r2.currentTime, o2 = r2.bandwidth, u2 = r2.duration, l2 = r2.segmentDuration, d2 = r2.timeUntilRebuffer, c2 = r2.currentTimeline, h2 = r2.syncController, a2 = (r2 = (a2 = !(a2 = (r2 = a2.playlists.filter(function(e4) {
          return !Nl.isIncompatible(e4);
        })).filter(Nl.isEnabled)).length ? r2.filter(function(e4) {
          return !Nl.isDisabled(e4);
        }) : a2).filter(Nl.hasAttribute.bind(null, "BANDWIDTH")).map(function(e4) {
          var t4 = h2.getSyncPoint(e4, u2, c2, s2) ? 1 : 2;
          return { playlist: e4, rebufferingImpact: Nl.estimateSegmentRequestTime(l2, o2, e4) * t4 - d2 };
        })).filter(function(e4) {
          return e4.rebufferingImpact <= 0;
        }), Tl(a2, function(e4, t4) {
          return wl(t4.playlist, e4.playlist);
        }), (r2 = a2.length ? a2[0] : (Tl(r2, function(e4, t4) {
          return e4.rebufferingImpact - t4.rebufferingImpact;
        }), r2[0] || null)) && (p2 = p2 - e3 - r2.rebufferingImpact, !r2.playlist || r2.playlist.uri === this.playlist_.uri || p2 < (e3 <= Rl ? 1 : 0.5) || (this.bandwidth = r2.playlist.attributes.BANDWIDTH * Wl.BANDWIDTH_VARIANCE + 1, this.trigger("earlyabort"))))));
      }, t2.handleAbort_ = function(e3) {
        this.logger_("Aborting " + Il(e3)), this.mediaRequestsAborted += 1;
      }, t2.handleProgress_ = function(e3, t3) {
        this.earlyAbortWhenNeeded_(t3.stats), this.checkForAbort_(t3.requestId) || this.trigger("progress");
      }, t2.handleTrackInfo_ = function(e3, t3) {
        this.earlyAbortWhenNeeded_(e3.stats), this.checkForAbort_(e3.requestId) || this.checkForIllegalMediaSwitch(t3) || (function(e4, t4) {
          if (!e4 && !t4 || !e4 && t4 || e4 && !t4)
            return false;
          if (e4 === t4)
            return true;
          var i2 = Object.keys(e4).sort(), n3 = Object.keys(t4).sort();
          if (i2.length !== n3.length)
            return false;
          for (var r2 = 0; r2 < i2.length; r2++) {
            var a2 = i2[r2];
            if (a2 !== n3[r2])
              return false;
            if (e4[a2] !== t4[a2])
              return false;
          }
          return true;
        }(this.currentMediaInfo_, t3 = t3 || {}) || (this.appendInitSegment_ = { audio: true, video: true }, this.startingMediaInfo_ = t3, this.currentMediaInfo_ = t3, this.logger_("trackinfo update", t3), this.trigger("trackinfo")), this.checkForAbort_(e3.requestId) || (this.pendingSegment_.trackInfo = t3, this.hasEnoughInfoToAppend_() && this.processCallQueue_()));
      }, t2.handleTimingInfo_ = function(e3, t3, i2, n3) {
        var r2;
        this.earlyAbortWhenNeeded_(e3.stats), this.checkForAbort_(e3.requestId) || ((r2 = this.pendingSegment_)[e3 = xl(t3)] = r2[e3] || {}, r2[e3][i2] = n3, this.logger_("timinginfo: " + t3 + " - " + i2 + " - " + n3), this.hasEnoughInfoToAppend_() && this.processCallQueue_());
      }, t2.handleCaptions_ = function(e3, t3) {
        var g2, y2, v2 = this;
        this.earlyAbortWhenNeeded_(e3.stats), this.checkForAbort_(e3.requestId) || (0 !== t3.length ? this.pendingSegment_.hasAppendedData_ ? (g2 = null === this.sourceUpdater_.videoTimestampOffset() ? this.sourceUpdater_.audioTimestampOffset() : this.sourceUpdater_.videoTimestampOffset(), y2 = {}, t3.forEach(function(e4) {
          y2[e4.stream] = y2[e4.stream] || { startTime: 1 / 0, captions: [], endTime: 0 };
          var t4 = y2[e4.stream];
          t4.startTime = Math.min(t4.startTime, e4.startTime + g2), t4.endTime = Math.max(t4.endTime, e4.endTime + g2), t4.captions.push(e4);
        }), Object.keys(y2).forEach(function(e4) {
          var t4, i2, n3, r2, a2, s2, o2, u2, l2, d2, c2 = y2[e4], h2 = c2.startTime, p2 = c2.endTime, f2 = c2.captions, m2 = v2.inbandTextTracks_;
          v2.logger_("adding cues from " + h2 + " -> " + p2 + " for " + e4), t4 = m2, i2 = v2.vhs_.tech_, t4[n3 = e4] || (i2.trigger({ type: "usage", name: "vhs-608" }), i2.trigger({ type: "usage", name: "hls-608" }), /^cc708_/.test(r2 = n3) && (r2 = "SERVICE" + n3.split("_")[1]), (o2 = i2.textTracks().getTrackById(r2)) ? t4[n3] = o2 : (s2 = a2 = n3, c2 = false, (o2 = (i2.options_.vhs && i2.options_.vhs.captionServices || {})[r2]) && (a2 = o2.label, s2 = o2.language, c2 = o2.default), t4[n3] = i2.addRemoteTextTrack({ kind: "captions", id: r2, default: c2, label: a2, language: s2 }, false).track)), kl(h2, p2, m2[e4]), l2 = (f2 = { captionArray: f2, inbandTextTracks: m2, timestampOffset: g2 }).inbandTextTracks, m2 = f2.captionArray, d2 = f2.timestampOffset, m2 && (u2 = window.WebKitDataCue || window.VTTCue, m2.forEach(function(e5) {
            var t5 = e5.stream;
            l2[t5].addCue(new u2(e5.startTime + d2, e5.endTime + d2, e5.text));
          }));
        }), this.transmuxer_ && this.transmuxer_.postMessage({ action: "clearParsedMp4Captions" })) : this.metadataQueue_.caption.push(this.handleCaptions_.bind(this, e3, t3)) : this.logger_("SegmentLoader received no captions from a caption event"));
      }, t2.handleId3_ = function(e3, t3, i2) {
        var n3, r2, a2, s2;
        this.earlyAbortWhenNeeded_(e3.stats), this.checkForAbort_(e3.requestId) || (this.pendingSegment_.hasAppendedData_ ? (n3 = null === this.sourceUpdater_.videoTimestampOffset() ? this.sourceUpdater_.audioTimestampOffset() : this.sourceUpdater_.videoTimestampOffset(), r2 = this.inbandTextTracks_, a2 = i2, s2 = this.vhs_.tech_, r2.metadataTrack_ || (r2.metadataTrack_ = s2.addRemoteTextTrack({ kind: "metadata", label: "Timed Metadata" }, false).track, r2.metadataTrack_.inBandMetadataTrackDispatchType = a2), El({ inbandTextTracks: this.inbandTextTracks_, metadataArray: t3, timestampOffset: n3, videoDuration: this.duration_() })) : this.metadataQueue_.id3.push(this.handleId3_.bind(this, e3, t3, i2)));
      }, t2.processMetadataQueue_ = function() {
        this.metadataQueue_.id3.forEach(function(e3) {
          return e3();
        }), this.metadataQueue_.caption.forEach(function(e3) {
          return e3();
        }), this.metadataQueue_.id3 = [], this.metadataQueue_.caption = [];
      }, t2.processCallQueue_ = function() {
        var e3 = this.callQueue_;
        this.callQueue_ = [], e3.forEach(function(e4) {
          return e4();
        });
      }, t2.processLoadQueue_ = function() {
        var e3 = this.loadQueue_;
        this.loadQueue_ = [], e3.forEach(function(e4) {
          return e4();
        });
      }, t2.hasEnoughInfoToLoad_ = function() {
        if ("audio" !== this.loaderType_)
          return true;
        var e3 = this.pendingSegment_;
        return !!e3 && (!this.getCurrentMediaInfo_() || !Al({ timelineChangeController: this.timelineChangeController_, currentTimeline: this.currentTimeline_, segmentTimeline: e3.timeline, loaderType: this.loaderType_, audioDisabled: this.audioDisabled_ }));
      }, t2.getCurrentMediaInfo_ = function(e3) {
        return (e3 = void 0 === e3 ? this.pendingSegment_ : e3) && e3.trackInfo || this.currentMediaInfo_;
      }, t2.getMediaInfo_ = function(e3) {
        return void 0 === e3 && (e3 = this.pendingSegment_), this.getCurrentMediaInfo_(e3) || this.startingMediaInfo_;
      }, t2.getPendingSegmentPlaylist = function() {
        return this.pendingSegment_ ? this.pendingSegment_.playlist : null;
      }, t2.hasEnoughInfoToAppend_ = function() {
        if (!this.sourceUpdater_.ready())
          return false;
        if (this.waitingOnRemove_ || this.quotaExceededErrorRetryTimeout_)
          return false;
        var e3 = this.pendingSegment_, t3 = this.getCurrentMediaInfo_();
        if (!e3 || !t3)
          return false;
        var i2 = t3.hasAudio, n3 = t3.hasVideo, t3 = t3.isMuxed;
        return !(n3 && !e3.videoTimingInfo) && (!(i2 && !this.audioDisabled_ && !t3 && !e3.audioTimingInfo) && !Al({ timelineChangeController: this.timelineChangeController_, currentTimeline: this.currentTimeline_, segmentTimeline: e3.timeline, loaderType: this.loaderType_, audioDisabled: this.audioDisabled_ }));
      }, t2.handleData_ = function(e3, t3) {
        if (this.earlyAbortWhenNeeded_(e3.stats), !this.checkForAbort_(e3.requestId))
          if (!this.callQueue_.length && this.hasEnoughInfoToAppend_()) {
            var i2, n3 = this.pendingSegment_;
            if (this.setTimeMapping_(n3.timeline), this.updateMediaSecondsLoaded_(n3.part || n3.segment), "closed" !== this.mediaSource_.readyState) {
              if (e3.map && (e3.map = this.initSegmentForMap(e3.map, true), n3.segment.map = e3.map), e3.key && this.segmentKey(e3.key, true), n3.isFmp4 = e3.isFmp4, n3.timingInfo = n3.timingInfo || {}, n3.isFmp4 ? (this.trigger("fmp4"), n3.timingInfo.start = n3[xl(t3.type)].start) : (i2 = this.getCurrentMediaInfo_(), (i2 = "main" === this.loaderType_ && i2 && i2.hasVideo) && (r2 = n3.videoTimingInfo.start), n3.timingInfo.start = this.trueSegmentStart_({ currentStart: n3.timingInfo.start, playlist: n3.playlist, mediaIndex: n3.mediaIndex, currentVideoTimestampOffset: this.sourceUpdater_.videoTimestampOffset(), useVideoTimingInfo: i2, firstVideoFrameTimeForData: r2, videoTimingInfo: n3.videoTimingInfo, audioTimingInfo: n3.audioTimingInfo })), this.updateAppendInitSegmentStatus(n3, t3.type), this.updateSourceBufferTimestampOffset_(n3), n3.isSyncRequest) {
                this.updateTimingInfoEnd_(n3), this.syncController_.saveSegmentTimingInfo({ segmentInfo: n3, shouldSaveTimelineMapping: "main" === this.loaderType_ });
                var r2 = this.chooseNextRequest_();
                if (r2.mediaIndex !== n3.mediaIndex || r2.partIndex !== n3.partIndex)
                  return void this.logger_("sync segment was incorrect, not appending");
                this.logger_("sync segment was correct, appending");
              }
              n3.hasAppendedData_ = true, this.processMetadataQueue_(), this.appendData_(n3, t3);
            }
          } else
            this.callQueue_.push(this.handleData_.bind(this, e3, t3));
      }, t2.updateAppendInitSegmentStatus = function(e3, t3) {
        "main" !== this.loaderType_ || "number" != typeof e3.timestampOffset || e3.changedTimestampOffset || (this.appendInitSegment_ = { audio: true, video: true }), this.playlistOfLastInitSegment_[t3] !== e3.playlist && (this.appendInitSegment_[t3] = true);
      }, t2.getInitSegmentAndUpdateState_ = function(e3) {
        var t3 = e3.type, i2 = e3.initSegment, n3 = e3.map, r2 = e3.playlist;
        if (n3) {
          e3 = Hu(n3);
          if (this.activeInitSegmentId_ === e3)
            return null;
          i2 = this.initSegmentForMap(n3, true).bytes, this.activeInitSegmentId_ = e3;
        }
        return i2 && this.appendInitSegment_[t3] ? (this.playlistOfLastInitSegment_[t3] = r2, this.appendInitSegment_[t3] = false, this.activeInitSegmentId_ = null, i2) : null;
      }, t2.handleQuotaExceededError_ = function(e3, t3) {
        var i2 = this, n3 = e3.segmentInfo, r2 = e3.type, a2 = e3.bytes, s2 = this.sourceUpdater_.audioBuffered(), o2 = this.sourceUpdater_.videoBuffered();
        1 < s2.length && this.logger_("On QUOTA_EXCEEDED_ERR, found gaps in the audio buffer: " + ru(s2).join(", ")), 1 < o2.length && this.logger_("On QUOTA_EXCEEDED_ERR, found gaps in the video buffer: " + ru(o2).join(", "));
        var u2 = s2.length ? s2.start(0) : 0, l2 = s2.length ? s2.end(s2.length - 1) : 0, d2 = o2.length ? o2.start(0) : 0, e3 = o2.length ? o2.end(o2.length - 1) : 0;
        if (l2 - u2 <= 1 && e3 - d2 <= 1)
          return this.logger_("On QUOTA_EXCEEDED_ERR, single segment too large to append to buffer, triggering an error. Appended byte length: " + a2.byteLength + ", audio buffer: " + ru(s2).join(", ") + ", video buffer: " + ru(o2).join(", ") + ", "), this.error({ message: "Quota exceeded error with append of a single segment of content", excludeUntil: 1 / 0 }), void this.trigger("error");
        this.waitingOnRemove_ = true, this.callQueue_.push(this.appendToSourceBuffer_.bind(this, { segmentInfo: n3, type: r2, bytes: a2 }));
        a2 = this.currentTime_() - 1;
        this.logger_("On QUOTA_EXCEEDED_ERR, removing audio/video from 0 to " + a2), this.remove(0, a2, function() {
          i2.logger_("On QUOTA_EXCEEDED_ERR, retrying append in 1s"), i2.waitingOnRemove_ = false, i2.quotaExceededErrorRetryTimeout_ = window.setTimeout(function() {
            i2.logger_("On QUOTA_EXCEEDED_ERR, re-processing call queue"), i2.quotaExceededErrorRetryTimeout_ = null, i2.processCallQueue_();
          }, 1e3);
        }, true);
      }, t2.handleAppendError_ = function(e3, t3) {
        var i2 = e3.segmentInfo, n3 = e3.type, e3 = e3.bytes;
        t3 && (22 !== t3.code ? (this.logger_("Received non QUOTA_EXCEEDED_ERR on append", t3), this.error(n3 + " append of " + e3.length + "b failed for segment #" + i2.mediaIndex + " in playlist " + i2.playlist.id), this.trigger("appenderror")) : this.handleQuotaExceededError_({ segmentInfo: i2, type: n3, bytes: e3 }));
      }, t2.appendToSourceBuffer_ = function(e3) {
        var t3, i2, n3 = e3.segmentInfo, r2 = e3.type, a2 = e3.initSegment, s2 = e3.data, o2 = e3.bytes;
        o2 || (e3 = [s2], s2 = s2.byteLength, a2 && (e3.unshift(a2), s2 += a2.byteLength), i2 = 0, (e3 = { bytes: s2, segments: e3 }).bytes && (t3 = new Uint8Array(e3.bytes), e3.segments.forEach(function(e4) {
          t3.set(e4, i2), i2 += e4.byteLength;
        })), o2 = t3), this.sourceUpdater_.appendBuffer({ segmentInfo: n3, type: r2, bytes: o2 }, this.handleAppendError_.bind(this, { segmentInfo: n3, type: r2, bytes: o2 }));
      }, t2.handleSegmentTimingInfo_ = function(e3, t3, i2) {
        this.pendingSegment_ && t3 === this.pendingSegment_.requestId && ((t3 = this.pendingSegment_.segment)[e3 = e3 + "TimingInfo"] || (t3[e3] = {}), t3[e3].transmuxerPrependedSeconds = i2.prependedContentDuration || 0, t3[e3].transmuxedPresentationStart = i2.start.presentation, t3[e3].transmuxedDecodeStart = i2.start.decode, t3[e3].transmuxedPresentationEnd = i2.end.presentation, t3[e3].transmuxedDecodeEnd = i2.end.decode, t3[e3].baseMediaDecodeTime = i2.baseMediaDecodeTime);
      }, t2.appendData_ = function(e3, t3) {
        var i2 = t3.type, n3 = t3.data;
        n3 && n3.byteLength && ("audio" === i2 && this.audioDisabled_ || (t3 = this.getInitSegmentAndUpdateState_({ type: i2, initSegment: t3.initSegment, playlist: e3.playlist, map: e3.isFmp4 ? e3.segment.map : null }), this.appendToSourceBuffer_({ segmentInfo: e3, type: i2, initSegment: t3, data: n3 })));
      }, t2.loadSegment_ = function(t3) {
        var i2 = this;
        this.state = "WAITING", this.pendingSegment_ = t3, this.trimBackBuffer_(t3), "number" == typeof t3.timestampOffset && this.transmuxer_ && this.transmuxer_.postMessage({ action: "clearAllMp4Captions" }), this.hasEnoughInfoToLoad_() ? this.updateTransmuxerAndRequestSegment_(t3) : this.loadQueue_.push(function() {
          var e3 = g({}, t3, { forceTimestampOffset: true });
          g(t3, i2.generateSegmentInfo_(e3)), i2.isPendingTimestampOffset_ = false, i2.updateTransmuxerAndRequestSegment_(t3);
        });
      }, t2.updateTransmuxerAndRequestSegment_ = function(n3) {
        var r2 = this;
        this.shouldUpdateTransmuxerTimestampOffset_(n3.timestampOffset) && (this.gopBuffer_.length = 0, n3.gopsToAlignWith = [], this.timeMapping_ = 0, this.transmuxer_.postMessage({ action: "reset" }), this.transmuxer_.postMessage({ action: "setTimestampOffset", timestampOffset: n3.timestampOffset }));
        var e3 = this.createSimplifiedSegmentObj_(n3), t3 = this.isEndOfStream_(n3.mediaIndex, n3.playlist, n3.partIndex), i2 = null !== this.mediaIndex, a2 = n3.timeline !== this.currentTimeline_ && 0 < n3.timeline, a2 = t3 || i2 && a2;
        this.logger_("Requesting " + Il(n3)), e3.map && !e3.map.bytes && (this.logger_("going to request init segment."), this.appendInitSegment_ = { video: true, audio: true }), n3.abortRequests = fl({ xhr: this.vhs_.xhr, xhrOptions: this.xhrOptions_, decryptionWorker: this.decrypter_, segment: e3, abortFn: this.handleAbort_.bind(this, n3), progressFn: this.handleProgress_.bind(this), trackInfoFn: this.handleTrackInfo_.bind(this), timingInfoFn: this.handleTimingInfo_.bind(this), videoSegmentTimingInfoFn: this.handleSegmentTimingInfo_.bind(this, "video", n3.requestId), audioSegmentTimingInfoFn: this.handleSegmentTimingInfo_.bind(this, "audio", n3.requestId), captionsFn: this.handleCaptions_.bind(this), isEndOfTimeline: a2, endedTimelineFn: function() {
          r2.logger_("received endedtimeline callback");
        }, id3Fn: this.handleId3_.bind(this), dataFn: this.handleData_.bind(this), doneFn: this.segmentRequestFinished_.bind(this), onTransmuxerLog: function(e4) {
          var t4 = e4.message, i3 = e4.level, e4 = e4.stream;
          r2.logger_(Il(n3) + " logged from transmuxer stream " + e4 + " as a " + i3 + ": " + t4);
        } });
      }, t2.trimBackBuffer_ = function(e3) {
        var t3, i2, n3, r2, r2 = (t3 = this.seekable_(), i2 = this.currentTime_(), n3 = this.playlist_.targetDuration || 10, r2 = i2 - Wl.BACK_BUFFER_LENGTH, t3.length && (r2 = Math.max(r2, t3.start(0))), Math.min(i2 - n3, r2));
        0 < r2 && this.remove(0, r2);
      }, t2.createSimplifiedSegmentObj_ = function(e3) {
        var t3 = e3.segment, i2 = e3.part, n3 = { resolvedUri: (i2 || t3).resolvedUri, byterange: (i2 || t3).byterange, requestId: e3.requestId, transmuxer: e3.transmuxer, audioAppendStart: e3.audioAppendStart, gopsToAlignWith: e3.gopsToAlignWith, part: e3.part }, i2 = e3.playlist.segments[e3.mediaIndex - 1];
        return i2 && i2.timeline === t3.timeline && (i2.videoTimingInfo ? n3.baseStartTime = i2.videoTimingInfo.transmuxedDecodeEnd : i2.audioTimingInfo && (n3.baseStartTime = i2.audioTimingInfo.transmuxedDecodeEnd)), t3.key && (e3 = t3.key.iv || new Uint32Array([0, 0, 0, e3.mediaIndex + e3.playlist.mediaSequence]), n3.key = this.segmentKey(t3.key), n3.key.iv = e3), t3.map && (n3.map = this.initSegmentForMap(t3.map)), n3;
      }, t2.saveTransferStats_ = function(e3) {
        this.mediaRequests += 1, e3 && (this.mediaBytesTransferred += e3.bytesReceived, this.mediaTransferDuration += e3.roundTripTime);
      }, t2.saveBandwidthRelatedStats_ = function(e3, t3) {
        this.pendingSegment_.byteLength = t3.bytesReceived, e3 < 1 / 60 ? this.logger_("Ignoring segment's bandwidth because its duration of " + e3 + " is less than the min to record " + 1 / 60) : (this.bandwidth = t3.bandwidth, this.roundTrip = t3.roundTripTime);
      }, t2.handleTimeout_ = function() {
        this.mediaRequestsTimedout += 1, this.bandwidth = 1, this.roundTrip = NaN, this.trigger("bandwidthupdate"), this.trigger("timeout");
      }, t2.segmentRequestFinished_ = function(e3, t3, i2) {
        if (this.callQueue_.length)
          this.callQueue_.push(this.segmentRequestFinished_.bind(this, e3, t3, i2));
        else if (this.saveTransferStats_(t3.stats), this.pendingSegment_ && t3.requestId === this.pendingSegment_.requestId) {
          if (e3)
            return this.pendingSegment_ = null, this.state = "READY", e3.code === $l ? void 0 : (this.pause(), e3.code === Ql ? void this.handleTimeout_() : (this.mediaRequestsErrored += 1, this.error(e3), void this.trigger("error")));
          e3 = this.pendingSegment_;
          this.saveBandwidthRelatedStats_(e3.duration, t3.stats), e3.endOfAllRequests = t3.endOfAllRequests, i2.gopInfo && (this.gopBuffer_ = function(e4, t4, i3) {
            if (!t4.length)
              return e4;
            if (i3)
              return t4.slice();
            for (var n3 = t4[0].pts, r2 = 0; r2 < e4.length && !(e4[r2].pts >= n3); r2++)
              ;
            return e4.slice(0, r2).concat(t4);
          }(this.gopBuffer_, i2.gopInfo, this.safeAppend_)), this.state = "APPENDING", this.trigger("appending"), this.waitForAppendsToComplete_(e3);
        }
      }, t2.setTimeMapping_ = function(e3) {
        e3 = this.syncController_.mappingForTimeline(e3);
        null !== e3 && (this.timeMapping_ = e3);
      }, t2.updateMediaSecondsLoaded_ = function(e3) {
        "number" == typeof e3.start && "number" == typeof e3.end ? this.mediaSecondsLoaded += e3.end - e3.start : this.mediaSecondsLoaded += e3.duration;
      }, t2.shouldUpdateTransmuxerTimestampOffset_ = function(e3) {
        return null !== e3 && ("main" === this.loaderType_ && e3 !== this.sourceUpdater_.videoTimestampOffset() || !this.audioDisabled_ && e3 !== this.sourceUpdater_.audioTimestampOffset());
      }, t2.trueSegmentStart_ = function(e3) {
        var t3 = e3.currentStart, i2 = e3.playlist, n3 = e3.mediaIndex, r2 = e3.firstVideoFrameTimeForData, a2 = e3.currentVideoTimestampOffset, s2 = e3.useVideoTimingInfo, o2 = e3.videoTimingInfo, e3 = e3.audioTimingInfo;
        if ("undefined" != typeof t3)
          return t3;
        if (!s2)
          return e3.start;
        i2 = i2.segments[n3 - 1];
        return 0 !== n3 && i2 && "undefined" != typeof i2.start && i2.end === r2 + a2 ? o2.start : r2;
      }, t2.waitForAppendsToComplete_ = function(e3) {
        var t3 = this.getCurrentMediaInfo_(e3);
        if (!t3)
          return this.error({ message: "No starting media returned, likely due to an unsupported media format.", blacklistDuration: 1 / 0 }), void this.trigger("error");
        var i2 = t3.hasAudio, n3 = t3.hasVideo, t3 = t3.isMuxed, n3 = "main" === this.loaderType_ && n3, t3 = !this.audioDisabled_ && i2 && !t3;
        if (e3.waitingOnAppends = 0, !e3.hasAppendedData_)
          return e3.timingInfo || "number" != typeof e3.timestampOffset || (this.isPendingTimestampOffset_ = true), e3.timingInfo = { start: 0 }, e3.waitingOnAppends++, this.isPendingTimestampOffset_ || (this.updateSourceBufferTimestampOffset_(e3), this.processMetadataQueue_()), void this.checkAppendsDone_(e3);
        n3 && e3.waitingOnAppends++, t3 && e3.waitingOnAppends++, n3 && this.sourceUpdater_.videoQueueCallback(this.checkAppendsDone_.bind(this, e3)), t3 && this.sourceUpdater_.audioQueueCallback(this.checkAppendsDone_.bind(this, e3));
      }, t2.checkAppendsDone_ = function(e3) {
        this.checkForAbort_(e3.requestId) || (e3.waitingOnAppends--, 0 === e3.waitingOnAppends && this.handleAppendsDone_());
      }, t2.checkForIllegalMediaSwitch = function(e3) {
        var t3, i2, e3 = (t3 = this.loaderType_, i2 = this.getCurrentMediaInfo_(), e3 = e3, "main" === t3 && i2 && e3 ? e3.hasAudio || e3.hasVideo ? i2.hasVideo && !e3.hasVideo ? "Only audio found in segment when we expected video. We can't switch to audio only from a stream that had video. To get rid of this message, please add codec information to the manifest." : !i2.hasVideo && e3.hasVideo ? "Video found in segment when we expected only audio. We can't switch to a stream with video from an audio only stream. To get rid of this message, please add codec information to the manifest." : null : "Neither audio nor video found in segment." : null);
        return !!e3 && (this.error({ message: e3, blacklistDuration: 1 / 0 }), this.trigger("error"), true);
      }, t2.updateSourceBufferTimestampOffset_ = function(e3) {
        var t3;
        null === e3.timestampOffset || "number" != typeof e3.timingInfo.start || e3.changedTimestampOffset || "main" !== this.loaderType_ || (t3 = false, e3.timestampOffset -= this.getSegmentStartTimeForTimestampOffsetCalculation_({ videoTimingInfo: e3.segment.videoTimingInfo, audioTimingInfo: e3.segment.audioTimingInfo, timingInfo: e3.timingInfo }), e3.changedTimestampOffset = true, e3.timestampOffset !== this.sourceUpdater_.videoTimestampOffset() && (this.sourceUpdater_.videoTimestampOffset(e3.timestampOffset), t3 = true), e3.timestampOffset !== this.sourceUpdater_.audioTimestampOffset() && (this.sourceUpdater_.audioTimestampOffset(e3.timestampOffset), t3 = true), t3 && this.trigger("timestampoffset"));
      }, t2.getSegmentStartTimeForTimestampOffsetCalculation_ = function(e3) {
        var t3 = e3.videoTimingInfo, i2 = e3.audioTimingInfo, e3 = e3.timingInfo;
        return this.useDtsForTimestampOffset_ ? t3 && "number" == typeof t3.transmuxedDecodeStart ? t3.transmuxedDecodeStart : i2 && "number" == typeof i2.transmuxedDecodeStart ? i2.transmuxedDecodeStart : e3.start : e3.start;
      }, t2.updateTimingInfoEnd_ = function(e3) {
        e3.timingInfo = e3.timingInfo || {};
        var t3 = this.getMediaInfo_(), t3 = "main" === this.loaderType_ && t3 && t3.hasVideo && e3.videoTimingInfo ? e3.videoTimingInfo : e3.audioTimingInfo;
        t3 && (e3.timingInfo.end = "number" == typeof t3.end ? t3.end : t3.start + e3.duration);
      }, t2.handleAppendsDone_ = function() {
        if (this.pendingSegment_ && this.trigger("appendsdone"), !this.pendingSegment_)
          return this.state = "READY", void (this.paused() || this.monitorBuffer_());
        var e3 = this.pendingSegment_;
        this.updateTimingInfoEnd_(e3), this.shouldSaveSegmentTimingInfo_ && this.syncController_.saveSegmentTimingInfo({ segmentInfo: e3, shouldSaveTimelineMapping: "main" === this.loaderType_ });
        var t3 = Ll(e3, this.sourceType_);
        if (t3 && ("warn" === t3.severity ? ir.log.warn(t3.message) : this.logger_(t3.message)), this.recordThroughput_(e3), this.pendingSegment_ = null, this.state = "READY", !e3.isSyncRequest || (this.trigger("syncinfoupdate"), e3.hasAppendedData_)) {
          this.logger_("Appended " + Il(e3)), this.addSegmentMetadataCue_(e3), this.fetchAtBuffer_ = true, this.currentTimeline_ !== e3.timeline && (this.timelineChangeController_.lastTimelineChange({ type: this.loaderType_, from: this.currentTimeline_, to: e3.timeline }), "main" !== this.loaderType_ || this.audioDisabled_ || this.timelineChangeController_.lastTimelineChange({ type: "audio", from: this.currentTimeline_, to: e3.timeline })), this.currentTimeline_ = e3.timeline, this.trigger("syncinfoupdate");
          var i2 = e3.segment, t3 = e3.part, i2 = i2.end && this.currentTime_() - i2.end > 3 * e3.playlist.targetDuration, t3 = t3 && t3.end && this.currentTime_() - t3.end > 3 * e3.playlist.partTargetDuration;
          if (i2 || t3)
            return this.logger_("bad " + (i2 ? "segment" : "part") + " " + Il(e3)), void this.resetEverything();
          null !== this.mediaIndex && this.trigger("bandwidthupdate"), this.trigger("progress"), this.mediaIndex = e3.mediaIndex, this.partIndex = e3.partIndex, this.isEndOfStream_(e3.mediaIndex, e3.playlist, e3.partIndex) && this.endOfStream(), this.trigger("appended"), e3.hasAppendedData_ && this.mediaAppends++, this.paused() || this.monitorBuffer_();
        } else
          this.logger_("Throwing away un-appended sync request " + Il(e3));
      }, t2.recordThroughput_ = function(e3) {
        var t3, i2;
        e3.duration < 1 / 60 ? this.logger_("Ignoring segment's throughput because its duration of " + e3.duration + " is less than the min to record " + 1 / 60) : (t3 = this.throughput.rate, i2 = Date.now() - e3.endOfAllRequests + 1, i2 = Math.floor(e3.byteLength / i2 * 8 * 1e3), this.throughput.rate += (i2 - t3) / ++this.throughput.count);
      }, t2.addSegmentMetadataCue_ = function(e3) {
        var t3, i2, n3, r2;
        this.segmentMetadataTrack_ && (i2 = (t3 = e3.segment).start, r2 = t3.end, Cl(i2) && Cl(r2) && (kl(i2, r2, this.segmentMetadataTrack_), n3 = window.WebKitDataCue || window.VTTCue, e3 = { custom: t3.custom, dateTimeObject: t3.dateTimeObject, dateTimeString: t3.dateTimeString, bandwidth: e3.playlist.attributes.BANDWIDTH, resolution: e3.playlist.attributes.RESOLUTION, codecs: e3.playlist.attributes.CODECS, byteLength: e3.byteLength, uri: e3.uri, timeline: e3.timeline, playlist: e3.playlist.id, start: i2, end: r2 }, (r2 = new n3(i2, r2, JSON.stringify(e3))).value = e3, this.segmentMetadataTrack_.addCue(r2)));
      }, e2;
    }(ir.EventTarget);
    function td() {
    }
    function id(e2) {
      return "string" != typeof e2 ? e2 : e2.replace(/./, function(e3) {
        return e3.toUpperCase();
      });
    }
    function nd(e2, t2) {
      var i2 = t2[e2 + "Buffer"];
      return i2 && i2.updating || t2.queuePending[e2];
    }
    function rd(e2, t2) {
      if (0 !== t2.queue.length) {
        var i2 = 0, n2 = t2.queue[i2];
        if ("mediaSource" !== n2.type) {
          if ("mediaSource" !== e2 && t2.ready() && "closed" !== t2.mediaSource.readyState && !nd(e2, t2)) {
            if (n2.type !== e2) {
              if (null === (i2 = function(e3, t3) {
                for (var i3 = 0; i3 < t3.length; i3++) {
                  var n3 = t3[i3];
                  if ("mediaSource" === n3.type)
                    return null;
                  if (n3.type === e3)
                    return i3;
                }
                return null;
              }(e2, t2.queue)))
                return;
              n2 = t2.queue[i2];
            }
            t2.queue.splice(i2, 1), (t2.queuePending[e2] = n2).action(e2, t2), n2.doneFn || (t2.queuePending[e2] = null, rd(e2, t2));
          }
        } else
          t2.updating() || "closed" === t2.mediaSource.readyState || (t2.queue.shift(), n2.action(t2), n2.doneFn && n2.doneFn(), rd("audio", t2), rd("video", t2));
      }
    }
    function ad(e2, t2) {
      var i2 = t2[e2 + "Buffer"], n2 = id(e2);
      i2 && (i2.removeEventListener("updateend", t2["on" + n2 + "UpdateEnd_"]), i2.removeEventListener("error", t2["on" + n2 + "Error_"]), t2.codecs[e2] = null, t2[e2 + "Buffer"] = null);
    }
    function sd(e2, t2) {
      return e2 && t2 && -1 !== Array.prototype.indexOf.call(e2.sourceBuffers, t2);
    }
    function od(e2) {
      var t2 = e2.type, i2 = e2.sourceUpdater, n2 = e2.action, r2 = e2.doneFn, e2 = e2.name;
      i2.queue.push({ type: t2, action: n2, doneFn: r2, name: e2 }), rd(t2, i2);
    }
    function ud(i2, n2) {
      return function(e2) {
        var t2;
        n2.queuePending[i2] && (t2 = n2.queuePending[i2].doneFn, n2.queuePending[i2] = null, t2 && t2(n2[i2 + "Error_"])), rd(i2, n2);
      };
    }
    function ld(e2) {
      return decodeURIComponent(escape(String.fromCharCode.apply(null, e2)));
    }
    function dd(e2, t2) {
      e2.abort(), e2.pause(), t2 && t2.activePlaylistLoader && (t2.activePlaylistLoader.pause(), t2.activePlaylistLoader = null);
    }
    function cd(e2, t2) {
      (t2.activePlaylistLoader = e2).load();
    }
    function hd(e2, t2) {
      for (var i2 = 0; i2 < e2.length; i2++) {
        if (Tu(t2, e2[i2]))
          return true;
        if (e2[i2].playlists && hd(e2[i2].playlists, t2))
          return true;
      }
      return false;
    }
    function pd(a2) {
      ["AUDIO", "SUBTITLES", "CLOSED-CAPTIONS"].forEach(function(e3) {
        Bd[e3](e3, a2);
      });
      var e2, s2 = a2.mediaTypes, t2 = a2.masterPlaylistLoader, i2 = a2.tech, n2 = a2.vhs, r2 = a2.segmentLoaders, o2 = r2.AUDIO, u2 = r2.main;
      function l2() {
        s2.AUDIO.onTrackChanged(), i2.trigger({ type: "usage", name: "vhs-audio-change" }), i2.trigger({ type: "usage", name: "hls-audio-change" });
      }
      for (e2 in ["AUDIO", "SUBTITLES"].forEach(function(e3) {
        var u3, l3, o3, d2, t3, i3, c2, h2, n3, r3;
        s2[e3].activeGroup = (u3 = e3, l3 = a2, function(t4) {
          var e4 = l3.masterPlaylistLoader, i4 = l3.mediaTypes[u3].groups, n4 = e4.media();
          if (!n4)
            return null;
          var r4 = null;
          n4.attributes[u3] && (r4 = i4[n4.attributes[u3]]);
          var a3 = Object.keys(i4);
          if (!r4)
            if ("AUDIO" === u3 && 1 < a3.length && Su(l3.master))
              for (var s3 = 0; s3 < a3.length; s3++) {
                var o4 = i4[a3[s3]];
                if (hd(o4, n4)) {
                  r4 = o4;
                  break;
                }
              }
            else
              i4.main ? r4 = i4.main : 1 === a3.length && (r4 = i4[a3[0]]);
          return "undefined" == typeof t4 ? r4 : null !== t4 && r4 && r4.filter(function(e5) {
            return e5.id === t4.id;
          })[0] || null;
        }), s2[e3].activeTrack = Fd[e3](e3, a2), s2[e3].onGroupChanged = (o3 = e3, d2 = a2, function() {
          var e4 = d2.segmentLoaders, t4 = e4[o3], i4 = e4.main, n4 = d2.mediaTypes[o3], r4 = n4.activeTrack(), a3 = n4.getActiveGroup(), s3 = n4.activePlaylistLoader, e4 = n4.lastGroup_;
          a3 && e4 && a3.id === e4.id || (n4.lastGroup_ = a3, n4.lastTrack_ = r4, dd(t4, n4), a3 && !a3.isMasterPlaylist && (a3.playlistLoader ? (t4.resyncLoader(), cd(a3.playlistLoader, n4)) : s3 && i4.resetEverything()));
        }), s2[e3].onGroupChanging = (t3 = e3, i3 = a2, function() {
          var e4 = i3.segmentLoaders[t3];
          i3.mediaTypes[t3].lastGroup_ = null, e4.abort(), e4.pause();
        }), s2[e3].onTrackChanged = (c2 = e3, h2 = a2, function() {
          var e4 = h2.masterPlaylistLoader, t4 = h2.segmentLoaders, i4 = t4[c2], n4 = t4.main, r4 = h2.mediaTypes[c2], a3 = r4.activeTrack(), s3 = r4.getActiveGroup(), o4 = r4.activePlaylistLoader, u4 = r4.lastTrack_;
          if ((!u4 || !a3 || u4.id !== a3.id) && (r4.lastGroup_ = s3, r4.lastTrack_ = a3, dd(i4, r4), s3)) {
            if (s3.isMasterPlaylist) {
              if (!a3 || !u4 || a3.id === u4.id)
                return;
              var l4 = h2.vhs.masterPlaylistController_, t4 = l4.selectPlaylist();
              return l4.media() === t4 ? void 0 : (r4.logger_("track change. Switching master audio from " + u4.id + " to " + a3.id), e4.pause(), n4.resetEverything(), void l4.fastQualityChange_(t4));
            }
            if ("AUDIO" === c2) {
              if (!s3.playlistLoader)
                return n4.setAudio(true), void n4.resetEverything();
              i4.setAudio(true), n4.setAudio(false);
            }
            o4 !== s3.playlistLoader && (i4.track && i4.track(a3), i4.resetEverything()), cd(s3.playlistLoader, r4);
          }
        }), s2[e3].getActiveGroup = (n3 = e3, r3 = a2.mediaTypes, function() {
          var e4 = r3[n3].activeTrack();
          return e4 ? r3[n3].activeGroup(e4) : null;
        });
      }), (r2 = s2.AUDIO.activeGroup()) && (r2 = (r2.filter(function(e3) {
        return e3.default;
      })[0] || r2[0]).id, s2.AUDIO.tracks[r2].enabled = true, s2.AUDIO.onGroupChanged(), s2.AUDIO.onTrackChanged(), s2.AUDIO.getActiveGroup().playlistLoader ? (u2.setAudio(false), o2.setAudio(true)) : u2.setAudio(true)), t2.on("mediachange", function() {
        ["AUDIO", "SUBTITLES"].forEach(function(e3) {
          return s2[e3].onGroupChanged();
        });
      }), t2.on("mediachanging", function() {
        ["AUDIO", "SUBTITLES"].forEach(function(e3) {
          return s2[e3].onGroupChanging();
        });
      }), i2.audioTracks().addEventListener("change", l2), i2.remoteTextTracks().addEventListener("change", s2.SUBTITLES.onTrackChanged), n2.on("dispose", function() {
        i2.audioTracks().removeEventListener("change", l2), i2.remoteTextTracks().removeEventListener("change", s2.SUBTITLES.onTrackChanged);
      }), i2.clearTracks("audio"), s2.AUDIO.tracks)
        i2.audioTracks().addTrack(s2.AUDIO.tracks[e2]);
    }
    function fd(e2, t2, i2) {
      var n2, r2, a2, s2, o2 = e2.masterPlaylistController_, u2 = o2[(e2.options_.smoothQualityChange ? "smooth" : "fast") + "QualityChange_"].bind(o2);
      t2.attributes && (n2 = t2.attributes.RESOLUTION, this.width = n2 && n2.width, this.height = n2 && n2.height, this.bandwidth = t2.attributes.BANDWIDTH, this.frameRate = t2.attributes["FRAME-RATE"]), this.codecs = vl(o2.master(), t2), this.playlist = t2, this.id = i2, this.enabled = (r2 = e2.playlists, a2 = t2.id, s2 = u2, function(e3) {
        var t3 = r2.master.playlists[a2], i3 = yu(t3), n3 = vu(t3);
        return "undefined" == typeof e3 ? n3 : (e3 ? delete t3.disabled : t3.disabled = true, e3 === n3 || i3 || (s2(), e3 ? r2.trigger("renditionenabled") : r2.trigger("renditiondisabled")), e3);
      });
    }
    function md(t2, e2) {
      var i2 = 0, n2 = 0, r2 = ir.mergeOptions(Wd, e2);
      function a2() {
        n2 && t2.currentTime(n2);
      }
      function s2(e3) {
        null != e3 && (n2 = t2.duration() !== 1 / 0 && t2.currentTime() || 0, t2.one("loadedmetadata", a2), t2.src(e3), t2.trigger({ type: "usage", name: "vhs-error-reload" }), t2.trigger({ type: "usage", name: "hls-error-reload" }), t2.play());
      }
      function o2() {
        return Date.now() - i2 < 1e3 * r2.errorInterval ? (t2.trigger({ type: "usage", name: "vhs-error-reload-canceled" }), void t2.trigger({ type: "usage", name: "hls-error-reload-canceled" })) : r2.getSource && "function" == typeof r2.getSource ? (i2 = Date.now(), r2.getSource.call(t2, s2)) : void ir.log.error("ERROR: reloadSourceOnError - The option getSource must be a function!");
      }
      function u2() {
        t2.off("loadedmetadata", a2), t2.off("error", o2), t2.off("dispose", u2);
      }
      t2.ready(function() {
        t2.trigger({ type: "usage", name: "vhs-error-reload-initialized" }), t2.trigger({ type: "usage", name: "hls-error-reload-initialized" });
      }), t2.on("error", o2), t2.on("dispose", u2), t2.reloadSourceOnError = function(e3) {
        u2(), md(t2, e3);
      };
    }
    var gd, yd = ["video", "audio"], vd = function(n2, r2, a2) {
      return function(t2, i2) {
        var e2 = i2[t2 + "Buffer"];
        if (sd(i2.mediaSource, e2)) {
          i2.logger_("Appending segment " + r2.mediaIndex + "'s " + n2.length + " bytes to " + t2 + "Buffer");
          try {
            e2.appendBuffer(n2);
          } catch (e3) {
            i2.logger_("Error with code " + e3.code + " " + (22 === e3.code ? "(QUOTA_EXCEEDED_ERR) " : "") + "when appending segment " + r2.mediaIndex + " to " + t2 + "Buffer"), i2.queuePending[t2] = null, a2(e3);
          }
        }
      };
    }, _d = function(n2, r2) {
      return function(t2, i2) {
        var e2 = i2[t2 + "Buffer"];
        if (sd(i2.mediaSource, e2)) {
          i2.logger_("Removing " + n2 + " to " + r2 + " from " + t2 + "Buffer");
          try {
            e2.remove(n2, r2);
          } catch (e3) {
            i2.logger_("Remove " + n2 + " to " + r2 + " from " + t2 + "Buffer failed");
          }
        }
      };
    }, bd = function(n2) {
      return function(e2, t2) {
        var i2 = t2[e2 + "Buffer"];
        sd(t2.mediaSource, i2) && (t2.logger_("Setting " + e2 + "timestampOffset to " + n2), i2.timestampOffset = n2);
      };
    }, Td = function(i2) {
      return function(e2, t2) {
        i2();
      };
    }, wd = function(t2) {
      return function(e2) {
        if ("open" === e2.mediaSource.readyState) {
          e2.logger_("Calling mediaSource endOfStream(" + (t2 || "") + ")");
          try {
            e2.mediaSource.endOfStream(t2);
          } catch (e3) {
            ir.log.warn("Failed to call media source endOfStream", e3);
          }
        }
      };
    }, Sd = function(t2) {
      return function(e2) {
        e2.logger_("Setting mediaSource duration to " + t2);
        try {
          e2.mediaSource.duration = t2;
        } catch (e3) {
          ir.log.warn("Failed to set media source duration", e3);
        }
      };
    }, Ed = function() {
      return function(t2, e2) {
        if ("open" === e2.mediaSource.readyState) {
          var i2 = e2[t2 + "Buffer"];
          if (sd(e2.mediaSource, i2)) {
            e2.logger_("calling abort on " + t2 + "Buffer");
            try {
              i2.abort();
            } catch (e3) {
              ir.log.warn("Failed to abort on " + t2 + "Buffer", e3);
            }
          }
        }
      };
    }, kd = function(n2, r2) {
      return function(e2) {
        var t2 = id(n2), i2 = fr(r2);
        e2.logger_("Adding " + n2 + "Buffer with codec " + r2 + " to mediaSource");
        i2 = e2.mediaSource.addSourceBuffer(i2);
        i2.addEventListener("updateend", e2["on" + t2 + "UpdateEnd_"]), i2.addEventListener("error", e2["on" + t2 + "Error_"]), e2.codecs[n2] = r2, e2[n2 + "Buffer"] = i2;
      };
    }, Cd = function(i2) {
      return function(e2) {
        var t2 = e2[i2 + "Buffer"];
        if (ad(i2, e2), sd(e2.mediaSource, t2)) {
          e2.logger_("Removing " + i2 + "Buffer with codec " + e2.codecs[i2] + " from mediaSource");
          try {
            e2.mediaSource.removeSourceBuffer(t2);
          } catch (e3) {
            ir.log.warn("Failed to removeSourceBuffer " + i2 + "Buffer", e3);
          }
        }
      };
    }, Id = function(r2) {
      return function(e2, t2) {
        var i2 = t2[e2 + "Buffer"], n2 = fr(r2);
        sd(t2.mediaSource, i2) && t2.codecs[e2] !== r2 && (t2.logger_("changing " + e2 + "Buffer codec from " + t2.codecs[e2] + " to " + r2), i2.changeType(n2), t2.codecs[e2] = r2);
      };
    }, xd = function(i2) {
      function e2(e3) {
        var t3 = i2.call(this) || this;
        return t3.mediaSource = e3, t3.sourceopenListener_ = function() {
          return rd("mediaSource", ft(t3));
        }, t3.mediaSource.addEventListener("sourceopen", t3.sourceopenListener_), t3.logger_ = Zo("SourceUpdater"), t3.audioTimestampOffset_ = 0, t3.videoTimestampOffset_ = 0, t3.queue = [], t3.queuePending = { audio: null, video: null }, t3.delayedAudioAppendQueue_ = [], t3.videoAppendQueued_ = false, t3.codecs = {}, t3.onVideoUpdateEnd_ = ud("video", ft(t3)), t3.onAudioUpdateEnd_ = ud("audio", ft(t3)), t3.onVideoError_ = function(e4) {
          t3.videoError_ = e4;
        }, t3.onAudioError_ = function(e4) {
          t3.audioError_ = e4;
        }, t3.createdSourceBuffers_ = false, t3.initializedEme_ = false, t3.triggeredReady_ = false, t3;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.initializedEme = function() {
        this.initializedEme_ = true, this.triggerReady();
      }, t2.hasCreatedSourceBuffers = function() {
        return this.createdSourceBuffers_;
      }, t2.hasInitializedAnyEme = function() {
        return this.initializedEme_;
      }, t2.ready = function() {
        return this.hasCreatedSourceBuffers() && this.hasInitializedAnyEme();
      }, t2.createSourceBuffers = function(e3) {
        this.hasCreatedSourceBuffers() || (this.addOrChangeSourceBuffers(e3), this.createdSourceBuffers_ = true, this.trigger("createdsourcebuffers"), this.triggerReady());
      }, t2.triggerReady = function() {
        this.ready() && !this.triggeredReady_ && (this.triggeredReady_ = true, this.trigger("ready"));
      }, t2.addSourceBuffer = function(e3, t3) {
        od({ type: "mediaSource", sourceUpdater: this, action: kd(e3, t3), name: "addSourceBuffer" });
      }, t2.abort = function(e3) {
        od({ type: e3, sourceUpdater: this, action: Ed(), name: "abort" });
      }, t2.removeSourceBuffer = function(e3) {
        this.canRemoveSourceBuffer() ? od({ type: "mediaSource", sourceUpdater: this, action: Cd(e3), name: "removeSourceBuffer" }) : ir.log.error("removeSourceBuffer is not supported!");
      }, t2.canRemoveSourceBuffer = function() {
        return !ir.browser.IE_VERSION && !ir.browser.IS_FIREFOX && window.MediaSource && window.MediaSource.prototype && "function" == typeof window.MediaSource.prototype.removeSourceBuffer;
      }, e2.canChangeType = function() {
        return window.SourceBuffer && window.SourceBuffer.prototype && "function" == typeof window.SourceBuffer.prototype.changeType;
      }, t2.canChangeType = function() {
        return this.constructor.canChangeType();
      }, t2.changeType = function(e3, t3) {
        this.canChangeType() ? od({ type: e3, sourceUpdater: this, action: Id(t3), name: "changeType" }) : ir.log.error("changeType is not supported!");
      }, t2.addOrChangeSourceBuffers = function(i3) {
        var n2 = this;
        if (!i3 || "object" != typeof i3 || 0 === Object.keys(i3).length)
          throw new Error("Cannot addOrChangeSourceBuffers to undefined codecs");
        Object.keys(i3).forEach(function(e3) {
          var t3 = i3[e3];
          if (!n2.hasCreatedSourceBuffers())
            return n2.addSourceBuffer(e3, t3);
          n2.canChangeType() && n2.changeType(e3, t3);
        });
      }, t2.appendBuffer = function(e3, t3) {
        var i3 = this, n2 = e3.segmentInfo, r2 = e3.type, a2 = e3.bytes;
        if (this.processedAppend_ = true, "audio" === r2 && this.videoBuffer && !this.videoAppendQueued_)
          return this.delayedAudioAppendQueue_.push([e3, t3]), void this.logger_("delayed audio append of " + a2.length + " until video append");
        od({ type: r2, sourceUpdater: this, action: vd(a2, n2 || { mediaIndex: -1 }, t3), doneFn: t3, name: "appendBuffer" }), "video" === r2 && (this.videoAppendQueued_ = true, this.delayedAudioAppendQueue_.length && (r2 = this.delayedAudioAppendQueue_.slice(), this.logger_("queuing delayed audio " + r2.length + " appendBuffers"), this.delayedAudioAppendQueue_.length = 0, r2.forEach(function(e4) {
          i3.appendBuffer.apply(i3, e4);
        })));
      }, t2.audioBuffered = function() {
        return sd(this.mediaSource, this.audioBuffer) && this.audioBuffer.buffered || ir.createTimeRange();
      }, t2.videoBuffered = function() {
        return sd(this.mediaSource, this.videoBuffer) && this.videoBuffer.buffered || ir.createTimeRange();
      }, t2.buffered = function() {
        var e3 = sd(this.mediaSource, this.videoBuffer) ? this.videoBuffer : null, t3 = sd(this.mediaSource, this.audioBuffer) ? this.audioBuffer : null;
        return t3 && !e3 ? this.audioBuffered() : e3 && !t3 ? this.videoBuffered() : function(e4, t4) {
          var i3 = null, n2 = null, r2 = 0, a2 = [], s2 = [];
          if (!(e4 && e4.length && t4 && t4.length))
            return ir.createTimeRange();
          for (var o2 = e4.length; o2--; )
            a2.push({ time: e4.start(o2), type: "start" }), a2.push({ time: e4.end(o2), type: "end" });
          for (o2 = t4.length; o2--; )
            a2.push({ time: t4.start(o2), type: "start" }), a2.push({ time: t4.end(o2), type: "end" });
          for (a2.sort(function(e5, t5) {
            return e5.time - t5.time;
          }), o2 = 0; o2 < a2.length; o2++)
            "start" === a2[o2].type ? 2 === ++r2 && (i3 = a2[o2].time) : "end" === a2[o2].type && 1 === --r2 && (n2 = a2[o2].time), null !== i3 && null !== n2 && (s2.push([i3, n2]), n2 = i3 = null);
          return ir.createTimeRanges(s2);
        }(this.audioBuffered(), this.videoBuffered());
      }, t2.setDuration = function(e3, t3) {
        void 0 === t3 && (t3 = td), od({ type: "mediaSource", sourceUpdater: this, action: Sd(e3), name: "duration", doneFn: t3 });
      }, t2.endOfStream = function(e3, t3) {
        void 0 === t3 && (t3 = td), od({ type: "mediaSource", sourceUpdater: this, action: wd(e3 = "string" != typeof (e3 = void 0 === e3 ? null : e3) ? void 0 : e3), name: "endOfStream", doneFn: t3 });
      }, t2.removeAudio = function(e3, t3, i3) {
        void 0 === i3 && (i3 = td), this.audioBuffered().length && 0 !== this.audioBuffered().end(0) ? od({ type: "audio", sourceUpdater: this, action: _d(e3, t3), doneFn: i3, name: "remove" }) : i3();
      }, t2.removeVideo = function(e3, t3, i3) {
        void 0 === i3 && (i3 = td), this.videoBuffered().length && 0 !== this.videoBuffered().end(0) ? od({ type: "video", sourceUpdater: this, action: _d(e3, t3), doneFn: i3, name: "remove" }) : i3();
      }, t2.updating = function() {
        return !(!nd("audio", this) && !nd("video", this));
      }, t2.audioTimestampOffset = function(e3) {
        return "undefined" != typeof e3 && this.audioBuffer && this.audioTimestampOffset_ !== e3 && (od({ type: "audio", sourceUpdater: this, action: bd(e3), name: "timestampOffset" }), this.audioTimestampOffset_ = e3), this.audioTimestampOffset_;
      }, t2.videoTimestampOffset = function(e3) {
        return "undefined" != typeof e3 && this.videoBuffer && this.videoTimestampOffset !== e3 && (od({ type: "video", sourceUpdater: this, action: bd(e3), name: "timestampOffset" }), this.videoTimestampOffset_ = e3), this.videoTimestampOffset_;
      }, t2.audioQueueCallback = function(e3) {
        this.audioBuffer && od({ type: "audio", sourceUpdater: this, action: Td(e3), name: "callback" });
      }, t2.videoQueueCallback = function(e3) {
        this.videoBuffer && od({ type: "video", sourceUpdater: this, action: Td(e3), name: "callback" });
      }, t2.dispose = function() {
        var t3 = this;
        this.trigger("dispose"), yd.forEach(function(e3) {
          t3.abort(e3), t3.canRemoveSourceBuffer() ? t3.removeSourceBuffer(e3) : t3[e3 + "QueueCallback"](function() {
            return ad(e3, t3);
          });
        }), this.videoAppendQueued_ = false, this.delayedAudioAppendQueue_.length = 0, this.sourceopenListener_ && this.mediaSource.removeEventListener("sourceopen", this.sourceopenListener_), this.off();
      }, e2;
    }(ir.EventTarget), Ad = new Uint8Array("\n\n".split("").map(function(e2) {
      return e2.charCodeAt(0);
    })), Pd = function(e2) {
      function t2() {
        return e2.call(this, "Trying to parse received VTT cues, but there is no WebVTT. Make sure vtt.js is loaded.") || this;
      }
      return mt(t2, e2), t2;
    }(W(Error)), Ld = function(i2) {
      function e2(e3, t3) {
        return (t3 = i2.call(this, e3, t3 = void 0 === t3 ? {} : t3) || this).mediaSource_ = null, t3.subtitlesTrack_ = null, t3.loaderType_ = "subtitle", t3.featuresNativeTextTracks_ = e3.featuresNativeTextTracks, t3.loadVttJs = e3.loadVttJs, t3.shouldSaveSegmentTimingInfo_ = false, t3;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.createTransmuxer_ = function() {
        return null;
      }, t2.buffered_ = function() {
        if (!this.subtitlesTrack_ || !this.subtitlesTrack_.cues || !this.subtitlesTrack_.cues.length)
          return ir.createTimeRanges();
        var e3 = this.subtitlesTrack_.cues, t3 = e3[0].startTime, e3 = e3[e3.length - 1].startTime;
        return ir.createTimeRanges([[t3, e3]]);
      }, t2.initSegmentForMap = function(e3, t3) {
        if (void 0 === t3 && (t3 = false), !e3)
          return null;
        var i3 = Hu(e3), n2 = this.initSegments_[i3];
        return t3 && !n2 && e3.bytes && (t3 = Ad.byteLength + e3.bytes.byteLength, (t3 = new Uint8Array(t3)).set(e3.bytes), t3.set(Ad, e3.bytes.byteLength), this.initSegments_[i3] = n2 = { resolvedUri: e3.resolvedUri, byterange: e3.byterange, bytes: t3 }), n2 || e3;
      }, t2.couldBeginLoading_ = function() {
        return this.playlist_ && this.subtitlesTrack_ && !this.paused();
      }, t2.init_ = function() {
        return this.state = "READY", this.resetEverything(), this.monitorBuffer_();
      }, t2.track = function(e3) {
        return "undefined" == typeof e3 || (this.subtitlesTrack_ = e3, "INIT" === this.state && this.couldBeginLoading_() && this.init_()), this.subtitlesTrack_;
      }, t2.remove = function(e3, t3) {
        kl(e3, t3, this.subtitlesTrack_);
      }, t2.fillBuffer_ = function() {
        var e3 = this, t3 = this.chooseNextRequest_();
        if (t3) {
          if (null === this.syncController_.timestampOffsetForTimeline(t3.timeline))
            return this.syncController_.one("timestampoffset", function() {
              e3.state = "READY", e3.paused() || e3.monitorBuffer_();
            }), void (this.state = "WAITING_ON_TIMELINE");
          this.loadSegment_(t3);
        }
      }, t2.timestampOffsetForSegment_ = function() {
        return null;
      }, t2.chooseNextRequest_ = function() {
        return this.skipEmptySegments_(i2.prototype.chooseNextRequest_.call(this));
      }, t2.skipEmptySegments_ = function(e3) {
        for (; e3 && e3.segment.empty; ) {
          if (e3.mediaIndex + 1 >= e3.playlist.segments.length) {
            e3 = null;
            break;
          }
          e3 = this.generateSegmentInfo_({ playlist: e3.playlist, mediaIndex: e3.mediaIndex + 1, startOfSegment: e3.startOfSegment + e3.duration, isSyncRequest: e3.isSyncRequest });
        }
        return e3;
      }, t2.stopForError = function(e3) {
        this.error(e3), this.state = "READY", this.pause(), this.trigger("error");
      }, t2.segmentRequestFinished_ = function(e3, t3, i3) {
        var n2 = this;
        if (this.subtitlesTrack_) {
          if (this.saveTransferStats_(t3.stats), !this.pendingSegment_)
            return this.state = "READY", void (this.mediaRequestsAborted += 1);
          if (e3)
            return e3.code === Ql && this.handleTimeout_(), e3.code === $l ? this.mediaRequestsAborted += 1 : this.mediaRequestsErrored += 1, void this.stopForError(e3);
          var r2 = this.pendingSegment_;
          this.saveBandwidthRelatedStats_(r2.duration, t3.stats), t3.key && this.segmentKey(t3.key, true), this.state = "APPENDING", this.trigger("appending");
          var a2 = r2.segment;
          if (a2.map && (a2.map.bytes = t3.map.bytes), r2.bytes = t3.bytes, "function" != typeof window.WebVTT && "function" == typeof this.loadVttJs)
            return this.state = "WAITING_ON_VTTJS", void this.loadVttJs().then(function() {
              return n2.segmentRequestFinished_(e3, t3, i3);
            }, function() {
              return n2.stopForError({ message: "Error loading vtt.js" });
            });
          a2.requested = true;
          try {
            this.parseVTTCues_(r2);
          } catch (e4) {
            return void this.stopForError({ message: e4.message });
          }
          if (this.updateTimeMapping_(r2, this.syncController_.timelines[r2.timeline], this.playlist_), r2.cues.length ? r2.timingInfo = { start: r2.cues[0].startTime, end: r2.cues[r2.cues.length - 1].endTime } : r2.timingInfo = { start: r2.startOfSegment, end: r2.startOfSegment + r2.duration }, r2.isSyncRequest)
            return this.trigger("syncinfoupdate"), this.pendingSegment_ = null, void (this.state = "READY");
          r2.byteLength = r2.bytes.byteLength, this.mediaSecondsLoaded += a2.duration, r2.cues.forEach(function(e4) {
            n2.subtitlesTrack_.addCue(n2.featuresNativeTextTracks_ ? new window.VTTCue(e4.startTime, e4.endTime, e4.text) : e4);
          }), function(t4) {
            var e4 = t4.cues;
            if (e4)
              for (var i4 = 0; i4 < e4.length; i4++) {
                for (var n3 = [], r3 = 0, a3 = 0; a3 < e4.length; a3++)
                  e4[i4].startTime === e4[a3].startTime && e4[i4].endTime === e4[a3].endTime && e4[i4].text === e4[a3].text && 1 < ++r3 && n3.push(e4[a3]);
                n3.length && n3.forEach(function(e5) {
                  return t4.removeCue(e5);
                });
              }
          }(this.subtitlesTrack_), this.handleAppendsDone_();
        } else
          this.state = "READY";
      }, t2.handleData_ = function() {
      }, t2.updateTimingInfoEnd_ = function() {
      }, t2.parseVTTCues_ = function(t3) {
        var e3 = false;
        if ("function" != typeof window.WebVTT)
          throw new Pd();
        "function" == typeof window.TextDecoder ? i3 = new window.TextDecoder("utf8") : (i3 = window.WebVTT.StringDecoder(), e3 = true);
        var i3 = new window.WebVTT.Parser(window, window.vttjs, i3);
        t3.cues = [], t3.timestampmap = { MPEGTS: 0, LOCAL: 0 }, i3.oncue = t3.cues.push.bind(t3.cues), i3.ontimestampmap = function(e4) {
          t3.timestampmap = e4;
        }, i3.onparsingerror = function(e4) {
          ir.log.warn("Error encountered when parsing cues: " + e4.message);
        }, t3.segment.map && (n2 = t3.segment.map.bytes, e3 && (n2 = ld(n2)), i3.parse(n2));
        var n2 = t3.bytes;
        e3 && (n2 = ld(n2)), i3.parse(n2), i3.flush();
      }, t2.updateTimeMapping_ = function(e3, t3, i3) {
        var n2, r2, a2 = e3.segment;
        t3 && (e3.cues.length ? (r2 = e3.timestampmap, n2 = r2.MPEGTS / Qo - r2.LOCAL + t3.mapping, e3.cues.forEach(function(e4) {
          e4.startTime += n2, e4.endTime += n2;
        }), i3.syncInfo || (r2 = e3.cues[0].startTime, t3 = e3.cues[e3.cues.length - 1].startTime, i3.syncInfo = { mediaSequence: i3.mediaSequence + e3.mediaIndex, time: Math.min(r2, t3 - a2.duration) })) : a2.empty = true);
      }, e2;
    }(ed), Od = [{ name: "VOD", run: function(e2, t2, i2, n2, r2) {
      if (i2 === 1 / 0)
        return null;
      return { time: 0, segmentIndex: 0, partIndex: null };
    } }, { name: "ProgramDateTime", run: function(e2, t2, i2, n2, r2) {
      if (!Object.keys(e2.timelineToDatetimeMappings).length)
        return null;
      var a2 = null, s2 = null, o2 = uu(t2);
      r2 = r2 || 0;
      for (var u2 = 0; u2 < o2.length; u2++) {
        var l2 = o2[t2.endList || 0 === r2 ? u2 : o2.length - (u2 + 1)], d2 = l2.segment, c2 = e2.timelineToDatetimeMappings[d2.timeline];
        if (c2 && d2.dateTimeObject) {
          var h2 = d2.dateTimeObject.getTime() / 1e3 + c2;
          if (d2.parts && "number" == typeof l2.partIndex)
            for (var p2 = 0; p2 < l2.partIndex; p2++)
              h2 += d2.parts[p2].duration;
          c2 = Math.abs(r2 - h2);
          if (null !== s2 && (0 === c2 || s2 < c2))
            break;
          s2 = c2, a2 = { time: h2, segmentIndex: l2.segmentIndex, partIndex: l2.partIndex };
        }
      }
      return a2;
    } }, { name: "Segment", run: function(e2, t2, i2, n2, r2) {
      var a2 = null, s2 = null;
      r2 = r2 || 0;
      for (var o2 = uu(t2), u2 = 0; u2 < o2.length; u2++) {
        var l2 = o2[t2.endList || 0 === r2 ? u2 : o2.length - (u2 + 1)], d2 = l2.segment, c2 = l2.part && l2.part.start || d2 && d2.start;
        if (d2.timeline === n2 && "undefined" != typeof c2) {
          d2 = Math.abs(r2 - c2);
          if (null !== s2 && s2 < d2)
            break;
          (!a2 || null === s2 || d2 <= s2) && (s2 = d2, a2 = { time: c2, segmentIndex: l2.segmentIndex, partIndex: l2.partIndex });
        }
      }
      return a2;
    } }, { name: "Discontinuity", run: function(e2, t2, i2, n2, r2) {
      var a2 = null;
      if (r2 = r2 || 0, t2.discontinuityStarts && t2.discontinuityStarts.length)
        for (var s2 = null, o2 = 0; o2 < t2.discontinuityStarts.length; o2++) {
          var u2 = t2.discontinuityStarts[o2], l2 = t2.discontinuitySequence + o2 + 1, d2 = e2.discontinuities[l2];
          if (d2) {
            l2 = Math.abs(r2 - d2.time);
            if (null !== s2 && s2 < l2)
              break;
            (!a2 || null === s2 || l2 <= s2) && (s2 = l2, a2 = { time: d2.time, segmentIndex: u2, partIndex: null });
          }
        }
      return a2;
    } }, { name: "Playlist", run: function(e2, t2, i2, n2, r2) {
      return t2.syncInfo ? { time: t2.syncInfo.time, segmentIndex: t2.syncInfo.mediaSequence - t2.mediaSequence, partIndex: null } : null;
    } }], Dd = function(i2) {
      function e2(e3) {
        var t3 = i2.call(this) || this;
        return t3.timelines = [], t3.discontinuities = [], t3.timelineToDatetimeMappings = {}, t3.logger_ = Zo("SyncController"), t3;
      }
      mt(e2, i2);
      var t2 = e2.prototype;
      return t2.getSyncPoint = function(e3, t3, i3, n2) {
        i3 = this.runStrategies_(e3, t3, i3, n2);
        return i3.length ? this.selectSyncPoint_(i3, { key: "time", value: n2 }) : null;
      }, t2.getExpiredTime = function(e3, t3) {
        if (!e3 || !e3.segments)
          return null;
        t3 = this.runStrategies_(e3, t3, e3.discontinuitySequence, 0);
        if (!t3.length)
          return null;
        t3 = this.selectSyncPoint_(t3, { key: "segmentIndex", value: 0 });
        return 0 < t3.segmentIndex && (t3.time *= -1), Math.abs(t3.time + fu({ defaultDuration: e3.targetDuration, durationList: e3.segments, startIndex: t3.segmentIndex, endIndex: 0 }));
      }, t2.runStrategies_ = function(e3, t3, i3, n2) {
        for (var r2 = [], a2 = 0; a2 < Od.length; a2++) {
          var s2 = Od[a2], o2 = s2.run(this, e3, t3, i3, n2);
          o2 && (o2.strategy = s2.name, r2.push({ strategy: s2.name, syncPoint: o2 }));
        }
        return r2;
      }, t2.selectSyncPoint_ = function(e3, t3) {
        for (var i3 = e3[0].syncPoint, n2 = Math.abs(e3[0].syncPoint[t3.key] - t3.value), r2 = e3[0].strategy, a2 = 1; a2 < e3.length; a2++) {
          var s2 = Math.abs(e3[a2].syncPoint[t3.key] - t3.value);
          s2 < n2 && (n2 = s2, i3 = e3[a2].syncPoint, r2 = e3[a2].strategy);
        }
        return this.logger_("syncPoint for [" + t3.key + ": " + t3.value + "] chosen with strategy [" + r2 + "]: [time:" + i3.time + ", segmentIndex:" + i3.segmentIndex + ("number" == typeof i3.partIndex ? ",partIndex:" + i3.partIndex : "") + "]"), i3;
      }, t2.saveExpiredSegmentInfo = function(e3, t3) {
        var i3 = t3.mediaSequence - e3.mediaSequence;
        if (86400 < i3)
          ir.log.warn("Not saving expired segment info. Media sequence gap " + i3 + " is too large.");
        else
          for (var n2 = i3 - 1; 0 <= n2; n2--) {
            var r2 = e3.segments[n2];
            if (r2 && "undefined" != typeof r2.start) {
              t3.syncInfo = { mediaSequence: e3.mediaSequence + n2, time: r2.start }, this.logger_("playlist refresh sync: [time:" + t3.syncInfo.time + ", mediaSequence: " + t3.syncInfo.mediaSequence + "]"), this.trigger("syncinfoupdate");
              break;
            }
          }
      }, t2.setDateTimeMappingForStart = function(e3) {
        var t3;
        this.timelineToDatetimeMappings = {}, e3.segments && e3.segments.length && e3.segments[0].dateTimeObject && (e3 = (t3 = e3.segments[0]).dateTimeObject.getTime() / 1e3, this.timelineToDatetimeMappings[t3.timeline] = -e3);
      }, t2.saveSegmentTimingInfo = function(e3) {
        var t3 = e3.segmentInfo, i3 = e3.shouldSaveTimelineMapping, n2 = this.calculateSegmentTimeMapping_(t3, t3.timingInfo, i3), e3 = t3.segment;
        n2 && (this.saveDiscontinuitySyncInfo_(t3), t3.playlist.syncInfo || (t3.playlist.syncInfo = { mediaSequence: t3.playlist.mediaSequence + t3.mediaIndex, time: e3.start }));
        t3 = e3.dateTimeObject;
        e3.discontinuity && i3 && t3 && (this.timelineToDatetimeMappings[e3.timeline] = -t3.getTime() / 1e3);
      }, t2.timestampOffsetForTimeline = function(e3) {
        return "undefined" == typeof this.timelines[e3] ? null : this.timelines[e3].time;
      }, t2.mappingForTimeline = function(e3) {
        return "undefined" == typeof this.timelines[e3] ? null : this.timelines[e3].mapping;
      }, t2.calculateSegmentTimeMapping_ = function(e3, t3, i3) {
        var n2, r2, a2 = e3.segment, s2 = e3.part, o2 = this.timelines[e3.timeline];
        if ("number" == typeof e3.timestampOffset)
          o2 = { time: e3.startOfSegment, mapping: e3.startOfSegment - t3.start }, i3 && (this.timelines[e3.timeline] = o2, this.trigger("timestampoffset"), this.logger_("time mapping for timeline " + e3.timeline + ": [time: " + o2.time + "] [mapping: " + o2.mapping + "]")), n2 = e3.startOfSegment, r2 = t3.end + o2.mapping;
        else {
          if (!o2)
            return false;
          n2 = t3.start + o2.mapping, r2 = t3.end + o2.mapping;
        }
        return s2 && (s2.start = n2, s2.end = r2), (!a2.start || n2 < a2.start) && (a2.start = n2), a2.end = r2, true;
      }, t2.saveDiscontinuitySyncInfo_ = function(e3) {
        var t3 = e3.playlist, i3 = e3.segment;
        if (i3.discontinuity)
          this.discontinuities[i3.timeline] = { time: i3.start, accuracy: 0 };
        else if (t3.discontinuityStarts && t3.discontinuityStarts.length)
          for (var n2 = 0; n2 < t3.discontinuityStarts.length; n2++) {
            var r2, a2 = t3.discontinuityStarts[n2], s2 = t3.discontinuitySequence + n2 + 1, o2 = a2 - e3.mediaIndex, u2 = Math.abs(o2);
            (!this.discontinuities[s2] || this.discontinuities[s2].accuracy > u2) && (r2 = void 0, r2 = o2 < 0 ? i3.start - fu({ defaultDuration: t3.targetDuration, durationList: t3.segments, startIndex: e3.mediaIndex, endIndex: a2 }) : i3.end + fu({ defaultDuration: t3.targetDuration, durationList: t3.segments, startIndex: e3.mediaIndex + 1, endIndex: a2 }), this.discontinuities[s2] = { time: r2, accuracy: u2 });
          }
      }, t2.dispose = function() {
        this.trigger("dispose"), this.off();
      }, e2;
    }(ir.EventTarget), Rd = function(t2) {
      function e2() {
        var e3 = t2.call(this) || this;
        return e3.pendingTimelineChanges_ = {}, e3.lastTimelineChanges_ = {}, e3;
      }
      mt(e2, t2);
      var i2 = e2.prototype;
      return i2.clearPendingTimelineChange = function(e3) {
        this.pendingTimelineChanges_[e3] = null, this.trigger("pendingtimelinechange");
      }, i2.pendingTimelineChange = function(e3) {
        var t3 = e3.type, i3 = e3.from, e3 = e3.to;
        return "number" == typeof i3 && "number" == typeof e3 && (this.pendingTimelineChanges_[t3] = { type: t3, from: i3, to: e3 }, this.trigger("pendingtimelinechange")), this.pendingTimelineChanges_[t3];
      }, i2.lastTimelineChange = function(e3) {
        var t3 = e3.type, i3 = e3.from, e3 = e3.to;
        return "number" == typeof i3 && "number" == typeof e3 && (this.lastTimelineChanges_[t3] = { type: t3, from: i3, to: e3 }, delete this.pendingTimelineChanges_[t3], this.trigger("timelinechange")), this.lastTimelineChanges_[t3];
      }, i2.dispose = function() {
        this.trigger("dispose"), this.pendingTimelineChanges_ = {}, this.lastTimelineChanges_ = {}, this.off();
      }, e2;
    }(ir.EventTarget), Md = x(ar(Qr(function() {
      var e2 = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof commonjsGlobal ? commonjsGlobal : "undefined" != typeof self ? self : {};
      function t2(e3, t3, i3) {
        return e3(i3 = { path: t3, exports: {}, require: function(e4, t4) {
          return function() {
            throw new Error("Dynamic requires are not currently supported by @rollup/plugin-commonjs");
          }(null == t4 && i3.path);
        } }, i3.exports), i3.exports;
      }
      var i2 = t2(function(e3) {
        function n3(e4, t3) {
          for (var i3 = 0; i3 < t3.length; i3++) {
            var n4 = t3[i3];
            n4.enumerable = n4.enumerable || false, n4.configurable = true, "value" in n4 && (n4.writable = true), Object.defineProperty(e4, n4.key, n4);
          }
        }
        e3.exports = function(e4, t3, i3) {
          return t3 && n3(e4.prototype, t3), i3 && n3(e4, i3), e4;
        }, e3.exports.default = e3.exports, e3.exports.__esModule = true;
      }), n2 = t2(function(i3) {
        function n3(e3, t3) {
          return i3.exports = n3 = Object.setPrototypeOf || function(e4, t4) {
            return e4.__proto__ = t4, e4;
          }, i3.exports.default = i3.exports, i3.exports.__esModule = true, n3(e3, t3);
        }
        i3.exports = n3, i3.exports.default = i3.exports, i3.exports.__esModule = true;
      }), r2 = t2(function(e3) {
        e3.exports = function(e4, t3) {
          e4.prototype = Object.create(t3.prototype), e4.prototype.constructor = e4, n2(e4, t3);
        }, e3.exports.default = e3.exports, e3.exports.__esModule = true;
      }), a2 = function() {
        function e3() {
          this.listeners = {};
        }
        var t3 = e3.prototype;
        return t3.on = function(e4, t4) {
          this.listeners[e4] || (this.listeners[e4] = []), this.listeners[e4].push(t4);
        }, t3.off = function(e4, t4) {
          if (!this.listeners[e4])
            return false;
          t4 = this.listeners[e4].indexOf(t4);
          return this.listeners[e4] = this.listeners[e4].slice(0), this.listeners[e4].splice(t4, 1), -1 < t4;
        }, t3.trigger = function(e4) {
          var t4 = this.listeners[e4];
          if (t4)
            if (2 === arguments.length)
              for (var i3 = t4.length, n3 = 0; n3 < i3; ++n3)
                t4[n3].call(this, arguments[1]);
            else
              for (var r3 = Array.prototype.slice.call(arguments, 1), a3 = t4.length, s3 = 0; s3 < a3; ++s3)
                t4[s3].apply(this, r3);
        }, t3.dispose = function() {
          this.listeners = {};
        }, t3.pipe = function(t4) {
          this.on("data", function(e4) {
            t4.push(e4);
          });
        }, e3;
      }();
      /*! @name aes-decrypter @version 3.1.3 @license Apache-2.0 */
      var d2 = null, m2 = function() {
        function e3(e4) {
          var t3, i3, n3;
          d2 = d2 || function() {
            for (var e5, t4, i4, n4, r4, a4, s4, o4 = [[[], [], [], [], []], [[], [], [], [], []]], u3 = o4[0], l4 = o4[1], d3 = u3[4], c2 = l4[4], h2 = [], p2 = [], f2 = 0; f2 < 256; f2++)
              p2[(h2[f2] = f2 << 1 ^ 283 * (f2 >> 7)) ^ f2] = f2;
            for (e5 = t4 = 0; !d3[e5]; e5 ^= i4 || 1, t4 = p2[t4] || 1)
              for (s4 = 16843009 * h2[n4 = h2[i4 = h2[c2[d3[e5] = r4 = (r4 = t4 ^ t4 << 1 ^ t4 << 2 ^ t4 << 3 ^ t4 << 4) >> 8 ^ 255 & r4 ^ 99] = e5]]] ^ 65537 * n4 ^ 257 * i4 ^ 16843008 * e5, a4 = 257 * h2[r4] ^ 16843008 * r4, f2 = 0; f2 < 4; f2++)
                u3[f2][e5] = a4 = a4 << 24 ^ a4 >>> 8, l4[f2][r4] = s4 = s4 << 24 ^ s4 >>> 8;
            for (f2 = 0; f2 < 5; f2++)
              u3[f2] = u3[f2].slice(0), l4[f2] = l4[f2].slice(0);
            return o4;
          }(), this._tables = [[d2[0][0].slice(), d2[0][1].slice(), d2[0][2].slice(), d2[0][3].slice(), d2[0][4].slice()], [d2[1][0].slice(), d2[1][1].slice(), d2[1][2].slice(), d2[1][3].slice(), d2[1][4].slice()]];
          var r3 = this._tables[0][4], a3 = this._tables[1], s3 = e4.length, o3 = 1;
          if (4 !== s3 && 6 !== s3 && 8 !== s3)
            throw new Error("Invalid aes key size");
          var u2 = e4.slice(0), l3 = [];
          for (this._key = [u2, l3], t3 = s3; t3 < 4 * s3 + 28; t3++)
            n3 = u2[t3 - 1], (t3 % s3 == 0 || 8 === s3 && t3 % s3 == 4) && (n3 = r3[n3 >>> 24] << 24 ^ r3[n3 >> 16 & 255] << 16 ^ r3[n3 >> 8 & 255] << 8 ^ r3[255 & n3], t3 % s3 == 0 && (n3 = n3 << 8 ^ n3 >>> 24 ^ o3 << 24, o3 = o3 << 1 ^ 283 * (o3 >> 7))), u2[t3] = u2[t3 - s3] ^ n3;
          for (i3 = 0; t3; i3++, t3--)
            n3 = u2[3 & i3 ? t3 : t3 - 4], l3[i3] = t3 <= 4 || i3 < 4 ? n3 : a3[0][r3[n3 >>> 24]] ^ a3[1][r3[n3 >> 16 & 255]] ^ a3[2][r3[n3 >> 8 & 255]] ^ a3[3][r3[255 & n3]];
        }
        return e3.prototype.decrypt = function(e4, t3, i3, n3, r3, a3) {
          for (var s3, o3, u2, l3 = this._key[1], d3 = e4 ^ l3[0], c2 = n3 ^ l3[1], h2 = i3 ^ l3[2], p2 = t3 ^ l3[3], f2 = l3.length / 4 - 2, m3 = 4, t3 = this._tables[1], g3 = t3[0], y2 = t3[1], v2 = t3[2], _2 = t3[3], b2 = t3[4], T2 = 0; T2 < f2; T2++)
            s3 = g3[d3 >>> 24] ^ y2[c2 >> 16 & 255] ^ v2[h2 >> 8 & 255] ^ _2[255 & p2] ^ l3[m3], o3 = g3[c2 >>> 24] ^ y2[h2 >> 16 & 255] ^ v2[p2 >> 8 & 255] ^ _2[255 & d3] ^ l3[m3 + 1], u2 = g3[h2 >>> 24] ^ y2[p2 >> 16 & 255] ^ v2[d3 >> 8 & 255] ^ _2[255 & c2] ^ l3[m3 + 2], p2 = g3[p2 >>> 24] ^ y2[d3 >> 16 & 255] ^ v2[c2 >> 8 & 255] ^ _2[255 & h2] ^ l3[m3 + 3], m3 += 4, d3 = s3, c2 = o3, h2 = u2;
          for (T2 = 0; T2 < 4; T2++)
            r3[(3 & -T2) + a3] = b2[d3 >>> 24] << 24 ^ b2[c2 >> 16 & 255] << 16 ^ b2[h2 >> 8 & 255] << 8 ^ b2[255 & p2] ^ l3[m3++], s3 = d3, d3 = c2, c2 = h2, h2 = p2, p2 = s3;
        }, e3;
      }(), l2 = function(t3) {
        function e3() {
          var e4 = t3.call(this, a2) || this;
          return e4.jobs = [], e4.delay = 1, e4.timeout_ = null, e4;
        }
        r2(e3, t3);
        var i3 = e3.prototype;
        return i3.processJob_ = function() {
          this.jobs.shift()(), this.jobs.length ? this.timeout_ = setTimeout(this.processJob_.bind(this), this.delay) : this.timeout_ = null;
        }, i3.push = function(e4) {
          this.jobs.push(e4), this.timeout_ || (this.timeout_ = setTimeout(this.processJob_.bind(this), this.delay));
        }, e3;
      }(a2), g2 = function(e3) {
        return e3 << 24 | (65280 & e3) << 8 | (16711680 & e3) >> 8 | e3 >>> 24;
      }, s2 = function() {
        function u2(e3, t3, i3, n3) {
          var r3 = u2.STEP, a3 = new Int32Array(e3.buffer), s3 = new Uint8Array(e3.byteLength), o3 = 0;
          for (this.asyncStream_ = new l2(), this.asyncStream_.push(this.decryptChunk_(a3.subarray(o3, o3 + r3), t3, i3, s3)), o3 = r3; o3 < a3.length; o3 += r3)
            i3 = new Uint32Array([g2(a3[o3 - 4]), g2(a3[o3 - 3]), g2(a3[o3 - 2]), g2(a3[o3 - 1])]), this.asyncStream_.push(this.decryptChunk_(a3.subarray(o3, o3 + r3), t3, i3, s3));
          this.asyncStream_.push(function() {
            /*! @name pkcs7 @version 1.0.4 @license Apache-2.0 */
            var e4;
            n3(null, (e4 = s3).subarray(0, e4.byteLength - e4[e4.byteLength - 1]));
          });
        }
        return u2.prototype.decryptChunk_ = function(t3, i3, n3, r3) {
          return function() {
            var e3 = function(e4, t4, i4) {
              for (var n4, r4, a3, s3, o3 = new Int32Array(e4.buffer, e4.byteOffset, e4.byteLength >> 2), u3 = new m2(Array.prototype.slice.call(t4)), e4 = new Uint8Array(e4.byteLength), l3 = new Int32Array(e4.buffer), d3 = i4[0], c2 = i4[1], h2 = i4[2], p2 = i4[3], f2 = 0; f2 < o3.length; f2 += 4)
                n4 = g2(o3[f2]), r4 = g2(o3[f2 + 1]), a3 = g2(o3[f2 + 2]), s3 = g2(o3[f2 + 3]), u3.decrypt(n4, r4, a3, s3, l3, f2), l3[f2] = g2(l3[f2] ^ d3), l3[f2 + 1] = g2(l3[f2 + 1] ^ c2), l3[f2 + 2] = g2(l3[f2 + 2] ^ h2), l3[f2 + 3] = g2(l3[f2 + 3] ^ p2), d3 = n4, c2 = r4, h2 = a3, p2 = s3;
              return e4;
            }(t3, i3, n3);
            r3.set(e3, t3.byteOffset);
          };
        }, i2(u2, null, [{ key: "STEP", get: function() {
          return 32e3;
        } }]), u2;
      }(), e2 = "undefined" != typeof window ? window : "undefined" != typeof e2 ? e2 : "undefined" != typeof self ? self : {}, e2 = e2.BigInt || Number;
      e2("0x1"), e2("0x100"), e2("0x10000"), e2("0x1000000"), e2("0x100000000"), e2("0x10000000000"), e2("0x1000000000000"), e2("0x100000000000000"), e2("0x10000000000000000");
      function o2(n3) {
        var r3 = {};
        return Object.keys(n3).forEach(function(e3) {
          var t3, i3 = n3[e3];
          t3 = i3, ("function" === ArrayBuffer.isView ? ArrayBuffer.isView(t3) : t3 && t3.buffer instanceof ArrayBuffer) ? r3[e3] = { bytes: i3.buffer, byteOffset: i3.byteOffset, byteLength: i3.byteLength } : r3[e3] = i3;
        }), r3;
      }
      self.onmessage = function(e3) {
        var i3 = e3.data, t3 = new Uint8Array(i3.encrypted.bytes, i3.encrypted.byteOffset, i3.encrypted.byteLength), n3 = new Uint32Array(i3.key.bytes, i3.key.byteOffset, i3.key.byteLength / 4), e3 = new Uint32Array(i3.iv.bytes, i3.iv.byteOffset, i3.iv.byteLength / 4);
        new s2(t3, n3, e3, function(e4, t4) {
          self.postMessage(o2({ source: i3.source, decrypted: t4 }), [t4.buffer]);
        });
      };
    }))), Nd = { AUDIO: function(s2, o2) {
      return function() {
        var e2 = o2.segmentLoaders[s2], t2 = o2.mediaTypes[s2], i2 = o2.blacklistCurrentPlaylist;
        dd(e2, t2);
        var n2 = t2.activeTrack(), e2 = t2.activeGroup(), e2 = (e2.filter(function(e3) {
          return e3.default;
        })[0] || e2[0]).id, r2 = t2.tracks[e2];
        if (n2 !== r2) {
          for (var a2 in ir.log.warn("Problem encountered loading the alternate audio track.Switching back to default."), t2.tracks)
            t2.tracks[a2].enabled = t2.tracks[a2] === r2;
          t2.onTrackChanged();
        } else
          i2({ message: "Problem encountered loading the default audio track." });
      };
    }, SUBTITLES: function(i2, n2) {
      return function() {
        var e2 = n2.segmentLoaders[i2], t2 = n2.mediaTypes[i2];
        ir.log.warn("Problem encountered loading the subtitle track.Disabling subtitle track."), dd(e2, t2);
        e2 = t2.activeTrack();
        e2 && (e2.mode = "disabled"), t2.onTrackChanged();
      };
    } }, Ud = { AUDIO: function(e2, t2, i2) {
      var n2, r2, a2;
      t2 && (n2 = i2.tech, r2 = i2.requestOptions, a2 = i2.segmentLoaders[e2], t2.on("loadedmetadata", function() {
        var e3 = t2.media();
        a2.playlist(e3, r2), (!n2.paused() || e3.endList && "none" !== n2.preload()) && a2.load();
      }), t2.on("loadedplaylist", function() {
        a2.playlist(t2.media(), r2), n2.paused() || a2.load();
      }), t2.on("error", Nd[e2](e2, i2)));
    }, SUBTITLES: function(e2, t2, i2) {
      var n2 = i2.tech, r2 = i2.requestOptions, a2 = i2.segmentLoaders[e2], s2 = i2.mediaTypes[e2];
      t2.on("loadedmetadata", function() {
        var e3 = t2.media();
        a2.playlist(e3, r2), a2.track(s2.activeTrack()), (!n2.paused() || e3.endList && "none" !== n2.preload()) && a2.load();
      }), t2.on("loadedplaylist", function() {
        a2.playlist(t2.media(), r2), n2.paused() || a2.load();
      }), t2.on("error", Nd[e2](e2, i2));
    } }, Bd = { AUDIO: function(e2, t2) {
      var i2, n2, r2 = t2.vhs, a2 = t2.sourceType, s2 = t2.segmentLoaders[e2], o2 = t2.requestOptions, u2 = t2.master.mediaGroups, l2 = t2.mediaTypes[e2], d2 = l2.groups, c2 = l2.tracks, h2 = l2.logger_, p2 = t2.masterPlaylistLoader, f2 = Su(p2.master);
      for (i2 in u2[e2] && 0 !== Object.keys(u2[e2]).length || (u2[e2] = { main: { default: { default: true } } }, f2 && (u2[e2].main.default.playlists = p2.master.playlists)), u2[e2])
        for (var m2 in d2[i2] || (d2[i2] = []), u2[e2][i2]) {
          var g2 = u2[e2][i2][m2], y2 = void 0, y2 = f2 ? (h2("AUDIO group '" + i2 + "' label '" + m2 + "' is a master playlist"), g2.isMasterPlaylist = true, null) : "vhs-json" === a2 && g2.playlists ? new Fl(g2.playlists[0], r2, o2) : g2.resolvedUri ? new Fl(g2.resolvedUri, r2, o2) : g2.playlists && "dash" === a2 ? new ql(g2.playlists[0], r2, o2, p2) : null, g2 = ir.mergeOptions({ id: m2, playlistLoader: y2 }, g2);
          Ud[e2](e2, g2.playlistLoader, t2), d2[i2].push(g2), "undefined" == typeof c2[m2] && (g2 = new ir.AudioTrack({ id: m2, kind: (n2 = void 0, n2 = (y2 = g2).default ? "main" : "alternative", n2 = y2.characteristics && 0 <= y2.characteristics.indexOf("public.accessibility.describes-video") ? "main-desc" : n2), enabled: false, language: g2.language, default: g2.default, label: m2 }), c2[m2] = g2);
        }
      s2.on("error", Nd[e2](e2, t2));
    }, SUBTITLES: function(e2, t2) {
      var i2, n2 = t2.tech, r2 = t2.vhs, a2 = t2.sourceType, s2 = t2.segmentLoaders[e2], o2 = t2.requestOptions, u2 = t2.master.mediaGroups, l2 = t2.mediaTypes[e2], d2 = l2.groups, c2 = l2.tracks, h2 = t2.masterPlaylistLoader;
      for (i2 in u2[e2])
        for (var p2 in d2[i2] || (d2[i2] = []), u2[e2][i2])
          if (!u2[e2][i2][p2].forced) {
            var f2 = u2[e2][i2][p2], m2 = void 0;
            if ("hls" === a2)
              m2 = new Fl(f2.resolvedUri, r2, o2);
            else if ("dash" === a2) {
              if (!f2.playlists.filter(function(e3) {
                return e3.excludeUntil !== 1 / 0;
              }).length)
                return;
              m2 = new ql(f2.playlists[0], r2, o2, h2);
            } else
              "vhs-json" === a2 && (m2 = new Fl(f2.playlists ? f2.playlists[0] : f2.resolvedUri, r2, o2));
            f2 = ir.mergeOptions({ id: p2, playlistLoader: m2 }, f2), Ud[e2](e2, f2.playlistLoader, t2), d2[i2].push(f2), "undefined" == typeof c2[p2] && (f2 = n2.addRemoteTextTrack({ id: p2, kind: "subtitles", default: f2.default && f2.autoselect, language: f2.language, label: p2 }, false).track, c2[p2] = f2);
          }
      s2.on("error", Nd[e2](e2, t2));
    }, "CLOSED-CAPTIONS": function(e2, t2) {
      var i2, n2 = t2.tech, r2 = t2.master.mediaGroups, t2 = t2.mediaTypes[e2], a2 = t2.groups, s2 = t2.tracks;
      for (i2 in r2[e2])
        for (var o2 in a2[i2] || (a2[i2] = []), r2[e2][i2]) {
          var u2, l2, d2 = r2[e2][i2][o2];
          /^(?:CC|SERVICE)/.test(d2.instreamId) && (void 0 === (l2 = (u2 = n2.options_.vhs && n2.options_.vhs.captionServices || {})[(l2 = { label: o2, language: d2.language, instreamId: d2.instreamId, default: d2.default && d2.autoselect }).instreamId] ? ir.mergeOptions(l2, u2[l2.instreamId]) : l2).default && delete l2.default, a2[i2].push(ir.mergeOptions({ id: o2 }, d2)), "undefined" == typeof s2[o2] && (l2 = n2.addRemoteTextTrack({ id: l2.instreamId, kind: "captions", default: l2.default, language: l2.language, label: l2.label }, false).track, s2[o2] = l2));
        }
    } }, Fd = { AUDIO: function(i2, n2) {
      return function() {
        var e2, t2 = n2.mediaTypes[i2].tracks;
        for (e2 in t2)
          if (t2[e2].enabled)
            return t2[e2];
        return null;
      };
    }, SUBTITLES: function(i2, n2) {
      return function() {
        var e2, t2 = n2.mediaTypes[i2].tracks;
        for (e2 in t2)
          if ("showing" === t2[e2].mode || "hidden" === t2[e2].mode)
            return t2[e2];
        return null;
      };
    } }, jd = ["mediaRequests", "mediaRequestsAborted", "mediaRequestsTimedout", "mediaRequestsErrored", "mediaTransferDuration", "mediaBytesTransferred", "mediaAppends"], Hd = function(v2) {
      function e2(e3) {
        var t3 = v2.call(this) || this, i2 = e3.src, n2 = e3.handleManifestRedirects, r2 = e3.withCredentials, a2 = e3.tech, s2 = e3.bandwidth, o2 = e3.externVhs, u2 = e3.useCueTags, l2 = e3.blacklistDuration, d2 = e3.enableLowInitialPlaylist, c2 = e3.sourceType, h2 = e3.cacheEncryptionKeys, p2 = e3.experimentalBufferBasedABR, f2 = e3.experimentalLeastPixelDiffSelector, m2 = e3.captionServices;
        if (!i2)
          throw new Error("A non-empty playlist URL or JSON manifest string is required");
        var g2, y2 = e3.maxPlaylistRetries;
        null !== y2 && "undefined" != typeof y2 || (y2 = 1 / 0), gd = o2, t3.experimentalBufferBasedABR = Boolean(p2), t3.experimentalLeastPixelDiffSelector = Boolean(f2), t3.withCredentials = r2, t3.tech_ = a2, t3.vhs_ = a2.vhs, t3.sourceType_ = c2, t3.useCueTags_ = u2, t3.blacklistDuration = l2, t3.maxPlaylistRetries = y2, t3.enableLowInitialPlaylist = d2, t3.useCueTags_ && (t3.cueTagsTrack_ = t3.tech_.addTextTrack("metadata", "ad-cues"), t3.cueTagsTrack_.inBandMetadataTrackDispatchType = ""), t3.requestOptions_ = { withCredentials: r2, handleManifestRedirects: n2, maxPlaylistRetries: y2, timeout: null }, t3.on("error", t3.pauseLoading), t3.mediaTypes_ = (g2 = {}, ["AUDIO", "SUBTITLES", "CLOSED-CAPTIONS"].forEach(function(e4) {
          g2[e4] = { groups: {}, tracks: {}, activePlaylistLoader: null, activeGroup: td, activeTrack: td, getActiveGroup: td, onGroupChanged: td, onTrackChanged: td, lastTrack_: null, logger_: Zo("MediaGroups[" + e4 + "]") };
        }), g2), t3.mediaSource = new window.MediaSource(), t3.handleDurationChange_ = t3.handleDurationChange_.bind(ft(t3)), t3.handleSourceOpen_ = t3.handleSourceOpen_.bind(ft(t3)), t3.handleSourceEnded_ = t3.handleSourceEnded_.bind(ft(t3)), t3.mediaSource.addEventListener("durationchange", t3.handleDurationChange_), t3.mediaSource.addEventListener("sourceopen", t3.handleSourceOpen_), t3.mediaSource.addEventListener("sourceended", t3.handleSourceEnded_), t3.seekable_ = ir.createTimeRanges(), t3.hasPlayed_ = false, t3.syncController_ = new Dd(e3), t3.segmentMetadataTrack_ = a2.addRemoteTextTrack({ kind: "metadata", label: "segment-metadata" }, false).track, t3.decrypter_ = new Md(), t3.sourceUpdater_ = new xd(t3.mediaSource), t3.inbandTextTracks_ = {}, t3.timelineChangeController_ = new Rd();
        h2 = { vhs: t3.vhs_, parse708captions: e3.parse708captions, useDtsForTimestampOffset: e3.useDtsForTimestampOffset, captionServices: m2, mediaSource: t3.mediaSource, currentTime: t3.tech_.currentTime.bind(t3.tech_), seekable: function() {
          return t3.seekable();
        }, seeking: function() {
          return t3.tech_.seeking();
        }, duration: function() {
          return t3.duration();
        }, hasPlayed: function() {
          return t3.hasPlayed_;
        }, goalBufferLength: function() {
          return t3.goalBufferLength();
        }, bandwidth: s2, syncController: t3.syncController_, decrypter: t3.decrypter_, sourceType: t3.sourceType_, inbandTextTracks: t3.inbandTextTracks_, cacheEncryptionKeys: h2, sourceUpdater: t3.sourceUpdater_, timelineChangeController: t3.timelineChangeController_, experimentalExactManifestTimings: e3.experimentalExactManifestTimings };
        t3.masterPlaylistLoader_ = new ("dash" === t3.sourceType_ ? ql : Fl)(i2, t3.vhs_, t3.requestOptions_), t3.setupMasterPlaylistLoaderListeners_(), t3.mainSegmentLoader_ = new ed(ir.mergeOptions(h2, { segmentMetadataTrack: t3.segmentMetadataTrack_, loaderType: "main" }), e3), t3.audioSegmentLoader_ = new ed(ir.mergeOptions(h2, { loaderType: "audio" }), e3), t3.subtitleSegmentLoader_ = new Ld(ir.mergeOptions(h2, { loaderType: "vtt", featuresNativeTextTracks: t3.tech_.featuresNativeTextTracks, loadVttJs: function() {
          return new Promise(function(e4, t4) {
            function i3() {
              a2.off("vttjserror", n3), e4();
            }
            function n3() {
              a2.off("vttjsloaded", i3), t4();
            }
            a2.one("vttjsloaded", i3), a2.one("vttjserror", n3), a2.addWebVttScript_();
          });
        } }), e3), t3.setupSegmentLoaderListeners_(), t3.experimentalBufferBasedABR && (t3.masterPlaylistLoader_.one("loadedplaylist", function() {
          return t3.startABRTimer_();
        }), t3.tech_.on("pause", function() {
          return t3.stopABRTimer_();
        }), t3.tech_.on("play", function() {
          return t3.startABRTimer_();
        })), jd.forEach(function(e4) {
          t3[e4 + "_"] = function(e5) {
            return this.audioSegmentLoader_[e5] + this.mainSegmentLoader_[e5];
          }.bind(ft(t3), e4);
        }), t3.logger_ = Zo("MPC"), t3.triggeredFmp4Usage = false, "none" === t3.tech_.preload() ? (t3.loadOnPlay_ = function() {
          t3.loadOnPlay_ = null, t3.masterPlaylistLoader_.load();
        }, t3.tech_.one("play", t3.loadOnPlay_)) : t3.masterPlaylistLoader_.load(), t3.timeToLoadedData__ = -1, t3.mainAppendsToLoadedData__ = -1, t3.audioAppendsToLoadedData__ = -1;
        e3 = "none" === t3.tech_.preload() ? "play" : "loadstart";
        return t3.tech_.one(e3, function() {
          var e4 = Date.now();
          t3.tech_.one("loadeddata", function() {
            t3.timeToLoadedData__ = Date.now() - e4, t3.mainAppendsToLoadedData__ = t3.mainSegmentLoader_.mediaAppends, t3.audioAppendsToLoadedData__ = t3.audioSegmentLoader_.mediaAppends;
          });
        }), t3;
      }
      mt(e2, v2);
      var t2 = e2.prototype;
      return t2.mainAppendsToLoadedData_ = function() {
        return this.mainAppendsToLoadedData__;
      }, t2.audioAppendsToLoadedData_ = function() {
        return this.audioAppendsToLoadedData__;
      }, t2.appendsToLoadedData_ = function() {
        var e3 = this.mainAppendsToLoadedData_(), t3 = this.audioAppendsToLoadedData_();
        return -1 === e3 || -1 === t3 ? -1 : e3 + t3;
      }, t2.timeToLoadedData_ = function() {
        return this.timeToLoadedData__;
      }, t2.checkABR_ = function(e3) {
        void 0 === e3 && (e3 = "abr");
        var t3 = this.selectPlaylist();
        t3 && this.shouldSwitchToMedia_(t3) && this.switchMedia_(t3, e3);
      }, t2.switchMedia_ = function(e3, t3, i2) {
        var n2 = this.media(), r2 = n2 && (n2.id || n2.uri), n2 = e3.id || e3.uri;
        r2 && r2 !== n2 && (this.logger_("switch media " + r2 + " -> " + n2 + " from " + t3), this.tech_.trigger({ type: "usage", name: "vhs-rendition-change-" + t3 })), this.masterPlaylistLoader_.media(e3, i2);
      }, t2.startABRTimer_ = function() {
        var e3 = this;
        this.stopABRTimer_(), this.abrTimer_ = window.setInterval(function() {
          return e3.checkABR_();
        }, 250);
      }, t2.stopABRTimer_ = function() {
        this.tech_.scrubbing && this.tech_.scrubbing() || (window.clearInterval(this.abrTimer_), this.abrTimer_ = null);
      }, t2.getAudioTrackPlaylists_ = function() {
        var e3 = this.master(), t3 = e3 && e3.playlists || [];
        if (!e3 || !e3.mediaGroups || !e3.mediaGroups.AUDIO)
          return t3;
        var i2, n2 = e3.mediaGroups.AUDIO, r2 = Object.keys(n2);
        if (Object.keys(this.mediaTypes_.AUDIO.groups).length)
          i2 = this.mediaTypes_.AUDIO.activeTrack();
        else {
          var a2, s2 = n2.main || r2.length && n2[r2[0]];
          for (a2 in s2)
            if (s2[a2].default) {
              i2 = { label: a2 };
              break;
            }
        }
        if (!i2)
          return t3;
        var o2, u2 = [];
        for (o2 in n2)
          if (n2[o2][i2.label]) {
            var l2 = n2[o2][i2.label];
            if (l2.playlists && l2.playlists.length)
              u2.push.apply(u2, l2.playlists);
            else if (l2.uri)
              u2.push(l2);
            else if (e3.playlists.length)
              for (var d2 = 0; d2 < e3.playlists.length; d2++) {
                var c2 = e3.playlists[d2];
                c2.attributes && c2.attributes.AUDIO && c2.attributes.AUDIO === o2 && u2.push(c2);
              }
          }
        return u2.length ? u2 : t3;
      }, t2.setupMasterPlaylistLoaderListeners_ = function() {
        var i2 = this;
        this.masterPlaylistLoader_.on("loadedmetadata", function() {
          var e3 = i2.masterPlaylistLoader_.media(), t3 = 1.5 * e3.targetDuration * 1e3;
          bu(i2.masterPlaylistLoader_.master, i2.masterPlaylistLoader_.media()) ? i2.requestOptions_.timeout = 0 : i2.requestOptions_.timeout = t3, e3.endList && "none" !== i2.tech_.preload() && (i2.mainSegmentLoader_.playlist(e3, i2.requestOptions_), i2.mainSegmentLoader_.load()), pd({ sourceType: i2.sourceType_, segmentLoaders: { AUDIO: i2.audioSegmentLoader_, SUBTITLES: i2.subtitleSegmentLoader_, main: i2.mainSegmentLoader_ }, tech: i2.tech_, requestOptions: i2.requestOptions_, masterPlaylistLoader: i2.masterPlaylistLoader_, vhs: i2.vhs_, master: i2.master(), mediaTypes: i2.mediaTypes_, blacklistCurrentPlaylist: i2.blacklistCurrentPlaylist.bind(i2) }), i2.triggerPresenceUsage_(i2.master(), e3), i2.setupFirstPlay(), !i2.mediaTypes_.AUDIO.activePlaylistLoader || i2.mediaTypes_.AUDIO.activePlaylistLoader.media() ? i2.trigger("selectedinitialmedia") : i2.mediaTypes_.AUDIO.activePlaylistLoader.one("loadedmetadata", function() {
            i2.trigger("selectedinitialmedia");
          });
        }), this.masterPlaylistLoader_.on("loadedplaylist", function() {
          i2.loadOnPlay_ && i2.tech_.off("play", i2.loadOnPlay_);
          var e3, t3 = i2.masterPlaylistLoader_.media();
          if (!t3) {
            if (i2.excludeUnsupportedVariants_(), !(e3 = (e3 = i2.enableLowInitialPlaylist ? i2.selectInitialPlaylist() : e3) || i2.selectPlaylist()) || !i2.shouldSwitchToMedia_(e3))
              return;
            if (i2.initialMedia_ = e3, i2.switchMedia_(i2.initialMedia_, "initial"), !("vhs-json" === i2.sourceType_ && i2.initialMedia_.segments))
              return;
            t3 = i2.initialMedia_;
          }
          i2.handleUpdatedMediaPlaylist(t3);
        }), this.masterPlaylistLoader_.on("error", function() {
          i2.blacklistCurrentPlaylist(i2.masterPlaylistLoader_.error);
        }), this.masterPlaylistLoader_.on("mediachanging", function() {
          i2.mainSegmentLoader_.abort(), i2.mainSegmentLoader_.pause();
        }), this.masterPlaylistLoader_.on("mediachange", function() {
          var e3 = i2.masterPlaylistLoader_.media(), t3 = 1.5 * e3.targetDuration * 1e3;
          bu(i2.masterPlaylistLoader_.master, i2.masterPlaylistLoader_.media()) ? i2.requestOptions_.timeout = 0 : i2.requestOptions_.timeout = t3, i2.masterPlaylistLoader_.load(), i2.mainSegmentLoader_.playlist(e3, i2.requestOptions_), i2.mainSegmentLoader_.load(), i2.tech_.trigger({ type: "mediachange", bubbles: true });
        }), this.masterPlaylistLoader_.on("playlistunchanged", function() {
          var e3 = i2.masterPlaylistLoader_.media();
          "playlist-unchanged" !== e3.lastExcludeReason_ && i2.stuckAtPlaylistEnd_(e3) && (i2.blacklistCurrentPlaylist({ message: "Playlist no longer updating.", reason: "playlist-unchanged" }), i2.tech_.trigger("playliststuck"));
        }), this.masterPlaylistLoader_.on("renditiondisabled", function() {
          i2.tech_.trigger({ type: "usage", name: "vhs-rendition-disabled" }), i2.tech_.trigger({ type: "usage", name: "hls-rendition-disabled" });
        }), this.masterPlaylistLoader_.on("renditionenabled", function() {
          i2.tech_.trigger({ type: "usage", name: "vhs-rendition-enabled" }), i2.tech_.trigger({ type: "usage", name: "hls-rendition-enabled" });
        });
      }, t2.handleUpdatedMediaPlaylist = function(e3) {
        this.useCueTags_ && this.updateAdCues_(e3), this.mainSegmentLoader_.playlist(e3, this.requestOptions_), this.updateDuration(!e3.endList), this.tech_.paused() || (this.mainSegmentLoader_.load(), this.audioSegmentLoader_ && this.audioSegmentLoader_.load());
      }, t2.triggerPresenceUsage_ = function(e3, t3) {
        var i2, n2 = e3.mediaGroups || {}, r2 = true, e3 = Object.keys(n2.AUDIO);
        for (i2 in n2.AUDIO)
          for (var a2 in n2.AUDIO[i2])
            n2.AUDIO[i2][a2].uri || (r2 = false);
        r2 && (this.tech_.trigger({ type: "usage", name: "vhs-demuxed" }), this.tech_.trigger({ type: "usage", name: "hls-demuxed" })), Object.keys(n2.SUBTITLES).length && (this.tech_.trigger({ type: "usage", name: "vhs-webvtt" }), this.tech_.trigger({ type: "usage", name: "hls-webvtt" })), gd.Playlist.isAes(t3) && (this.tech_.trigger({ type: "usage", name: "vhs-aes" }), this.tech_.trigger({ type: "usage", name: "hls-aes" })), e3.length && 1 < Object.keys(n2.AUDIO[e3[0]]).length && (this.tech_.trigger({ type: "usage", name: "vhs-alternate-audio" }), this.tech_.trigger({ type: "usage", name: "hls-alternate-audio" })), this.useCueTags_ && (this.tech_.trigger({ type: "usage", name: "vhs-playlist-cue-tags" }), this.tech_.trigger({ type: "usage", name: "hls-playlist-cue-tags" }));
      }, t2.shouldSwitchToMedia_ = function(e3) {
        var t3 = this.masterPlaylistLoader_.media() || this.masterPlaylistLoader_.pendingMedia_, i2 = this.tech_.currentTime(), n2 = this.bufferLowWaterLine(), r2 = this.bufferHighWaterLine();
        return function(e4) {
          var t4 = e4.currentPlaylist, i3 = e4.buffered, n3 = e4.currentTime, r3 = e4.nextPlaylist, a2 = e4.bufferLowWaterLine, s2 = e4.bufferHighWaterLine, o2 = e4.duration, u2 = e4.experimentalBufferBasedABR, l2 = e4.log;
          if (!r3)
            return ir.log.warn("We received no playlist to switch to. Please check your stream."), false;
          var d2 = "allowing switch " + (t4 && t4.id || "null") + " -> " + r3.id;
          if (!t4)
            return l2(d2 + " as current playlist is not set"), true;
          if (r3.id === t4.id)
            return false;
          e4 = Boolean(tu(i3, n3).length);
          if (!t4.endList)
            return e4 || "number" != typeof t4.partTargetDuration ? (l2(d2 + " as current playlist is live"), true) : (l2("not " + d2 + " as current playlist is live llhls, but currentTime isn't in buffered."), false);
          i3 = su(i3, n3), n3 = u2 ? Wl.EXPERIMENTAL_MAX_BUFFER_LOW_WATER_LINE : Wl.MAX_BUFFER_LOW_WATER_LINE;
          if (o2 < n3)
            return l2(d2 + " as duration < max low water line (" + o2 + " < " + n3 + ")"), true;
          n3 = r3.attributes.BANDWIDTH, r3 = t4.attributes.BANDWIDTH;
          if (n3 < r3 && (!u2 || i3 < s2)) {
            t4 = d2 + " as next bandwidth < current bandwidth (" + n3 + " < " + r3 + ")";
            return u2 && (t4 += " and forwardBuffer < bufferHighWaterLine (" + i3 + " < " + s2 + ")"), l2(t4), true;
          }
          if ((!u2 || r3 < n3) && a2 <= i3) {
            a2 = d2 + " as forwardBuffer >= bufferLowWaterLine (" + i3 + " >= " + a2 + ")";
            return u2 && (a2 += " and next bandwidth > current bandwidth (" + n3 + " > " + r3 + ")"), l2(a2), true;
          }
          return l2("not " + d2 + " as no switching criteria met"), false;
        }({ buffered: this.tech_.buffered(), currentTime: i2, currentPlaylist: t3, nextPlaylist: e3, bufferLowWaterLine: n2, bufferHighWaterLine: r2, duration: this.duration(), experimentalBufferBasedABR: this.experimentalBufferBasedABR, log: this.logger_ });
      }, t2.setupSegmentLoaderListeners_ = function() {
        var t3 = this;
        this.mainSegmentLoader_.on("bandwidthupdate", function() {
          t3.checkABR_("bandwidthupdate"), t3.tech_.trigger("bandwidthupdate");
        }), this.mainSegmentLoader_.on("timeout", function() {
          t3.experimentalBufferBasedABR && t3.mainSegmentLoader_.load();
        }), this.experimentalBufferBasedABR || this.mainSegmentLoader_.on("progress", function() {
          t3.trigger("progress");
        }), this.mainSegmentLoader_.on("error", function() {
          t3.blacklistCurrentPlaylist(t3.mainSegmentLoader_.error());
        }), this.mainSegmentLoader_.on("appenderror", function() {
          t3.error = t3.mainSegmentLoader_.error_, t3.trigger("error");
        }), this.mainSegmentLoader_.on("syncinfoupdate", function() {
          t3.onSyncInfoUpdate_();
        }), this.mainSegmentLoader_.on("timestampoffset", function() {
          t3.tech_.trigger({ type: "usage", name: "vhs-timestamp-offset" }), t3.tech_.trigger({ type: "usage", name: "hls-timestamp-offset" });
        }), this.audioSegmentLoader_.on("syncinfoupdate", function() {
          t3.onSyncInfoUpdate_();
        }), this.audioSegmentLoader_.on("appenderror", function() {
          t3.error = t3.audioSegmentLoader_.error_, t3.trigger("error");
        }), this.mainSegmentLoader_.on("ended", function() {
          t3.logger_("main segment loader ended"), t3.onEndOfStream();
        }), this.mainSegmentLoader_.on("earlyabort", function(e4) {
          t3.experimentalBufferBasedABR || (t3.delegateLoaders_("all", ["abort"]), t3.blacklistCurrentPlaylist({ message: "Aborted early because there isn't enough bandwidth to complete the request without rebuffering." }, 120));
        });
        function e3() {
          if (!t3.sourceUpdater_.hasCreatedSourceBuffers())
            return t3.tryToCreateSourceBuffers_();
          var e4 = t3.getCodecsOrExclude_();
          e4 && t3.sourceUpdater_.addOrChangeSourceBuffers(e4);
        }
        this.mainSegmentLoader_.on("trackinfo", e3), this.audioSegmentLoader_.on("trackinfo", e3), this.mainSegmentLoader_.on("fmp4", function() {
          t3.triggeredFmp4Usage || (t3.tech_.trigger({ type: "usage", name: "vhs-fmp4" }), t3.tech_.trigger({ type: "usage", name: "hls-fmp4" }), t3.triggeredFmp4Usage = true);
        }), this.audioSegmentLoader_.on("fmp4", function() {
          t3.triggeredFmp4Usage || (t3.tech_.trigger({ type: "usage", name: "vhs-fmp4" }), t3.tech_.trigger({ type: "usage", name: "hls-fmp4" }), t3.triggeredFmp4Usage = true);
        }), this.audioSegmentLoader_.on("ended", function() {
          t3.logger_("audioSegmentLoader ended"), t3.onEndOfStream();
        });
      }, t2.mediaSecondsLoaded_ = function() {
        return Math.max(this.audioSegmentLoader_.mediaSecondsLoaded + this.mainSegmentLoader_.mediaSecondsLoaded);
      }, t2.load = function() {
        this.mainSegmentLoader_.load(), this.mediaTypes_.AUDIO.activePlaylistLoader && this.audioSegmentLoader_.load(), this.mediaTypes_.SUBTITLES.activePlaylistLoader && this.subtitleSegmentLoader_.load();
      }, t2.smoothQualityChange_ = function(e3) {
        void 0 === e3 && (e3 = this.selectPlaylist()), this.fastQualityChange_(e3);
      }, t2.fastQualityChange_ = function(e3) {
        var t3 = this;
        (e3 = void 0 === e3 ? this.selectPlaylist() : e3) !== this.masterPlaylistLoader_.media() ? (this.switchMedia_(e3, "fast-quality"), this.mainSegmentLoader_.resetEverything(function() {
          ir.browser.IE_VERSION || ir.browser.IS_EDGE ? t3.tech_.setCurrentTime(t3.tech_.currentTime() + 0.04) : t3.tech_.setCurrentTime(t3.tech_.currentTime());
        })) : this.logger_("skipping fastQualityChange because new media is same as old");
      }, t2.play = function() {
        if (!this.setupFirstPlay()) {
          this.tech_.ended() && this.tech_.setCurrentTime(0), this.hasPlayed_ && this.load();
          var e3 = this.tech_.seekable();
          return this.tech_.duration() === 1 / 0 && this.tech_.currentTime() < e3.start(0) ? this.tech_.setCurrentTime(e3.end(e3.length - 1)) : void 0;
        }
      }, t2.setupFirstPlay = function() {
        var e3 = this, t3 = this.masterPlaylistLoader_.media();
        if (!t3 || this.tech_.paused() || this.hasPlayed_)
          return false;
        if (!t3.endList) {
          var i2 = this.seekable();
          if (!i2.length)
            return false;
          if (ir.browser.IE_VERSION && 0 === this.tech_.readyState())
            return this.tech_.one("loadedmetadata", function() {
              e3.trigger("firstplay"), e3.tech_.setCurrentTime(i2.end(0)), e3.hasPlayed_ = true;
            }), false;
          this.trigger("firstplay"), this.tech_.setCurrentTime(i2.end(0));
        }
        return this.hasPlayed_ = true, this.load(), true;
      }, t2.handleSourceOpen_ = function() {
        var e3;
        this.tryToCreateSourceBuffers_(), !this.tech_.autoplay() || "undefined" != typeof (e3 = this.tech_.play()) && "function" == typeof e3.then && e3.then(null, function(e4) {
        }), this.trigger("sourceopen");
      }, t2.handleSourceEnded_ = function() {
        var e3, t3;
        !this.inbandTextTracks_.metadataTrack_ || (e3 = this.inbandTextTracks_.metadataTrack_.cues) && e3.length && (t3 = this.duration(), e3[e3.length - 1].endTime = isNaN(t3) || Math.abs(t3) === 1 / 0 ? Number.MAX_VALUE : t3);
      }, t2.handleDurationChange_ = function() {
        this.tech_.trigger("durationchange");
      }, t2.onEndOfStream = function() {
        var e3, t3 = this.mainSegmentLoader_.ended_;
        (t3 = this.mediaTypes_.AUDIO.activePlaylistLoader ? ((e3 = this.mainSegmentLoader_.getCurrentMediaInfo_()) && !e3.hasVideo || t3) && this.audioSegmentLoader_.ended_ : t3) && (this.stopABRTimer_(), this.sourceUpdater_.endOfStream());
      }, t2.stuckAtPlaylistEnd_ = function(e3) {
        if (!this.seekable().length)
          return false;
        var t3 = this.syncController_.getExpiredTime(e3, this.duration());
        if (null === t3)
          return false;
        var i2 = gd.Playlist.playlistEnd(e3, t3), e3 = this.tech_.currentTime(), t3 = this.tech_.buffered();
        if (!t3.length)
          return i2 - e3 <= 0.1;
        t3 = t3.end(t3.length - 1);
        return t3 - e3 <= 0.1 && i2 - t3 <= 0.1;
      }, t2.blacklistCurrentPlaylist = function(e3, t3) {
        var i2 = (e3 = void 0 === e3 ? {} : e3).playlist || this.masterPlaylistLoader_.media();
        if (t3 = t3 || e3.blacklistDuration || this.blacklistDuration, !i2)
          return this.error = e3, void ("open" !== this.mediaSource.readyState ? this.trigger("error") : this.sourceUpdater_.endOfStream("network"));
        i2.playlistErrors_++;
        var n2, r2 = this.masterPlaylistLoader_.master.playlists, a2 = r2.filter(vu), s2 = 1 === a2.length && a2[0] === i2;
        if (1 === r2.length && t3 !== 1 / 0)
          return ir.log.warn("Problem encountered with playlist " + i2.id + ". Trying again since it is the only playlist."), this.tech_.trigger("retryplaylist"), this.masterPlaylistLoader_.load(s2);
        s2 && (n2 = false, r2.forEach(function(e4) {
          var t4;
          e4 === i2 || "undefined" != typeof (t4 = e4.excludeUntil) && t4 !== 1 / 0 && (n2 = true, delete e4.excludeUntil);
        }), n2 && (ir.log.warn("Removing other playlists from the exclusion list because the last rendition is about to be excluded."), this.tech_.trigger("retryplaylist"))), a2 = i2.playlistErrors_ > this.maxPlaylistRetries ? 1 / 0 : Date.now() + 1e3 * t3, i2.excludeUntil = a2, e3.reason && (i2.lastExcludeReason_ = e3.reason), this.tech_.trigger("blacklistplaylist"), this.tech_.trigger({ type: "usage", name: "vhs-rendition-blacklisted" }), this.tech_.trigger({ type: "usage", name: "hls-rendition-blacklisted" });
        r2 = this.selectPlaylist();
        if (!r2)
          return this.error = "Playback cannot continue. No available working or supported playlists.", void this.trigger("error");
        t3 = e3.internal ? this.logger_ : ir.log.warn, a2 = e3.message ? " " + e3.message : "";
        t3((e3.internal ? "Internal problem" : "Problem") + " encountered with playlist " + i2.id + "." + a2 + " Switching to playlist " + r2.id + "."), r2.attributes.AUDIO !== i2.attributes.AUDIO && this.delegateLoaders_("audio", ["abort", "pause"]), r2.attributes.SUBTITLES !== i2.attributes.SUBTITLES && this.delegateLoaders_("subtitle", ["abort", "pause"]), this.delegateLoaders_("main", ["abort", "pause"]);
        a2 = r2.targetDuration / 2 * 1e3 || 5e3, a2 = "number" == typeof r2.lastRequest && Date.now() - r2.lastRequest <= a2;
        return this.switchMedia_(r2, "exclude", s2 || a2);
      }, t2.pauseLoading = function() {
        this.delegateLoaders_("all", ["abort", "pause"]), this.stopABRTimer_();
      }, t2.delegateLoaders_ = function(i2, e3) {
        var n2 = this, r2 = [], t3 = "all" === i2;
        !t3 && "main" !== i2 || r2.push(this.masterPlaylistLoader_);
        var a2 = [];
        !t3 && "audio" !== i2 || a2.push("AUDIO"), !t3 && "subtitle" !== i2 || (a2.push("CLOSED-CAPTIONS"), a2.push("SUBTITLES")), a2.forEach(function(e4) {
          e4 = n2.mediaTypes_[e4] && n2.mediaTypes_[e4].activePlaylistLoader;
          e4 && r2.push(e4);
        }), ["main", "audio", "subtitle"].forEach(function(e4) {
          var t4 = n2[e4 + "SegmentLoader_"];
          !t4 || i2 !== e4 && "all" !== i2 || r2.push(t4);
        }), r2.forEach(function(t4) {
          return e3.forEach(function(e4) {
            "function" == typeof t4[e4] && t4[e4]();
          });
        });
      }, t2.setCurrentTime = function(e3) {
        var t3 = tu(this.tech_.buffered(), e3);
        return this.masterPlaylistLoader_ && this.masterPlaylistLoader_.media() && this.masterPlaylistLoader_.media().segments ? t3 && t3.length ? e3 : (this.mainSegmentLoader_.resetEverything(), this.mainSegmentLoader_.abort(), this.mediaTypes_.AUDIO.activePlaylistLoader && (this.audioSegmentLoader_.resetEverything(), this.audioSegmentLoader_.abort()), this.mediaTypes_.SUBTITLES.activePlaylistLoader && (this.subtitleSegmentLoader_.resetEverything(), this.subtitleSegmentLoader_.abort()), void this.load()) : 0;
      }, t2.duration = function() {
        if (!this.masterPlaylistLoader_)
          return 0;
        var e3 = this.masterPlaylistLoader_.media();
        return e3 ? e3.endList ? this.mediaSource ? this.mediaSource.duration : gd.Playlist.duration(e3) : 1 / 0 : 0;
      }, t2.seekable = function() {
        return this.seekable_;
      }, t2.onSyncInfoUpdate_ = function() {
        var e3;
        if (this.masterPlaylistLoader_) {
          var t3 = this.masterPlaylistLoader_.media();
          if (t3) {
            var i2 = this.syncController_.getExpiredTime(t3, this.duration());
            if (null !== i2) {
              var n2, r2, a2 = this.masterPlaylistLoader_.master, s2 = gd.Playlist.seekable(t3, i2, gd.Playlist.liveEdgeDelay(a2, t3));
              if (0 !== s2.length) {
                if (this.mediaTypes_.AUDIO.activePlaylistLoader) {
                  if (t3 = this.mediaTypes_.AUDIO.activePlaylistLoader.media(), null === (i2 = this.syncController_.getExpiredTime(t3, this.duration())))
                    return;
                  if (0 === (e3 = gd.Playlist.seekable(t3, i2, gd.Playlist.liveEdgeDelay(a2, t3))).length)
                    return;
                }
                this.seekable_ && this.seekable_.length && (n2 = this.seekable_.end(0), r2 = this.seekable_.start(0)), !e3 || e3.start(0) > s2.end(0) || s2.start(0) > e3.end(0) ? this.seekable_ = s2 : this.seekable_ = ir.createTimeRanges([[(e3.start(0) > s2.start(0) ? e3 : s2).start(0), (e3.end(0) < s2.end(0) ? e3 : s2).end(0)]]), this.seekable_ && this.seekable_.length && this.seekable_.end(0) === n2 && this.seekable_.start(0) === r2 || (this.logger_("seekable updated [" + nu(this.seekable_) + "]"), this.tech_.trigger("seekablechanged"));
              }
            }
          }
        }
      }, t2.updateDuration = function(e3) {
        if (this.updateDuration_ && (this.mediaSource.removeEventListener("sourceopen", this.updateDuration_), this.updateDuration_ = null), "open" !== this.mediaSource.readyState)
          return this.updateDuration_ = this.updateDuration.bind(this, e3), void this.mediaSource.addEventListener("sourceopen", this.updateDuration_);
        if (e3) {
          var t3 = this.seekable();
          return t3.length ? void ((isNaN(this.mediaSource.duration) || this.mediaSource.duration < t3.end(t3.length - 1)) && this.sourceUpdater_.setDuration(t3.end(t3.length - 1))) : void 0;
        }
        e3 = this.tech_.buffered(), t3 = gd.Playlist.duration(this.masterPlaylistLoader_.media());
        0 < e3.length && (t3 = Math.max(t3, e3.end(e3.length - 1))), this.mediaSource.duration !== t3 && this.sourceUpdater_.setDuration(t3);
      }, t2.dispose = function() {
        var n2 = this;
        this.trigger("dispose"), this.decrypter_.terminate(), this.masterPlaylistLoader_.dispose(), this.mainSegmentLoader_.dispose(), this.loadOnPlay_ && this.tech_.off("play", this.loadOnPlay_), ["AUDIO", "SUBTITLES"].forEach(function(e3) {
          var t3, i2 = n2.mediaTypes_[e3].groups;
          for (t3 in i2)
            i2[t3].forEach(function(e4) {
              e4.playlistLoader && e4.playlistLoader.dispose();
            });
        }), this.audioSegmentLoader_.dispose(), this.subtitleSegmentLoader_.dispose(), this.sourceUpdater_.dispose(), this.timelineChangeController_.dispose(), this.stopABRTimer_(), this.updateDuration_ && this.mediaSource.removeEventListener("sourceopen", this.updateDuration_), this.mediaSource.removeEventListener("durationchange", this.handleDurationChange_), this.mediaSource.removeEventListener("sourceopen", this.handleSourceOpen_), this.mediaSource.removeEventListener("sourceended", this.handleSourceEnded_), this.off();
      }, t2.master = function() {
        return this.masterPlaylistLoader_.master;
      }, t2.media = function() {
        return this.masterPlaylistLoader_.media() || this.initialMedia_;
      }, t2.areMediaTypesKnown_ = function() {
        var e3 = !!this.mediaTypes_.AUDIO.activePlaylistLoader, t3 = !!this.mainSegmentLoader_.getCurrentMediaInfo_(), e3 = !e3 || !!this.audioSegmentLoader_.getCurrentMediaInfo_();
        return t3 && e3;
      }, t2.getCodecsOrExclude_ = function() {
        var n2 = this, r2 = { main: this.mainSegmentLoader_.getCurrentMediaInfo_() || {}, audio: this.audioSegmentLoader_.getCurrentMediaInfo_() || {} }, t3 = this.mainSegmentLoader_.getPendingSegmentPlaylist() || this.media();
        r2.video = r2.main;
        var e3 = vl(this.master(), t3), a2 = {}, i2 = !!this.mediaTypes_.AUDIO.activePlaylistLoader;
        if (r2.main.hasVideo && (a2.video = e3.video || r2.main.videoCodec || "avc1.4d400d"), r2.main.isMuxed && (a2.video += "," + (e3.audio || r2.main.audioCodec || Lr)), (r2.main.hasAudio && !r2.main.isMuxed || r2.audio.hasAudio || i2) && (a2.audio = e3.audio || r2.main.audioCodec || r2.audio.audioCodec || Lr, r2.audio.isFmp4 = (r2.main.hasAudio && !r2.main.isMuxed ? r2.main : r2.audio).isFmp4), a2.audio || a2.video) {
          var s2, o2, u2 = {};
          if (["video", "audio"].forEach(function(e4) {
            var t4, i3;
            a2.hasOwnProperty(e4) && (t4 = r2[e4].isFmp4, i3 = a2[e4], !(t4 ? mr : gr)(i3)) && (i3 = r2[e4].isFmp4 ? "browser" : "muxer", u2[i3] = u2[i3] || [], u2[i3].push(a2[e4]), "audio" === e4 && (s2 = i3));
          }), i2 && s2 && t3.attributes.AUDIO && (o2 = t3.attributes.AUDIO, this.master().playlists.forEach(function(e4) {
            (e4.attributes && e4.attributes.AUDIO) === o2 && e4 !== t3 && (e4.excludeUntil = 1 / 0);
          }), this.logger_("excluding audio group " + o2 + " as " + s2 + ' does not support codec(s): "' + a2.audio + '"')), !Object.keys(u2).length) {
            if (this.sourceUpdater_.hasCreatedSourceBuffers() && !this.sourceUpdater_.canChangeType()) {
              var l2 = [];
              if (["video", "audio"].forEach(function(e4) {
                var t4 = (hr(n2.sourceUpdater_.codecs[e4] || "")[0] || {}).type, i3 = (hr(a2[e4] || "")[0] || {}).type;
                t4 && i3 && t4.toLowerCase() !== i3.toLowerCase() && l2.push('"' + n2.sourceUpdater_.codecs[e4] + '" -> "' + a2[e4] + '"');
              }), l2.length)
                return void this.blacklistCurrentPlaylist({ playlist: t3, message: "Codec switching not supported: " + l2.join(", ") + ".", blacklistDuration: 1 / 0, internal: true });
            }
            return a2;
          }
          i2 = Object.keys(u2).reduce(function(e4, t4) {
            return e4 && (e4 += ", "), e4 += t4 + ' does not support codec(s): "' + u2[t4].join(",") + '"';
          }, "") + ".";
          this.blacklistCurrentPlaylist({ playlist: t3, internal: true, message: i2, blacklistDuration: 1 / 0 });
        } else
          this.blacklistCurrentPlaylist({ playlist: t3, message: "Could not determine codecs for playlist.", blacklistDuration: 1 / 0 });
      }, t2.tryToCreateSourceBuffers_ = function() {
        var e3;
        "open" !== this.mediaSource.readyState || this.sourceUpdater_.hasCreatedSourceBuffers() || !this.areMediaTypesKnown_() || (e3 = this.getCodecsOrExclude_()) && (this.sourceUpdater_.createSourceBuffers(e3), e3 = [e3.video, e3.audio].filter(Boolean).join(","), this.excludeIncompatibleVariants_(e3));
      }, t2.excludeUnsupportedVariants_ = function() {
        var n2 = this, r2 = this.master().playlists, a2 = [];
        Object.keys(r2).forEach(function(e3) {
          var t3, i2 = r2[e3];
          -1 === a2.indexOf(i2.id) && (a2.push(i2.id), t3 = [], !(e3 = vl(n2.master, i2)).audio || gr(e3.audio) || mr(e3.audio) || t3.push("audio codec " + e3.audio), !e3.video || gr(e3.video) || mr(e3.video) || t3.push("video codec " + e3.video), e3.text && "stpp.ttml.im1t" === e3.text && t3.push("text codec " + e3.text), t3.length && (i2.excludeUntil = 1 / 0, n2.logger_("excluding " + i2.id + " for unsupported: " + t3.join(", "))));
        });
      }, t2.excludeIncompatibleVariants_ = function(e3) {
        var r2 = this, a2 = [], s2 = this.master().playlists, e3 = gl(hr(e3)), o2 = yl(e3), u2 = e3.video && hr(e3.video)[0] || null, l2 = e3.audio && hr(e3.audio)[0] || null;
        Object.keys(s2).forEach(function(e4) {
          var t3, i2, n2 = s2[e4];
          -1 === a2.indexOf(n2.id) && n2.excludeUntil !== 1 / 0 && (a2.push(n2.id), t3 = [], i2 = vl(r2.masterPlaylistLoader_.master, n2), e4 = yl(i2), (i2.audio || i2.video) && (e4 !== o2 && t3.push('codec count "' + e4 + '" !== "' + o2 + '"'), r2.sourceUpdater_.canChangeType() || (e4 = i2.video && hr(i2.video)[0] || null, i2 = i2.audio && hr(i2.audio)[0] || null, e4 && u2 && e4.type.toLowerCase() !== u2.type.toLowerCase() && t3.push('video codec "' + e4.type + '" !== "' + u2.type + '"'), i2 && l2 && i2.type.toLowerCase() !== l2.type.toLowerCase() && t3.push('audio codec "' + i2.type + '" !== "' + l2.type + '"')), t3.length && (n2.excludeUntil = 1 / 0, r2.logger_("blacklisting " + n2.id + ": " + t3.join(" && ")))));
        });
      }, t2.updateAdCues_ = function(e3) {
        var t3 = 0, i2 = this.seekable();
        i2.length && (t3 = i2.start(0)), function(e4, t4, i3) {
          if (void 0 === i3 && (i3 = 0), e4.segments)
            for (var n2 = i3, r2 = 0; r2 < e4.segments.length; r2++) {
              var a2, s2, o2, u2 = e4.segments[r2];
              if (o2 = o2 || function(e5, t5) {
                for (var i4 = e5.cues, n3 = 0; n3 < i4.length; n3++) {
                  var r3 = i4[n3];
                  if (t5 >= r3.adStartTime && t5 <= r3.adEndTime)
                    return r3;
                }
                return null;
              }(t4, n2 + u2.duration / 2)) {
                if ("cueIn" in u2) {
                  o2.endTime = n2, o2.adEndTime = n2, n2 += u2.duration, o2 = null;
                  continue;
                }
                if (n2 < o2.endTime) {
                  n2 += u2.duration;
                  continue;
                }
                o2.endTime += u2.duration;
              } else
                "cueOut" in u2 && ((o2 = new window.VTTCue(n2, n2 + u2.duration, u2.cueOut)).adStartTime = n2, o2.adEndTime = n2 + parseFloat(u2.cueOut), t4.addCue(o2)), "cueOutCont" in u2 && (a2 = (s2 = u2.cueOutCont.split("/").map(parseFloat))[0], s2 = s2[1], (o2 = new window.VTTCue(n2, n2 + u2.duration, "")).adStartTime = n2 - a2, o2.adEndTime = o2.adStartTime + s2, t4.addCue(o2));
              n2 += u2.duration;
            }
        }(e3, this.cueTagsTrack_, t3);
      }, t2.goalBufferLength = function() {
        var e3 = this.tech_.currentTime(), t3 = Wl.GOAL_BUFFER_LENGTH, i2 = Wl.GOAL_BUFFER_LENGTH_RATE, n2 = Math.max(t3, Wl.MAX_GOAL_BUFFER_LENGTH);
        return Math.min(t3 + e3 * i2, n2);
      }, t2.bufferLowWaterLine = function() {
        var e3 = this.tech_.currentTime(), t3 = Wl.BUFFER_LOW_WATER_LINE, i2 = Wl.BUFFER_LOW_WATER_LINE_RATE, n2 = Math.max(t3, Wl.MAX_BUFFER_LOW_WATER_LINE), r2 = Math.max(t3, Wl.EXPERIMENTAL_MAX_BUFFER_LOW_WATER_LINE);
        return Math.min(t3 + e3 * i2, this.experimentalBufferBasedABR ? r2 : n2);
      }, t2.bufferHighWaterLine = function() {
        return Wl.BUFFER_HIGH_WATER_LINE;
      }, e2;
    }(ir.EventTarget), Vd = ["seeking", "seeked", "pause", "playing", "error"], qd = function() {
      function e2(e3) {
        var i2 = this;
        this.masterPlaylistController_ = e3.masterPlaylistController, this.tech_ = e3.tech, this.seekable = e3.seekable, this.allowSeeksWithinUnsafeLiveWindow = e3.allowSeeksWithinUnsafeLiveWindow, this.liveRangeSafeTimeDelta = e3.liveRangeSafeTimeDelta, this.media = e3.media, this.consecutiveUpdates = 0, this.lastRecordedTime = null, this.timer_ = null, this.checkCurrentTimeTimeout_ = null, this.logger_ = Zo("PlaybackWatcher"), this.logger_("initialize");
        function t3() {
          return i2.monitorCurrentTime_();
        }
        function n2() {
          return i2.monitorCurrentTime_();
        }
        function r2() {
          return i2.techWaiting_();
        }
        function a2() {
          return i2.cancelTimer_();
        }
        var s2 = this.masterPlaylistController_, o2 = ["main", "subtitle", "audio"], u2 = {};
        o2.forEach(function(e4) {
          u2[e4] = { reset: function() {
            return i2.resetSegmentDownloads_(e4);
          }, updateend: function() {
            return i2.checkSegmentDownloads_(e4);
          } }, s2[e4 + "SegmentLoader_"].on("appendsdone", u2[e4].updateend), s2[e4 + "SegmentLoader_"].on("playlistupdate", u2[e4].reset), i2.tech_.on(["seeked", "seeking"], u2[e4].reset);
        });
        function l2(t4) {
          ["main", "audio"].forEach(function(e4) {
            s2[e4 + "SegmentLoader_"][t4]("appended", i2.seekingAppendCheck_);
          });
        }
        this.seekingAppendCheck_ = function() {
          i2.fixesBadSeeks_() && (i2.consecutiveUpdates = 0, i2.lastRecordedTime = i2.tech_.currentTime(), l2("off"));
        }, this.clearSeekingAppendCheck_ = function() {
          return l2("off");
        }, this.watchForBadSeeking_ = function() {
          i2.clearSeekingAppendCheck_(), l2("on");
        }, this.tech_.on("seeked", this.clearSeekingAppendCheck_), this.tech_.on("seeking", this.watchForBadSeeking_), this.tech_.on("waiting", r2), this.tech_.on(Vd, a2), this.tech_.on("canplay", n2), this.tech_.one("play", t3), this.dispose = function() {
          i2.clearSeekingAppendCheck_(), i2.logger_("dispose"), i2.tech_.off("waiting", r2), i2.tech_.off(Vd, a2), i2.tech_.off("canplay", n2), i2.tech_.off("play", t3), i2.tech_.off("seeking", i2.watchForBadSeeking_), i2.tech_.off("seeked", i2.clearSeekingAppendCheck_), o2.forEach(function(e4) {
            s2[e4 + "SegmentLoader_"].off("appendsdone", u2[e4].updateend), s2[e4 + "SegmentLoader_"].off("playlistupdate", u2[e4].reset), i2.tech_.off(["seeked", "seeking"], u2[e4].reset);
          }), i2.checkCurrentTimeTimeout_ && window.clearTimeout(i2.checkCurrentTimeTimeout_), i2.cancelTimer_();
        };
      }
      var t2 = e2.prototype;
      return t2.monitorCurrentTime_ = function() {
        this.checkCurrentTime_(), this.checkCurrentTimeTimeout_ && window.clearTimeout(this.checkCurrentTimeTimeout_), this.checkCurrentTimeTimeout_ = window.setTimeout(this.monitorCurrentTime_.bind(this), 250);
      }, t2.resetSegmentDownloads_ = function(e3) {
        var t3 = this.masterPlaylistController_[e3 + "SegmentLoader_"];
        0 < this[e3 + "StalledDownloads_"] && this.logger_("resetting possible stalled download count for " + e3 + " loader"), this[e3 + "StalledDownloads_"] = 0, this[e3 + "Buffered_"] = t3.buffered_();
      }, t2.checkSegmentDownloads_ = function(e3) {
        var t3 = this.masterPlaylistController_, i2 = t3[e3 + "SegmentLoader_"], n2 = i2.buffered_(), r2 = function(e4, t4) {
          if (e4 === t4)
            return false;
          if (!e4 && t4 || !t4 && e4)
            return true;
          if (e4.length !== t4.length)
            return true;
          for (var i3 = 0; i3 < e4.length; i3++)
            if (e4.start(i3) !== t4.start(i3) || e4.end(i3) !== t4.end(i3))
              return true;
          return false;
        }(this[e3 + "Buffered_"], n2);
        this[e3 + "Buffered_"] = n2, r2 ? this.resetSegmentDownloads_(e3) : (this[e3 + "StalledDownloads_"]++, this.logger_("found #" + this[e3 + "StalledDownloads_"] + " " + e3 + " appends that did not increase buffer (possible stalled download)", { playlistId: i2.playlist_ && i2.playlist_.id, buffered: ru(n2) }), this[e3 + "StalledDownloads_"] < 10 || (this.logger_(e3 + " loader stalled download exclusion"), this.resetSegmentDownloads_(e3), this.tech_.trigger({ type: "usage", name: "vhs-" + e3 + "-download-exclusion" }), "subtitle" !== e3 && t3.blacklistCurrentPlaylist({ message: "Excessive " + e3 + " segment downloading detected." }, 1 / 0)));
      }, t2.checkCurrentTime_ = function() {
        if (!this.tech_.paused() && !this.tech_.seeking()) {
          var e3 = this.tech_.currentTime(), t3 = this.tech_.buffered();
          if (this.lastRecordedTime === e3 && (!t3.length || e3 + 0.1 >= t3.end(t3.length - 1)))
            return this.techWaiting_();
          5 <= this.consecutiveUpdates && e3 === this.lastRecordedTime ? (this.consecutiveUpdates++, this.waiting_()) : e3 === this.lastRecordedTime ? this.consecutiveUpdates++ : (this.consecutiveUpdates = 0, this.lastRecordedTime = e3);
        }
      }, t2.cancelTimer_ = function() {
        this.consecutiveUpdates = 0, this.timer_ && (this.logger_("cancelTimer_"), clearTimeout(this.timer_)), this.timer_ = null;
      }, t2.fixesBadSeeks_ = function() {
        if (!this.tech_.seeking())
          return false;
        var e3, t3 = this.seekable(), i2 = this.tech_.currentTime();
        if (this.afterSeekableWindow_(t3, i2, this.media(), this.allowSeeksWithinUnsafeLiveWindow) && (e3 = t3.end(t3.length - 1)), "undefined" != typeof (e3 = this.beforeSeekableWindow_(t3, i2) ? (a2 = t3.start(0)) + (a2 === t3.end(0) ? 0 : 0.1) : e3))
          return this.logger_("Trying to seek outside of seekable at time " + i2 + " with seekable range " + nu(t3) + ". Seeking to " + e3 + "."), this.tech_.setCurrentTime(e3), true;
        for (var n2 = this.masterPlaylistController_.sourceUpdater_, r2 = this.tech_.buffered(), a2 = n2.audioBuffer ? n2.audioBuffered() : null, t3 = n2.videoBuffer ? n2.videoBuffered() : null, n2 = this.media(), s2 = n2.partTargetDuration || 2 * (n2.targetDuration - Rl), o2 = [a2, t3], u2 = 0; u2 < o2.length; u2++)
          if (o2[u2]) {
            if (su(o2[u2], i2) < s2)
              return false;
          }
        r2 = iu(r2, i2);
        return 0 !== r2.length && (e3 = r2.start(0) + 0.1, this.logger_("Buffered region starts (" + r2.start(0) + ")  just beyond seek point (" + i2 + "). Seeking to " + e3 + "."), this.tech_.setCurrentTime(e3), true);
      }, t2.waiting_ = function() {
        var e3, t3;
        this.techWaiting_() || (e3 = this.tech_.currentTime(), t3 = this.tech_.buffered(), (t3 = tu(t3, e3)).length && e3 + 3 <= t3.end(0) && (this.cancelTimer_(), this.tech_.setCurrentTime(e3), this.logger_("Stopped at " + e3 + " while inside a buffered region [" + t3.start(0) + " -> " + t3.end(0) + "]. Attempting to resume playback by seeking to the current time."), this.tech_.trigger({ type: "usage", name: "vhs-unknown-waiting" }), this.tech_.trigger({ type: "usage", name: "hls-unknown-waiting" })));
      }, t2.techWaiting_ = function() {
        var e3 = this.seekable(), t3 = this.tech_.currentTime();
        if (this.tech_.seeking() || null !== this.timer_)
          return true;
        if (this.beforeSeekableWindow_(e3, t3)) {
          var i2 = e3.end(e3.length - 1);
          return this.logger_("Fell out of live window at time " + t3 + ". Seeking to live point (seekable end) " + i2), this.cancelTimer_(), this.tech_.setCurrentTime(i2), this.tech_.trigger({ type: "usage", name: "vhs-live-resync" }), this.tech_.trigger({ type: "usage", name: "hls-live-resync" }), true;
        }
        e3 = this.tech_.vhs.masterPlaylistController_.sourceUpdater_, i2 = this.tech_.buffered();
        if (this.videoUnderflow_({ audioBuffered: e3.audioBuffered(), videoBuffered: e3.videoBuffered(), currentTime: t3 }))
          return this.cancelTimer_(), this.tech_.setCurrentTime(t3), this.tech_.trigger({ type: "usage", name: "vhs-video-underflow" }), this.tech_.trigger({ type: "usage", name: "hls-video-underflow" }), true;
        e3 = iu(i2, t3);
        if (0 < e3.length) {
          i2 = e3.start(0) - t3;
          return this.logger_("Stopped at " + t3 + ", setting timer for " + i2 + ", seeking to " + e3.start(0)), this.cancelTimer_(), this.timer_ = setTimeout(this.skipTheGap_.bind(this), 1e3 * i2, t3), true;
        }
        return false;
      }, t2.afterSeekableWindow_ = function(e3, t3, i2, n2) {
        if (void 0 === n2 && (n2 = false), !e3.length)
          return false;
        var r2 = e3.end(e3.length - 1) + 0.1;
        return (r2 = !i2.endList && n2 ? e3.end(e3.length - 1) + 3 * i2.targetDuration : r2) < t3;
      }, t2.beforeSeekableWindow_ = function(e3, t3) {
        return !!(e3.length && 0 < e3.start(0) && t3 < e3.start(0) - this.liveRangeSafeTimeDelta);
      }, t2.videoUnderflow_ = function(e3) {
        var t3, i2, n2 = e3.videoBuffered, r2 = e3.audioBuffered, a2 = e3.currentTime;
        if (n2)
          return n2.length && r2.length ? (i2 = tu(n2, a2 - 3), e3 = tu(n2, a2), (r2 = tu(r2, a2)).length && !e3.length && i2.length && (t3 = { start: i2.end(0), end: r2.end(0) })) : iu(n2, a2).length || (t3 = this.gapFromVideoUnderflow_(n2, a2)), !!t3 && (this.logger_("Encountered a gap in video from " + t3.start + " to " + t3.end + ". Seeking to current time " + a2), true);
      }, t2.skipTheGap_ = function(e3) {
        var t3 = this.tech_.buffered(), i2 = this.tech_.currentTime(), t3 = iu(t3, i2);
        this.cancelTimer_(), 0 !== t3.length && i2 === e3 && (this.logger_("skipTheGap_:", "currentTime:", i2, "scheduled currentTime:", e3, "nextRange start:", t3.start(0)), this.tech_.setCurrentTime(t3.start(0) + Rl), this.tech_.trigger({ type: "usage", name: "vhs-gap-skip" }), this.tech_.trigger({ type: "usage", name: "hls-gap-skip" }));
      }, t2.gapFromVideoUnderflow_ = function(e3, t3) {
        for (var i2 = function(e4) {
          if (e4.length < 2)
            return ir.createTimeRanges();
          for (var t4 = [], i3 = 1; i3 < e4.length; i3++) {
            var n3 = e4.end(i3 - 1), r3 = e4.start(i3);
            t4.push([n3, r3]);
          }
          return ir.createTimeRanges(t4);
        }(e3), n2 = 0; n2 < i2.length; n2++) {
          var r2 = i2.start(n2), a2 = i2.end(n2);
          if (t3 - r2 < 4 && 2 < t3 - r2)
            return { start: r2, end: a2 };
        }
        return null;
      }, e2;
    }(), Wd = { errorInterval: 30, getSource: function(e2) {
      return e2(this.tech({ IWillNotUseThisInPlugins: true }).currentSource_ || this.currentSource());
    } }, Gd = { PlaylistLoader: Fl, Playlist: Nl, utils: U, STANDARD_PLAYLIST_SELECTOR: zt, INITIAL_PLAYLIST_SELECTOR: function() {
      var t2 = this, e2 = this.playlists.master.playlists.filter(Nl.isEnabled);
      return Tl(e2, wl), e2.filter(function(e3) {
        return !!vl(t2.playlists.master, e3).video;
      })[0] || null;
    }, lastBandwidthSelector: zt, movingAverageBandwidthSelector: function(t2) {
      var i2 = -1, n2 = -1;
      if (t2 < 0 || 1 < t2)
        throw new Error("Moving average bandwidth decay must be between 0 and 1.");
      return function() {
        var e2 = this.useDevicePixelRatio && window.devicePixelRatio || 1;
        return i2 < 0 && (i2 = this.systemBandwidth, n2 = this.systemBandwidth), 0 < this.systemBandwidth && this.systemBandwidth !== n2 && (i2 = t2 * this.systemBandwidth + (1 - t2) * i2, n2 = this.systemBandwidth), Sl(this.playlists.master, i2, parseInt(bl(this.tech_.el(), "width"), 10) * e2, parseInt(bl(this.tech_.el(), "height"), 10) * e2, this.limitRenditionByPlayerDimensions, this.masterPlaylistController_);
      };
    }, comparePlaylistBandwidth: wl, comparePlaylistResolution: function(e2, t2) {
      var i2, n2;
      return (i2 = (i2 = e2.attributes.RESOLUTION && e2.attributes.RESOLUTION.width ? e2.attributes.RESOLUTION.width : i2) || window.Number.MAX_VALUE) === (n2 = (n2 = t2.attributes.RESOLUTION && t2.attributes.RESOLUTION.width ? t2.attributes.RESOLUTION.width : n2) || window.Number.MAX_VALUE) && e2.attributes.BANDWIDTH && t2.attributes.BANDWIDTH ? e2.attributes.BANDWIDTH - t2.attributes.BANDWIDTH : i2 - n2;
    }, xhr: Nu() };
    Object.keys(Wl).forEach(function(t2) {
      Object.defineProperty(Gd, t2, { get: function() {
        return ir.log.warn("using Vhs." + t2 + " is UNSAFE be sure you know what you are doing"), Wl[t2];
      }, set: function(e2) {
        ir.log.warn("using Vhs." + t2 + " is UNSAFE be sure you know what you are doing"), "number" != typeof e2 || e2 < 0 ? ir.log.warn("value of Vhs." + t2 + " must be greater than or equal to 0") : Wl[t2] = e2;
      } });
    });
    function zd(e2, t2) {
      for (var i2 = t2.media(), n2 = -1, r2 = 0; r2 < e2.length; r2++)
        if (e2[r2].id === i2.id) {
          n2 = r2;
          break;
        }
      e2.selectedIndex_ = n2, e2.trigger({ selectedIndex: n2, type: "change" });
    }
    var Xd = "videojs-vhs";
    Gd.canPlaySource = function() {
      return ir.log.warn("HLS is no longer a tech. Please remove it from your player's techOrder.");
    };
    function Kd(e2) {
      var n2 = e2.player, t2 = e2.sourceKeySystems, i2 = e2.audioMedia, e2 = e2.mainPlaylists;
      if (!n2.eme.initializeMediaKeys)
        return Promise.resolve();
      var r2, e2 = (e2 = e2 = i2 ? e2.concat([i2]) : e2, r2 = Object.keys(t2), e2.reduce(function(e3, n3) {
        if (!n3.contentProtection)
          return e3;
        var t3 = r2.reduce(function(e4, t4) {
          var i3 = n3.contentProtection[t4];
          return i3 && i3.pssh && (e4[t4] = { pssh: i3.pssh }), e4;
        }, {});
        return Object.keys(t3).length && e3.push(t3), e3;
      }, [])), a2 = [], s2 = [];
      return e2.forEach(function(e3) {
        s2.push(new Promise(function(e4, t3) {
          n2.tech_.one("keysessioncreated", e4);
        })), a2.push(new Promise(function(t3, i3) {
          n2.eme.initializeMediaKeys({ keySystems: e3 }, function(e4) {
            e4 ? i3(e4) : t3();
          });
        }));
      }), Promise.race([Promise.all(a2), Promise.race(s2)]);
    }
    function Yd(e2) {
      var t2 = e2.player;
      return !!(e2 = function(e3, t3, i2) {
        if (!e3)
          return e3;
        var n2 = {};
        t3 && t3.attributes && t3.attributes.CODECS && (n2 = gl(hr(t3.attributes.CODECS))), i2 && i2.attributes && i2.attributes.CODECS && (n2.audio = i2.attributes.CODECS);
        var r2, a2 = fr(n2.video), s2 = fr(n2.audio), o2 = {};
        for (r2 in e3)
          o2[r2] = {}, s2 && (o2[r2].audioContentType = s2), a2 && (o2[r2].videoContentType = a2), t3.contentProtection && t3.contentProtection[r2] && t3.contentProtection[r2].pssh && (o2[r2].pssh = t3.contentProtection[r2].pssh), "string" == typeof e3[r2] && (o2[r2].url = e3[r2]);
        return ir.mergeOptions(e3, o2);
      }(e2.sourceKeySystems, e2.media, e2.audioMedia)) && (!((t2.currentSource().keySystems = e2) && !t2.eme) || (ir.log.warn("DRM encrypted source cannot be decrypted without a DRM plugin"), false));
    }
    function Qd() {
      if (!window.localStorage)
        return null;
      var e2 = window.localStorage.getItem(Xd);
      if (!e2)
        return null;
      try {
        return JSON.parse(e2);
      } catch (e3) {
        return null;
      }
    }
    Gd.supportsNativeHls = function() {
      if (!document || !document.createElement)
        return false;
      var t2 = document.createElement("video");
      if (!ir.getTech("Html5").isSupported())
        return false;
      return ["application/vnd.apple.mpegurl", "audio/mpegurl", "audio/x-mpegurl", "application/x-mpegurl", "video/x-mpegurl", "video/mpegurl", "application/mpegurl"].some(function(e2) {
        return /maybe|probably/i.test(t2.canPlayType(e2));
      });
    }(), Gd.supportsNativeDash = !!(document && document.createElement && ir.getTech("Html5").isSupported()) && /maybe|probably/i.test(document.createElement("video").canPlayType("application/dash+xml")), Gd.supportsTypeNatively = function(e2) {
      return "hls" === e2 ? Gd.supportsNativeHls : "dash" === e2 && Gd.supportsNativeDash;
    }, Gd.isSupported = function() {
      return ir.log.warn("HLS is no longer a tech. Please remove it from your player's techOrder.");
    };
    var $d = function(r2) {
      function e2(e3, t3, i2) {
        var n2 = r2.call(this, t3, ir.mergeOptions(i2.hls, i2.vhs)) || this;
        if (i2.hls && Object.keys(i2.hls).length && ir.log.warn("Using hls options is deprecated. Please rename `hls` to `vhs` in your options object."), "number" == typeof i2.initialBandwidth && (n2.options_.bandwidth = i2.initialBandwidth), n2.logger_ = Zo("VhsHandler"), t3.options_ && t3.options_.playerId && ((i2 = ir(t3.options_.playerId)).hasOwnProperty("hls") || Object.defineProperty(i2, "hls", { get: function() {
          return ir.log.warn("player.hls is deprecated. Use player.tech().vhs instead."), t3.trigger({ type: "usage", name: "hls-player-access" }), ft(n2);
        }, configurable: true }), i2.hasOwnProperty("vhs") || Object.defineProperty(i2, "vhs", { get: function() {
          return ir.log.warn("player.vhs is deprecated. Use player.tech().vhs instead."), t3.trigger({ type: "usage", name: "vhs-player-access" }), ft(n2);
        }, configurable: true }), i2.hasOwnProperty("dash") || Object.defineProperty(i2, "dash", { get: function() {
          return ir.log.warn("player.dash is deprecated. Use player.tech().vhs instead."), ft(n2);
        }, configurable: true }), n2.player_ = i2), n2.tech_ = t3, n2.source_ = e3, n2.stats = {}, n2.ignoreNextSeekingEvent_ = false, n2.setOptions_(), n2.options_.overrideNative && t3.overrideNativeAudioTracks && t3.overrideNativeVideoTracks)
          t3.overrideNativeAudioTracks(true), t3.overrideNativeVideoTracks(true);
        else if (n2.options_.overrideNative && (t3.featuresNativeVideoTracks || t3.featuresNativeAudioTracks))
          throw new Error("Overriding native HLS requires emulated tracks. See https://git.io/vMpjB");
        return n2.on(document, ["fullscreenchange", "webkitfullscreenchange", "mozfullscreenchange", "MSFullscreenChange"], function(e4) {
          var t4 = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement;
          t4 && t4.contains(n2.tech_.el()) ? n2.masterPlaylistController_.fastQualityChange_() : n2.masterPlaylistController_.checkABR_();
        }), n2.on(n2.tech_, "seeking", function() {
          this.ignoreNextSeekingEvent_ ? this.ignoreNextSeekingEvent_ = false : this.setCurrentTime(this.tech_.currentTime());
        }), n2.on(n2.tech_, "error", function() {
          this.tech_.error() && this.masterPlaylistController_ && this.masterPlaylistController_.pauseLoading();
        }), n2.on(n2.tech_, "play", n2.play), n2;
      }
      mt(e2, r2);
      var t2 = e2.prototype;
      return t2.setOptions_ = function() {
        var e3, t3 = this;
        this.options_.withCredentials = this.options_.withCredentials || false, this.options_.handleManifestRedirects = false !== this.options_.handleManifestRedirects, this.options_.limitRenditionByPlayerDimensions = false !== this.options_.limitRenditionByPlayerDimensions, this.options_.useDevicePixelRatio = this.options_.useDevicePixelRatio || false, this.options_.smoothQualityChange = this.options_.smoothQualityChange || false, this.options_.useBandwidthFromLocalStorage = "undefined" != typeof this.source_.useBandwidthFromLocalStorage ? this.source_.useBandwidthFromLocalStorage : this.options_.useBandwidthFromLocalStorage || false, this.options_.useNetworkInformationApi = this.options_.useNetworkInformationApi || false, this.options_.useDtsForTimestampOffset = this.options_.useDtsForTimestampOffset || false, this.options_.customTagParsers = this.options_.customTagParsers || [], this.options_.customTagMappers = this.options_.customTagMappers || [], this.options_.cacheEncryptionKeys = this.options_.cacheEncryptionKeys || false, "number" != typeof this.options_.blacklistDuration && (this.options_.blacklistDuration = 300), "number" != typeof this.options_.bandwidth && this.options_.useBandwidthFromLocalStorage && ((e3 = Qd()) && e3.bandwidth && (this.options_.bandwidth = e3.bandwidth, this.tech_.trigger({ type: "usage", name: "vhs-bandwidth-from-local-storage" }), this.tech_.trigger({ type: "usage", name: "hls-bandwidth-from-local-storage" })), e3 && e3.throughput && (this.options_.throughput = e3.throughput, this.tech_.trigger({ type: "usage", name: "vhs-throughput-from-local-storage" }), this.tech_.trigger({ type: "usage", name: "hls-throughput-from-local-storage" }))), "number" != typeof this.options_.bandwidth && (this.options_.bandwidth = Wl.INITIAL_BANDWIDTH), this.options_.enableLowInitialPlaylist = this.options_.enableLowInitialPlaylist && this.options_.bandwidth === Wl.INITIAL_BANDWIDTH, ["withCredentials", "useDevicePixelRatio", "limitRenditionByPlayerDimensions", "bandwidth", "smoothQualityChange", "customTagParsers", "customTagMappers", "handleManifestRedirects", "cacheEncryptionKeys", "playlistSelector", "initialPlaylistSelector", "experimentalBufferBasedABR", "liveRangeSafeTimeDelta", "experimentalLLHLS", "useNetworkInformationApi", "useDtsForTimestampOffset", "experimentalExactManifestTimings", "experimentalLeastPixelDiffSelector"].forEach(function(e4) {
          "undefined" != typeof t3.source_[e4] && (t3.options_[e4] = t3.source_[e4]);
        }), this.limitRenditionByPlayerDimensions = this.options_.limitRenditionByPlayerDimensions, this.useDevicePixelRatio = this.options_.useDevicePixelRatio;
      }, t2.src = function(e3, t3) {
        var n2 = this;
        e3 && (this.setOptions_(), this.options_.src = 0 === (e3 = this.source_.src).toLowerCase().indexOf("data:application/vnd.videojs.vhs+json,") ? JSON.parse(e3.substring(e3.indexOf(",") + 1)) : e3, this.options_.tech = this.tech_, this.options_.externVhs = Gd, this.options_.sourceType = yr(t3), this.options_.seekTo = function(e4) {
          n2.tech_.setCurrentTime(e4);
        }, this.options_.smoothQualityChange && ir.log.warn("smoothQualityChange is deprecated and will be removed in the next major version"), this.masterPlaylistController_ = new Hd(this.options_), t3 = ir.mergeOptions({ liveRangeSafeTimeDelta: 0.1 }, this.options_, { seekable: function() {
          return n2.seekable();
        }, media: function() {
          return n2.masterPlaylistController_.media();
        }, masterPlaylistController: this.masterPlaylistController_ }), this.playbackWatcher_ = new qd(t3), this.masterPlaylistController_.on("error", function() {
          var e4 = ir.players[n2.tech_.options_.playerId], t4 = n2.masterPlaylistController_.error;
          "object" != typeof t4 || t4.code ? "string" == typeof t4 && (t4 = { message: t4, code: 3 }) : t4.code = 3, e4.error(t4);
        }), t3 = this.options_.experimentalBufferBasedABR ? Gd.movingAverageBandwidthSelector(0.55) : Gd.STANDARD_PLAYLIST_SELECTOR, this.masterPlaylistController_.selectPlaylist = (this.selectPlaylist || t3).bind(this), this.masterPlaylistController_.selectInitialPlaylist = Gd.INITIAL_PLAYLIST_SELECTOR.bind(this), this.playlists = this.masterPlaylistController_.masterPlaylistLoader_, this.mediaSource = this.masterPlaylistController_.mediaSource, Object.defineProperties(this, { selectPlaylist: { get: function() {
          return this.masterPlaylistController_.selectPlaylist;
        }, set: function(e4) {
          this.masterPlaylistController_.selectPlaylist = e4.bind(this);
        } }, throughput: { get: function() {
          return this.masterPlaylistController_.mainSegmentLoader_.throughput.rate;
        }, set: function(e4) {
          this.masterPlaylistController_.mainSegmentLoader_.throughput.rate = e4, this.masterPlaylistController_.mainSegmentLoader_.throughput.count = 1;
        } }, bandwidth: { get: function() {
          var e4 = this.masterPlaylistController_.mainSegmentLoader_.bandwidth, t4 = window.navigator.connection || window.navigator.mozConnection || window.navigator.webkitConnection;
          return e4 = this.options_.useNetworkInformationApi && t4 ? 1e7 <= (t4 = 1e3 * t4.downlink * 1e3) && 1e7 <= e4 ? Math.max(e4, t4) : t4 : e4;
        }, set: function(e4) {
          this.masterPlaylistController_.mainSegmentLoader_.bandwidth = e4, this.masterPlaylistController_.mainSegmentLoader_.throughput = { rate: 0, count: 0 };
        } }, systemBandwidth: { get: function() {
          var e4 = 1 / (this.bandwidth || 1), t4 = 0 < this.throughput ? 1 / this.throughput : 0;
          return Math.floor(1 / (e4 + t4));
        }, set: function() {
          ir.log.error('The "systemBandwidth" property is read-only');
        } } }), this.options_.bandwidth && (this.bandwidth = this.options_.bandwidth), this.options_.throughput && (this.throughput = this.options_.throughput), Object.defineProperties(this.stats, { bandwidth: { get: function() {
          return n2.bandwidth || 0;
        }, enumerable: true }, mediaRequests: { get: function() {
          return n2.masterPlaylistController_.mediaRequests_() || 0;
        }, enumerable: true }, mediaRequestsAborted: { get: function() {
          return n2.masterPlaylistController_.mediaRequestsAborted_() || 0;
        }, enumerable: true }, mediaRequestsTimedout: { get: function() {
          return n2.masterPlaylistController_.mediaRequestsTimedout_() || 0;
        }, enumerable: true }, mediaRequestsErrored: { get: function() {
          return n2.masterPlaylistController_.mediaRequestsErrored_() || 0;
        }, enumerable: true }, mediaTransferDuration: { get: function() {
          return n2.masterPlaylistController_.mediaTransferDuration_() || 0;
        }, enumerable: true }, mediaBytesTransferred: { get: function() {
          return n2.masterPlaylistController_.mediaBytesTransferred_() || 0;
        }, enumerable: true }, mediaSecondsLoaded: { get: function() {
          return n2.masterPlaylistController_.mediaSecondsLoaded_() || 0;
        }, enumerable: true }, mediaAppends: { get: function() {
          return n2.masterPlaylistController_.mediaAppends_() || 0;
        }, enumerable: true }, mainAppendsToLoadedData: { get: function() {
          return n2.masterPlaylistController_.mainAppendsToLoadedData_() || 0;
        }, enumerable: true }, audioAppendsToLoadedData: { get: function() {
          return n2.masterPlaylistController_.audioAppendsToLoadedData_() || 0;
        }, enumerable: true }, appendsToLoadedData: { get: function() {
          return n2.masterPlaylistController_.appendsToLoadedData_() || 0;
        }, enumerable: true }, timeToLoadedData: { get: function() {
          return n2.masterPlaylistController_.timeToLoadedData_() || 0;
        }, enumerable: true }, buffered: { get: function() {
          return ru(n2.tech_.buffered());
        }, enumerable: true }, currentTime: { get: function() {
          return n2.tech_.currentTime();
        }, enumerable: true }, currentSource: { get: function() {
          return n2.tech_.currentSource_;
        }, enumerable: true }, currentTech: { get: function() {
          return n2.tech_.name_;
        }, enumerable: true }, duration: { get: function() {
          return n2.tech_.duration();
        }, enumerable: true }, master: { get: function() {
          return n2.playlists.master;
        }, enumerable: true }, playerDimensions: { get: function() {
          return n2.tech_.currentDimensions();
        }, enumerable: true }, seekable: { get: function() {
          return ru(n2.tech_.seekable());
        }, enumerable: true }, timestamp: { get: function() {
          return Date.now();
        }, enumerable: true }, videoPlaybackQuality: { get: function() {
          return n2.tech_.getVideoPlaybackQuality();
        }, enumerable: true } }), this.tech_.one("canplay", this.masterPlaylistController_.setupFirstPlay.bind(this.masterPlaylistController_)), this.tech_.on("bandwidthupdate", function() {
          n2.options_.useBandwidthFromLocalStorage && function(e4) {
            if (!window.localStorage)
              return;
            var t4 = (t4 = Qd()) ? ir.mergeOptions(t4, e4) : e4;
            try {
              window.localStorage.setItem(Xd, JSON.stringify(t4));
            } catch (e5) {
              return;
            }
          }({ bandwidth: n2.bandwidth, throughput: Math.round(n2.throughput) });
        }), this.masterPlaylistController_.on("selectedinitialmedia", function() {
          var i2;
          (i2 = n2).representations = function() {
            var e4 = i2.masterPlaylistController_.master(), e4 = Su(e4) ? i2.masterPlaylistController_.getAudioTrackPlaylists_() : e4.playlists;
            return e4 ? e4.filter(function(e5) {
              return !yu(e5);
            }).map(function(e5, t4) {
              return new fd(i2, e5, e5.id);
            }) : [];
          };
        }), this.masterPlaylistController_.sourceUpdater_.on("createdsourcebuffers", function() {
          n2.setupEme_();
        }), this.on(this.masterPlaylistController_, "progress", function() {
          this.tech_.trigger("progress");
        }), this.on(this.masterPlaylistController_, "firstplay", function() {
          this.ignoreNextSeekingEvent_ = true;
        }), this.setupQualityLevels_(), this.tech_.el() && (this.mediaSourceUrl_ = window.URL.createObjectURL(this.masterPlaylistController_.mediaSource), this.tech_.src(this.mediaSourceUrl_)));
      }, t2.createKeySessions_ = function() {
        var t3 = this, e3 = this.masterPlaylistController_.mediaTypes_.AUDIO.activePlaylistLoader;
        this.logger_("waiting for EME key session creation"), Kd({ player: this.player_, sourceKeySystems: this.source_.keySystems, audioMedia: e3 && e3.media(), mainPlaylists: this.playlists.master.playlists }).then(function() {
          t3.logger_("created EME key session"), t3.masterPlaylistController_.sourceUpdater_.initializedEme();
        }).catch(function(e4) {
          t3.logger_("error while creating EME key session", e4), t3.player_.error({ message: "Failed to initialize media keys for EME", code: 3 });
        });
      }, t2.handleWaitingForKey_ = function() {
        this.logger_("waitingforkey fired, attempting to create any new key sessions"), this.createKeySessions_();
      }, t2.setupEme_ = function() {
        var i2 = this, e3 = this.masterPlaylistController_.mediaTypes_.AUDIO.activePlaylistLoader, e3 = Yd({ player: this.player_, sourceKeySystems: this.source_.keySystems, media: this.playlists.media(), audioMedia: e3 && e3.media() });
        this.player_.tech_.on("keystatuschange", function(e4) {
          var t3;
          "output-restricted" !== e4.status || (e4 = i2.masterPlaylistController_.master()) && e4.playlists && (t3 = [], e4.playlists.forEach(function(e5) {
            e5 && e5.attributes && e5.attributes.RESOLUTION && 720 <= e5.attributes.RESOLUTION.height && (!e5.excludeUntil || e5.excludeUntil < 1 / 0) && (e5.excludeUntil = 1 / 0, t3.push(e5));
          }), t3.length && ((e4 = ir.log).warn.apply(e4, ['DRM keystatus changed to "output-restricted." Removing the following HD playlists that will most likely fail to play and clearing the buffer. This may be due to HDCP restrictions on the stream and the capabilities of the current device.'].concat(t3)), i2.masterPlaylistController_.fastQualityChange_()));
        }), this.handleWaitingForKey_ = this.handleWaitingForKey_.bind(this), this.player_.tech_.on("waitingforkey", this.handleWaitingForKey_), 11 !== ir.browser.IE_VERSION && e3 ? this.createKeySessions_() : this.masterPlaylistController_.sourceUpdater_.initializedEme();
      }, t2.setupQualityLevels_ = function() {
        var i2 = this, e3 = ir.players[this.tech_.options_.playerId];
        e3 && e3.qualityLevels && !this.qualityLevels_ && (this.qualityLevels_ = e3.qualityLevels(), this.masterPlaylistController_.on("selectedinitialmedia", function() {
          var t3, e4;
          t3 = i2.qualityLevels_, (e4 = i2).representations().forEach(function(e5) {
            t3.addQualityLevel(e5);
          }), zd(t3, e4.playlists);
        }), this.playlists.on("mediachange", function() {
          zd(i2.qualityLevels_, i2.playlists);
        }));
      }, e2.version = function() {
        return { "@videojs/http-streaming": "2.16.2", "mux.js": "6.0.1", "mpd-parser": "0.22.1", "m3u8-parser": "4.8.0", "aes-decrypter": "3.1.3" };
      }, t2.version = function() {
        return this.constructor.version();
      }, t2.canChangeType = function() {
        return xd.canChangeType();
      }, t2.play = function() {
        this.masterPlaylistController_.play();
      }, t2.setCurrentTime = function(e3) {
        this.masterPlaylistController_.setCurrentTime(e3);
      }, t2.duration = function() {
        return this.masterPlaylistController_.duration();
      }, t2.seekable = function() {
        return this.masterPlaylistController_.seekable();
      }, t2.dispose = function() {
        this.playbackWatcher_ && this.playbackWatcher_.dispose(), this.masterPlaylistController_ && this.masterPlaylistController_.dispose(), this.qualityLevels_ && this.qualityLevels_.dispose(), this.player_ && (delete this.player_.vhs, delete this.player_.dash, delete this.player_.hls), this.tech_ && this.tech_.vhs && delete this.tech_.vhs, this.tech_ && delete this.tech_.hls, this.mediaSourceUrl_ && window.URL.revokeObjectURL && (window.URL.revokeObjectURL(this.mediaSourceUrl_), this.mediaSourceUrl_ = null), this.tech_ && this.tech_.off("waitingforkey", this.handleWaitingForKey_), r2.prototype.dispose.call(this);
      }, t2.convertToProgramTime = function(e3, t3) {
        return Wu({ playlist: this.masterPlaylistController_.media(), time: e3, callback: t3 });
      }, t2.seekToProgramTime = function(e3, t3, i2, n2) {
        return void 0 === i2 && (i2 = true), void 0 === n2 && (n2 = 2), Gu({ programTime: e3, playlist: this.masterPlaylistController_.media(), retryCount: n2, pauseAfterSeek: i2, seekTo: this.options_.seekTo, tech: this.options_.tech, callback: t3 });
      }, e2;
    }(ir.getComponent("Component")), Jd = { name: "videojs-http-streaming", VERSION: "2.16.2", canHandleSource: function(e2, t2) {
      t2 = ir.mergeOptions(ir.options, t2 = void 0 === t2 ? {} : t2);
      return Jd.canPlayType(e2.type, t2);
    }, handleSource: function(e2, t2, i2) {
      i2 = ir.mergeOptions(ir.options, i2 = void 0 === i2 ? {} : i2);
      return t2.vhs = new $d(e2, t2, i2), ir.hasOwnProperty("hls") || Object.defineProperty(t2, "hls", { get: function() {
        return ir.log.warn("player.tech().hls is deprecated. Use player.tech().vhs instead."), t2.vhs;
      }, configurable: true }), t2.vhs.xhr = Nu(), t2.vhs.src(e2.src, e2.type), t2.vhs;
    }, canPlayType: function(e2, t2) {
      e2 = yr(e2);
      if (!e2)
        return "";
      t2 = Jd.getOverrideNative(t2);
      return !Gd.supportsTypeNatively(e2) || t2 ? "maybe" : "";
    }, getOverrideNative: function(e2) {
      var t2 = (e2 = void 0 === e2 ? {} : e2).vhs, i2 = e2.hls, e2 = !(ir.browser.IS_ANY_SAFARI || ir.browser.IS_IOS), t2 = (void 0 === t2 ? {} : t2).overrideNative, i2 = (void 0 === i2 ? {} : i2).overrideNative;
      return void 0 !== i2 && i2 || (void 0 === t2 ? e2 : t2);
    } };
    return mr("avc1.4d400d,mp4a.40.2") && ir.getTech("Html5").registerSourceHandler(Jd, 0), ir.VhsHandler = $d, Object.defineProperty(ir, "HlsHandler", { get: function() {
      return ir.log.warn("videojs.HlsHandler is deprecated. Use videojs.VhsHandler instead."), $d;
    }, configurable: true }), ir.VhsSourceHandler = Jd, Object.defineProperty(ir, "HlsSourceHandler", { get: function() {
      return ir.log.warn("videojs.HlsSourceHandler is deprecated. Use videojs.VhsSourceHandler instead."), Jd;
    }, configurable: true }), ir.Vhs = Gd, Object.defineProperty(ir, "Hls", { get: function() {
      return ir.log.warn("videojs.Hls is deprecated. Use videojs.Vhs instead."), Gd;
    }, configurable: true }), ir.use || (ir.registerComponent("Hls", Gd), ir.registerComponent("Vhs", Gd)), ir.options.vhs = ir.options.vhs || {}, ir.options.hls = ir.options.hls || {}, ir.getPlugin && ir.getPlugin("reloadSourceOnError") || (ir.registerPlugin || ir.plugin)("reloadSourceOnError", function(e2) {
      md(this, e2);
    }), ir;
  });
})(video_min);
const videojs = /* @__PURE__ */ getDefaultExportFromCjs(video_min.exports);
const videoJs = "";
const videoM3u8_vue_vue_type_style_index_0_scoped_11c9280e_lang = "";
const _sfc_main = {
  __name: "video-m3u8",
  setup(__props) {
    const { refs, ready } = useElementRefs();
    const route = useRoute();
    const params = computed(() => {
      return mergeObject({
        url: ""
      }, route.query);
    });
    const videoEntity = ref$1(null);
    function initVideo() {
      videojs(unref(refs), {
        bigPlayButton: false,
        textTrackDisplay: false,
        posterImage: false,
        errorDisplay: false,
        controlBar: false
      }, () => {
        videoEntity.value = videojs(unref(refs));
        videoEntity.value.src([
          {
            type: "application/x-mpegURL",
            src: unref(params).url
          }
        ]);
        videoEntity.value.play();
        videoEntity.value.on("error", () => {
        });
        console.log(videoEntity.value);
      });
    }
    function disposeVideo() {
      if (isNil(unref(videoEntity)))
        return;
      videoEntity.value.dispose();
    }
    watch(refs, () => unref(ready) && initVideo(), { immediate: true });
    onBeforeUnmount(() => {
      disposeVideo();
    });
    return { __sfc: true, refs, ready, route, params, videoEntity, initVideo, disposeVideo, videojs, useElementRefs, useRoute, mergeObject };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c;
  _vm._self._setupProxy;
  return _c("div", { staticClass: "video-m3u8" }, [_c("video", { ref: "refs", attrs: { "controls": "controls", "muted": "muted", "autoplay": "autoplay", "loop": "loop" }, domProps: { "muted": true } })]);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "11c9280e",
  null,
  null
);
const videoM3u8 = __component__.exports;
export {
  videoM3u8 as default
};
