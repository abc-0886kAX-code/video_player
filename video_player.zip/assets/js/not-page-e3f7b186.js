import { g as getCurrentInstance } from "./element-ui-f852ba61.js";
import { n as normalizeComponent } from "./index-3c10d39a.js";
const notPage_vue_vue_type_style_index_0_scoped_84b99a6c_lang = "";
const _sfc_main = {
  __name: "not-page",
  setup(__props) {
    const { proxy } = getCurrentInstance();
    function gobackHome() {
      proxy.$router.push({ name: "home" });
    }
    return { __sfc: true, proxy, gobackHome };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "not-page" }, [_c("img", { attrs: { "src": "https://element-plus-admin.cn/assets/404-1759fece.svg", "alt": "" } }), _c("div", { staticClass: "not-page-text" }, [_vm._v("\u62B1\u6B49\uFF0C\u60A8\u8BBF\u95EE\u7684\u9875\u9762\u4E0D\u5B58\u5728\u3002")]), _c("div", { staticClass: "not-page-btn" }, [_c("el-button", { attrs: { "size": "mini", "type": "primary" }, on: { "click": _setup.gobackHome } }, [_vm._v("\u8FD4\u56DE\u9996\u9875")])], 1)]);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "84b99a6c",
  null,
  null
);
const notPage = __component__.exports;
export {
  notPage as default
};
