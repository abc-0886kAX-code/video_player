import { r as ref$1, j as computed, u as unref } from "./element-ui-f852ba61.js";
import { i as isNil } from "./index-3c10d39a.js";
function useElementRefs() {
  const refs = ref$1(null);
  const ready = computed(() => !isNil(unref(refs)));
  return {
    refs,
    ready
  };
}
export {
  useElementRefs as u
};
