var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
import { j as computed, r as ref$1, w as watch, x as onMounted, p as onUnmounted, u as unref } from "./element-ui-f852ba61.js";
import { u as useElementRefs } from "./useElement-8dd44703.js";
import { n as normalizeComponent, u as useRoute, i as isNil, m as mergeObject } from "./index-3c10d39a.js";
const videoFlv_vue_vue_type_style_index_0_scoped_2447642b_lang = "";
const _sfc_main = {
  __name: "video-flv",
  setup(__props) {
    const { refs, ready } = useElementRefs();
    const route = useRoute();
    const params = computed(() => {
      return mergeObject({
        url: "",
        fit: "contain"
      }, route.query);
    });
    const flvPlayer = ref$1(null);
    const loading = ref$1(true);
    const videoStyle = computed(() => {
      return {
        "object-fit": unref(params).fit
      };
    });
    function defineVideo() {
      return __async(this, null, function* () {
        loading.value = true;
        flvPlayer.value = window.flvjs.createPlayer({
          type: "flv",
          isLive: true,
          hasAudio: false,
          url: unref(params).url
        });
        flvPlayer.value.attachMediaElement(unref(refs));
        flvPlayer.value.load();
        flvPlayer.value.play();
        flvPlayer.value.on(window.flvjs.Events.ERROR, (error) => {
          console.log(error);
          loading.value = false;
        });
        loading.value = false;
      });
    }
    watch(ready, (state) => {
      if (state && window.flvjs.isSupported() && isNil(unref(flvPlayer)))
        defineVideo();
    });
    onMounted(() => {
      loading.value = true;
    });
    onUnmounted(() => {
      if (isNil(unref(flvPlayer)))
        return;
      unref(flvPlayer).pause();
      unref(flvPlayer).unload();
      unref(flvPlayer).destroy();
      loading.value = false;
      flvPlayer.value = null;
    });
    return { __sfc: true, refs, ready, route, params, flvPlayer, loading, videoStyle, defineVideo, useElementRefs, useRoute, mergeObject };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "video-url" }, [_c("video", { ref: "refs", staticClass: "video-url-main", style: _setup.videoStyle, attrs: { "muted": "muted", "autoplay": "autoplay", "loop": "loop", "controls": "" }, domProps: { "muted": true } }), _c("div", { staticClass: "video-url-slot" }, [_vm._t("default")], 2)]);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "2447642b",
  null,
  null
);
const videoFlv = __component__.exports;
export {
  videoFlv as default
};
