var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
import { r as ref$1, g as getCurrentInstance, u as unref } from "./element-ui-f852ba61.js";
import { n as normalizeComponent, a as useUserStore } from "./index-3c10d39a.js";
let getRandomValues;
const rnds8 = new Uint8Array(16);
function rng() {
  if (!getRandomValues) {
    getRandomValues = typeof crypto !== "undefined" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);
    if (!getRandomValues) {
      throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
    }
  }
  return getRandomValues(rnds8);
}
const byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}
const randomUUID = typeof crypto !== "undefined" && crypto.randomUUID && crypto.randomUUID.bind(crypto);
const native = {
  randomUUID
};
function v4(options, buf, offset) {
  if (native.randomUUID && !buf && !options) {
    return native.randomUUID();
  }
  options = options || {};
  const rnds = options.random || (options.rng || rng)();
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
const uuid = v4;
const __$_require_1c523976__ = "/assets/logo-00df824c.png";
const login_vue_vue_type_style_index_0_scoped_89e53e60_lang = "";
const _sfc_main = {
  __name: "login",
  setup(__props) {
    const { proxy } = getCurrentInstance();
    const user = useUserStore();
    const loginForm = ref$1(null);
    const form = ref$1({
      username: "admin",
      userpwd: "123456"
    });
    const rules = {
      username: [
        {
          required: true,
          message: "\u8D26\u53F7\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      userpwd: [
        {
          required: true,
          message: "\u5BC6\u7801\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ]
    };
    function logon() {
      unref(loginForm).validate((valid) => __async(this, null, function* () {
        if (!valid)
          return;
        user.setupToken(uuid());
        proxy.$router.push({ name: "home" });
      }));
    }
    return { __sfc: true, proxy, user, loginForm, form, rules, logon, uuid, useUserStore };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "login" }, [_vm._m(0), _c("div", { staticClass: "login-console" }, [_c("div", { staticClass: "login-console-control" }, [_vm._v("CONTROL")]), _c("div", { staticClass: "login-console-body" }, [_c("div", { staticClass: "login-console-body-label" }, [_vm._v("\u767B\u5F55")]), _c("el-form", { ref: "loginForm", staticClass: "login-console-body-form", attrs: { "label-position": "top", "label-width": "80px", "model": _setup.form, "rules": _setup.rules } }, [_c("el-form-item", { attrs: { "label": "\u7528\u6237\u540D", "prop": "username" } }, [_c("el-input", { attrs: { "type": "text", "placeholder": "\u8BF7\u8F93\u5165\u8D26\u53F7" }, model: { value: _setup.form.username, callback: function($$v) {
    _vm.$set(_setup.form, "username", $$v);
  }, expression: "form.username" } })], 1), _c("el-form-item", { attrs: { "label": "\u5BC6\u7801", "prop": "userpwd" } }, [_c("el-input", { attrs: { "type": "password", "placeholder": "\u8BF7\u8F93\u5165\u5BC6\u7801" }, model: { value: _setup.form.userpwd, callback: function($$v) {
    _vm.$set(_setup.form, "userpwd", $$v);
  }, expression: "form.userpwd" } })], 1), _c("el-form-item", [_c("el-button", { staticStyle: { "width": "100%" }, attrs: { "type": "primary" }, on: { "click": _setup.logon } }, [_vm._v("\u767B\u5F55")])], 1), _c("el-form-item", [_c("el-button", { staticStyle: { "width": "100%" } }, [_vm._v("\u6CE8\u518C")])], 1)], 1)], 1)])]);
};
var _sfc_staticRenderFns = [function() {
  var _vm = this, _c = _vm._self._c;
  _vm._self._setupProxy;
  return _c("div", { staticClass: "login-introduce" }, [_c("div", { staticClass: "login-introduce-logo" }, [_c("img", { attrs: { "src": __$_require_1c523976__, "alt": "" } })]), _c("div", { staticClass: "login-introduce-content" }, [_c("div", { staticClass: "login-introduce-content-image" }, [_c("img", { attrs: { "src": "https://element-plus-admin.cn/assets/login-box-bg-fec91044.svg", "alt": "" } })]), _c("div", { staticClass: "login-introduce-content-label" }, [_vm._v("\u6B22\u8FCE\u4F7F\u7528\u672C\u7CFB\u7EDF")]), _c("div", { staticClass: "login-introduce-content-desc" }, [_vm._v("\u57FA\u4E8EVUE2.7\u5B9E\u73B0\u5BA2\u6237\u7AEF\u5F00\u53D1\u5E73\u53F0")])])]);
}];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "89e53e60",
  null,
  null
);
const login = __component__.exports;
export {
  login as default
};
