import { n as normalizeComponent } from "./index-3c10d39a.js";
import "./element-ui-f852ba61.js";
const home_vue_vue_type_style_index_0_scoped_ee9caaa7_lang = "";
const _sfc_main = {
  __name: "home",
  setup(__props) {
    return { __sfc: true };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c;
  _vm._self._setupProxy;
  return _c("div", { staticClass: "home" }, [_vm._v("home")]);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "ee9caaa7",
  null,
  null
);
const home = __component__.exports;
export {
  home as default
};
